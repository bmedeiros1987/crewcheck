# CrewCheck v10.8.84 — Menu Premium Completo

- Menu inferior reestilizado sem azul claro de seleção.
- Tema claro e escuro com seleção premium neutra/clean.
- Speed dial global para Android/PWA com acesso a Chefe de Cabine, Checklist Médico, Importação, Saída, Diárias, Salário, Histórico e Ajuda.
- Menu da escala também recebe speed dial para não esconder recursos recém-criados.
- Versão interna atualizada para 10.8.84.
