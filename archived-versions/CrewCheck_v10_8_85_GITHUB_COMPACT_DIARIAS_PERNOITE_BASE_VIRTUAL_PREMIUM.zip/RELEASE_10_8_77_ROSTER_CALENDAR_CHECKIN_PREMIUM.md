# CrewCheck v10.8.77 — Roster Menu + Calendar Recreate + Check-in Premium

## Ajustes principais
- Menu da tela de escala padronizado com o menu global do app: Cockpit, Escala, iFlight, Saída e Conta.
- A tela de escala no modo app deixa de exibir o grid antigo Summary/Roster/Alerts.
- Escalas que já trazem programação do próximo mês agora exibem somente os dias efetivamente publicados, com data e mês corretos.
- O sistema não cria mais dias artificiais para completar o mês, evitando dia 31 em mês de 30 e evitando conflito ao subir a escala completa do mês seguinte.
- Exportação/sincronização Google Calendar agora apaga eventos CrewCheck antigos do período e recria tudo no novo padrão premium.
- Adicionado lembrete premium de Formulário de Check-in da escala para ASB/reserva e voo extra/PS com apresentação na base, exceto casos de treinamento.
- Exportação de calendário inclui evento transparente de Check-in com alarmes.
- Versão interna atualizada para 10.8.77 / Android versionCode 10877.
