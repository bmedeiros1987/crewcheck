# CrewCheck v10.8.81 — Chefe de Cabine Pro Premium

## Novidades
- Água por porcentagem nos tanques dianteiro/traseiro.
- Ocorrências manuais por tipo, horário e texto livre.
- Registro local de PDFs por data, número do voo e rota para facilitar busca.
- Exportar PDF e compartilhar pelo recurso nativo quando disponível.
- Passageiros opcionais: faixas aproximadas e campo de número exato.
- Métrica de consumo de água por passageiros e previsão local de água final quando o chefe esquecer a medição.
- Botão “Usar dados do voo” para preencher apresentação/decolagem/pouso/chegada com base na escala.
- Formulário interno para sugestões dos colegas.
- Assistente local mais completo para lembrar tarefas e montar texto para transcrição no sistema oficial.

## Privacidade
Os aprendizados de água e sugestões ficam salvos localmente no aparelho/navegador até o usuário exportar ou limpar dados.
