# CrewCheck v10.8.79 - Exportação Premium + Manuais

- PDF agora retorna nome do arquivo, tamanho aproximado e local sugerido de salvamento.
- Toast de exportação tem ação Abrir e mensagem clara de Downloads/Arquivos.
- Compartilhamento por WhatsApp/e-mail não envia mais link local quebrado: usa compartilhamento nativo com arquivo quando disponível ou orienta anexar o PDF salvo.
- Menu Ajuda ganhou Manual Completo em PDF e Guia de Funcionalidades para venda.
- Versão interna atualizada para 10.8.79 e Android 10879.
