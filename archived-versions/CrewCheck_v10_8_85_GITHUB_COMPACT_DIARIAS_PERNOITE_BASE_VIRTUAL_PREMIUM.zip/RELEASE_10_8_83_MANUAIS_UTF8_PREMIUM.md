# CrewCheck v10.8.83 - Manuais UTF-8 Premium

- Todos os manuais HTML/PDF foram revisados para UTF-8.
- Manual web corrigido com `meta charset="UTF-8"` e estrutura HTML válida.
- PDFs de manual completo e guia comercial recriados com fonte Unicode para preservar acentos, cedilha e símbolos.
- Textos de ajuda e suporte atualizados para a versão 10.8.83.
- Android atualizado para versionCode 10883 e versionName 10.8.83.
