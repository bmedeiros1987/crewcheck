# CrewCheck v10.8.71

- Hard fix 2: reforço definitivo para Reserva e acionamento operacional contarem deslocamento.
- Reforço visual dos pills dos cards no tema escuro.
