# CrewCheck v10.8.78 — Menu da Escala Padronizado

- Menu inferior da tela Minha Escala foi recriado copiando o padrão visual do Cockpit.
- Ícones, proporção, dock, espaçamento e estado ativo foram padronizados.
- A label da escala fica como “Escala”, evitando “Roster” na interface PT-BR.
- Mantém a versão interna atualizada para 10.8.78.
