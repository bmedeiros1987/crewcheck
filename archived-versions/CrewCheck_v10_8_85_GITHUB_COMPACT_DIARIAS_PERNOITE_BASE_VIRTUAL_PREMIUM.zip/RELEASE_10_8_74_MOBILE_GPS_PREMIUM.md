# CrewCheck v10.8.74 — Mobile GPS Premium + Escala Landscape Reliable

- Android passa a solicitar permissão de localização e notificações de forma proativa ao abrir o app.
- Web GPS ganhou fallback premium com `watchPosition`, alta precisão, cache local curto e mensagens claras quando o navegador bloqueia.
- Saída Inteligente passa a guardar amostras locais de GPS para melhorar repetição dos cálculos sem enviar histórico pessoal desnecessário.
- Escala no celular deitado força 1 card por linha, aumenta tipografia e melhora nitidez.
- Menu inferior padronizado: Cockpit, Escala, iFlight, Saída e Conta.
- Cards pequenos de rotina passam a usar chips escuros premium com bom contraste.
- Versionamento interno atualizado para 10.8.74 / versionCode 10874.
