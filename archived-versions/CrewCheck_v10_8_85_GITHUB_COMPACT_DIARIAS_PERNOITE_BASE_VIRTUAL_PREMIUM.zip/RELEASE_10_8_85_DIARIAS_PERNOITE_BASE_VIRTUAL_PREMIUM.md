# CrewCheck v10.8.85 — Diárias Premium: Pernoite, Base Virtual e Pernoite Dirigido

- Pernoite fora da base gera almoço e jantar quando cruza as janelas previstas, sem café e sem ceia em pernoite puro.
- Ceia permanece restrita a atividade efetiva: voo, reserva, treinamento ou tripulante extra a serviço, considerando apresentação/atividade na janela 00:00–01:00.
- Encerramento na base contratual não cria almoço/jantar no dia seguinte se não houver trabalho efetivo.
- Adicionado ajuste de Base Virtual: repouso/folga na base virtual não soma diárias automaticamente.
- Adicionado ajuste de Pernoite Dirigido como opção manual de revisão.
- Tela de Diárias ganhou card de regras pessoais e texto explicativo mais claro.
- Versão interna 10.8.85 / Android versionCode 10885.
