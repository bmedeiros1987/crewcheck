# CrewCheck v10.8.82 — Chefe de Cabine + Checklist Médico Premium

- Configuração de tanques ajustável pelo usuário: QTA/água potável e QTU/rejeitos, com quantidade de tanques por aeronave.
- Água inicial/final agora prioriza QTA/QTU, mantendo frente/traseiro quando aplicável.
- Formulário virtual de Ocorrência Médica - Checklist, inspirado no formulário físico enviado pelo usuário.
- Exportação PDF do checklist médico no padrão de formulário para anexar ao AQD ou enviar ao comandante/equipe médica/colegas.
- Botão de compartilhar PDF por sistema nativo quando disponível.
- Ajuda/manual web atualizado com instalação por PWA e atalho na tela inicial.
- Versão interna, Android versionCode e versionName atualizados para 10.8.82 / 10882.
