# CrewCheck v10.8.75 — iOS Ready

Esta versão adiciona preparação iOS com Capacitor, sem incluir a pasta `ios/` gerada para manter o pacote GitHub com menos de 100 arquivos.

## Caminho recomendado

1. Suba este ZIP no GitHub.
2. No Mac, clone o repositório.
3. Rode:

```bash
bash scripts/ios_gerar_no_mac_v10_8_75.sh
```

4. O Xcode abrirá o projeto iOS.
5. Em `Signing & Capabilities`, selecione sua equipe Apple Developer.
6. Faça `Product > Archive`.
7. Envie para TestFlight/App Store Connect.

## Identificação do app

- Bundle ID: `com.crewcheck.app`
- App Name: `CrewCheck`
- Version: `10.8.75`
- Build: `10875`

## Observação

Para publicar no TestFlight/App Store é necessário Xcode no macOS e uma conta Apple Developer com acesso a assinatura/distribuição.
