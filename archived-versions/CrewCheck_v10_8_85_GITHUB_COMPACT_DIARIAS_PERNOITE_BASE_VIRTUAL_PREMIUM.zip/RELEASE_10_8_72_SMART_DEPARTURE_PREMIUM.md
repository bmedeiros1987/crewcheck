# CrewCheck v10.8.72 — Saída Inteligente Premium e Configurações Visuais

## Ajustes
- Métrica de tempo para carro, transporte público e corrida por app recalibrada.
- Corrida por app agora considera chamada média de 8 minutos e pisos por distância/faixa de horário.
- Trecho urbano de cerca de 23 km deixa de cair em estimativa otimista de ~23 minutos em horário de pico.
- Sistema informa de forma simples se o dado vem de fonte real ou se é estimativa CrewCheck.
- Configurações dão feedback visual ao clicar e rolam para a tela escolhida.
- Usuário pode personalizar cores da escala e dos pequenos cards/pills de rotina.
- Cards de confiança, choque de horário e tipo de atividade usam fonte mais escura e cores customizáveis.
