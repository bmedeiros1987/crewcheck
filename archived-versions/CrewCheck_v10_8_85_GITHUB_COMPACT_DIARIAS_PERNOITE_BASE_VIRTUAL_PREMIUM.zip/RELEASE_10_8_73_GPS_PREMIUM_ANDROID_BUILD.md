# CrewCheck v10.8.73 — GPS Premium + Android Build Reliable

## Saída Inteligente / Localização
- Web: fallback premium de localização com GPS do navegador, watchPosition, cache local temporário e mensagem clara quando o navegador não entrega coordenadas.
- Android: mantém ponte nativa e reforça uso de GPS/última posição confiável.
- Aprendizado local: guarda pequenas amostras de posição somente no dispositivo para calibrar confiança de deslocamento, sem enviar histórico pessoal para terceiros.
- O painel indica de forma simples: “Dados reais” ou “Estimativa CrewCheck”.

## Android / GitHub Actions
- `versionCode` atualizado para 10873 e `versionName` para 10.8.73.
- Gradle/Android SDK mais reliable no workflow.
- Release não quebra mais quando secrets de assinatura não existirem.
- Gera APK debug e tenta gerar APK/AAB release; se houver keystore nos secrets, gera release assinado.
