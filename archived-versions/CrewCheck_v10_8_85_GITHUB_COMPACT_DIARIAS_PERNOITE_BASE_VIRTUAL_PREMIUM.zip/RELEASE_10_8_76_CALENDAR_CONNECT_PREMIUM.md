# CrewCheck v10.8.76 — Exportação de Calendário Premium

## Padrão visual de calendário
- Exportação passa a gerar um evento principal de pairing por jornada de voo, no formato `BSB-GRU-MCZ`.
- Cada perna também é exportada como evento separado: `BSB-GRU`, `GRU-MCZ`, etc.
- Cores aproximam a organização visual tipo Crew Lounge: pairing roxo, pernas lilás, extra/PS cinza, reserva/sobreaviso vermelho/laranja, folga verde.
- Sincronização via Google Calendar API passa a mapear as cores para `colorId`, melhorando a visualização no app Google Calendar.

## Mais informações dentro dos eventos
- Descrição com C/I e C/O, horários UTC/local, rota, aeronave, tripulação, chefe efetivo quando disponível e `#CREWCHECK`.
- Eventos de voo individual incluem origem/destino, horário local/UTC, aircraft e tipo de operação.
- ASB/HSB/treinamentos/folgas mantêm categorias e cores próprias.

## Versão
- App: 10.8.76
- Android versionCode: 10876
- iOS script: 10.8.76 / build 10876
