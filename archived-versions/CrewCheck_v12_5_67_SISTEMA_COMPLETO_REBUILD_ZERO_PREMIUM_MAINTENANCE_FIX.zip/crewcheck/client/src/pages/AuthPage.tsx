import { useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { useLocation } from 'wouter';
import {
  ArrowRight,
  BadgeCheck,
  CalendarDays,
  Cloud,
  Lock,
  Mail,
  MessageCircle,
  Eye,
  EyeOff,
  UserRound,
  Plane,
  PhoneCall,
  ShieldCheck,
  Sparkles,
  WifiOff,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { AuthClientError, confirmPasswordReset, getAuthConfig, login, register, resendVerification, requestPasswordReset, verifyEmail } from '@/lib/authClient';

type AuthMode = 'login' | 'register' | 'reset' | 'verify';
const APP_VERSION = '12.5.67';



const AUTH_FUNCTION_OPTIONS = [
  { value: '', label: 'Detectar automaticamente pela escala' },
  { value: 'CCM', label: 'CCM / Comissário(a)' },
  { value: 'Chefe de Cabine', label: 'Chefe de Cabine' },
  { value: 'Comandante', label: 'Comandante' },
  { value: 'FO', label: 'Copiloto / FO' },
  { value: 'Piloto', label: 'Piloto(a)' },
] as const;

function authRoleSelectionFromRank(rank?: string | null) {
  const clean = String(rank || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toUpperCase();
  if (/\b(CCM|CC|CCF|CMS|COMISS|CABIN|CHEFE|PUR|SENIOR)\b/.test(clean)) return 'cabin';
  if (/\b(PILOTO|PILOT|COMANDANTE|CMTE|CMT|CMD|CAPT|CAP|COPILOTO|CO PILOTO|CO-PILOTO|FO|F\/O|FIRST OFFICER|SIC|P1|P2)\b/.test(clean)) return 'pilot';
  return 'auto';
}

const AUTH_COUNTRY_PHONE_OPTIONS = [
  { iso: 'BR', name: 'Brasil', code: '+55', example: '61996071663' },
  { iso: 'US', name: 'Estados Unidos/Canadá', code: '+1', example: '3055550100' },
  { iso: 'GB', name: 'Reino Unido', code: '+44', example: '7860089214' },
  { iso: 'PT', name: 'Portugal', code: '+351', example: '912345678' },
  { iso: 'ES', name: 'Espanha', code: '+34', example: '612345678' },
  { iso: 'FR', name: 'França', code: '+33', example: '612345678' },
  { iso: 'DE', name: 'Alemanha', code: '+49', example: '15123456789' },
  { iso: 'AR', name: 'Argentina', code: '+54', example: '91123456789' },
  { iso: 'CL', name: 'Chile', code: '+56', example: '912345678' },
  { iso: 'UY', name: 'Uruguai', code: '+598', example: '91234567' },
  { iso: 'PY', name: 'Paraguai', code: '+595', example: '981123456' },
  { iso: 'PE', name: 'Peru', code: '+51', example: '912345678' },
  { iso: 'CO', name: 'Colômbia', code: '+57', example: '3001234567' },
  { iso: 'MX', name: 'México', code: '+52', example: '5512345678' },
] as const;

function authCountryByIso(iso?: string | null) {
  const clean = String(iso || '').toUpperCase();
  return AUTH_COUNTRY_PHONE_OPTIONS.find((item) => item.iso === clean) || AUTH_COUNTRY_PHONE_OPTIONS[0];
}

function normalizeAuthPhoneDigits(value?: string | null) {
  return String(value || '').replace(/\D+/g, '').slice(0, 18);
}

function composeAuthPhoneE164(countryCode?: string | null, local?: string | null) {
  const code = normalizeAuthPhoneDigits(countryCode || '+55').slice(0, 4) || '55';
  let digits = normalizeAuthPhoneDigits(local);
  if (digits.startsWith(code)) digits = digits.slice(code.length);
  return digits ? `+${code}${digits}` : '';
}

declare global {
  interface Window {
    turnstile?: {
      render: (container: HTMLElement | string, options: Record<string, unknown>) => string;
      reset: (widgetId?: string) => void;
      remove?: (widgetId: string) => void;
    };
  }
}

export default function AuthPage() {
  const [, setLocation] = useLocation();
  const [mode, setMode] = useState<AuthMode>('login');
  const [isLoading, setIsLoading] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [authConfig, setAuthConfig] = useState<{ captchaRequired: boolean; turnstileSiteKey?: string | null; emailVerificationRequired?: boolean } | null>(null);
  const [turnstileToken, setTurnstileToken] = useState<string | null>(null);
  const [pendingEmail, setPendingEmail] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [invalidFields, setInvalidFields] = useState<Set<string>>(new Set());
  const [resetCodeSent, setResetCodeSent] = useState(false);
  const [form, setForm] = useState({
    email: '',
    confirmEmail: '',
    firstName: '',
    lastName: '',
    password: '',
    confirmPassword: '',
    verificationCode: '',
    usageIntent: 'free',
    hasVirtualBase: 'no',
    virtualBase: '',
    telegramUsername: '',
    phoneCountryIso: 'BR',
    phoneCountryCode: '+55',
    phoneLocal: '',
    rank: '',
  });
  const captchaRef = useRef<HTMLDivElement | null>(null);
  const widgetIdRef = useRef<string | null>(null);
  const autoVerifyRanRef = useRef(false);

  const update = (key: keyof typeof form, value: string) => {
    setInvalidFields((current) => {
      if (!current.has(String(key))) return current;
      const next = new Set(current);
      next.delete(String(key));
      return next;
    });
    const cleaned = key === 'virtualBase'
      ? value.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 3)
      : key === 'telegramUsername'
        ? value.replace(/@+/g, '').replace(/[^A-Za-z0-9_]/g, '').slice(0, 32)
        : key === 'phoneLocal'
          ? normalizeAuthPhoneDigits(value)
          : key === 'rank'
            ? value.slice(0, 40)
            : key === 'phoneCountryIso'
            ? authCountryByIso(value).iso
            : value;
    setForm((prev) => ({ ...prev, [key]: cleaned }));
  };
  const isLatamCorporateEmail = form.email.trim().toLowerCase().endsWith('@latam.com');
  const verificationEmail = form.email || pendingEmail;

  useEffect(() => {
    getAuthConfig()
      .then((config) => setAuthConfig(config))
      .catch(() => setAuthConfig({ captchaRequired: false, turnstileSiteKey: null, emailVerificationRequired: true }));
  }, []);

  useEffect(() => {
    if (autoVerifyRanRef.current) return;
    const params = new URLSearchParams(window.location.search);
    const email = params.get('email') || '';
    const code = params.get('verify') || '';
    if (!email || !code) return;
    autoVerifyRanRef.current = true;
    setMode('verify');
    setPendingEmail(email);
    setForm((prev) => ({ ...prev, email, verificationCode: code }));
    setIsLoading(true);
    verifyEmail(email, code)
      .then(() => {
        toast.success('E-mail confirmado. Bem-vindo ao CrewCheck.');
        setLocation('/');
      })
      .catch((error) => {
        toast.error(error instanceof Error ? error.message : 'Não foi possível confirmar o e-mail.');
      })
      .finally(() => setIsLoading(false));
  }, [setLocation]);

  useEffect(() => {
    setTurnstileToken(null);
    if (mode !== 'register' || !authConfig?.turnstileSiteKey || !captchaRef.current) return;

    let cancelled = false;
    const renderWidget = () => {
      if (cancelled || !captchaRef.current || !window.turnstile || widgetIdRef.current) return;
      widgetIdRef.current = window.turnstile.render(captchaRef.current, {
        sitekey: authConfig.turnstileSiteKey,
        theme: 'auto',
        size: 'flexible',
        callback: (token: string) => setTurnstileToken(token),
        'expired-callback': () => setTurnstileToken(null),
        'error-callback': () => setTurnstileToken(null),
      });
    };

    if (!document.querySelector('script[src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit"]')) {
      const script = document.createElement('script');
      script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
      script.async = true;
      script.defer = true;
      script.onload = renderWidget;
      document.head.appendChild(script);
    }

    const timer = window.setInterval(renderWidget, 350);
    renderWidget();
    return () => {
      cancelled = true;
      window.clearInterval(timer);
      if (widgetIdRef.current && window.turnstile?.remove) {
        try { window.turnstile.remove(widgetIdRef.current); } catch {}
      }
      widgetIdRef.current = null;
      if (captchaRef.current) captchaRef.current.innerHTML = '';
    };
  }, [authConfig?.turnstileSiteKey, mode]);

  function changeMode(nextMode: AuthMode) {
    setMode(nextMode);
    if (nextMode !== 'reset') setResetCodeSent(false);
    setTurnstileToken(null);
    if (widgetIdRef.current && window.turnstile) {
      try { window.turnstile.reset(widgetIdRef.current); } catch {}
    }
  }


  function startDemoSession() {
    try {
      sessionStorage.setItem('crewcheck_demo_active', '1');
      localStorage.setItem('crewcheck_demo_mode_seen', '1');
      localStorage.setItem('crewcheck_demo_autoload', '1');
      localStorage.removeItem('crewcheck_auth_token');
      localStorage.removeItem('crewcheck_auth_user');
    } catch {}
    toast.info('Abrindo demonstração com dados fictícios. Nenhum dado pessoal será usado.');
    setLocation('/');
  }

  async function handleResend() {
    const email = verificationEmail.trim();
    if (!email) {
      toast.error('Informe o e-mail para reenviar o código.');
      return;
    }
    setIsResending(true);
    try {
      await resendVerification(email);
      toast.success('Se a conta estiver aguardando validação, enviaremos um novo código.');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Não foi possível reenviar o código.');
    } finally {
      setIsResending(false);
    }
  }

  function validateBeforeSubmit(): boolean {
    const missing = new Set<string>();
    const email = (form.email || pendingEmail).trim();
    const needsEmail = mode === 'reset' || mode === 'login' || mode === 'register' || mode === 'verify';
    const emailLooksValid = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);

    if (needsEmail && !email) missing.add('email');
    if (needsEmail && email && !emailLooksValid) {
      missing.add('email');
      setInvalidFields(missing);
      toast.error('E-mail inválido. Confira o endereço digitado.');
      return false;
    }

    if (mode === 'login') {
      if (!form.password.trim()) missing.add('password');
    }

    if (mode === 'reset' && (resetCodeSent || form.verificationCode.trim() || form.password.trim())) {
      if (!form.verificationCode.trim()) missing.add('verificationCode');
      if (!form.password.trim()) missing.add('password');
      if (!form.confirmPassword.trim()) missing.add('confirmPassword');
      if (form.password && form.confirmPassword && form.password !== form.confirmPassword) {
        missing.add('confirmPassword');
        setInvalidFields(missing);
        toast.error('As senhas não coincidem. Digite a mesma senha nos dois campos.');
        return false;
      }
    }

    if (mode === 'register') {
      if (!form.firstName.trim()) missing.add('firstName');
      if (!form.lastName.trim()) missing.add('lastName');
      if (!form.password.trim()) missing.add('password');
      if (!form.confirmPassword.trim()) missing.add('confirmPassword');
      if (form.password && form.confirmPassword && form.password !== form.confirmPassword) {
        missing.add('confirmPassword');
        setInvalidFields(missing);
        toast.error('As senhas não coincidem. Digite a mesma senha nos dois campos.');
        return false;
      }
      if (form.password && form.password.length < 6) {
        missing.add('password');
        setInvalidFields(missing);
        toast.error('A senha precisa ter pelo menos 6 caracteres.');
        return false;
      }
    }

    if (mode === 'verify' && !form.verificationCode.trim()) missing.add('verificationCode');

    if (missing.size) {
      setInvalidFields(missing);
      toast.error('Preencha os campos obrigatórios destacados.');
      return false;
    }

    setInvalidFields(new Set());
    return true;
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!validateBeforeSubmit()) return;
    setIsLoading(true);
    try {
      if (mode === 'reset') {
        if (!resetCodeSent && !form.verificationCode.trim() && !form.password.trim()) {
          await requestPasswordReset(form.email);
          setResetCodeSent(true);
          toast.success('Se o e-mail estiver cadastrado, enviaremos um código temporário para redefinir sua senha.');
          return;
        }
        await confirmPasswordReset({ email: form.email, code: form.verificationCode, password: form.password, confirmPassword: form.confirmPassword });
        toast.success('Senha redefinida. Entre com a nova senha.');
        setForm((prev) => ({ ...prev, password: '', confirmPassword: '', verificationCode: '' }));
        setResetCodeSent(false);
        changeMode('login');
        return;
      }
      if (mode === 'verify') {
        await verifyEmail(verificationEmail, form.verificationCode);
        toast.success('E-mail confirmado. Login realizado.');
        setLocation('/');
        return;
      }
      if (mode === 'register') {
        if (isLatamCorporateEmail) {
          throw new Error('Use um e-mail pessoal para criar sua conta CrewCheck. O e-mail corporativo @latam.com deve ser usado somente dentro do portal iFlight.');
        }
        if (authConfig?.captchaRequired && authConfig.turnstileSiteKey && !turnstileToken) {
          throw new Error('Confirme o captcha para concluir o cadastro.');
        }
        const firstName = form.firstName.trim().replace(/\s+/g, ' ');
        const lastName = form.lastName.trim().replace(/\s+/g, ' ');
        if (!firstName || !lastName) throw new Error('Informe nome e sobrenome para concluir o cadastro.');
        const phoneCountry = authCountryByIso(form.phoneCountryIso);
        const phoneLocal = normalizeAuthPhoneDigits(form.phoneLocal);
        const phoneE164 = composeAuthPhoneE164(phoneCountry.code, phoneLocal);
        const hasVirtualBase = form.hasVirtualBase === 'yes';
        const virtualBase = hasVirtualBase ? form.virtualBase.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 3) : '';
        if (hasVirtualBase && virtualBase.length < 2) throw new Error('Informe a sigla da base virtual. Ex.: SP, SAO, RIO, CGH ou GIG.');
        try {
          localStorage.setItem('crewcheck_profile_display_name', `${firstName} ${lastName}`);
          localStorage.setItem('crewcheck_profile_has_virtual_base', hasVirtualBase ? '1' : '0');
          localStorage.setItem('crewcheck_usage_intent', form.usageIntent || 'free');
          localStorage.setItem('crewcheck_profile_rank', form.rank || '');
          localStorage.setItem('crewcheck_profile_role_selection', authRoleSelectionFromRank(form.rank));
          if (authRoleSelectionFromRank(form.rank) !== 'auto') localStorage.setItem('crewcheck_role_selection', authRoleSelectionFromRank(form.rank));
          localStorage.setItem('crewcheck_profile_virtual_base_airport', virtualBase);
          localStorage.setItem('crewcheck_profile_telegram_username', form.telegramUsername.trim());
          localStorage.setItem('crewcheck_profile_phone_country_iso', phoneCountry.iso);
          localStorage.setItem('crewcheck_profile_phone_country_code', phoneCountry.code);
          localStorage.setItem('crewcheck_profile_phone_local', phoneLocal);
          localStorage.setItem('crewcheck_profile_phone_e164', phoneE164);
          const current = JSON.parse(localStorage.getItem('crewcheck_perdiem_settings') || '{}');
          localStorage.setItem('crewcheck_perdiem_settings', JSON.stringify({ ...current, baseVirtualEnabled: hasVirtualBase, baseVirtualAirport: virtualBase }));
        } catch {}
        const response = await register({
          email: form.email,
          firstName,
          lastName,
          name: `${firstName} ${lastName}`,
          password: form.password,
          confirmPassword: form.confirmPassword,
          role: 'crew',
          rank: form.rank || '',
          turnstileToken,
          hasVirtualBase,
          virtualBase,
          usageIntent: form.usageIntent || 'free',
          telegramUsername: form.telegramUsername.trim(),
          phoneCountryIso: phoneCountry.iso,
          phoneCountryCode: phoneCountry.code,
          phoneLocal,
          phoneE164,
        });
        if ('verificationRequired' in response && response.verificationRequired) {
          setPendingEmail(form.email);
          changeMode('verify');
          toast.success('Cadastro realizado com sucesso. Enviamos um e-mail de confirmação para você entrar com segurança.');
          return;
        }
        toast.success('Cadastro realizado com sucesso. E-mail confirmado e login liberado.');
      } else {
        await login(form.email, form.password);
        toast.success('Login realizado.');
      }
      setLocation('/');
    } catch (error) {
      if (error instanceof AuthClientError && error.code === 'EMAIL_NOT_VERIFIED') {
        setPendingEmail(form.email);
        changeMode('verify');
      }
      toast.error(error instanceof Error ? error.message : 'Não foi possível acessar.');
      if (widgetIdRef.current && window.turnstile) {
        try { window.turnstile.reset(widgetIdRef.current); } catch {}
        setTurnstileToken(null);
      }
    } finally {
      setIsLoading(false);
    }
  }

  const title = mode === 'register' ? 'Comece com segurança.' : mode === 'reset' ? 'Recupere o acesso.' : mode === 'verify' ? 'Confirme seu e-mail.' : 'Bem-vindo de volta.';
  const description = mode === 'register'
    ? 'Informe apenas nome, e-mail pessoal e senha. Telegram, concierge e telefone ficam nas configurações internas.'
    : mode === 'reset'
      ? resetCodeSent ? 'Digite o código temporário recebido por e-mail e defina uma nova senha definitiva.' : 'Informe seu e-mail cadastrado. Enviaremos um código temporário para redefinir a senha.'
      : mode === 'verify'
        ? 'Abra o botão de confirmação enviado por e-mail. O código manual fica reservado apenas para recuperação de senha.'
        : 'Entre para carregar sua escala e continuar de onde parou.';

  return (
    <div className="cc1265-auth-page cc1267-auth-from-scratch" data-version={APP_VERSION}>
      <div className="cc1265-wallpaper" aria-hidden="true" />

      <main className="cc1265-auth-main">
        <section className="cc1265-auth-brand">
          <div className="cc1265-logo"><Plane className="h-6 w-6" /></div>
          <div>
            <h1>CrewCheck</h1>
            <p>Roster Intelligence</p>
            <div className="cc1265-auth-badges"><span>Premium</span><b>Beta</b></div>
          </div>
        </section>

        <section className="cc1265-auth-card">
          <div className="cc1265-auth-tabs" role="tablist" aria-label="Tipo de acesso">
            <button type="button" role="tab" aria-selected={mode === 'login'} onClick={() => changeMode('login')} className={mode === 'login' ? 'is-active' : ''}>Entrar</button>
            <button type="button" role="tab" aria-selected={mode === 'register'} onClick={() => changeMode('register')} className={mode === 'register' ? 'is-active' : ''}>Criar cadastro</button>
          </div>

          <div className="cc1265-auth-title">
            <span>{mode === 'register' ? 'Cadastro com validação' : mode === 'reset' ? 'Senha provisória' : mode === 'verify' ? 'Confirmação obrigatória' : 'Acesso ao sistema'}</span>
            <h2>{title}</h2>
            <p>{description}</p>
          </div>

          <form onSubmit={submit} noValidate className="cc1265-auth-form">
            <Field icon={Mail} label={mode === 'register' ? 'E-mail pessoal *' : mode === 'verify' ? 'E-mail para confirmar *' : 'E-mail cadastrado *'} invalid={invalidFields.has('email')}>
              <input type="email" value={form.email || pendingEmail} onChange={(e) => update('email', e.target.value)} className={`field-input crewcheck-auth-input ${invalidFields.has('email') ? 'is-invalid' : ''} ${mode === 'register' && isLatamCorporateEmail ? 'is-invalid' : ''}`} placeholder={mode === 'register' ? 'tripulante@exemplo.com' : 'seu.email@exemplo.com'} aria-invalid={invalidFields.has('email')} />
            </Field>

            {mode === 'register' && (
              <div className="cc1265-auth-grid two">
                <Field icon={UserRound} label="Nome *" invalid={invalidFields.has('firstName')}>
                  <input value={form.firstName} onChange={(e) => update('firstName', e.target.value)} className={`field-input crewcheck-auth-input ${invalidFields.has('firstName') ? 'is-invalid' : ''}`} placeholder="Ana" autoComplete="given-name" aria-invalid={invalidFields.has('firstName')} />
                </Field>
                <Field icon={UserRound} label="Sobrenome *" invalid={invalidFields.has('lastName')}>
                  <input value={form.lastName} onChange={(e) => update('lastName', e.target.value)} className={`field-input crewcheck-auth-input ${invalidFields.has('lastName') ? 'is-invalid' : ''}`} placeholder="Silva" autoComplete="family-name" aria-invalid={invalidFields.has('lastName')} />
                </Field>
              </div>
            )}

            {mode === 'register' && (
              <Field icon={Plane} label="Função / regulamentação automática">
                <select value={form.rank} onChange={(e) => update('rank', e.target.value)} className="field-input crewcheck-auth-input">
                  {AUTH_FUNCTION_OPTIONS.map((option) => <option key={option.value || 'auto'} value={option.value}>{option.label}</option>)}
                </select>
                <p className="cc1265-auth-help">O CrewCheck usa essa função para aplicar ACT/RBAC de forma conservadora.</p>
              </Field>
            )}

            {mode === 'register' && isLatamCorporateEmail && (
              <div className="cc1265-auth-warning">
                Use e-mail pessoal. Não use e-mail corporativo para preservar privacidade e independência do app.
              </div>
            )}

            {mode !== 'verify' && (
              <Field icon={Lock} label="Senha *" invalid={invalidFields.has('password')}>
                <div className="cc1265-auth-password">
                  <input type={showPassword ? 'text' : 'password'} value={form.password} onChange={(e) => update('password', e.target.value)} className={`field-input crewcheck-auth-input ${invalidFields.has('password') ? 'is-invalid' : ''}`} placeholder="mínimo 6 caracteres" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} aria-invalid={invalidFields.has('password')} />
                  <button type="button" onClick={() => setShowPassword((v) => !v)} aria-label={showPassword ? 'Ocultar senha' : 'Mostrar senha'}>{showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button>
                </div>
              </Field>
            )}

            {mode === 'register' && (
              <Field icon={Lock} label="Confirmar senha *" invalid={invalidFields.has('confirmPassword')}>
                <div className="cc1265-auth-password">
                  <input type={showConfirmPassword ? 'text' : 'password'} value={form.confirmPassword} onChange={(e) => update('confirmPassword', e.target.value)} className={`field-input crewcheck-auth-input ${invalidFields.has('confirmPassword') ? 'is-invalid' : ''}`} placeholder="repita a senha" autoComplete="new-password" aria-invalid={invalidFields.has('confirmPassword')} />
                  <button type="button" onClick={() => setShowConfirmPassword((v) => !v)} aria-label={showConfirmPassword ? 'Ocultar confirmação' : 'Mostrar confirmação'}>{showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button>
                </div>
                {invalidFields.has('confirmPassword') && <p className="cc1265-auth-help error">As senhas não coincidem.</p>}
              </Field>
            )}

            {mode === 'register' && (
              <div className="cc1265-auth-choice-panel">
                <div>
                  <span>Base virtual</span>
                  <p>Opcional. Se marcar NÃO, nada será usado como base virtual.</p>
                </div>
                <div className="cc1265-auth-choice-row">
                  <button type="button" onClick={() => update('hasVirtualBase', 'yes')} className={form.hasVirtualBase === 'yes' ? 'is-selected' : ''}>SIM<small>tenho base virtual</small></button>
                  <button type="button" onClick={() => { setForm((prev) => ({ ...prev, hasVirtualBase: 'no', virtualBase: '' })); setInvalidFields((current) => { const next = new Set(current); next.delete('virtualBase'); return next; }); toast.success('Base virtual marcada como NÃO.'); }} className={form.hasVirtualBase !== 'yes' ? 'is-selected' : ''}>NÃO<small>não tenho</small></button>
                </div>
                {form.hasVirtualBase === 'yes' && <input value={form.virtualBase} onChange={(e) => update('virtualBase', e.target.value)} maxLength={3} className="field-input crewcheck-auth-input cc1265-auth-base-input" placeholder="SAO" />}
              </div>
            )}

            {mode === 'verify' && (
              <Field icon={ShieldCheck} label="Código recebido por e-mail *" invalid={invalidFields.has('verificationCode')}>
                <input inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={form.verificationCode} onChange={(e) => update('verificationCode', e.target.value.replace(/\D/g, '').slice(0, 6))} className={`field-input crewcheck-auth-input ${invalidFields.has('verificationCode') ? 'is-invalid' : ''}`} placeholder="000000" aria-invalid={invalidFields.has('verificationCode')} />
              </Field>
            )}

            {mode === 'register' && authConfig?.turnstileSiteKey && (
              <div className="cc1265-auth-captcha">
                <span><ShieldCheck className="h-3.5 w-3.5" /> Verificação anti-robô</span>
                <div ref={captchaRef} className="min-h-[65px] overflow-hidden rounded-xl" />
                {authConfig.captchaRequired && !turnstileToken && <p>Confirme o desafio para liberar o cadastro.</p>}
              </div>
            )}

            {mode === 'register' && authConfig?.captchaRequired && !authConfig.turnstileSiteKey && (
              <div className="cc1265-auth-warning">A verificação de segurança está temporariamente indisponível. Tente novamente em alguns minutos.</div>
            )}

            <Button disabled={isLoading} type="submit" className="cc1265-auth-submit">
              {isLoading ? 'Aguarde...' : mode === 'reset' ? (resetCodeSent ? 'Definir nova senha' : 'Enviar código temporário') : mode === 'register' ? 'Criar cadastro seguro' : mode === 'verify' ? 'Confirmar e entrar' : 'Entrar no CrewCheck'}
              <ArrowRight className="h-5 w-5" />
            </Button>

            {mode !== 'verify' && (
              <button type="button" onClick={startDemoSession} className="cc1265-auth-demo">
                <Sparkles className="h-4 w-4" /> Ver modo demonstração
              </button>
            )}
          </form>

          <div className="cc1265-auth-links">
            {mode === 'verify' ? <button type="button" disabled={isResending} onClick={handleResend}>{isResending ? 'Reenviando...' : 'Reenviar código'}</button> : mode !== 'reset' ? <button type="button" onClick={() => changeMode('reset')}>Esqueci minha senha</button> : <button type="button" onClick={() => changeMode('login')}>Voltar para entrar</button>}
            {mode === 'login' && <button type="button" onClick={() => changeMode('register')}>Criar conta</button>}
            {mode === 'verify' && <button type="button" onClick={() => changeMode('login')}>Voltar para login</button>}
          </div>
        </section>

        <div className="cc1265-auth-version"><ShieldCheck className="h-4 w-4" /> CREWCHECK V{APP_VERSION} · PREMIUM BETA</div>
      </main>
    </div>
  );
}

function Feature({ icon: Icon, title, text }: { icon: LucideIcon; title: string; text: string }) {
  return <div className="rounded-3xl border border-white/10 bg-white/[.07] p-4 backdrop-blur-xl"><Icon className="h-5 w-5 text-cyan-200" /><h3 className="mt-3 font-black">{title}</h3><p className="mt-1 text-sm leading-6 text-slate-300">{text}</p></div>;
}

function Field({ icon: Icon, label, children, invalid = false }: { icon: LucideIcon; label: string; children: ReactNode; invalid?: boolean }) {
  return <label className={`cc1265-auth-field ${invalid ? 'is-invalid' : ''}`}><span><Icon className="h-3.5 w-3.5" /> {label}</span>{children}</label>;
}
