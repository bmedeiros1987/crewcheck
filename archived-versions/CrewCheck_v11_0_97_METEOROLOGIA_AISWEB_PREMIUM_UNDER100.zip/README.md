# CrewCheck v11.0.97 — Meteorologia AISWEB Premium

Meteorologia Premium para pilotos/admin, com METAR/TAF, favoritos, glossário, integração Aviation Weather + AISWEB/DECEA, Concierge Telegram em texto/áudio estilo ATIS e alertas de condição operacional.

## Destaques

- Menu Meteorologia liberado para piloto e administrador nesta fase.
- Consulta METAR/TAF via proxy backend do Aviation Weather Center, respeitando cache/rate limit oficial.
- Integração AISWEB/DECEA como fonte aeronáutica brasileira complementar, com links oficiais e estrutura para chave da API.
- METAR da próxima programação só aparece no card quando a programação é do dia; para programação futura, mostra TAF e aviso de METAR disponível no dia.
- Hora do METAR/TAF exibida no card para validação.
- Semáforo meteorológico por aeródromo: verde, amarelo ou vermelho conforme visibilidade, teto, trovoada, chuva forte, CB e rajada.
- Limites de consulta meteorológica para usuários gratuitos, com bloqueio especial no Telegram.
- Favoritos de aeródromos e busca por ICAO/IATA.
- Exibição normal, traduzida ou ambas.
- Glossário METAR/TAF para download.
- Detecção de piora/sensibilidade: chuva forte, trovoada, cumulonimbus, teto baixo, visibilidade ruim, nevoeiro e rajada de vento.
- Concierge Telegram responde meteorologia por texto ou por áudio estilo ATIS quando a entrada for áudio.
- Para cabine, mantém aviso simplificado de piora meteorológica, sem excesso técnico.
- Produção Android mantém R8/ProGuard, shrinkResources e mapping.txt.

## Android

- versionName: 11.0.97
- versionCode: 11097


## Variáveis opcionais de meteorologia

```env
AVIATION_WEATHER_API_BASE=https://aviationweather.gov/api/data
CREWCHECK_WEATHER_USER_AGENT=CrewCheck-Premium-Meteorology/11.0.97 (support@crewcheck.app)
CREWCHECK_FREE_WEATHER_DAILY_LIMIT=6
CREWCHECK_FREE_TELEGRAM_WEATHER_DAILY_LIMIT=0
AISWEB_PUBLIC_AERODROME_BASE=https://aisweb.decea.mil.br/
AISWEB_API_KEY=
```

Observação: a API-AISWEB exige chave solicitada ao DECEA; sem chave, o CrewCheck mantém link/consulta pública e usa Aviation Weather como fonte METAR/TAF principal.
