# CrewCheck v11.1.80

Hotfix: leitura humana de escala AIMS, sem contaminação de folga/sobreaviso/pernoite e com separação de jornadas por descanso >= 12h.
