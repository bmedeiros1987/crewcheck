# CrewCheck v11.0.98 — Meteorologia ATIS Premium sem dados fictícios

Meteorologia Premium para pilotos/admin, com METAR/TAF, favoritos, glossário, integração Aviation Weather + AISWEB/DECEA, Concierge Telegram em texto/áudio e briefing em estilo ATIS sem gerar letra, pista ou procedimento fictício.

## Destaques

- Menu Meteorologia liberado para piloto e administrador nesta fase.
- Consulta METAR/TAF via proxy backend do Aviation Weather Center, respeitando cache/rate limit oficial.
- Exibição em formato normal, traduzido ou ambos.
- Áudio do Telegram em estilo ATIS, mas sem criar “informação Alfa/Bravo” quando a fonte oficial não fornece ATIS.
- O áudio usa o nome comum do aeródromo, exemplo: Aeroporto Internacional de Guarulhos, não alfabeto fonético para o nome do aeroporto.
- Pista em uso, versão/letra ATIS, procedimento, nível de transição e NOTAM só aparecem quando vierem de fonte oficial configurada; o CrewCheck não estima esses campos.
- METAR da próxima programação só aparece no card quando a programação é do dia; para programação futura, mostra TAF e aviso de METAR disponível no dia.
- Hora do METAR/TAF exibida no card para validação.
- Semáforo meteorológico por aeródromo: verde, amarelo ou vermelho conforme visibilidade, teto, trovoada, chuva forte, CB e rajada.
- Limites de consulta meteorológica para usuários gratuitos, com bloqueio especial no Telegram.
- Favoritos de aeródromos e busca por ICAO/IATA.
- Glossário METAR/TAF para download.
- Produção Android mantém R8/ProGuard, shrinkResources e mapping.txt.

## Android

- versionName: 11.0.98
- versionCode: 11098

## Variáveis opcionais de meteorologia

```env
AVIATION_WEATHER_API_BASE=https://aviationweather.gov/api/data
CREWCHECK_WEATHER_USER_AGENT=CrewCheck-Premium-Meteorology/11.0.98 (support@crewcheck.app)
CREWCHECK_FREE_WEATHER_DAILY_LIMIT=6
CREWCHECK_FREE_TELEGRAM_WEATHER_DAILY_LIMIT=0
AISWEB_PUBLIC_AERODROME_BASE=https://aisweb.decea.mil.br/
AISWEB_API_KEY=
```

Observação: Aviation Weather fornece METAR/TAF. Ele não fornece a versão/letra real do ATIS do aeródromo. Por segurança operacional, o CrewCheck não cria letra ATIS fictícia nem inventa pista em uso.
