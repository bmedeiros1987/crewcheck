# CrewCheck v10.8.139 — Cockpit com apresentação publicada

Correção pontual de lançamento:

- O card **Próxima Programação** no Cockpit agora usa o horário de **apresentação publicado na escala** quando disponível.
- A decolagem não sobrescreve mais o início visual do card principal.
- A decolagem permanece disponível nos detalhes do voo/radar.
- A Saída Inteligente mantém a regra própria para cálculo de deslocamento.

Android:
- versionName: `10.8.139`
- versionCode: `10934`
