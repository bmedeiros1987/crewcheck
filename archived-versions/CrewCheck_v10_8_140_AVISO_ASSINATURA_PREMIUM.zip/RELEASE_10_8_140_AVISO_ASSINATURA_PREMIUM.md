# CrewCheck v10.8.140 — Aviso curto antes da assinatura Premium

## Objetivo

Adicionar aviso curto e obrigatório na página de assinatura, sem publicar ainda o termo completo de limitação de responsabilidade enquanto ele será revisado por advogado.

## Alterações

- Página de assinatura agora exibe aviso claro de que o CrewCheck é ferramenta independente de apoio pessoal.
- Aviso informa que o CrewCheck não é aplicativo oficial de companhia aérea.
- Aviso informa que o CrewCheck não substitui a escala oficial nem canais oficiais da empresa.
- Aviso informa que dados podem estar incorretos, incompletos ou desatualizados.
- Modal de checkout exige ciência antes de criar a assinatura no Asaas.
- Backend bloqueia checkout se o aviso curto não for confirmado.
- Auditoria da criação de assinatura registra versão do aviso curto aceito.
- Termo completo não foi publicado nesta versão; fica aguardando revisão jurídica.

## Android

- versionName: `10.8.140`
- versionCode: `10935`

## Validação

```bash
node --check server.mjs
npm run check
npm run build
```
