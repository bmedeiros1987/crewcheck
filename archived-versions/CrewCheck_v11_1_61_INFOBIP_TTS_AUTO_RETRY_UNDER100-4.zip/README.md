# CrewCheck v11.1.61 — Infobip TTS Auto Retry

Correção para contas/rotas da Infobip que recusam `pt` ou `pt-BR` com `REJECTED_UNSUPPORTED_LANGUAGE`.

- O teste de ligação Premium tenta idiomas em sequência: `auto`, `pt-BR`, `pt` e `en`.
- Em `auto`, o backend não envia campo `language` nem `voice`, permitindo que a Infobip trate/detecte quando disponível.
- Se português continuar recusado, o app mostra diagnóstico real e pode validar a rota em inglês.
- Ligação continua exclusiva para Premium/Admin; gratuito continua no Telegram.
- Abertura Full HD, payload pequeno, CallMeBot fallback e ElevenLabs Admin preservados.

Variáveis recomendadas:

```env
INFOBIP_LANGUAGE=auto
INFOBIP_LANGUAGE_RETRY=auto,pt-BR,pt,en
INFOBIP_VOICE_NAME=
INFOBIP_VOICE_GENDER=
```
