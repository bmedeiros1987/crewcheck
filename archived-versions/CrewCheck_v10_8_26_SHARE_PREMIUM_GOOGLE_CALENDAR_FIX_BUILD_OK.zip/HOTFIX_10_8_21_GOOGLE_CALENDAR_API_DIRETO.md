# CrewCheck v10.8.21 — Google Calendar API Direto

- Restaura sincronização direta com Google Calendar pela API oficial.
- Usa Google Identity Services no front-end.
- Lê `VITE_GOOGLE_CLIENT_ID` e inclui fallback para o client ID autorizado informado.
- Lista calendários editáveis.
- Sincroniza escala sem duplicidade por período.
- Remove dependência obrigatória do link ICS para sincronização principal.
- Mantém Exportar ICS como alternativa manual.
- Atualiza Android para `versionCode 10821` e `versionName 10.8.21`.
