# Google Calendar direto via API no CrewCheck

A versão 10.8.22 voltou a usar a API oficial do Google Calendar.

## Render / Vercel

Configure antes do build:

```env
VITE_GOOGLE_CLIENT_ID=811142401548-da2kf1qmqn8629ik689oaf3acsa8c3ai.apps.googleusercontent.com
```

Também mantenha a Google Calendar API habilitada no projeto do Google Cloud e o domínio do CrewCheck em **Authorized JavaScript origins**.

## Como funciona

1. O usuário conecta a Conta Google pelo Google Identity Services.
2. O CrewCheck lista calendários editáveis.
3. Ao sincronizar a escala, o app remove os eventos CrewCheck do mesmo período e cria a escala atualizada.
4. A senha Google nunca passa pelo CrewCheck. O app recebe apenas token temporário de acesso concedido pelo Google.

## Escopos

- `https://www.googleapis.com/auth/calendar.events`
- `https://www.googleapis.com/auth/calendar.calendarlist.readonly`

## Anti-duplicidade

Os eventos recebem `extendedProperties.private` com:

- `crewcheck=true`
- `crewcheckPeriodKey=crewcheck:<tripulante>:<ano-mes>:<modo>`
- `crewcheckEventKey=<chave-estavel>`

Antes de sincronizar novamente, o CrewCheck remove somente os eventos do período marcado pelo próprio app e recria a escala atualizada.
