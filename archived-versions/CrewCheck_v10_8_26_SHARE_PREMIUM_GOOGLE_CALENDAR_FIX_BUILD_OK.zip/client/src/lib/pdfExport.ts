import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { CrewRoster, RosterDay } from './pdfParser';
import type { ComplianceResult, GymRecommendation } from './complianceEngine';

const MONTHS = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

export type PremiumReportScope = 'general' | 'roster' | 'irregularities' | 'routine' | 'metrics' | 'summary';

function reportScopeTitle(scope?: PremiumReportScope): string {
  switch (scope) {
    case 'roster': return 'Escala completa traduzida';
    case 'irregularities': return 'Conformidade e pontos de atenção traduzidos';
    case 'routine': return 'Rotina, descanso e recuperação';
    case 'metrics': return 'Métricas da escala explicadas';
    case 'summary': return 'Resumo geral da escala';
    default: return 'Apanhado geral CrewCheck';
  }
}

function reportScopeSubtitle(scope?: PremiumReportScope): string {
  switch (scope) {
    case 'roster': return 'Programações, voos, folgas, reservas e treinamentos em linguagem simples.';
    case 'irregularities': return 'Alertas explicados com foco em entendimento, não em termos técnicos.';
    case 'routine': return 'Sugestões de treino, estudo, descanso e recuperação sem choque com a escala.';
    case 'metrics': return 'Indicadores traduzidos para quem não é da aviação.';
    case 'summary': return 'Resumo compacto para família, suporte ou organização pessoal.';
    default: return 'Resumo completo, didático e compartilhável para pessoas fora da aviação.';
  }
}

function plain(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}



const IATA_CITY: Record<string, string> = {
  BSB: 'Brasília', GRU: 'Guarulhos/São Paulo', CGH: 'Congonhas/São Paulo', VCP: 'Viracopos/Campinas', SDU: 'Santos Dumont/Rio de Janeiro', GIG: 'Galeão/Rio de Janeiro',
  CNF: 'Confins/Belo Horizonte', PLU: 'Pampulha/Belo Horizonte', REC: 'Recife', FOR: 'Fortaleza', NAT: 'Natal', SSA: 'Salvador', POA: 'Porto Alegre', CWB: 'Curitiba',
  FLN: 'Florianópolis', MAO: 'Manaus', BEL: 'Belém', SLZ: 'São Luís', THE: 'Teresina', JPA: 'João Pessoa', MCZ: 'Maceió', AJU: 'Aracaju', VIX: 'Vitória',
  GYN: 'Goiânia', CGB: 'Cuiabá', CGR: 'Campo Grande', IGU: 'Foz do Iguaçu', LDB: 'Londrina', MGF: 'Maringá', RAO: 'Ribeirão Preto', UDI: 'Uberlândia',
  IOS: 'Ilhéus', BPS: 'Porto Seguro', NVT: 'Navegantes', JOI: 'Joinville', PMW: 'Palmas', PVH: 'Porto Velho', RBR: 'Rio Branco', BVB: 'Boa Vista', MCP: 'Macapá',
  MIA: 'Miami', LIS: 'Lisboa', EZE: 'Buenos Aires/Ezeiza', AEP: 'Buenos Aires/Aeroparque', SCL: 'Santiago', LIM: 'Lima', BOG: 'Bogotá', PTY: 'Cidade do Panamá'
};

const ROSTER_CODE_TRANSLATIONS: Record<string, string> = {
  DO: 'Folga', DR: 'Folga pedida', DOP: 'Folga após férias', FR: 'Férias', VC: 'Férias',
  HSB: 'Sobreaviso em casa', HSBE: 'Sobreaviso em casa extra', ASB: 'Reserva no aeroporto', RES: 'Reserva',
  CBF: 'Treinamento: combate ao fogo', EMER: 'Treinamento: emergências gerais', C32F: 'Treinamento/check A32F', CRM: 'Treinamento CRM', MT: 'Reunião/treinamento',
  PS: 'Voo extra/posicionamento', SB: 'Sobreaviso', DH: 'Deslocamento como passageiro', GT: 'Transporte terrestre'
};

function translateIata(value?: string): string {
  if (!value) return '-';
  return String(value).replace(/\b[A-Z]{3}\b/g, (code) => IATA_CITY[code] ? `${code} (${IATA_CITY[code]})` : code);
}

function friendlyRosterCode(code?: string, fallback?: string): string {
  const normalized = String(code || fallback || '').toUpperCase().trim();
  if (!normalized) return fallback || '-';
  const direct = ROSTER_CODE_TRANSLATIONS[normalized];
  if (direct) return `${direct} (${normalized})`;
  const matched = Object.keys(ROSTER_CODE_TRANSLATIONS).find((key) => normalized.includes(key));
  return matched ? `${ROSTER_CODE_TRANSLATIONS[matched]} (${normalized})` : normalized;
}

function dayFriendlyType(day: CrewRoster['days'][number]): string {
  const code = String(day.pairingCode || day.type || '').toUpperCase();
  if (day.legs?.length) return 'Voo';
  return friendlyRosterCode(code, day.type);
}

function familyFriendlyDayDetails(day: CrewRoster['days'][number]): string {
  if (day.legs?.length) {
    const routes = day.legs.map((leg) => `${translateIata(leg.origin)} → ${translateIata(leg.destination)}${leg.flightNumber ? ` · voo ${leg.flightNumber}` : ''}`);
    return routes.join(' | ');
  }
  const code = friendlyRosterCode(day.pairingCode || day.type, day.type);
  if (String(day.type).toUpperCase().includes('LAYOVER')) return `Pernoite/inativo${day.hotel ? ` · hotel ${day.hotel}` : ''}`;
  if (String(day.type).toUpperCase().includes('OFF')) return 'Dia sem programação de voo/trabalho: folga ou repouso.';
  return `${code}${day.dutyReport ? ` · início ${day.dutyReport}` : ''}${day.dutyDebrief ? ` · fim ${day.dutyDebrief}` : ''}`;
}

export function crewcheckPdfFileName(roster: CrewRoster): string {
  const safeName = String(roster.crewName || 'tripulante').replace(/[^a-zA-Z0-9_-]+/g, '_').slice(0, 30) || 'tripulante';
  return `CrewCheck_Escala_Traduzida_${MONTHS[roster.month - 1]}_${roster.year}_${safeName}.pdf`;
}

export function exportReport(
  roster: CrewRoster,
  compliance: ComplianceResult,
  gymRecommendations: GymRecommendation[],
  options: { autoSave?: boolean; familyFriendly?: boolean; scope?: PremiumReportScope; title?: string } = {}
): Blob {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  
  // Derive irregularities and warnings from alerts
  const irregularities = compliance.alerts.filter(a => a.severity === 'error');
  const warnings = compliance.alerts.filter(a => a.severity === 'warning');
  
  // ============================================================
  // HEADER
  // ============================================================
  doc.setFillColor(27, 42, 74); // #1B2A4A
  doc.rect(0, 0, pageWidth, 40, 'F');
  
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text('CrewCheck', 14, 18);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(options.familyFriendly ? reportScopeTitle(options.scope) : 'Relatorio de Conformidade de Escala', 14, 26);
  doc.text(options.familyFriendly ? reportScopeSubtitle(options.scope) : 'RBAC 117 - Lei 13.475/2017 - ACT aplicavel', 14, 33);
  
  // Date on right
  doc.setFontSize(9);
  const dateStr = `Gerado em ${new Date().toLocaleDateString('pt-BR')}`;
  doc.text(dateStr, pageWidth - 14, 33, { align: 'right' });
  
  // ============================================================
  // CREW INFO
  // ============================================================
  let y = 50;
  doc.setTextColor(27, 42, 74);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(`${MONTHS[roster.month - 1]} ${roster.year}`, 14, y);
  
  y += 8;
  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  doc.text(`${roster.crewName} - ${roster.rank} - Base ${roster.base}`, 14, y);
  y += 7;
  doc.setFontSize(9);
  doc.text(`ACT: ${compliance.legalProfile.actName} | Funcao: ${compliance.legalProfile.roleLabel} / ${compliance.legalProfile.functionLabel}`, 14, y);
  y += 5;
  doc.text(`Limite voo: ${compliance.legalProfile.flightLimit28Days}h/28d e ${compliance.legalProfile.flightLimit365Days}h/365d | Equipamento: ${compliance.legalProfile.aircraftGroupLabel}`, 14, y);

  if (options.familyFriendly) {
    y += 9;
    doc.setFillColor(236, 248, 255);
    doc.roundedRect(14, y, pageWidth - 28, 25, 3, 3, 'F');
    doc.setTextColor(27, 42, 74);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('Como ler este PDF', 18, y + 7);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    const explain = 'Este arquivo traduz a escala para linguagem simples. Codigos aparecem por extenso, com a sigla entre parenteses. Aeroportos aparecem com cidade/nome sempre que conhecido. Confira sempre a escala oficial da empresa.';
    doc.text(doc.splitTextToSize(explain, pageWidth - 40), 18, y + 13);
    y += 30;
  }
  
  // ============================================================
  // SCORE SUMMARY
  // ============================================================
  y += 12;
  doc.setFillColor(245, 245, 245);
  doc.roundedRect(14, y, pageWidth - 28, 20, 3, 3, 'F');
  
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(27, 42, 74);
  
  const scoreX = 30;
  const irregX = 80;
  const alertX = 130;
  
  doc.text(`Score: ${compliance.score}`, scoreX, y + 13);
  
  const irregColor = irregularities.length > 0 ? [211, 47, 47] : [46, 125, 50];
  doc.setTextColor(irregColor[0], irregColor[1], irregColor[2]);
  doc.text(`Irregularidades: ${irregularities.length}`, irregX, y + 13);
  
  const alertColor = warnings.length > 0 ? [245, 124, 0] : [46, 125, 50];
  doc.setTextColor(alertColor[0], alertColor[1], alertColor[2]);
  doc.text(`Alertas: ${warnings.length}`, alertX, y + 13);
  
  // ============================================================
  // IRREGULARITIES
  // ============================================================
  y += 30;
  if (irregularities.length > 0) {
    doc.setTextColor(211, 47, 47);
    doc.setFontSize(13);
    doc.setFont('helvetica', 'bold');
    doc.text(`IRREGULARIDADES (${irregularities.length})`, 14, y);
    y += 4;
    
    const irregData = irregularities.map(item => [
      item.title,
      item.description,
      item.legalReference || '-'
    ]);
    
    autoTable(doc, {
      startY: y,
      head: [['Problema', 'Descricao', 'Base Legal']],
      body: irregData,
      theme: 'striped',
      headStyles: { fillColor: [211, 47, 47], fontSize: 9 },
      bodyStyles: { fontSize: 8 },
      columnStyles: {
        0: { cellWidth: 45, fontStyle: 'bold' },
        1: { cellWidth: 80 },
        2: { cellWidth: 45 }
      },
      margin: { left: 14, right: 14 }
    });
    
    y = (doc as any).lastAutoTable.finalY + 10;
  }
  
  // ============================================================
  // WARNINGS
  // ============================================================
  if (warnings.length > 0) {
    if (y > 240) { doc.addPage(); y = 20; }
    
    doc.setTextColor(245, 124, 0);
    doc.setFontSize(13);
    doc.setFont('helvetica', 'bold');
    doc.text(`PONTOS DE ATENCAO (${warnings.length})`, 14, y);
    y += 4;
    
    const warnData = warnings.map(item => [
      item.title,
      item.description,
      item.legalReference || '-'
    ]);
    
    autoTable(doc, {
      startY: y,
      head: [['Ponto', 'Descricao', 'Base Legal']],
      body: warnData,
      theme: 'striped',
      headStyles: { fillColor: [245, 124, 0], fontSize: 9 },
      bodyStyles: { fontSize: 8 },
      columnStyles: {
        0: { cellWidth: 45, fontStyle: 'bold' },
        1: { cellWidth: 80 },
        2: { cellWidth: 45 }
      },
      margin: { left: 14, right: 14 }
    });
    
    y = (doc as any).lastAutoTable.finalY + 10;
  }
  
  // If no irregularities and no warnings
  if (irregularities.length === 0 && warnings.length === 0) {
    doc.setTextColor(46, 125, 50);
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('ESCALA CONFORME - Nenhuma irregularidade encontrada.', 14, y);
    y += 15;
  }
  
  // ============================================================
  // METRICS
  // ============================================================
  if (y > 220) { doc.addPage(); y = 20; }
  
  doc.setTextColor(27, 42, 74);
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text(options.familyFriendly ? 'RESUMO DIDATICO' : 'METRICAS', 14, y);
  y += 4;
  
  const metricsData = [
    ['Horas de voo (tempo voando)', `${compliance.metrics.totalFlightHours.toFixed(0)}h`, `${compliance.legalProfile.flightLimit28Days}h/28d`, compliance.legalProfile.actName],
    ['Horas de trabalho / jornada', `${compliance.metrics.totalDutyHours.toFixed(0)}h`, '176h (max)', 'Art. 41 - Lei 13.475'],
    ['Folgas no mês', `${compliance.metrics.totalDaysOff} dias`, `${compliance.metrics.minDaysOffRequired} parametro / 9 atencao`, compliance.legalProfile.actName],
    ['Sobreavisos / reservas', `${compliance.metrics.totalStandby}`, `${compliance.metrics.maxStandbyMonth} max`, compliance.legalProfile.actName],
    ['Operações na madrugada', `${compliance.metrics.nightOperations}`, `${compliance.metrics.maxNightOps168h} por 168h`, compliance.legalProfile.actName],
    ['Folgas em fim de semana', `${compliance.metrics.weekendPairs} dia(s)`, '2 (min)', 'Art. 51 - Lei 13.475'],
  ];
  
  autoTable(doc, {
    startY: y,
    head: [['Metrica', 'Valor', 'Limite', 'Base Legal']],
    body: metricsData,
    theme: 'striped',
    headStyles: { fillColor: [27, 42, 74], fontSize: 9 },
    bodyStyles: { fontSize: 9 },
    margin: { left: 14, right: 14 }
  });
  
  y = (doc as any).lastAutoTable.finalY + 10;
  
  // ============================================================
  // TIMELINE
  // ============================================================
  doc.addPage();
  y = 20;
  
  doc.setTextColor(27, 42, 74);
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text(options.familyFriendly ? 'ESCALA TRADUZIDA' : 'TIMELINE DA ESCALA', 14, y);
  y += 4;
  
  const timelineData = roster.days.map(day => {
    const details = options.familyFriendly ? familyFriendlyDayDetails(day) : (() => {
      if (day.legs && day.legs.length > 0) return day.legs.map(l => `${l.origin}-${l.destination}`).join(', ');
      if (['HSB', 'HSBE'].includes(String(day.type).toUpperCase())) return `Sobreaviso ${day.dutyReport || ''} - ${day.dutyDebrief || ''}`;
      if (['ASB'].includes(String(day.type).toUpperCase())) return `Reserva aeroportuária ${day.dutyReport || ''} - ${day.dutyDebrief || ''}`;
      if (day.type === 'LAYOVER') return `Inativo/pernoite ${day.hotel || ''}`.trim();
      if (day.type === 'OFF') return 'Extensão de descanso/repouso';
      return '';
    })();
    return [
      day.date,
      day.dayOfWeek,
      options.familyFriendly ? dayFriendlyType(day) : day.type,
      day.dutyReport || '-',
      day.dutyDebrief || '-',
      day.dutyHours ? `${day.dutyHours.toFixed(1)}h` : '-',
      details
    ];
  });
  
  autoTable(doc, {
    startY: y,
    head: [[options.familyFriendly ? 'Data' : 'Data', 'Dia', options.familyFriendly ? 'Programação' : 'Tipo', 'Início', 'Fim', 'Jornada', options.familyFriendly ? 'Explicação para familiares' : 'Detalhes']],
    body: timelineData,
    theme: 'striped',
    headStyles: { fillColor: [27, 42, 74], fontSize: 8 },
    bodyStyles: { fontSize: 7 },
    columnStyles: {
      0: { cellWidth: 20 },
      1: { cellWidth: 12 },
      2: { cellWidth: options.familyFriendly ? 34 : 15 },
      3: { cellWidth: 14 },
      4: { cellWidth: 15 },
      5: { cellWidth: 17 },
      6: { cellWidth: 'auto' }
    },
    margin: { left: 14, right: 14 }
  });
  
  // ============================================================
  // GYM RECOMMENDATIONS
  // ============================================================
  doc.addPage();
  y = 20;
  
  doc.setTextColor(27, 42, 74);
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text(options.familyFriendly ? 'ROTINA SUGERIDA E RECUPERACAO' : 'PLANEJAMENTO DE ACADEMIA', 14, y);
  y += 4;
  
  const gymData = gymRecommendations.map(rec => {
    const status = rec.availability === 'ideal' ? 'IDEAL' : 
                   rec.availability === 'good' ? 'BOM' : 
                   rec.availability === 'moderate' ? 'MODERADO' : 'LIMITADO';
    return [
      rec.date,
      rec.dayType,
      status,
      rec.suggestedTime || `${rec.startTime}-${rec.endTime}`,
      rec.suggestedDuration,
      rec.reason
    ];
  });
  
  autoTable(doc, {
    startY: y,
    head: [['Data', 'Dia', 'Janela', 'Horário', 'Duração', 'Explicação']],
    body: gymData,
    theme: 'striped',
    headStyles: { fillColor: [27, 42, 74], fontSize: 8 },
    bodyStyles: { fontSize: 7 },
    columnStyles: {
      0: { cellWidth: 20 },
      1: { cellWidth: 12 },
      2: { cellWidth: 20 },
      3: { cellWidth: 28 },
      4: { cellWidth: 18 },
      5: { cellWidth: 'auto' }
    },
    margin: { left: 14, right: 14 },
    didParseCell: (data: any) => {
      if (data.section === 'body' && data.column.index === 2) {
        const cellText = data.cell.raw as string;
        if (cellText.includes('IDEAL') || cellText.includes('BOM')) {
          data.cell.styles.textColor = [46, 125, 50];
          data.cell.styles.fontStyle = 'bold';
        } else if (cellText.includes('MODERADO')) {
          data.cell.styles.textColor = [245, 124, 0];
          data.cell.styles.fontStyle = 'bold';
        } else {
          data.cell.styles.textColor = [211, 47, 47];
          data.cell.styles.fontStyle = 'bold';
        }
      }
    }
  });
  
  // ============================================================
  // FOOTER on all pages
  // ============================================================
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
    doc.setFont('helvetica', 'normal');
    doc.text(
      options.familyFriendly ? `CrewCheck - Relatorio traduzido - Pagina ${i}/${totalPages}` : `CrewCheck - Analise de Conformidade - Pagina ${i}/${totalPages}`,
      pageWidth / 2,
      doc.internal.pageSize.getHeight() - 8,
      { align: 'center' }
    );
  }
  
  const blob = doc.output('blob');
  if (options.autoSave !== false) {
    doc.save(crewcheckPdfFileName(roster));
  }
  return blob;
}


export function buildHumanFriendlyShareText(roster: CrewRoster, compliance: ComplianceResult, scope: PremiumReportScope = 'general'): string {
  const month = MONTHS[roster.month - 1] || String(roster.month);
  const days = roster.days || [];
  const flights = days.filter((day) => day.legs?.length).length;
  const offDays = days.filter((day) => /^(DO|DR|OFF|FR|VC|DOP)$/i.test(String(day.type || day.pairingCode || ''))).length;
  const standby = days.filter((day) => /^(HSB|HSBE|ASB|RES)$/i.test(String(day.type || day.pairingCode || ''))).length;
  const alerts = compliance.alerts.filter((item) => item.severity === 'error' || item.severity === 'warning').length;
  const nextItems = days.slice(0, 8).map((day) => humanFriendlyDayLine(day)).filter(Boolean).join('\n');
  const intro = `${reportScopeTitle(scope)}\n${plain(roster.crewName || 'Tripulante')} · ${month}/${roster.year} · Base ${roster.base || '-'}\n`;
  const summary = `Resumo: ${flights} dia(s) com voo, ${offDays} folga(s), ${standby} reserva/sobreaviso(s), ${alerts} alerta(s) para revisão.\n`;
  const note = 'Observação: este resumo foi traduzido pelo CrewCheck para facilitar o entendimento de familiares e pessoas fora da aviação. A escala oficial da empresa continua sendo a referência.';
  return [intro, summary, nextItems ? `\nPrincipais programações:\n${nextItems}` : '', `\n${note}`].join('').trim();
}

function humanFriendlyDayLine(day: RosterDay): string {
  const date = day.date || '';
  const start = day.dutyReport || (day as any).reportTime || '';
  const end = day.dutyDebrief || (day as any).endTime || '';
  const time = start || end ? ` · ${start || '?'}–${end || '?'}` : '';
  if (day.legs?.length) {
    const route = day.legs.map((leg) => `${translateIata(leg.origin)} → ${translateIata(leg.destination)}${leg.flightNumber ? ` (${leg.flightNumber})` : ''}`).join(' / ');
    return `${date}${time} · Voo: ${route}`;
  }
  return `${date}${time} · ${dayFriendlyType(day)}`;
}
