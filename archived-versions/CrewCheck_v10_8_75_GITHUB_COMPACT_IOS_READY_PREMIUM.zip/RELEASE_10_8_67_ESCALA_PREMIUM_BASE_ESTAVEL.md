# CrewCheck v10.8.67 — Escala Premium sobre a base estável v10.8.63

Esta versão foi refeita usando como base o ZIP v10.8.63 que estava funcionando, para não quebrar o carregamento da última escala nem a importação de uma nova escala.

## Mantido da base estável

- Abertura da última escala carregada.
- Fluxo de escolher/importar PDF no navegador, Android/WebView e Render.
- Escala/Cockpit exibindo o horário publicado, sem inventar apresentação artificial.
- Saída Inteligente separada do horário exibido na escala.

## Atualizações adicionadas

- AIMS: quando o primeiro voo traz dois horários antes da rota, o primeiro é Apresentação e o segundo é Decolagem.
- Ticket: campo explícito “Apresentação” continua como fonte principal.
- CrewRoster/iFlight: `PS`, `[extra]` e `Extra` identificam voo extra/passageiro.
- Voo extra: cinza, símbolo de passageiro e status `Extra · Passageiro (PS)`.
- Exportação: voo extra também sai em cinza e com marcação de passageiro.
- Saída Inteligente: considera apenas voo, reserva fora de casa, reunião e treinamento presencial; ignora folga, férias, descanso, EAD e sobreaviso.
- Comparação local da escala do mesmo mês registra adicionados, removidos, alterados e duplicidades ignoradas.

## Validação sugerida

```bash
npm install
npm run validate:10867
npm run check
npm run build
node --check server.mjs
```
