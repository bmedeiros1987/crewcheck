# CrewCheck v10.8.69

- Reserva conta como deslocamento.
- Acionamento dentro de sobreaviso para reserva/voo passa a contar deslocamento.
- Cards de rotina com contraste premium reforçado no modo escuro.
