# CrewCheck v10.8.70

- Hard fix: Reserva não pode aparecer como sem deslocamento.
- Hard fix: acionamento operacional dentro de sobreaviso volta a contar deslocamento.
- Pills dos cards de rotina ficaram mais claras e legíveis no tema escuro.
