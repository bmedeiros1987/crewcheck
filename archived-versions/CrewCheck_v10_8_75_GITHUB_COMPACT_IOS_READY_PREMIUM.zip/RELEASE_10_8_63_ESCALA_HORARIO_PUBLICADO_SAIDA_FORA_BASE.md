# CrewCheck v10.8.63 — Escala com Horário Publicado + Saída Fora de Base

Correção de confiança solicitada:

- A tela de Escala/Cockpit não inventa apresentação 1h antes da decolagem.
- Se a escala trouxe apresentação, ela é exibida.
- Se a escala não trouxe apresentação, a escala mostra o horário visível/publicado, normalmente a decolagem.
- A regra operacional de 1h antes fica exclusiva da Saída Inteligente quando o voo inicia fora da base e não há apresentação publicada confiável.
- O cálculo de hora de sair usa `smartDepartureTargetIso`, separado do horário exibido na escala.
- Parser local também remove fallback antigo de apresentação sintética de 45 minutos antes.

Validação: `npm run check`, `npm run build`, `node scripts/validate-v10.8.63.mjs`, `node --check server.mjs`.
