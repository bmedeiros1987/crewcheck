# CrewCheck v10.8.68 — Próxima Programação Premium + Escala por Voo

## Principais ajustes
- Próxima programação agora considera a programação subsequente mais próxima da escala.
- Eventos sem deslocamento de casa (folga, sobreaviso, férias e afins) aparecem sem contagem regressiva e sem cálculo de deslocamento.
- Eventos com deslocamento (voo, reserva, reunião, CRM e similares) continuam com destaque operacional.
- Escala do mesmo dia agora gera **um card por voo/perna**, facilitando leitura operacional e identificação do tempo de solo.
- Subtítulo de cada voo mostra apresentação/decolagem, chegada e janela de solo quando houver perna subsequente.
- Card de Próxima Programação foi refinado para mostrar apenas informações relevantes e um CTA de **Mais informações**.
- Mini cards e pills receberam contraste reforçado, especialmente no tema escuro.
- Visual geral refinado para um resultado mais premium, minimalista e legível.

## Build
```bash
npm ci
npm run build
node server.mjs
```
