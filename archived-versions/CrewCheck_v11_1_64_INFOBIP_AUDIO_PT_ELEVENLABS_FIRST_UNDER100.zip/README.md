# CrewCheck v11.1.64 — Infobip áudio português ElevenLabs first

Correção da ligação premium quando a Infobip aceitava a chamada, mas usava voz americana lendo texto em português.

- Prioriza TTS brasileiro antes de qualquer modo automático.
- Testa combinações pt-BR/pt com vozes brasileiras comuns: Camila, Vitoria e Ricardo.
- Evita usar `auto` como primeira tentativa, porque isso pode cair em voz americana.
- Se precisar cair em `auto` ou `en`, usa texto em inglês para não ficar voz americana lendo português.
- Mantém gratuito apenas no Telegram e ligação somente para Premium/Admin.
- Mantém abertura Full HD, payload pequeno, diagnóstico Infobip e fallback CallMeBot.

Variáveis recomendadas no Render:

```env
INFOBIP_LANGUAGE=pt-BR
INFOBIP_LANGUAGE_RETRY=pt-BR,pt,auto,en
INFOBIP_VOICE_RETRY=Camila,Vitoria,Ricardo,
INFOBIP_VOICE_NAME=Camila
INFOBIP_VOICE_GENDER=female
CREWCHECK_INFOBIP_PORTUGUESE_FIRST=true
CREWCHECK_INFOBIP_AUTO_USE_ENGLISH_FALLBACK=true
```
