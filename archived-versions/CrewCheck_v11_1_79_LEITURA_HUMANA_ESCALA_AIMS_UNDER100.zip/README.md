CrewCheck v11.1.79 - Leitura Humana de Escala AIMS

Hotfix premium para estabilizar leitura de escala:
- Folga/DO/OFF/DR não ganha programação por contaminação visual.
- Voo, reserva, sobreaviso e treinamento têm prioridade sobre marcador de folga quando aparecem no mesmo bloco oficial.
- Sobreaviso/HSB e reserva/ASB não herdam DO/OFF de outro dia.
- Continuação operacional entre pernas virando meia-noite não gera alerta falso de repouso/pernoite <12h.
- Corrige ReferenceError antigo em aimsDayQualityScore.
- Mantém Radar SSA/HST, Infobip v3 + ElevenLabs MP3 voice id Qrdut83w0Cr152Yb4Xn3, moedas e Regulamentação pernas 1..5.
