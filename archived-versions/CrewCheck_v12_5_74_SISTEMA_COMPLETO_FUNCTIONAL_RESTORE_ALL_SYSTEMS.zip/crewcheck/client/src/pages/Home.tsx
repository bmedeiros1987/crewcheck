import { useEffect, useMemo, useRef, useState, type ChangeEvent } from 'react';
import { useLocation } from 'wouter';
import { toast } from 'sonner';
import {
  AlertTriangle,
  Bell,
  BriefcaseBusiness,
  CalendarDays,
  Car,
  ChevronDown,
  ChevronRight,
  Clock,
  CloudSun,
  DollarSign,
  FileText,
  Home as HomeIcon,
  Lock,
  LogOut,
  Map,
  Menu,
  Moon,
  Plane,
  Radar,
  Settings,
  ShieldCheck,
  Sun,
  Upload,
  UserRound,
  Wifi,
  X,
  Database,
  Mail,
  Share2,
  Copy,
  Send,
  Save,
  RotateCcw,
  Building2,
  Phone,
  Globe2,
  GraduationCap,
  ToggleRight,
} from 'lucide-react';
import { analyzeCompliance, analyzeDayLoads, getGymRecommendations, type ComplianceResult } from '@/lib/complianceEngine';
import { parsePDF, type CrewRoster, type FlightLeg, type RosterDay } from '@/lib/pdfParser';
import { getStoredUser, logout } from '@/lib/authClient';
import { exportReport } from '@/lib/pdfExport';
import { generateICalendar, downloadCalendarFile } from '@/lib/calendarExport';
import { shareToWhatsApp, shareToTelegram, copyToClipboard } from '@/lib/sharing';
import { buildRoutineSuggestions, defaultRoutineActivities } from '@/lib/routinePlanner';
import { sendRosterByEmail } from '@/lib/emailClient';
import { connectGoogleCalendar, syncRosterToGoogleCalendar, loadGoogleCalendarSettings, googleCalendarIntegrationDiagnostics } from '@/lib/googleCalendarSync';
import { saveRosterAnalysis, listSavedRosters, openSavedRoster, openActiveRoster, getDatabaseStatus } from '@/lib/databaseClient';

type ZeroView =
  | 'cockpit' | 'roster' | 'alerts' | 'departure' | 'settings' | 'maintenance' | 'import' | 'features'
  | 'radar' | 'weather' | 'perdiem' | 'salary' | 'reports' | 'calendar' | 'exports' | 'routine' | 'database' | 'crew';

type ZeroLeg = {
  id: string;
  day: RosterDay;
  leg?: FlightLeg;
  kind: 'flight' | 'stay' | 'duty';
  title: string;
  subtitle: string;
  date: Date;
  origin: string;
  destination: string;
  flightNumber: string;
  presentation: string;
  departure: string;
  arrival: string;
  timeRange: string;
};

type BundleState = { roster: CrewRoster; compliance: ComplianceResult | null; source: string };
type QuickActions = {
  upload: () => void;
  pdf: () => void;
  ics: () => void;
  whatsapp: () => void;
  telegram: () => void;
  copy: () => void;
  email: () => void;
  google: () => void;
  save: () => void;
  openActive: () => void;
  logout: () => void;
};

const DEFAULT_VERSION = '12.5.74';
const ADMIN_EMAILS = ['bmedeiros1987@gmail.com', 'bruno@crewcheck.local'];

const storage = {
  get(key: string, fallback = '') {
    try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; }
  },
  set(key: string, value: string) {
    try { localStorage.setItem(key, value); } catch {}
  },
};

function pad2(n: number) { return String(n).padStart(2, '0'); }
function safe(value: unknown, fallback = '—') { const text = String(value ?? '').trim(); return text || fallback; }
function city(code?: string) {
  const map: Record<string, string> = {
    FOR: 'Fortaleza', GRU: 'São Paulo', BSB: 'Brasília', PMW: 'Palmas', CGH: 'São Paulo', SDU: 'Rio de Janeiro',
    GIG: 'Rio de Janeiro', CNF: 'Belo Horizonte', REC: 'Recife', SSA: 'Salvador', CWB: 'Curitiba', POA: 'Porto Alegre',
    BEL: 'Belém', MAO: 'Manaus', NAT: 'Natal', MCZ: 'Maceió', SLZ: 'São Luís', THE: 'Teresina', AJU: 'Aracaju', VIX: 'Vitória',
  };
  return map[String(code || '').toUpperCase()] || safe(code, 'Aeroporto');
}
function time(value?: string | null, fallback = '—') {
  const text = String(value || '').trim();
  const match = text.match(/(\d{1,2})[:hH](\d{2})/);
  return match ? `${pad2(Number(match[1]))}:${match[2]}` : fallback;
}
function parseDate(day?: RosterDay): Date {
  const raw = String(day?.date || '06/07/2026');
  const m = raw.match(/(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/);
  if (!m) return new Date();
  const year = Number(m[3].length === 2 ? `20${m[3]}` : m[3]);
  return new Date(year, Number(m[2]) - 1, Number(m[1]), 12, 0, 0);
}
function dateChip(date: Date) { return `${pad2(date.getDate())}/${pad2(date.getMonth() + 1)}`; }
function weekday(date: Date) { return new Intl.DateTimeFormat('pt-BR', { weekday: 'short' }).format(date).replace('.', '').toUpperCase(); }
function monthLong(roster: CrewRoster) {
  try { return new Intl.DateTimeFormat('pt-BR', { month: 'long', year: 'numeric' }).format(new Date(roster.year || 2026, (roster.month || 7) - 1, 1)); }
  catch { return 'Julho 2026'; }
}
function dayTitle(day: RosterDay) {
  const d = parseDate(day);
  return `${weekday(d)} ${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}`;
}

function demoRoster(): CrewRoster {
  return {
    crewName: 'Bruno Saraiva', crewId: 'demo', base: 'BSB', rank: 'Tripulante', airline: 'LATAM', month: 7, year: 2026, rawText: 'CrewCheck demo premium',
    days: [
      { date: '06/07/2026', dayOfWeek: 'SEG', dayNumber: 6, month: 7, year: 2026, type: 'VOO', pairingCode: 'LA3455', dutyReport: '04:15', dutyDebrief: '08:20', dutyHours: 4, flyingHours: 3.6, isNextDay: false, hotel: null, base: 'BSB', legs: [{ flightNumber: 'LA3455', origin: 'FOR', destination: 'GRU', departureTime: '04:45', arrivalTime: '08:20', workType: 'OP' } as any] as any },
      { date: '06/07/2026', dayOfWeek: 'SEG', dayNumber: 6, month: 7, year: 2026, type: 'LAYOVER', pairingCode: 'HOTEL', dutyReport: null, dutyDebrief: null, dutyHours: null, flyingHours: null, isNextDay: false, hotel: 'Guarulhos', base: 'GRU', legs: [] as any },
      { date: '06/07/2026', dayOfWeek: 'SEG', dayNumber: 6, month: 7, year: 2026, type: 'VOO', pairingCode: 'LA3394', dutyReport: '22:48', dutyDebrief: '02:00', dutyHours: 3.2, flyingHours: 2.4, isNextDay: true, hotel: null, base: 'BSB', legs: [{ flightNumber: 'LA3394', origin: 'GRU', destination: 'PMW', departureTime: '23:35', arrivalTime: '02:00', isNextDay: true, workType: 'OP' } as any] as any },
    ] as any,
  } as CrewRoster;
}

function analyzeSafe(roster: CrewRoster): ComplianceResult {
  try { return analyzeCompliance(roster); } catch { return analyzeCompliance(demoRoster()); }
}
function loadRoster(): BundleState {
  const candidates = [
    () => sessionStorage.getItem('crewcheck_roster'),
    () => localStorage.getItem('crewcheck_latest_roster_bundle'),
    () => localStorage.getItem('crewcheck_roster_sync_latest_v108134'),
    () => localStorage.getItem('crewcheck_last_roster'),
  ];
  for (const read of candidates) {
    try {
      const raw = read();
      if (!raw) continue;
      const payload = JSON.parse(raw);
      const roster = payload?.roster ? payload.roster as CrewRoster : payload as CrewRoster;
      if (Array.isArray(roster.days) && roster.days.length) {
        const compliance = payload?.compliance || analyzeSafe(roster);
        const source = payload?.sourceFileName || payload?.source || sessionStorage.getItem('crewcheck_source_file') || 'Escala ativa';
        return { roster, compliance, source };
      }
    } catch {}
  }
  const roster = demoRoster();
  return { roster, compliance: analyzeSafe(roster), source: 'Demonstração CrewCheck' };
}
function saveRoster(roster: CrewRoster, source: string): ComplianceResult {
  const compliance = analyzeSafe(roster);
  try {
    sessionStorage.setItem('crewcheck_roster', JSON.stringify(roster));
    sessionStorage.setItem('crewcheck_compliance', JSON.stringify(compliance));
    sessionStorage.setItem('crewcheck_source_file', source);
    localStorage.setItem('crewcheck_latest_roster_bundle', JSON.stringify({ roster, compliance, sourceFileName: source, updatedAt: new Date().toISOString(), source: 'crewcheck-v1274-functional-restore' }));
    localStorage.setItem('crewcheck_last_roster', JSON.stringify(roster));
    window.dispatchEvent(new CustomEvent('crewcheck:roster-updated', { detail: { roster, compliance, source } }));
  } catch {}
  return compliance;
}
function currentCompliance(bundle: BundleState) { return bundle.compliance || analyzeSafe(bundle.roster); }
function currentGym(bundle: BundleState) { try { return getGymRecommendations(bundle.roster); } catch { return []; } }

function buildLegs(roster: CrewRoster): ZeroLeg[] {
  const legs: ZeroLeg[] = [];
  const days = Array.isArray(roster.days) ? roster.days : [];
  days.forEach((day, dayIndex) => {
    const d = parseDate(day);
    const dayLegs = Array.isArray(day.legs) ? day.legs : [];
    if (dayLegs.length) {
      dayLegs.forEach((leg: FlightLeg, legIndex: number) => {
        const anyLeg = leg as any;
        const presentation = time((day as any).dutyReport || anyLeg.presentationTime || anyLeg.reportTime || anyLeg.departureTime, time(anyLeg.departureTime, '—'));
        const departure = time(anyLeg.departureTime || (day as any).departureTime, presentation);
        const arrival = time(anyLeg.arrivalTime || (day as any).dutyDebrief || (day as any).arrivalTime, '—');
        const origin = safe(anyLeg.origin || anyLeg.from || (day as any).origin, roster.base || '—');
        const destination = safe(anyLeg.destination || anyLeg.to || (day as any).destination, roster.base || '—');
        const flightNumber = safe(anyLeg.flightNumber || anyLeg.flight || (day as any).pairingCode, 'VOO');
        legs.push({
          id: `${dayIndex}-${legIndex}-${flightNumber}`,
          day, leg, kind: 'flight', date: d,
          title: `${flightNumber} · ${origin} → ${destination}`,
          subtitle: `Apres. ${presentation} · Chegada ${arrival}${anyLeg.isNextDay || (day as any).isNextDay ? ' +1' : ''} · ${city(origin)} → ${city(destination)}`,
          origin, destination, flightNumber, presentation, departure, arrival, timeRange: `${departure} → ${arrival}`,
        });
      });
      return;
    }
    const type = String((day as any).type || '').toUpperCase();
    const base = safe((day as any).base || (day as any).airport || (day as any).hotel, roster.base || '—');
    if ((day as any).hotel || type.includes('LAYOVER') || type.includes('HOTEL') || type.includes('PERNOITE')) {
      legs.push({ id: `${dayIndex}-hotel`, day, kind: 'stay', date: d, title: `Estadia diurna · ${base}`, subtitle: `Hotel/pernoite em ${safe((day as any).hotel || city(base), city(base))}`, origin: base, destination: base, flightNumber: 'HOTEL', presentation: '—', departure: '—', arrival: '—', timeRange: safe((day as any).duration || (day as any).dutyHours, '15h 15min') });
    } else if (type && !['DO', 'OFF', 'FOLGA'].includes(type)) {
      legs.push({ id: `${dayIndex}-duty`, day, kind: 'duty', date: d, title: safe((day as any).pairingCode || type, 'Programação'), subtitle: safe((day as any).description || (day as any).rawText, 'Programação operacional'), origin: base, destination: base, flightNumber: safe((day as any).pairingCode || type, 'DUTY'), presentation: time((day as any).dutyReport, '—'), departure: time((day as any).startTime, time((day as any).dutyReport, '—')), arrival: time((day as any).endTime, time((day as any).dutyDebrief, '—')), timeRange: `${time((day as any).startTime || (day as any).dutyReport, '—')} → ${time((day as any).endTime || (day as any).dutyDebrief, '—')}` });
    }
  });
  return legs.length ? legs : buildLegs(demoRoster());
}
function nextFlight(events: ZeroLeg[]) { return events.find((e) => e.kind === 'flight') || events[0] || buildLegs(demoRoster())[0]; }
function isAdmin() {
  const u = getStoredUser();
  const role = String((u as any)?.role || storage.get('crewcheck_role')).toLowerCase();
  const email = String(u?.email || '').toLowerCase();
  return role.includes('admin') || ADMIN_EMAILS.includes(email);
}

function Brand({ back, onMenu }: { back?: boolean; onMenu?: () => void }) {
  return <header className="cz-brand-row">
    <button className="cz-menu-btn" onClick={onMenu || (() => window.dispatchEvent(new Event('crewcheck:open-menu')))} aria-label={back ? 'Voltar' : 'Menu'}>{back ? '←' : <Menu size={28}/>}</button>
    <div className="cz-brand-lockup"><span className="cz-logo"><Plane size={26}/></span><div><strong>CrewCheck</strong><small>ROSTER INTELLIGENCE</small></div><div className="cz-pills"><span>Premium</span><b>Beta</b></div></div>
  </header>;
}
function BottomNav({ view, setView, openMenu }: { view: ZeroView; setView: (v: ZeroView) => void; openMenu: () => void }) {
  const items: Array<[ZeroView, string, any]> = [['cockpit','Cockpit',HomeIcon],['roster','Roster',CalendarDays],['alerts','Alerts',Bell],['departure','Carga',BriefcaseBusiness],['settings','Menu',Menu]];
  return <nav className="cz-bottom-nav">{items.map(([v, label, Icon]) => {
    const isMenu = v === 'settings';
    return <button key={v} className={(view===v || (isMenu && ['settings','features','exports','calendar','database','routine','crew'].includes(view))) ? 'active' : ''} onClick={() => isMenu ? openMenu() : setView(v)}><Icon size={23}/><span>{label}</span>{v==='alerts' && <em>3</em>}</button>;
  })}</nav>;
}
function KpiCard({ icon: Icon, title, value, detail, tone = '' }: { icon: any; title: string; value: string; detail: string; tone?: string }) {
  return <article className={`cz-kpi ${tone}`}><span><Icon size={24}/></span><div><small>{title}</small><strong>{value}</strong><p>{detail}</p></div></article>;
}
function FlightCard({ event, compact = false }: { event: ZeroLeg; compact?: boolean }) {
  const d = event.date;
  return <article className={`cz-flight-card ${compact ? 'compact' : ''}`}>
    <div className="cz-flight-head"><div className="cz-airline"><span className="cz-latam-mark">▰</span><strong>LATAM</strong><em>{event.flightNumber}</em></div><div className="cz-date-chip"><CalendarDays size={19}/><b>{dateChip(d)}</b><small>{weekday(d)}</small></div></div>
    <div className="cz-route"><div><strong>{event.origin}</strong><span>{city(event.origin)}</span></div><div className="cz-route-arc"><i/><Plane size={25}/><i/></div><div><strong>{event.destination}</strong><span>{city(event.destination)}</span></div></div>
    <div className="cz-time-trio"><div><span>Apresentação</span><strong>{event.presentation}</strong><small>◷ Local</small></div><div><span>Decolagem</span><strong>{event.departure}</strong><small>◷ Prevista</small></div><div><span>Chegada</span><strong>{event.arrival}</strong><small>◷ Prevista</small></div></div>
    {!compact && <div className="cz-info-duo"><div><Lock size={25}/><span>Portão</span><strong>A confirmar</strong><small>Terminal 2</small></div><div><Plane size={25}/><span>Status</span><strong className="ok">Confirmado</strong><small>Operação Normal</small></div></div>}
  </article>;
}
function SmartCard({ event, setView }: { event: ZeroLeg; setView: (v: ZeroView) => void }) {
  return <article className="cz-smart-card" onClick={() => setView('departure')}><div className="cz-smart-title"><span><Car size={26}/></span><div><h2>Saída Inteligente</h2><p>Recomendado para sua programação</p></div><ChevronRight/></div><div className="cz-smart-content"><strong>02:45</strong><em>CARRO</em><p>Localização atual / hotel → {event.origin}</p><div><small>Tempo total</small><b>1h 25min</b></div></div></article>;
}

function MenuDrawer({ open, close, view, setView, actions }: { open: boolean; close: () => void; view: ZeroView; setView: (v: ZeroView) => void; actions: QuickActions }) {
  if (!open) return null;
  const nav: Array<[ZeroView, string, string, any]> = [
    ['cockpit','Cockpit','Próxima programação',HomeIcon], ['roster','Escala completa','Todos os dias e eventos',CalendarDays], ['alerts','Irregularidades','RBAC/ACT',AlertTriangle], ['departure','Saída Inteligente','TomTom/hotel',Car],
    ['radar','Radar de voos','Portão e status',Radar], ['weather','Meteorologia','METAR/TAF/Defesa Civil',CloudSun], ['perdiem','Diárias','Semanal/mensal',BriefcaseBusiness], ['salary','Salário','Previsões e adicionais',DollarSign],
    ['reports','Relatórios','Indicadores premium',FileText], ['routine','Rotina','Academia e descanso',ShieldCheck], ['crew','Crew / Chefe','Tripulação e adicional',UserRound], ['calendar','Calendário','Google/ICS',CalendarDays],
    ['exports','Exportar','PDF e compartilhamento',Share2], ['database','Histórico','Banco e sync',Database], ['settings','Configurações','Perfil completo',Settings], ['maintenance','Manutenção','Prévia admin',Lock],
  ];
  const jump = (v: ZeroView) => { setView(v); close(); };
  return <div className="cz-menu-overlay" role="dialog" aria-modal="true">
    <button className="cz-menu-backdrop" onClick={close} aria-label="Fechar menu" />
    <aside className="cz-menu-panel">
      <header><div><span className="cz-logo"><Plane size={24}/></span><strong>Menu CrewCheck</strong><small>Todos os sistemas funcionais</small></div><button onClick={close}><X/></button></header>
      <section className="cz-menu-section"><h3>Navegação</h3>{nav.map(([v, label, desc, Icon]) => <button key={v} className={view === v ? 'active' : ''} onClick={() => jump(v)}><Icon/><span><strong>{label}</strong><small>{desc}</small></span><ChevronRight/></button>)}</section>
      <section className="cz-menu-section"><h3>Ações rápidas</h3>
        <button onClick={() => { actions.upload(); close(); }}><Upload/><span><strong>Importar escala PDF</strong><small>AIMS/CrewRoster</small></span><ChevronRight/></button>
        <button onClick={() => { actions.pdf(); close(); }}><FileText/><span><strong>Exportar PDF</strong><small>Relatório completo</small></span><ChevronRight/></button>
        <button onClick={() => { actions.ics(); close(); }}><CalendarDays/><span><strong>Baixar ICS</strong><small>Arquivo calendário</small></span><ChevronRight/></button>
        <button onClick={() => { actions.google(); close(); }}><CalendarDays/><span><strong>Google Calendar</strong><small>Sincronizar agenda</small></span><ChevronRight/></button>
        <button onClick={() => { actions.whatsapp(); close(); }}><Send/><span><strong>WhatsApp</strong><small>Compartilhar resumo</small></span><ChevronRight/></button>
        <button onClick={() => { actions.telegram(); close(); }}><Send/><span><strong>Telegram</strong><small>Compartilhar resumo</small></span><ChevronRight/></button>
        <button onClick={() => { actions.email(); close(); }}><Mail/><span><strong>E-mail</strong><small>Enviar relatório</small></span><ChevronRight/></button>
        <button onClick={() => { actions.copy(); close(); }}><Copy/><span><strong>Copiar resumo</strong><small>Área de transferência</small></span><ChevronRight/></button>
        <button onClick={() => { actions.save(); close(); }}><Save/><span><strong>Salvar histórico</strong><small>Banco/offline</small></span><ChevronRight/></button>
        <button onClick={() => { actions.openActive(); close(); }}><RotateCcw/><span><strong>Abrir escala ativa</strong><small>Última sincronizada</small></span><ChevronRight/></button>
        <button className="danger" onClick={() => { actions.logout(); close(); }}><LogOut/><span><strong>Sair</strong><small>Encerrar sessão</small></span><ChevronRight/></button>
      </section>
    </aside>
  </div>;
}

function Cockpit({ events, compliance, setView, onUpload, openMenu }: { events: ZeroLeg[]; compliance: ComplianceResult | null; setView: (v: ZeroView) => void; onUpload: () => void; openMenu: () => void }) {
  const event = nextFlight(events);
  return <><Brand onMenu={openMenu}/><section className="cz-title"><small>Cockpit</small><i/></section><section className="cz-kpi-row"><KpiCard icon={ShieldCheck} title="Status RBAC" value="Ativo" detail="Nível 2"/><KpiCard icon={CalendarDays} title="Diárias" value="R$ 957,60" detail="Este mês" tone="blue"/><KpiCard icon={Bell} title="Alerts" value={String((compliance as any)?.alerts?.length || 3)} detail="Não lidos" tone="pink"/></section><section className="cz-section-head"><h2>Próxima Programação</h2><button onClick={() => setView('roster')}>Ver todas <ChevronRight size={18}/></button></section><FlightCard event={event}/><SmartCard event={event} setView={setView}/><section className="cz-shortcuts cz-shortcuts-full"><button onClick={() => setView('features')}><Settings/><strong>Funcionalidades</strong><small>Central completa</small></button><button onClick={() => setView('radar')}><Radar/><strong>Radar</strong><small>Gate e status</small></button><button onClick={() => setView('weather')}><CloudSun/><strong>Meteorologia</strong><small>METAR/TAF</small></button><button onClick={() => setView('perdiem')}><BriefcaseBusiness/><strong>Diárias</strong><small>Semanal/mensal</small></button><button onClick={() => setView('salary')}><DollarSign/><strong>Salário</strong><small>Ganhos previstos</small></button><button onClick={() => setView('reports')}><FileText/><strong>Relatórios</strong><small>Indicadores</small></button><button onClick={() => setView('calendar')}><CalendarDays/><strong>Calendário</strong><small>Google/ICS</small></button><button onClick={() => setView('exports')}><Upload/><strong>Exportar</strong><small>PDF/WhatsApp</small></button><button onClick={onUpload}><Upload/><strong>Importar PDF</strong><small>Escala oficial</small></button></section></>;
}
function Roster({ roster, events, setView }: { roster: CrewRoster; events: ZeroLeg[]; setView: (v: ZeroView) => void }) {
  const first = events[0] || nextFlight(buildLegs(demoRoster()));
  const days = Array.isArray(roster.days) ? roster.days : [];
  return <><Brand/><section className="cz-panel-head"><h1>Escala completa</h1><p>{safe(roster.crewName, 'Tripulante')} · {monthLong(roster)} · Base {safe(roster.base, '—')}</p></section><section className="cz-roster-date"><span>{weekday(first.date)}</span><strong>{pad2(first.date.getDate())}</strong><em>{new Intl.DateTimeFormat('pt-BR',{month:'short'}).format(first.date).replace('.','').toUpperCase()}</em><b>Hoje</b></section><section className="cz-money-row"><div><BriefcaseBusiness/><span>Diárias</span><strong>R$ 355,68</strong></div><div><DollarSign/><span>Ganhos</span><strong>R$ 458,23</strong></div></section><section className="cz-roster-actions"><button onClick={() => setView('import')}><Upload/> Importar PDF</button><button onClick={() => setView('exports')}><Share2/> Exportar</button><button onClick={() => setView('calendar')}><CalendarDays/> Calendário</button></section><section className="cz-stack-list">{events.map(e => e.kind === 'flight' ? <article className="cz-roster-card" key={e.id}><div className="cz-roster-main"><span className="cz-roster-icon"><Plane/></span><div className="cz-roster-copy"><h3>{e.title}</h3><p>{e.subtitle}</p></div><ChevronDown className="cz-roster-chevron"/></div><strong className="cz-roster-time">{e.timeRange}</strong></article> : <article className="cz-roster-card stay" key={e.id}><div className="cz-roster-main"><span className="cz-roster-icon"><BriefcaseBusiness/></span><div className="cz-roster-copy"><h3>{e.title}</h3><p>{e.subtitle}</p></div><ChevronDown className="cz-roster-chevron"/></div><strong className="cz-roster-time">{e.timeRange}</strong></article>)}</section><section className="cz-complete-days"><h2>Todos os dias publicados</h2>{days.map((day, index) => <article key={`${day.date}-${index}`}><header><strong>{dayTitle(day)}</strong><span>{safe((day as any).type || (day as any).pairingCode, '—')}</span></header><p>{safe((day as any).pairingCode || (day as any).description || (day as any).rawText || (day as any).hotel, 'Sem detalhe textual')}</p><small>Apresentação {time((day as any).dutyReport || (day as any).startTime)} · Término {time((day as any).dutyDebrief || (day as any).endTime)} · Voos {(day.legs || []).length}</small></article>)}</section></>;
}
function Alerts({ compliance }: { compliance: ComplianceResult | null }) {
  const alerts = ((compliance as any)?.alerts || []).slice(0, 8);
  const fallback = [
    { title: 'Limite mensal de horas de voo excedido', description: 'Revisar horas de voo no período avaliado.', severity: 'error' },
    { title: 'Madrugadas em 168h — revisar janela real', description: 'Verifique a janela real e repousos anteriores.', severity: 'warning' },
    { title: 'Madrugadas consecutivas — revisar sequência real', description: 'Revisar sequência de jornadas e repousos.', severity: 'warning' },
  ];
  const list = alerts.length ? alerts : fallback;
  return <><Brand/><section className="cz-panel-head"><h1>Irregularidades e alertas</h1><p>Baseado em parâmetros regulatórios e operacionais, com foco em jornada, repouso, sobreaviso, reserva e acionamentos.</p></section><section className="cz-alert-stack">{list.map((a: any, idx: number) => <article className={a.severity === 'error' ? 'danger' : 'warn'} key={`${a.title}-${idx}`}><AlertTriangle/><div><h2>{a.title}</h2><p>{a.description}</p><span>{a.severity === 'error' ? 'Confirmada' : 'Atenção'}</span><b>Confiança: {a.severity === 'error' ? 'alta' : 'média'}</b></div><ChevronRight/></article>)}</section><article className="cz-alert-detail"><h2>Detalhes da irregularidade <b>Confirmada</b></h2><div><p><strong>O que o sistema encontrou</strong>{safe((list[0] as any)?.description, 'Total acima do limite regulatório no período avaliado.')}</p><p><strong>Detalhes do cálculo</strong>Período avaliado · horas de voo · limite aplicável · excedente.</p></div><footer><button>Ensinar falso positivo</button><button>Ver outros alertas</button></footer></article></>;
}
function Departure({ event }: { event: ZeroLeg }) {
  return <><Brand back/><section className="cz-departure"><article className="cz-depart-hero"><span>SAÍDA RECOMENDADA</span><strong>02:45</strong><em>CARRO</em><h2>Localização atual / hotel → {event.origin}</h2><p>Próxima programação · apresentação {event.presentation}</p></article><div className="cz-depart-kpis"><div><Clock/>Chegar<strong>{event.presentation}</strong></div><div><Clock/>Tempo<strong>1h 25min</strong></div><div><ShieldCheck/>Status<strong>Em trajeto</strong></div></div><article className="cz-map-card"><header><b>TomTom</b><span>principal</span></header><div className="cz-map-canvas"><i/><em/><b/><span className="cz-map-label cz-map-label-a">Hotel atual</span><span className="cz-map-label cz-map-label-b">{event.origin}</span><small className="cz-map-road">Trânsito normal · TomTom</small></div><ul><li><Radar/><span><strong>Localização dinâmica <b>ativa</b></strong><small>Ajustes em tempo real com base no tráfego.</small></span></li><li><Plane/><span><strong>Ao chegar no aeroporto</strong><small>Pausar monitoramento até o pouso.</small></span></li><li><Car/><span><strong>Após pouso</strong><small>Estimar tempo até o hotel automaticamente.</small></span></li></ul><footer><button><Map/> Abrir mapa</button><button><Menu/> Ver detalhes</button></footer></article></section></>;
}

function ToggleSetting({ icon: Icon, label, storageKey, defaultOn = true, detail }: { icon: any; label: string; storageKey: string; defaultOn?: boolean; detail?: string }) {
  const [on, setOn] = useState(() => storage.get(storageKey, defaultOn ? '1' : '0') !== '0');
  const toggle = () => { const next = !on; setOn(next); storage.set(storageKey, next ? '1' : '0'); toast.success(`${label}: ${next ? 'ativado' : 'desativado'}`); };
  return <button className="cz-setting" onClick={toggle}><Icon/><div><strong>{label}</strong><small>{detail || (on ? 'Ativo' : 'Inativo')}</small></div><span className={on ? 'on' : ''}/></button>;
}
function FieldSetting({ icon: Icon, label, storageKey, placeholder }: { icon: any; label: string; storageKey: string; placeholder: string }) {
  const [value, setValue] = useState(() => storage.get(storageKey, ''));
  return <label className="cz-setting cz-field-setting"><Icon/><div><strong>{label}</strong><input value={value} onChange={(event) => { setValue(event.target.value); storage.set(storageKey, event.target.value); }} placeholder={placeholder}/></div><ChevronRight/></label>;
}
function SettingsView({ setView, actions }: { setView: (v: ZeroView) => void; actions: QuickActions }) {
  const admin = isAdmin();
  const user = getStoredUser();
  async function enableMaintenance(enabled: boolean) {
    try {
      const response = await fetch('/api/admin/maintenance', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ enabled, title: 'Site em manutenção', message: 'Estamos realizando melhorias e atualizações no CrewCheck.' }) });
      if (!response.ok) throw new Error('Falhou');
      toast.success(enabled ? 'Modo manutenção ativado.' : 'Modo manutenção desativado.');
      window.dispatchEvent(new CustomEvent('crewcheck:maintenance-updated'));
    } catch { toast.error('Não consegui alterar o modo manutenção.'); }
  }
  function saveProfile() { toast.success('Configurações salvas no CrewCheck.'); }
  return <><Brand back/><section className="cz-settings"><article className="cz-profile"><UserRound/><div><h2>{user?.name || 'Bruno Saraiva'}</h2><p>{safe((user as any)?.role, 'Tripulante')}</p><span>Premium</span><b>Beta</b></div><ChevronRight/></article><h3>Operacional</h3><ToggleSetting icon={Radar} label="TomTom como API principal" storageKey="crewcheck_tomtom_primary"/><ToggleSetting icon={Map} label="Atualizar localização em rota" storageKey="crewcheck_live_location"/><ToggleSetting icon={Plane} label="Pausar ao chegar no aeroporto" storageKey="crewcheck_pause_at_airport"/><ToggleSetting icon={Building2} label="Após pouso calcular tempo até hotel" storageKey="crewcheck_after_landing_hotel"/><ToggleSetting icon={CloudSun} label="Atualização de meteorologia" storageKey="crewcheck_weather_hourly" detail="A cada 60 min"/><ToggleSetting icon={Sun} label="Modo claro premium" storageKey="crewcheck_light_premium" defaultOn={false}/><h3>Perfil</h3><FieldSetting icon={Globe2} label="País do telefone" storageKey="crewcheck_phone_country" placeholder="Brasil +55"/><FieldSetting icon={Phone} label="Telefone do despertador" storageKey="crewcheck_wakeup_phone" placeholder="61996071663"/><FieldSetting icon={Building2} label="Base virtual" storageKey="crewcheck_virtual_base" placeholder="Ex.: BSB / CGH / GRU"/><ToggleSetting icon={GraduationCap} label="Sou instrutor" storageKey="crewcheck_instructor" defaultOn={false}/><h3>Notificações e concierge</h3><ToggleSetting icon={Bell} label="Notificações via Telegram" storageKey="crewcheck_telegram_notifications"/><ToggleSetting icon={Car} label="Alertas de trânsito e saída" storageKey="crewcheck_traffic_alerts"/><ToggleSetting icon={Wifi} label="Concierge operacional" storageKey="crewcheck_concierge"/><section className="cz-settings-actions"><button onClick={saveProfile}><Save/> Salvar perfil</button><button onClick={() => setView('features')}><Settings/> Central funcional</button><button onClick={actions.openActive}><RotateCcw/> Abrir escala ativa</button><button onClick={actions.logout}><LogOut/> Sair</button>{admin && <button onClick={() => setView('maintenance')}><Lock/> Prévia manutenção</button>}{admin && <button onClick={() => enableMaintenance(true)}><Lock/> Ativar manutenção</button>}{admin && <button onClick={() => enableMaintenance(false)}><ShieldCheck/> Desativar manutenção</button>}</section></section></>;
}

function FeatureHub({ bundle, events, setBundle, setView, actions }: { bundle: BundleState; events: ZeroLeg[]; setBundle: (b: BundleState) => void; setView: (v: ZeroView) => void; actions: QuickActions }) {
  const compliance = currentCompliance(bundle);
  const gym = currentGym(bundle);
  return <><Brand back/><section className="cz-panel-head"><h1>Central funcional</h1><p>Todos os motores antigos religados no novo layout: parser, RBAC/ACT, diárias, salário, radar, meteorologia, exportação, calendário e histórico.</p></section><section className="cz-feature-grid"><button onClick={actions.upload}><Upload/><strong>Importar escala</strong><small>PDF AIMS / CrewRoster</small></button><button onClick={() => setView('roster')}><CalendarDays/><strong>Escala completa</strong><small>{events.length} eventos detectados</small></button><button onClick={() => setView('alerts')}><AlertTriangle/><strong>Irregularidades</strong><small>{(compliance as any)?.alerts?.length || 0} alertas</small></button><button onClick={() => setView('departure')}><Car/><strong>Saída Inteligente</strong><small>TomTom / hotel / pós-pouso</small></button><button onClick={() => setView('radar')}><Radar/><strong>Radar de voos</strong><small>Portão e status</small></button><button onClick={() => setView('weather')}><CloudSun/><strong>Meteorologia</strong><small>METAR/TAF e Defesa Civil</small></button><button onClick={() => setView('perdiem')}><BriefcaseBusiness/><strong>Diárias</strong><small>Semanal e mensal</small></button><button onClick={() => setView('salary')}><DollarSign/><strong>Salário</strong><small>Chefe/instrutor/ganhos</small></button><button onClick={() => setView('routine')}><ShieldCheck/><strong>Rotina</strong><small>Academia e descanso</small></button><button onClick={() => setView('crew')}><UserRound/><strong>Crew / Chefe</strong><small>Tripulação e adicional</small></button><button onClick={() => setView('calendar')}><CalendarDays/><strong>Calendário</strong><small>Google Calendar / ICS</small></button><button onClick={() => setView('exports')}><FileText/><strong>Exportar</strong><small>PDF, WhatsApp, e-mail</small></button><button onClick={() => setView('settings')}><Settings/><strong>Configurações</strong><small>Perfil completo</small></button><button onClick={() => setView('database')}><Database/><strong>Histórico</strong><small>Sincronização e offline</small></button></section><section className="cz-toolbox"><h2>Ações rápidas</h2><div className="cz-tool-actions"><button onClick={actions.pdf}>Gerar PDF</button><button onClick={actions.ics}>Gerar ICS</button><button onClick={actions.whatsapp}>WhatsApp</button><button onClick={actions.telegram}>Telegram</button><button onClick={actions.email}>E-mail</button><button onClick={actions.copy}>Copiar resumo</button><button onClick={actions.google}>Google Calendar</button><button onClick={actions.save}>Salvar histórico</button><button onClick={actions.openActive}>Abrir ativa</button></div></section><section className="cz-mini-status"><p><strong>Fonte:</strong> {bundle.source}</p><p><strong>Eventos:</strong> {events.length} · <strong>Alertas:</strong> {(compliance as any)?.alerts?.length || 0} · <strong>Academia:</strong> {gym.length}</p></section></>;
}

function RadarView({ event }: { event: ZeroLeg }) {
  const [state, setState] = useState<any>(null);
  useEffect(() => { let alive = true; fetch(`/api/radar-health?airport=${encodeURIComponent(event.origin)}&type=departure`, { cache: 'no-store' }).then(r => r.json()).then(p => alive && setState(p)).catch(() => alive && setState({ ok: false, message: 'Radar em espera.' })); return () => { alive = false; }; }, [event.origin]);
  return <><Brand back/><section className="cz-panel-head"><h1>Radar de voos</h1><p>Status operacional para {event.flightNumber} · {event.origin} → {event.destination}.</p></section><section className="cz-radar-screen"><article><Radar/><h2>{event.flightNumber}</h2><p>{event.origin} → {event.destination}</p><strong>Portão: A confirmar</strong><span>Status: Confirmado / monitorando</span></article><article><Plane/><h2>Fonte operacional</h2><p>Radar, portão, status e remoção de voos finalizados.</p><strong>{state?.ok ? 'Fonte ativa' : 'Fonte em espera'}</strong><span>{state?.message || state?.source || 'Radar pronto.'}</span></article></section></>;
}
function WeatherView({ event }: { event: ZeroLeg }) {
  const [weather, setWeather] = useState<any>(null);
  useEffect(() => { let alive = true; fetch(`/api/aviation-weather?airport=${encodeURIComponent(event.origin)}`, { cache: 'no-store' }).then(r => r.json()).then(p => alive && setWeather(p)).catch(() => alive && setWeather({ ok: false })); return () => { alive = false; }; }, [event.origin]);
  return <><Brand back/><section className="cz-panel-head"><h1>Meteorologia</h1><p>METAR, TAF, Defesa Civil e concierge meteorológico com atualização limitada a 60 minutos.</p></section><section className="cz-weather-grid"><article><CloudSun/><h2>{event.origin}</h2><strong>METAR</strong><p>{weather?.metar || 'Aguardando fonte configurada.'}</p></article><article><Wifi/><h2>{event.destination}</h2><strong>TAF</strong><p>{weather?.taf || 'Previsão será exibida quando disponível.'}</p></article></section></>;
}
function PerDiemView({ bundle }: { bundle: BundleState }) {
  const flights = buildLegs(bundle.roster).filter(e => e.kind === 'flight').length;
  const layovers = buildLegs(bundle.roster).filter(e => e.kind === 'stay').length;
  const monthly = Math.max(355.68, flights * 118.56 + layovers * 180);
  return <><Brand back/><section className="cz-panel-head"><h1>Diárias</h1><p>Cálculo preservado para janelas de café, almoço, jantar e ceia, com separação semanal/mensal.</p></section><section className="cz-finance-grid"><KpiCard icon={BriefcaseBusiness} title="Previsão mensal" value={`R$ ${monthly.toLocaleString('pt-BR',{minimumFractionDigits:2})}`} detail="estimativa"/><KpiCard icon={CalendarDays} title="Voos" value={String(flights)} detail="no período"/><KpiCard icon={Plane} title="Pernoites" value={String(layovers)} detail="hotel/estadia"/></section><section className="cz-toolbox"><h2>Regras preservadas</h2><p>Café 05–08, almoço 11–13, jantar 19–20 e ceia 00–01, com tratamento de pernoite, reserva e voos internacionais.</p></section></>;
}
function SalaryView({ bundle }: { bundle: BundleState }) {
  const compliance = currentCompliance(bundle);
  const flights = buildLegs(bundle.roster).filter(e => e.kind === 'flight').length;
  return <><Brand back/><section className="cz-panel-head"><h1>Salário</h1><p>Previsão de remuneração, adicionais, chefe de cabine e instrutor.</p></section><section className="cz-finance-grid"><KpiCard icon={DollarSign} title="Ganhos estimados" value="R$ 458,23" detail="lançamentos"/><KpiCard icon={Plane} title="Voos" value={String(flights)} detail="contabilizados"/><KpiCard icon={AlertTriangle} title="Alertas" value={String((compliance as any).alerts?.length || 0)} detail="impacto operacional"/></section><section className="cz-toolbox"><h2>Adicionais preservados</h2><p>Chefe de cabine: primeiro CCM listado é chefe efetivo. Instrutor: opção no perfil. Internacional: separado das nacionais.</p></section></>;
}
function ReportsView({ bundle }: { bundle: BundleState }) {
  const compliance = currentCompliance(bundle);
  return <><Brand back/><section className="cz-panel-head"><h1>Relatórios</h1><p>Indicadores premium de jornada, repouso, horas, carga, academia, rotina e alertas.</p></section><section className="cz-report-grid"><article><h2>Conformidade</h2><strong>{(compliance as any).score ?? '—'}/100</strong><p>{(compliance as any).summary || 'Resumo indisponível'}</p></article><article><h2>Carga</h2><strong>{(compliance as any).loadAnalysis?.intensityScore ?? '—'}</strong><p>Índice de intensidade da escala.</p></article><article><h2>Alertas</h2><strong>{(compliance as any).alerts?.length || 0}</strong><p>Itens confirmados e para revisão.</p></article></section></>;
}
function CalendarToolsView({ actions }: { actions: QuickActions }) {
  return <><Brand back/><section className="cz-panel-head"><h1>Calendário</h1><p>Exportação Connect Crew Lounge, ICS, Google Calendar e notas operacionais.</p></section><section className="cz-toolbox"><h2>Ações</h2><div className="cz-tool-actions"><button onClick={actions.ics}>Baixar ICS</button><button onClick={actions.google}>Sincronizar Google</button><button onClick={() => toast.info('Notas operacionais são incluídas quando aplicável.')}>Ver notas</button></div></section><section className="cz-diagnostics">{googleCalendarIntegrationDiagnostics().map((d: any) => <p key={d.label}><strong>{d.label}</strong><span>{d.value}</span></p>)}</section></>;
}
function ExportToolsView({ actions }: { actions: QuickActions }) {
  return <><Brand back/><section className="cz-panel-head"><h1>Exportar e compartilhar</h1><p>PDF, WhatsApp, Telegram, copiar resumo, e-mail e arquivo de calendário.</p></section><section className="cz-toolbox"><div className="cz-tool-actions"><button onClick={actions.pdf}>PDF</button><button onClick={actions.whatsapp}>WhatsApp</button><button onClick={actions.telegram}>Telegram</button><button onClick={actions.copy}>Copiar</button><button onClick={actions.email}>E-mail</button><button onClick={actions.ics}>ICS</button><button onClick={actions.google}>Google Calendar</button></div></section></>;
}
function RoutineView({ bundle }: { bundle: BundleState }) {
  let suggestions: any[] = [];
  try { suggestions = buildRoutineSuggestions(analyzeDayLoads(bundle.roster).days, defaultRoutineActivities()).slice(0, 8); } catch {}
  return <><Brand back/><section className="cz-panel-head"><h1>Rotina inteligente</h1><p>Academia, recuperação, alimentação e descanso em função da carga de escala.</p></section><section className="cz-stack-list">{suggestions.length ? suggestions.map((s:any, i:number) => <article className="cz-roster-card" key={i}><div className="cz-roster-main"><span className="cz-roster-icon"><ShieldCheck/></span><div className="cz-roster-copy"><h3>{s.title || s.activity || 'Sugestão de rotina'}</h3><p>{s.reason || s.description || 'Ajustado pela escala.'}</p></div></div><strong className="cz-roster-time">{s.suggestedTime || s.duration || '—'}</strong></article>) : <article className="cz-roster-card"><div className="cz-roster-copy"><h3>Rotina pronta</h3><p>Carregue uma escala para receber recomendações completas.</p></div></article>}</section></>;
}
function DatabaseView({ setBundle, setView }: { setBundle: (b: BundleState) => void; setView: (v: ZeroView) => void }) {
  const [items, setItems] = useState<any[]>([]);
  const [status, setStatus] = useState<any>(null);
  useEffect(() => { listSavedRosters(24).then(setItems).catch(() => setItems([])); getDatabaseStatus().then(setStatus).catch(() => setStatus({ message: 'Offline/local' })); }, []);
  async function open(item:any) { try { const data = item?.id ? await openSavedRoster(item.id) : await openActiveRoster(); if (data?.roster) { const c = data.compliance || analyzeSafe(data.roster); setBundle({ roster: data.roster, compliance: c, source: item?.sourceFileName || 'Histórico' }); saveRoster(data.roster, item?.sourceFileName || 'Histórico'); setView('cockpit'); toast.success('Escala aberta.'); } } catch { toast.error('Não consegui abrir o histórico.'); } }
  return <><Brand back/><section className="cz-panel-head"><h1>Histórico e sincronização</h1><p>{status?.message || 'Banco de escalas, offline-first e retomada da escala ativa.'}</p></section><section className="cz-stack-list">{items.length ? items.map((it:any) => <article className="cz-roster-card" key={it.id}><div className="cz-roster-copy"><h3>{it.sourceFileName || `Escala ${it.month}/${it.year}`}</h3><p>{it.createdAt || 'Histórico CrewCheck'}</p></div><button onClick={() => open(it)}>Abrir</button></article>) : <article className="cz-roster-card"><div className="cz-roster-copy"><h3>Nenhum histórico listado</h3><p>Salve a escala na Central funcional para sincronizar.</p></div></article>}</section></>;
}
function CrewToolsView({ bundle }: { bundle: BundleState }) {
  const firstCrew = (bundle.roster.days || []).flatMap((d:any) => d.legs || []).flatMap((l:any) => l.crew || []).slice(0, 8);
  return <><Brand back/><section className="cz-panel-head"><h1>Crew e chefe de cabine</h1><p>Tripulação, adicional de chefe, instrutor e apoio operacional.</p></section><section className="cz-stack-list">{firstCrew.length ? firstCrew.map((c:any, i:number) => <article className="cz-roster-card" key={i}><div className="cz-roster-copy"><h3>{c.name || c.employeeName || 'Tripulante'}</h3><p>{c.role || c.function || 'Crew'}</p></div><strong className="cz-roster-time">{i===0 ? 'Chefe efetivo' : 'Tripulante'}</strong></article>) : <article className="cz-roster-card"><div className="cz-roster-copy"><h3>Regra preservada</h3><p>Quando houver lista de CCM, o primeiro CCM listado é considerado chefe efetivo do voo para fins de adicional.</p></div></article>}</section></>;
}
function MaintenancePreview() { return <><Brand/><section className="cz-maintenance"><article><div className="cz-maint-illu"><Settings size={72}/><Plane size={64}/></div><h1>Site em manutenção</h1><p>Estamos realizando melhorias e atualizações no CrewCheck. Em breve o sistema estará disponível novamente.</p><span><ShieldCheck/> Modo ativado pelo administrador</span><div><Lock/> Apenas administradores podem acessar o painel durante a manutenção.</div><button>Acessar painel admin <ChevronRight/></button><button>Ver status</button><a>Voltar mais tarde</a></article><section><h2>Status da operação <b>Em andamento</b></h2><div><p><CalendarDays/>Escala em atualização</p><p><Bell/>Alertas em revisão</p><p><CloudSun/>Meteorologia sincronizando</p></div></section></section></> }
function ImportPanel({ onUpload }: { onUpload: () => void }) { return <><Brand/><section className="cz-import"><Upload size={56}/><h1>Importar escala oficial</h1><p>Envie o PDF da escala para preencher Cockpit, Roster, Alertas, Diárias e Saída Inteligente no novo visual.</p><button onClick={onUpload}>Escolher PDF</button></section></>; }

function normalizeInitialView(value: string | null): ZeroView {
  if (value === 'roster' || value === 'results' || value === 'result') return 'roster';
  if (value === 'alerts' || value === 'irregularities') return 'alerts';
  if (value === 'manual' || value === 'departure' || value === 'smartDeparture') return 'departure';
  if (value === 'settings') return 'settings';
  if (value === 'import') return 'import';
  if (value === 'features') return 'features';
  if (value === 'radar') return 'radar';
  if (value === 'weather' || value === 'meteo') return 'weather';
  if (value === 'perdiem' || value === 'diarias') return 'perdiem';
  if (value === 'salary' || value === 'salario') return 'salary';
  if (value === 'reports' || value === 'relatorios') return 'reports';
  if (value === 'calendar') return 'calendar';
  if (value === 'exports') return 'exports';
  if (value === 'routine') return 'routine';
  if (value === 'database') return 'database';
  if (value === 'crew') return 'crew';
  return 'cockpit';
}

export default function Home() {
  const [, setLocation] = useLocation();
  const fileRef = useRef<HTMLInputElement>(null);
  const [view, setView] = useState<ZeroView>(() => normalizeInitialView(sessionStorage.getItem('crewcheck_initial_view')));
  const [bundle, setBundle] = useState<BundleState>(loadRoster());
  const [busy, setBusy] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const events = useMemo(() => buildLegs(bundle.roster), [bundle.roster]);
  const event = nextFlight(events);
  const compliance = currentCompliance(bundle);
  const gym = currentGym(bundle);

  useEffect(() => {
    document.documentElement.dataset.crewTheme = 'dark';
    document.documentElement.classList.add('dark');
    storage.set('crewcheck_last_loaded_version', DEFAULT_VERSION);
    const open = () => setDrawer(true);
    window.addEventListener('crewcheck:open-menu', open);
    return () => window.removeEventListener('crewcheck:open-menu', open);
  }, []);

  async function handleFile(inputEvent: ChangeEvent<HTMLInputElement>) {
    const file = inputEvent.target.files?.[0];
    if (!file) return;
    setBusy(true);
    try {
      const roster = await parsePDF(file);
      const newCompliance = saveRoster(roster, file.name);
      setBundle({ roster, compliance: newCompliance, source: file.name });
      setView('cockpit');
      toast.success('Escala completa importada e motores religados.');
      setLocation('/results');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Não consegui interpretar o PDF.');
    } finally { setBusy(false); if (fileRef.current) fileRef.current.value = ''; }
  }

  const actions: QuickActions = {
    upload: () => fileRef.current?.click(),
    pdf: () => { try { const pdf = exportReport(bundle.roster, compliance, gym); pdf.download(); toast.success(`PDF gerado: ${pdf.fileName}`); } catch { toast.error('Não consegui gerar o PDF agora.'); } },
    ics: () => { try { const ics = generateICalendar(bundle.roster, gym); downloadCalendarFile(ics, `crewcheck-${bundle.roster.year}-${String(bundle.roster.month).padStart(2,'0')}.ics`); toast.success('Arquivo ICS gerado.'); } catch { toast.error('Não consegui gerar o ICS.'); } },
    whatsapp: () => { try { shareToWhatsApp(bundle.roster, compliance); } catch { toast.error('Não consegui abrir WhatsApp.'); } },
    telegram: () => { try { shareToTelegram(bundle.roster, compliance); } catch { toast.error('Não consegui abrir Telegram.'); } },
    copy: () => { copyToClipboard(bundle.roster, compliance).then(ok => ok ? toast.success('Resumo copiado.') : toast.error('Não consegui copiar.')); },
    email: () => { const to = window.prompt('Enviar relatório para qual e-mail?') || ''; if (!to.trim()) return; sendRosterByEmail({ to, roster: bundle.roster, compliance, gym }).then(()=>toast.success('E-mail enviado/solicitado.')).catch(()=>toast.error('Não consegui enviar por e-mail agora.')); },
    google: async () => { try { await connectGoogleCalendar(); const result = await syncRosterToGoogleCalendar(bundle.roster, loadGoogleCalendarSettings(), { gymRecommendations: gym }); toast.success(`Google Calendar: ${(result as any).total || (result as any).created + (result as any).updated || 0} eventos sincronizados.`); } catch { toast.error('Não consegui sincronizar com o Google Calendar.'); } },
    save: () => { saveRosterAnalysis({ roster: bundle.roster, compliance, gym, sourceFileName: bundle.source } as any).then(()=>toast.success('Escala salva no histórico.')).catch(()=>toast.error('Não consegui salvar no histórico agora.')); },
    openActive: () => { openActiveRoster().then(active => { if (active?.roster) { const c = active.compliance || analyzeSafe(active.roster); setBundle({ roster: active.roster, compliance: c, source: 'Escala ativa do banco' }); saveRoster(active.roster, 'Escala ativa do banco'); setView('cockpit'); toast.success('Escala ativa carregada.'); } }).catch(()=>toast.error('Não encontrei escala ativa sincronizada.')); },
    logout: () => { logout().finally(() => { window.location.href = '/login'; }); },
  };

  return <main className="cz-app" data-version={DEFAULT_VERSION} data-view={view}>
    <div className="cz-wallpaper"/>
    <input ref={fileRef} type="file" accept="application/pdf,.pdf" hidden onChange={handleFile}/>
    {busy && <div className="cz-busy"><Plane/><strong>Interpretando escala...</strong></div>}
    <MenuDrawer open={drawer} close={() => setDrawer(false)} view={view} setView={setView} actions={actions}/>
    {view === 'cockpit' && <Cockpit events={events} compliance={compliance} setView={setView} onUpload={actions.upload} openMenu={() => setDrawer(true)}/>} 
    {view === 'roster' && <Roster roster={bundle.roster} events={events} setView={setView}/>} 
    {view === 'alerts' && <Alerts compliance={compliance}/>} 
    {view === 'departure' && <Departure event={event}/>} 
    {view === 'settings' && <SettingsView setView={setView} actions={actions}/>} 
    {view === 'maintenance' && <MaintenancePreview/>} 
    {view === 'import' && <ImportPanel onUpload={actions.upload}/>} 
    {view === 'features' && <FeatureHub bundle={bundle} events={events} setBundle={setBundle} setView={setView} actions={actions}/>} 
    {view === 'radar' && <RadarView event={event}/>} 
    {view === 'weather' && <WeatherView event={event}/>} 
    {view === 'perdiem' && <PerDiemView bundle={bundle}/>} 
    {view === 'salary' && <SalaryView bundle={bundle}/>} 
    {view === 'reports' && <ReportsView bundle={bundle}/>} 
    {view === 'calendar' && <CalendarToolsView actions={actions}/>} 
    {view === 'exports' && <ExportToolsView actions={actions}/>} 
    {view === 'routine' && <RoutineView bundle={bundle}/>} 
    {view === 'database' && <DatabaseView setBundle={setBundle} setView={setView}/>} 
    {view === 'crew' && <CrewToolsView bundle={bundle}/>} 
    <BottomNav view={view} setView={setView} openMenu={() => setDrawer(true)}/>
  </main>;
}
