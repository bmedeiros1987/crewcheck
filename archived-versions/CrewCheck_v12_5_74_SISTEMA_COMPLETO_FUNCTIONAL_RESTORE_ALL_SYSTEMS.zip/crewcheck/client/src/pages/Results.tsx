import { useEffect } from 'react';
import Home from './Home';

export default function Results() {
  useEffect(() => {
    sessionStorage.setItem('crewcheck_initial_view', 'roster');
  }, []);
  return <Home />;
}
