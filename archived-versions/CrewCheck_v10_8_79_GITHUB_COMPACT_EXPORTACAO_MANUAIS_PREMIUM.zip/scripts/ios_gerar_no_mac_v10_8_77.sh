#!/bin/bash
set -euo pipefail

# CrewCheck v10.8.78 — gerar projeto iOS no Mac
# Requisitos: macOS, Xcode instalado, Node.js 22+, conta Apple Developer se quiser TestFlight/App Store.

APP_VERSION="10.8.78"
BUNDLE_ID="com.crewcheck.app"

echo "============================================================"
echo "CrewCheck ${APP_VERSION} — preparação iOS"
echo "============================================================"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "Este script precisa rodar no macOS."
  exit 1
fi

command -v node >/dev/null 2>&1 || { echo "Instale Node.js 22+ antes de continuar."; exit 1; }
command -v xcodebuild >/dev/null 2>&1 || { echo "Instale/abra o Xcode antes de continuar."; exit 1; }

echo "Node: $(node -v)"
echo "Xcode:"
xcodebuild -version || true

echo "Instalando dependências..."
npm install

echo "Gerando build web..."
npm run build

if [[ ! -d "ios" ]]; then
  echo "Criando projeto iOS Capacitor..."
  npx cap add ios
else
  echo "Projeto iOS já existe. Sincronizando..."
fi

echo "Sincronizando web build com iOS..."
npx cap sync ios

echo "Aplicando versão no projeto iOS, quando possível..."
if [[ -f "ios/App/App/Info.plist" ]]; then
  /usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString ${APP_VERSION}" "ios/App/App/Info.plist" 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Set :CFBundleVersion 10878" "ios/App/App/Info.plist" 2>/dev/null || true
fi

echo ""
echo "Abrindo no Xcode..."
npx cap open ios

echo ""
echo "============================================================"
echo "No Xcode:"
echo "1. Selecione App > Signing & Capabilities"
echo "2. Team: sua conta Apple Developer"
echo "3. Bundle Identifier: ${BUNDLE_ID}"
echo "4. Product > Archive"
echo "5. Distribute App > App Store Connect / TestFlight"
echo "============================================================"
