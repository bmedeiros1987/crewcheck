# CrewCheck v10.8.102 — Radar Ultra Premium

## Base
- Mantém a v10.8.101.
- Incorpora o radar multifonte dos arquivos enviados, sem substituir a UI atual por telas antigas.

## Radar Ultra
- Consulta fontes oficiais públicas expandidas.
- Evita aceitar como “dado útil” resposta oficial vazia, indisponível ou “voo não localizado”.
- Consulta qualquer aeroporto oficial envolvido na rota, não só BSB/GRU.
- Mantém provedores premium quando configurados: Cirium/FlightStats, AeroDataBox, FlightAware, Aviationstack, Amadeus e proxy privado.
- Garante fallback final pela escala importada, com status “Previsto pela escala”.
- `/api/airport-board` agora entrega fallback da escala quando o painel/API retornar vazio.
- `/api/radar/private-status` recebe também o horário previsto da escala.
- Diagnóstico `/api/radar-health` preservado.

## Segurança
- Sem token embutido no ZIP.
- Sem exposição de links externos privados ao usuário final.

## Versão
- App: 10.8.102
- Android: versionCode 108102 / versionName 10.8.102
