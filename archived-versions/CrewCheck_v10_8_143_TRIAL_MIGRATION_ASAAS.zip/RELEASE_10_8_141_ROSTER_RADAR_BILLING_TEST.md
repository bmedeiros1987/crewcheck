# CrewCheck v10.8.141 — Ajustes de escala, radar e teste de cobrança

## Correções
- Botões da Escala ajustados para caber dentro do card no Android/iOS, sem estourar para fora da tela.
- Radar e Vivo de Extra passam a exibir o número do voo sem repetir o designativo da companhia quando a logo já está visível.
  - Exemplo: logo LATAM + `3445`, em vez de logo LATAM + `LA3445`.
- Escala agora rola automaticamente para a próxima programação/dia vigente ao abrir a tela.
- Próxima programação continua usando apresentação publicada no Cockpit.

## Cobrança / Asaas
- Mantida assinatura recorrente via `/subscriptions`.
- Incluído checklist de teste de cobrança para validar sandbox/homologação, checkout, webhook e painel admin antes do lançamento.

## Android
- versionName: 10.8.141
- versionCode: 10936
