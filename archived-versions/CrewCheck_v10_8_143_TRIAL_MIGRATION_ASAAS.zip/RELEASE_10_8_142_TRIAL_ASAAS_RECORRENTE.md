# CrewCheck v10.8.142 — Trial Asaas Recorrente

- Corrige o teste grátis para criar assinatura recorrente no Asaas.
- O teste agora exige CPF e ciência obrigatória antes da ativação.
- A primeira cobrança mensal fica programada para após os 7 dias grátis.
- Usuário fica `trialing`, mas com `asaas_subscription_id` salvo.
- Dashboard/admin passa a enxergar a assinatura mesmo durante o trial.
- Se o Asaas falhar, o trial não é liberado localmente sem assinatura.
- Home banner orienta o usuário a iniciar teste pela página Assinatura.
- Android: versionName 10.8.142 / versionCode 10937.
