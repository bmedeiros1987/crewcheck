# CrewCheck v10.8.143 — Migração urgente de trials para Asaas

## Correções
- Usuários com trial antigo/Premium sem `asaas_subscription_id` agora veem aviso de regularização na página de Assinatura.
- Novo endpoint do usuário: `POST /api/billing/regularize-trial-as-subscription`.
- Regularização cria assinatura recorrente mensal no Asaas, preservando os dias restantes do teste quando houver.
- A primeira cobrança fica programada para o fim do período restante do trial.
- Se o trial estiver vencido, a assinatura é criada com cobrança imediata/pendente.
- Contas grátis já cadastradas continuam sem cobrança automática; elas ativam o Premium pela página de Assinatura.
- Admin ganhou painel/API de diagnóstico da migração:
  - `GET /api/admin/billing/trial-regularization`
  - `POST /api/admin/billing/trial-regularization/notify`
  - `POST /api/admin/billing/trial-regularization/backfill`
- Backfill automático só atua em trial antigo que já possui CPF salvo e exige `dryRun=false`.
- E-mails de aviso são enviados pelo sistema usando SendGrid/MailerSend/SMTP fallback.

## Android
- versionName: 10.8.143
- versionCode: 10938

## Validação
- `node --check server.mjs`
- `npm run check`
- `npm run build`
