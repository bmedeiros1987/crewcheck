# CrewCheck v11.1.60 — Correção Infobip TTS idioma português

Correção específica para o erro `REJECTED_UNSUPPORTED_LANGUAGE` da Infobip.

## Ajustes
- Normaliza `INFOBIP_LANGUAGE=pt-BR` para `pt` antes de enviar para `/tts/3/advanced`.
- Ignora `INFOBIP_VOICE_NAME=br-pt`, pois isso não é nome de voz da Infobip.
- Quando `INFOBIP_VOICE_NAME` fica vazio, o provedor usa a voz padrão do idioma.
- Mensagem de erro do teste agora mostra orientação direta para `INFOBIP_LANGUAGE=pt`.
- Mantém ligação apenas para Premium/Admin e Telegram para gratuito.
- Mantém abertura Full HD, CallMeBot fallback e diagnóstico Infobip.

## Render recomendado
Use:

```env
INFOBIP_LANGUAGE=pt
INFOBIP_VOICE_NAME=
```

Não use:

```env
INFOBIP_LANGUAGE=pt-BR
INFOBIP_VOICE_NAME=br-pt
```
