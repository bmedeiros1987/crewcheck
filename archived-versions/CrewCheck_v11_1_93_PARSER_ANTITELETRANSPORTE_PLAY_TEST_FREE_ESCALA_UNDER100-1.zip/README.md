# CrewCheck v11.1.93 — Parser anti-teletransporte e Google Play teste gratuito

Base: v11.1.91.

## Principais correções

- Cards da escala exibem limite de regulamentação quando aplicável:
  - RBAC 117 B.1 por hora de início e número de etapas.
  - Reserva acionada conta desde o início da reserva/apresentação.
  - Reserva/sobreaviso sem voo mostra janela lida e alerta de referência operacional.
- Menu web padronizado com visual Premium claro da tela Operacional, respeitando modo claro/escuro/sistema.
- Meteorologia operacional volta a aparecer nos cards da escala para piloto e comissário.
- Despertador/VOIP recebe fuso configurado pelo usuário, evitando exibição em UTC quando o sistema estiver em BSB.
- Google Calendar/ICS ganha modo recomendado “Voo + folgas”.
- Exportação padrão fica limpa: rotina, tripulação, diárias e detalhes ficam dentro do evento principal, sem criar compromissos separados.
- Deduplicação da escala reforçada e bloqueio para não criar sobreaviso/reserva aleatória a partir de texto residual do PDF.

## Validação local

- `node --check server.mjs` OK.
- Sintaxe TS/TSX validada por `typescript.transpileModule` nos arquivos principais.
- `npm run build` depende do `vite` instalado no ambiente do deploy.

## Mantido

- Infobip como ligação Premium.
- WhatsApp Premium/trial limitado e importação preparada.
- FreeCurrencyAPI.
- Parser por continuidade física da escala.


## v11.1.93
- Reancora jornadas por continuidade física, preservando voos que cruzam meia-noite.
- Separa nova jornada somente com repouso/pernoite >=12h entre programações na mesma localidade.
- Evita teletransporte visual: perna após meia-noite aparece no dia operacional correto.
- Deduplicação reforçada dos cards de voo e eventos de escala.
- Mantém v11.1.92: cards com regulamentação, menu Premium, meteorologia, fuso BSB, WhatsApp/Infobip e calendário limpo.
- Orientação Play Console: app pago em teste fechado/aberto cobra o testador; teste interno instala grátis.
