# CrewCheck v11.0.95 — Meteorologia Premium, Crewtopia Parser e Cards Personalizados

Atualização Premium com aba de Meteorologia para pilotos, METAR/TAF traduzido ou bruto, favoritos, glossário, integração com Concierge Telegram, correções de leitura Crewtopia/AIMS e personalização dos cards da escala.

## Principais ajustes

- Nova aba **Meteorologia** no menu Operacional e no Cockpit Premium.
- Busca METAR/TAF por ICAO ou IATA, com favoritos e modo bruto/traduzido.
- Glossário de meteorologia exportável em CSV.
- Concierge Telegram entende pedidos de METAR/TAF/ATIS e responde em texto ou áudio conforme a entrada.
- Integração com Aviation Weather Center via endpoint server-side, evitando CORS no navegador.
- Parser Crewtopia/AIMS reforçado para não perder dias como 08/07 e 20/07 quando o PDF traz blocos contínuos.
- Correção do escopo de **extra/PS**: voo de extra não contamina os demais voos do mesmo dia.
- Endpoint Asaas aceita aliases e GET de health para reduzir erro “API endpoint não encontrado” ao testar webhook.
- Configuração de exibição dos cards da escala em Configurações > Aparência.
- Produção Android mantém R8/ProGuard, shrinkResources e mapping.txt.

## Android

- versionName: 11.0.95
- versionCode: 11095
