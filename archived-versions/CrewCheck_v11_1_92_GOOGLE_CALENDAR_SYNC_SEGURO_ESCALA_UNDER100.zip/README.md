# CrewCheck v11.1.92 — Google Calendar sincronismo seguro

Base: v11.1.91.

## Hotfix principal

Corrige o cenário em que o usuário consegue conectar a agenda e listar os calendários, mas a escala não é enviada corretamente ou só alguns dias aparecem no Google Calendar.

## Ajustes técnicos

- Troca o fluxo antigo de “apagar o período inteiro e recriar tudo” por sincronismo seguro por **upsert**.
- O CrewCheck agora busca eventos existentes do período, atualiza pelo `crewcheckEventKey`, cria o que não existe e só remove sobras quando todos os eventos novos são processados sem erro.
- Se o Google rejeitar um evento isolado, a sincronização continua para os demais dias e preserva os eventos antigos.
- Ao conectar o Google depois de importar uma escala, se houver sincronização automática pendente, o app envia a escala imediatamente.
- Botões e textos foram ajustados de “Atualizar ICS” para “Sincronizar escala agora”, deixando claro que é Google Calendar direto.
- Mantidos: reserva acionada como voo, WhatsApp Import, FreeCurrencyAPI, Infobip e parser por continuidade física.

## Validação

- `node --check server.mjs`: OK
- ZIP: 99 arquivos, sem `node_modules` e sem `dist`
