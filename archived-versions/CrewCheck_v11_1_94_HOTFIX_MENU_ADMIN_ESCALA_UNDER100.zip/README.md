# CrewCheck v11.1.94

Hotfix do menu Admin: recuperação visual do Dashboard Admin quando o cache/localStorage ou /api/auth/me volta sem role, mantendo endpoints administrativos protegidos no backend. Também força atualização do cache PWA/service worker ao mudar versão.
