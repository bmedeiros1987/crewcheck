# CrewCheck v10.8.95 — Menu, Diárias e Admin Premium

## Correções e melhorias
- Menu inferior da tela Escala padronizado com o menu global do sistema.
- Ícones e botões do menu da Escala alinhados com Cockpit, Saída e Conta.
- Escala em landscape reforçada: dia da semana em cima, número no centro e mês embaixo.
- Horário principal do card de voo reforçado para exibir decolagem; apresentação permanece nos detalhes/subtítulo.
- Diárias: novo painel de calibração com valores recebidos por semana.
- Diárias reais informadas pelo administrador:
  - 03/06/2026: R$ 684,00
  - 11/06/2026: R$ 547,20
  - 28/05/2026: R$ 656,54
  - 21/05/2026: R$ 875,52
- Dashboard Admin não invasivo com saúde do sistema, banco, fila offline, módulos e métricas agregadas.
- Novo endpoint opcional `/api/admin/usage-summary` para totais agregados, sem expor nomes, e-mails, PDFs, escala ou localização individual.
- Android atualizado para versionCode 10895 e versionName 10.8.95.
