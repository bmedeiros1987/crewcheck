import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  BarChart3,
  Bell,
  Calendar,
  CheckCircle2,
  ChevronRight,
  Clock,
  FileText,
  FolderSync,
  Gauge,
  GraduationCap,
  Home as HomeIcon,
  Lock,
  MapPin,
  Navigation,
  Menu,
  Plane,
  Radar,
  Monitor,
  RefreshCw,
  Settings,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  UserRound,
  Wifi,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { getSavedLanguage, getTranslations } from '@/lib/i18n';

interface DashboardProps {
  user: {
    name: string;
    company: string;
    avatar?: string;
    base?: string;
  };
  nextEvent?: {
    title: string;
    time: string;
    endTime: string;
    date: string;
    route?: string;
    status?: string;
    gate?: string;
    terminal?: string;
    countdown?: string;
    source?: string;
    isFlight?: boolean;
    targetIso?: string;
    origin?: string;
    destination?: string;
    base?: string;
  };
  onNavigate: (view: string) => void;
  canAccessC32FAcademy?: boolean;
  pendingOffline?: number;
  hasRoster?: boolean;
  alertsCount?: number;
  daysLoaded?: number;
  complianceScore?: number;
}

const Dashboard: React.FC<DashboardProps> = ({
  user,
  nextEvent,
  onNavigate,
  canAccessC32FAcademy = false,
  pendingOffline = 0,
  hasRoster = false,
  alertsCount = 0,
  daysLoaded = 0,
  complianceScore,
}) => {
  const i18n = getTranslations(getSavedLanguage());
  const displayName = user.name || i18n.crewMember;
  const firstName = displayName.split(/\s+/).filter(Boolean).slice(0, 2).join(' ') || 'Crew';
  const initials = displayName
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('') || 'CC';

  const menuItems = [
    { icon: FileText, label: i18n.newRoster, caption: 'PDF CrewTopia, iFlight ou AIMS', color: 'from-cyan-300 to-blue-500', onClick: () => onNavigate('import') },
    { icon: Calendar, label: i18n.myRoster, caption: 'linha do tempo premium', color: 'from-blue-400 to-indigo-600', onClick: () => onNavigate('roster') },
    { icon: FolderSync, label: i18n.myRoutine, caption: 'descanso, treino e estudo', color: 'from-emerald-300 to-teal-600', onClick: () => onNavigate('routine') },
    ...(canAccessC32FAcademy ? [{ icon: GraduationCap, label: 'C32F', caption: 'apostila e check A32F', color: 'from-violet-300 to-fuchsia-600', onClick: () => onNavigate('c32f') }] : []),
    { icon: AlertCircle, label: i18n.irregularities, caption: 'descanso e ACT', color: 'from-rose-400 to-red-600', onClick: () => onNavigate('irregularities') },
    { icon: BarChart3, label: 'Meu mês', caption: 'horas, voos e folgas', color: 'from-sky-300 to-cyan-600', onClick: () => onNavigate('reports') },
    { icon: Clock, label: i18n.history, caption: 'histórico sem duplicar', color: 'from-amber-300 to-orange-600', onClick: () => onNavigate('history') },
    { icon: Plane, label: 'iFlight LATAM', caption: canAccessC32FAcademy ? 'sincronização admin' : 'automático em desenvolvimento', color: 'from-orange-300 to-amber-600', onClick: () => onNavigate('iflight') },
    { icon: Monitor, label: 'Radar de Voos', caption: 'painel por aeroporto e companhia', color: 'from-cyan-200 to-sky-600', onClick: () => onNavigate('flightboard') },
    { icon: FileText, label: 'Diárias', caption: 'previsão mensal e semanal', color: 'from-emerald-300 to-teal-600', onClick: () => onNavigate('perdiem') },
    { icon: TrendingUp, label: 'Salário', caption: 'bruto, líquido e descontos', color: 'from-lime-300 to-emerald-600', onClick: () => onNavigate('salary') },
    { icon: Navigation, label: 'Saída Inteligente', caption: 'trânsito real até a base', color: 'from-emerald-300 to-cyan-600', onClick: () => onNavigate('departure') },
    { icon: FileText, label: i18n.notes, caption: 'privado no dispositivo', color: 'from-yellow-300 to-amber-500', onClick: () => onNavigate('notes') },
    { icon: Settings, label: i18n.settings, caption: 'tema, idioma e conta', color: 'from-slate-300 to-slate-600', onClick: () => onNavigate('settings') },
  ];

  return (
    <div className="min-h-screen overflow-x-hidden overflow-y-auto bg-[#030914] text-white crewcheck-commercial-dashboard">
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_10%_4%,rgba(14,165,233,0.33),transparent_31%),radial-gradient(circle_at_88%_8%,rgba(37,99,235,0.26),transparent_30%),linear-gradient(180deg,#030914_0%,#07111f_43%,#020817_100%)]" />
        <div className="absolute inset-x-0 top-0 h-72 bg-[radial-gradient(circle_at_50%_0%,rgba(255,255,255,0.16),transparent_44%)]" />
        <div className="absolute -bottom-28 left-1/2 h-80 w-[48rem] -translate-x-1/2 rounded-full bg-cyan-500/10 blur-3xl" />
      </div>

      <div className="relative z-10 mx-auto grid min-h-[100dvh] w-full max-w-[96rem] grid-cols-1 gap-5 px-4 pb-32 pt-[calc(1rem+env(safe-area-inset-top,0px))] sm:px-6 lg:grid-cols-[20rem_minmax(0,1fr)] lg:pb-10 lg:pt-6 2xl:grid-cols-[20rem_minmax(0,1fr)_18rem]">
        <aside className="hidden rounded-[2rem] border border-white/10 bg-white/[0.045] p-5 shadow-2xl shadow-black/30 backdrop-blur-2xl lg:block">
          <div className="flex items-center gap-4">
            <img src="/icons/crewcheck-icon.svg" alt="CrewCheck" className="h-16 w-16 rounded-3xl shadow-2xl shadow-cyan-950/40" />
            <div>
              <h1 className="text-2xl font-black tracking-tight">CrewCheck</h1>
              <p className="mt-1 text-[0.64rem] font-black uppercase tracking-[0.22em] text-cyan-100/60">Roster Intelligence</p>
            </div>
          </div>

          <button onClick={() => onNavigate('import')} className="mt-6 flex w-full items-center justify-between rounded-3xl border border-cyan-300/20 bg-cyan-300/10 px-4 py-3 text-left text-sm font-bold text-cyan-50 transition hover:bg-cyan-300/15">
            <span><Sparkles className="mr-2 inline h-4 w-4 text-cyan-200" /> Importar PDF · CrewTopia/iFlight</span>
            <ChevronRight className="h-4 w-4" />
          </button>

          <div className="mt-6 space-y-3">
            <FeatureLine icon={Wifi} title="100% Offline" text="Escala, rotina e notas funcionam no dispositivo." />
            <FeatureLine icon={RefreshCw} title="Sync inteligente" text={pendingOffline ? `${pendingOffline} item(ns) pendente(s).` : 'Atualiza quando voltar online.'} />
            <FeatureLine icon={ShieldCheck} title="Privacidade LGPD" text="Sem salvar senha corporativa; MFA sempre no portal oficial." />
            <FeatureLine icon={Lock} title="Conta protegida" text="Dados mínimos, sessão local e controle de exportação." />
          </div>

          <button onClick={() => onNavigate('settings')} className="cc-profile-quick-card mt-6 w-full rounded-3xl border border-white/10 bg-white/[0.04] p-4 text-left transition hover:bg-white/[0.07]">
            <div className="flex items-center gap-3">
              <ProfileAvatar avatar={user.avatar} initials={initials} size="sm" />
              <div className="min-w-0">
                <p className="truncate font-black leading-tight">{firstName}</p>
                <p className="text-xs text-slate-400">{user.base || 'Base'} · perfil premium</p>
                <p className="mt-1 text-[10px] font-black uppercase tracking-[0.12em] text-cyan-200">Alterar foto</p>
              </div>
            </div>
          </button>
        </aside>

        <main className="min-w-0 space-y-5">
          <section className="relative overflow-hidden rounded-[2rem] border border-cyan-200/15 bg-[linear-gradient(135deg,rgba(255,255,255,.14),rgba(125,211,252,.10),rgba(255,255,255,.05))] p-5 shadow-2xl shadow-cyan-950/20 backdrop-blur-2xl sm:p-7">
            <div className="absolute -right-12 top-4 h-44 w-44 rounded-full border-[14px] border-cyan-200/10" />
            <Plane className="pointer-events-none absolute -right-3 top-8 h-32 w-32 rotate-12 text-cyan-100/25 drop-shadow-2xl sm:h-40 sm:w-40 xl:text-cyan-100/35" />
            <div className="relative z-10 max-w-2xl">
              <div className="flex items-start gap-4">
                <button type="button" onClick={() => onNavigate('settings')} className="cc-hero-avatar-button shrink-0 text-left" title="Alterar foto de perfil">
                  <ProfileAvatar avatar={user.avatar} initials={initials} size="lg" />
                  <span className="mt-2 block text-center text-[10px] font-black uppercase tracking-[0.14em] text-cyan-100/70">Foto</span>
                </button>
                <div className="min-w-0">
                  <p className="text-[0.7rem] font-black uppercase tracking-[0.32em] text-cyan-100/70">Cockpit pessoal</p>
                  <h2 className="mt-2 max-w-xl break-words text-3xl font-black leading-[0.95] tracking-tight sm:text-5xl">{firstName}</h2>
                  <p className="mt-3 text-sm font-semibold text-slate-300 sm:text-base">CrewCheck Premium · {user.base || 'BSB'} · escala, rotina, alertas e calendário em um só lugar.</p>
                </div>
              </div>
              <div className="mt-5 grid max-w-xl grid-cols-3 gap-2 sm:gap-3">
                <MiniStatus icon={Wifi} value="Offline" label="pronto" />
                <MiniStatus icon={ShieldCheck} value="LGPD" label="privado" />
                <MiniStatus icon={RefreshCw} value="Beta" label="em teste" />
              </div>
              <div className="mt-5 max-w-2xl rounded-3xl border border-amber-300/20 bg-amber-300/10 px-4 py-3 text-sm leading-6 text-amber-50/90">
                <b>Fase de testes privados:</b> confira sempre os dados com a escala oficial. Se encontrar divergência, envie o PDF/print pela aba Suporte para ajustarmos o CrewCheck.
              </div>
            </div>
          </section>

          <section className="grid gap-4 2xl:grid-cols-[minmax(0,1fr)_17rem]">
            <NextProgramBoardingPass nextEvent={nextEvent} hasRoster={hasRoster} onOpenRoster={() => onNavigate('roster')} onImport={() => onNavigate('import')} onSync={() => onNavigate('iflight')} />
            <SmartDepartureCard nextEvent={nextEvent} hasRoster={hasRoster} userBase={user.base} onOpen={() => onNavigate('departure')} />
            <div className="grid gap-3 sm:grid-cols-3 xl:grid-cols-1">
              <SideKpi icon={Calendar} label="Dias carregados" value={String(daysLoaded || '—')} />
              <SideKpi icon={Bell} label="Alertas" value={String(alertsCount)} tone={alertsCount ? 'text-rose-200' : 'text-emerald-200'} />
              <SideKpi icon={Gauge} label="Conformidade" value={complianceScore ? `${complianceScore}/100` : '—'} />
            </div>
          </section>

          <section className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 2xl:grid-cols-5">
            {menuItems.map((item) => <MenuCard key={item.label} {...item} />)}
          </section>
        </main>

        <aside className="hidden space-y-4 2xl:block">
          <SideCard icon={ShieldCheck} title="Privacy by design" text="Sem senha corporativa salva. O usuário autentica no portal oficial e o CrewCheck importa apenas a escala necessária." />
          <SideCard icon={TrendingUp} title="Produto vendável" text="Dashboard premium, plano offline, histórico, rotina, relatórios e proposta clara para assinatura futura." />
          <button onClick={() => onNavigate('settings')} className="w-full rounded-[1.65rem] border border-white/10 bg-white/[0.055] p-5 text-left shadow-xl shadow-black/20 backdrop-blur-xl transition hover:bg-white/[0.08]">
            <Settings className="mb-4 h-8 w-8 text-cyan-200" />
            <p className="font-black">Perfil premium</p>
            <p className="mt-1 text-sm leading-6 text-slate-400">Foto, idioma, tema, base e preferências de calendário.</p>
          </button>
        </aside>
      </div>

      <nav className="crewcheck-dashboard-bottom-nav fixed bottom-0 left-0 right-0 z-50 border-t border-white/10 bg-[#08111f]/90 px-5 pb-[calc(0.75rem+env(safe-area-inset-bottom,0px))] pt-3 shadow-2xl shadow-black backdrop-blur-2xl lg:hidden">
        <div className="mx-auto flex max-w-md items-center justify-between">
          <NavItem icon={HomeIcon} label="Cockpit" active onClick={() => onNavigate('home')} />
          <NavItem icon={Calendar} label={i18n.roster} onClick={() => onNavigate('roster')} />
          <NavItem icon={Plane} label="iFlight" onClick={() => onNavigate('iflight')} />
          <NavItem icon={Bell} label={i18n.alerts} badge={alertsCount || undefined} onClick={() => onNavigate('alerts')} />
          <NavItem icon={Menu} label={i18n.more} onClick={() => onNavigate('more')} />
        </div>
      </nav>
    </div>
  );
};

function NextProgramBoardingPass({ nextEvent, hasRoster, onOpenRoster, onImport, onSync }: { nextEvent?: DashboardProps['nextEvent']; hasRoster: boolean; onOpenRoster: () => void; onImport: () => void; onSync: () => void }) {
  const isFlight = Boolean(nextEvent?.isFlight);
  const liveCountdown = useLiveCountdown(nextEvent?.targetIso, nextEvent?.countdown);
  return (
    <div className="overflow-hidden rounded-[1.8rem] border border-white/10 bg-white/[0.06] shadow-2xl shadow-black/20 backdrop-blur-2xl">
      <div className="grid gap-0 lg:grid-cols-[minmax(0,1fr)_14rem]">
        <div className="p-5 sm:p-6">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-[0.65rem] font-black uppercase tracking-[0.26em] text-cyan-100/60">Próxima programação</p>
              <h3 className="mt-2 text-2xl font-black tracking-tight sm:text-3xl">{nextEvent?.route || nextEvent?.title || (hasRoster ? 'Escala carregada' : 'Importe sua escala')}</h3>
              <p className="mt-1 text-sm font-semibold text-slate-400">{nextEvent?.date || 'PDF, AIMS ou iFlight'} · {nextEvent?.source || 'CrewCheck local'}</p>
            </div>
            <div className="hidden h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-cyan-300/10 text-cyan-100 sm:flex"><Plane className="h-7 w-7" /></div>
          </div>
          <div className={isFlight ? "mt-5 grid grid-cols-2 gap-2 sm:grid-cols-5" : "mt-5 grid grid-cols-2 gap-2 sm:grid-cols-3"}>
            <GlassPill label="Apresentação" value={nextEvent?.time || '—'} />
            <GlassPill label="Fim" value={nextEvent?.endTime || '—'} />
            {isFlight ? (
              <>
                <GlassPill label="Status" value={nextEvent?.status || 'Programado'} />
                <GlassPill label="Portão" value={nextEvent?.gate || '—'} />
                <GlassPill label="Terminal" value={nextEvent?.terminal || '—'} />
              </>
            ) : (
              <GlassPill label="Tipo" value={nextEvent?.status || (hasRoster ? 'Programação' : 'Importação')} />
            )}
          </div>
          <div className="mt-5 flex flex-wrap gap-2">
            <button onClick={hasRoster ? onOpenRoster : onImport} className="cc-button-primary rounded-2xl px-4 py-3 text-sm font-black shadow-lg transition active:scale-95">{hasRoster ? 'Abrir detalhes' : 'Importar PDF'}</button>
            <button onClick={onSync} className="cc-button-secondary rounded-2xl px-4 py-3 text-sm font-black transition active:scale-95">{hasRoster ? 'iFlight beta' : 'Ver opções'}</button>
          </div>
        </div>
        <div className="border-t border-white/10 bg-cyan-300/[0.07] p-5 lg:border-l lg:border-t-0">
          <p className="text-[0.65rem] font-black uppercase tracking-[0.22em] text-cyan-100/60">tempo restante</p>
          <p className="mt-2 text-4xl font-black tracking-tight">{liveCountdown}</p>
          <p className="mt-2 text-sm leading-6 text-slate-400">{isFlight ? `Dados de voo: ${nextEvent?.source || 'consulta online quando disponível'}` : 'Rotina e detalhes ficam organizados dentro da escala.'}</p>
        </div>
      </div>
    </div>
  );
}



type SmartDeparturePlan = {
  ok: boolean;
  airport?: string;
  airportName?: string;
  leaveAtLabel?: string;
  arrivalDeadlineLabel?: string;
  durationMinutes?: number;
  delayMinutes?: number | null;
  distanceKm?: number | null;
  isLate?: boolean;
  source?: string;
  warning?: string | null;
  message?: string;
  marginMinutes?: number;
  safetyMarginMinutes?: number;
};

const CREWCHECK_SMART_DEPARTURE_DEFAULT_MARGIN = 15;
const CREWCHECK_SUPPORTED_AIRPORTS = 'BSB|GRU|CGH|GIG|SDU|CNF|VCP|POA|CWB|SSA|REC|FOR|NAT|MAO|BEL|FLN|IGU|AJU|JPA|MCZ|VIX|GYN|CGB|CGR|SLZ|THE|PVH|RBR|BVB|PMW|MCP|NVT|JOI|LDB|MGF|RAO|UDI|IOS|BPS';

function getSmartDepartureMarginMinutes() {
  const stored = Number(localStorage.getItem('crewcheck_departure_margin_minutes') || '');
  if (Number.isFinite(stored) && stored >= CREWCHECK_SMART_DEPARTURE_DEFAULT_MARGIN) return String(Math.min(120, stored));
  try { localStorage.setItem('crewcheck_departure_margin_minutes', String(CREWCHECK_SMART_DEPARTURE_DEFAULT_MARGIN)); } catch {}
  return String(CREWCHECK_SMART_DEPARTURE_DEFAULT_MARGIN);
}

function inferAirportForDeparture(nextEvent?: DashboardProps['nextEvent'], fallbackBase?: string) {
  const candidates = [
    nextEvent?.origin,
    nextEvent?.base,
    nextEvent?.route,
    fallbackBase,
    localStorage.getItem('crewcheck_preferred_airport') || '',
  ].map((item) => String(item || '').toUpperCase());
  const airportPattern = new RegExp(`\\b(${CREWCHECK_SUPPORTED_AIRPORTS})\\b`);
  for (const raw of candidates) {
    const match = raw.match(airportPattern);
    if (match?.[1]) return match[1];
  }
  return 'BSB';
}

function SmartDepartureCard({ nextEvent, hasRoster, userBase, onOpen }: { nextEvent?: DashboardProps['nextEvent']; hasRoster: boolean; userBase?: string; onOpen?: () => void }) {
  const [permission, setPermission] = useState<'idle' | 'requesting' | 'granted' | 'denied' | 'unsupported'>('idle');
  const [plan, setPlan] = useState<SmartDeparturePlan | null>(null);
  const [error, setError] = useState<string | null>(null);
  const airport = inferAirportForDeparture(nextEvent, userBase);
  const canCalculate = Boolean(hasRoster && nextEvent?.targetIso);

  const calculate = React.useCallback(() => {
    if (!canCalculate) {
      setError('Importe uma escala para calcular a hora de sair.');
      return;
    }
    if (!('geolocation' in navigator)) {
      setPermission('unsupported');
      setError('Localização indisponível neste dispositivo.');
      return;
    }
    setPermission('requesting');
    setError(null);
    navigator.geolocation.getCurrentPosition(async (position) => {
      try {
        setPermission('granted');
        const params = new URLSearchParams({
          lat: String(position.coords.latitude),
          lng: String(position.coords.longitude),
          airport,
          targetIso: String(nextEvent?.targetIso || ''),
          marginMinutes: getSmartDepartureMarginMinutes(),
          mode: 'DRIVE',
        });
        const response = await fetch(`/api/smart-departure?${params.toString()}`, { cache: 'no-store' });
        const payload = await response.json().catch(() => null) as SmartDeparturePlan | null;
        if (!response.ok || !payload?.ok) throw new Error(payload?.message || 'Não foi possível calcular a saída.');
        setPlan(payload);
        try {
          localStorage.setItem('crewcheck_departure_location_permission', 'granted');
          localStorage.setItem('crewcheck_departure_last_airport', airport);
          localStorage.setItem('crewcheck_departure_last_plan', JSON.stringify(payload));
        } catch {}
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Falha ao calcular saída inteligente.');
      }
    }, (geoError) => {
      setPermission('denied');
      setError(geoError?.code === 1 ? 'Permita a localização para calcular com trânsito real.' : 'Não consegui obter sua localização atual.');
    }, { enableHighAccuracy: true, timeout: 12_000, maximumAge: 90_000 });
  }, [airport, canCalculate, nextEvent?.targetIso]);

  useEffect(() => {
    if (!canCalculate) return;
    let timer: number | undefined;
    const refresh = () => {
      try {
        const saved = localStorage.getItem('crewcheck_departure_last_plan');
        if (saved) setPlan(JSON.parse(saved));
        if (localStorage.getItem('crewcheck_departure_location_permission') === 'granted') calculate();
      } catch {}
    };
    refresh();
    timer = window.setInterval(refresh, 5 * 60_000);
    window.addEventListener('crewcheck:refresh-smart-departure', refresh);
    window.addEventListener('focus', refresh);
    window.addEventListener('online', refresh);
    document.addEventListener('visibilitychange', refresh);
    return () => {
      if (timer) window.clearInterval(timer);
      window.removeEventListener('crewcheck:refresh-smart-departure', refresh);
      window.removeEventListener('focus', refresh);
      window.removeEventListener('online', refresh);
      document.removeEventListener('visibilitychange', refresh);
    };
  }, [calculate, canCalculate]);

  return (
    <div className="rounded-[1.8rem] border border-cyan-200/15 bg-[linear-gradient(135deg,rgba(34,211,238,.12),rgba(59,130,246,.08),rgba(255,255,255,.045))] p-5 shadow-2xl shadow-cyan-950/10 backdrop-blur-2xl">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[0.65rem] font-black uppercase tracking-[0.24em] text-cyan-100/60">saída inteligente</p>
          <h3 className="mt-2 text-2xl font-black tracking-tight">{plan?.leaveAtLabel || 'Hora de sair'}</h3>
          <p className="mt-1 text-sm font-semibold leading-6 text-slate-400">
            {plan?.ok ? `Chegue em ${plan.airport || airport} até ${plan.arrivalDeadlineLabel} · margem ${plan.marginMinutes || CREWCHECK_SMART_DEPARTURE_DEFAULT_MARGIN} min` : `Calcula automaticamente até o aeroporto da apresentação (${airport}), usando sua localização atual.`}
          </p>
        </div>
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-cyan-300/12 text-cyan-100"><Navigation className="h-6 w-6" /></div>
      </div>

      {plan?.ok ? (
        <div className="mt-4 grid grid-cols-3 gap-2">
          <GlassPill label="Trânsito" value={`${plan.durationMinutes || '—'} min`} />
          <GlassPill label="Destino" value={plan.airport || airport} />
          <GlassPill label="Distância" value={plan.distanceKm ? `${plan.distanceKm} km` : '—'} />
        </div>
      ) : null}

      {error ? <p className="mt-3 rounded-2xl border border-amber-300/20 bg-amber-300/10 px-3 py-2 text-xs font-bold leading-5 text-amber-50/90">{error}</p> : null}
      {plan?.warning ? <p className="mt-3 text-xs font-semibold leading-5 text-amber-100/75">{plan.warning}</p> : null}
      {plan?.airportName ? <p className="mt-3 text-xs font-semibold leading-5 text-cyan-50/70">Destino detectado: {plan.airportName}. Para tripulantes em Recife, Brasília, São Paulo ou outra cidade, a rota parte da localização atual autorizada no celular.</p> : null}
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <button onClick={calculate} disabled={permission === 'requesting' || !canCalculate} className="cc-button-primary rounded-2xl px-4 py-3 text-sm font-black shadow-lg transition active:scale-95 disabled:opacity-50">
          {permission === 'requesting' ? 'Calculando...' : plan?.ok ? 'Atualizar trânsito' : 'Ativar localização'}
        </button>
        <span className="inline-flex items-center gap-1 rounded-2xl border border-white/10 bg-white/[0.045] px-3 py-2 text-[11px] font-black uppercase tracking-[0.12em] text-slate-400">
          <MapPin className="h-3.5 w-3.5 text-cyan-200" /> localização sob permissão
        </span>
        {onOpen ? <button onClick={onOpen} className="cc-button-secondary rounded-2xl px-4 py-3 text-sm font-black transition active:scale-95">Abrir painel</button> : null}
      </div>
      <p className="mt-3 text-xs leading-5 text-slate-500">Estimativa para chegar pelo menos 15 min antes da apresentação. Funciona para bases diferentes: o destino é o aeroporto da próxima apresentação e a origem é sua localização atual.</p>
    </div>
  );
}

function ProfileAvatar({ avatar, initials, size = 'sm' }: { avatar?: string; initials: string; size?: 'sm' | 'lg' }) {
  const sizeClass = size === 'lg' ? 'h-20 w-20 rounded-[1.65rem]' : 'h-11 w-11 rounded-2xl';
  const textClass = size === 'lg' ? 'text-xl' : 'text-sm';
  if (avatar) {
    return <img src={avatar} alt="Foto de perfil" className={`${sizeClass} object-cover shadow-xl shadow-cyan-950/35 ring-2 ring-cyan-200/20`} />;
  }
  return <div className={`${sizeClass} flex items-center justify-center bg-white/10 ${textClass} font-black text-cyan-50 shadow-xl shadow-cyan-950/25 ring-2 ring-cyan-200/15`}>{initials}</div>;
}

function useLiveCountdown(targetIso?: string, fallback = '—') {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 60_000);
    return () => window.clearInterval(timer);
  }, []);
  return useMemo(() => formatLiveCountdown(targetIso, now, fallback), [targetIso, now, fallback]);
}

function formatLiveCountdown(targetIso?: string, now = Date.now(), fallback = '—') {
  if (!targetIso) return fallback || '—';
  const target = new Date(targetIso).getTime();
  if (!Number.isFinite(target)) return fallback || '—';
  const diff = target - now;
  if (diff <= 0) return 'agora';
  const totalMinutes = Math.max(0, Math.floor(diff / 60000));
  const days = Math.floor(totalMinutes / 1440);
  const hours = Math.floor((totalMinutes % 1440) / 60);
  const minutes = totalMinutes % 60;
  if (days > 0) return `${days}d ${hours}h`;
  return `${hours}h ${String(minutes).padStart(2, '0')}m`;
}

function FeatureLine({ icon: Icon, title, text }: { icon: LucideIcon; title: string; text: string }) {
  return (
    <div className="flex items-start gap-3 rounded-3xl border border-white/8 bg-white/[0.035] p-3">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-cyan-300/10 text-cyan-200"><Icon className="h-5 w-5" /></div>
      <div><p className="text-sm font-black">{title}</p><p className="mt-0.5 text-xs leading-5 text-slate-400">{text}</p></div>
    </div>
  );
}

function MiniStatus({ icon: Icon, value, label }: { icon: LucideIcon; value: string; label: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.07] p-3 text-center backdrop-blur-xl">
      <Icon className="mx-auto mb-1 h-4 w-4 text-cyan-200" />
      <p className="text-sm font-black">{value}</p>
      <p className="text-[9px] font-black uppercase tracking-[0.13em] text-slate-400">{label}</p>
    </div>
  );
}

function GlassPill({ label, value }: { label: string; value: string }) {
  return <div className="min-w-0 rounded-2xl border border-white/10 bg-white/[0.055] px-3 py-3"><p className="truncate text-[0.58rem] font-black uppercase tracking-[0.16em] text-slate-500">{label}</p><p className="mt-1 truncate text-sm font-black text-white">{value}</p></div>;
}

function MenuCard({ icon: Icon, label, caption, color, onClick }: { icon: LucideIcon; label: string; caption: string; color: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="cc-menu-card group min-h-[7.2rem] rounded-[1.45rem] border border-white/10 bg-white/[0.045] p-3 text-left shadow-xl shadow-black/15 transition hover:-translate-y-0.5 hover:bg-white/[0.075] active:scale-95 sm:p-4">
      <div className={`mb-3 flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br ${color} text-[#06101d] shadow-lg shadow-black/20 transition group-hover:scale-105`}>
        <Icon className="h-5 w-5" />
      </div>
      <p className="text-[0.74rem] font-black leading-tight text-white sm:text-sm">{label}</p>
      <p className="mt-1 hidden text-[10px] font-bold leading-4 text-slate-500 sm:block">{caption}</p>
    </button>
  );
}

function SideKpi({ icon: Icon, label, value, tone = 'text-cyan-200' }: { icon: LucideIcon; label: string; value: string; tone?: string }) {
  return <div className="rounded-[1.35rem] border border-white/10 bg-white/[0.055] p-4 shadow-xl shadow-black/15 backdrop-blur-xl"><Icon className={`h-6 w-6 ${tone}`} /><p className="mt-3 text-[0.62rem] font-black uppercase tracking-[0.16em] text-slate-500">{label}</p><p className="mt-1 text-2xl font-black text-white">{value}</p></div>;
}

function SideCard({ icon: Icon, title, text }: { icon: LucideIcon; title: string; text: string }) {
  return (
    <div className="rounded-[1.65rem] border border-white/10 bg-white/[0.055] p-5 shadow-xl shadow-black/20 backdrop-blur-xl">
      <Icon className="mb-4 h-9 w-9 text-cyan-200" />
      <p className="font-black">{title}</p>
      <p className="mt-1 text-sm leading-6 text-slate-400">{text}</p>
    </div>
  );
}

function NavItem({ icon: Icon, label, active, badge, onClick }: { icon: LucideIcon; label: string; active?: boolean; badge?: number; onClick: () => void }) {
  return (
    <button onClick={onClick} className={`flex min-w-12 flex-col items-center gap-1 rounded-2xl px-2 py-1 transition ${active ? 'text-cyan-300' : 'text-slate-500'}`}>
      <span className={`relative flex h-9 w-9 items-center justify-center rounded-2xl ${active ? 'bg-cyan-300/15' : ''}`}>
        <Icon className="h-5 w-5" />
        {badge ? <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[8px] font-black text-white">{badge}</span> : null}
      </span>
      <span className="text-[10px] font-black">{label}</span>
    </button>
  );
}

export default Dashboard;
