# CrewCheck v12.5.73 — True Zero UI Final Mockup Alignment

Versão de alinhamento visual baseada nos vídeos enviados pelo usuário.

## Correções principais
- Login reconstruído no padrão escuro premium aprovado, sem fundo claro genérico.
- Correção do override `prefers-color-scheme: light`, que deixava a tela de login clara mesmo com tema escuro.
- Header, pills Premium/Beta, card de login, rodapé e wallpaper ajustados ao mockup aprovado.
- Mais contraste no Cockpit/Roster/Saída/Alertas/Configurações.
- Mantém funcionalidades, rota `/result`, manutenção admin e cache/PWA atualizados.

## Versão
- Web: 12.5.73
- Android versionName: 12.5.73
- Android versionCode: 125730
