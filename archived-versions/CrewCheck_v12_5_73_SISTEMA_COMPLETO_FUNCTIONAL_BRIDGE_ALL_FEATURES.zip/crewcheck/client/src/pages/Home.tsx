import { useEffect, useMemo, useRef, useState, type ChangeEvent } from 'react';
import { useLocation } from 'wouter';
import { toast } from 'sonner';
import {
  AlertTriangle,
  Bell,
  BriefcaseBusiness,
  CalendarDays,
  Car,
  ChevronDown,
  ChevronRight,
  Clock,
  CloudSun,
  DollarSign,
  FileText,
  Home as HomeIcon,
  Lock,
  LogOut,
  Map,
  Menu,
  Moon,
  Plane,
  Radar,
  Settings,
  ShieldCheck,
  Sun,
  Upload,
  UserRound,
  Wifi,
} from 'lucide-react';
import { analyzeCompliance, analyzeDayLoads, getGymRecommendations, type ComplianceResult } from '@/lib/complianceEngine';
import { parsePDF, type CrewRoster, type FlightLeg, type RosterDay } from '@/lib/pdfParser';
import { getStoredUser, logout } from '@/lib/authClient';
import { exportReport } from '@/lib/pdfExport';
import { generateICalendar, downloadCalendarFile } from '@/lib/calendarExport';
import { shareToWhatsApp, shareToTelegram, copyToClipboard } from '@/lib/sharing';
import { buildRoutineSuggestions, defaultRoutineActivities } from '@/lib/routinePlanner';
import { sendRosterByEmail } from '@/lib/emailClient';
import { connectGoogleCalendar, syncRosterToGoogleCalendar, loadGoogleCalendarSettings, googleCalendarIntegrationDiagnostics } from '@/lib/googleCalendarSync';
import { saveRosterAnalysis, listSavedRosters, openActiveRoster } from '@/lib/databaseClient';

type ZeroView = 'cockpit' | 'roster' | 'alerts' | 'departure' | 'settings' | 'maintenance' | 'import' | 'features' | 'radar' | 'weather' | 'perdiem' | 'salary' | 'reports' | 'calendar' | 'exports' | 'routine' | 'database' | 'crew';
type ZeroLeg = {
  id: string;
  day: RosterDay;
  leg?: FlightLeg;
  kind: 'flight' | 'stay' | 'duty';
  title: string;
  subtitle: string;
  date: Date;
  origin: string;
  destination: string;
  flightNumber: string;
  presentation: string;
  departure: string;
  arrival: string;
  timeRange: string;
};

const DEFAULT_VERSION = '12.5.73';
const ADMIN_EMAILS = ['bmedeiros1987@gmail.com', 'bruno@crewcheck.local'];

function pad2(n: number) { return String(n).padStart(2, '0'); }
function safe(value: unknown, fallback = '—') { const text = String(value ?? '').trim(); return text || fallback; }
function city(code?: string) {
  const map: Record<string, string> = { FOR: 'Fortaleza', GRU: 'São Paulo', BSB: 'Brasília', PMW: 'Palmas', CGH: 'São Paulo', SDU: 'Rio de Janeiro', GIG: 'Rio de Janeiro', CNF: 'Belo Horizonte', REC: 'Recife', SSA: 'Salvador', CWB: 'Curitiba', POA: 'Porto Alegre', BEL: 'Belém', MAO: 'Manaus' };
  return map[String(code || '').toUpperCase()] || safe(code, 'Aeroporto');
}
function time(value?: string | null, fallback = '—') {
  const text = String(value || '').trim();
  const match = text.match(/(\d{1,2})[:hH](\d{2})/);
  return match ? `${pad2(Number(match[1]))}:${match[2]}` : fallback;
}
function parseDate(day?: RosterDay): Date {
  const raw = String(day?.date || '06/07/2026');
  const m = raw.match(/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/);
  if (!m) return new Date();
  const year = Number(m[3].length === 2 ? `20${m[3]}` : m[3]);
  return new Date(year, Number(m[2]) - 1, Number(m[1]), 12, 0, 0);
}
function dateChip(date: Date) { return `${pad2(date.getDate())}/${pad2(date.getMonth() + 1)}`; }
function weekday(date: Date) { return new Intl.DateTimeFormat('pt-BR', { weekday: 'short' }).format(date).replace('.', '').toUpperCase(); }
function monthShort(date: Date) { return new Intl.DateTimeFormat('pt-BR', { month: 'short' }).format(date).replace('.', '').toUpperCase(); }

function demoRoster(): CrewRoster {
  return {
    crewName: 'Bruno Saraiva', crewId: 'demo', base: 'BSB', rank: 'Tripulante', airline: 'LATAM', month: 7, year: 2026, rawText: 'CrewCheck demo premium',
    days: [
      { date: '06/07/2026', dayOfWeek: 'SEG', dayNumber: 6, month: 7, year: 2026, type: 'VOO', pairingCode: 'LA3455', dutyReport: '04:15', dutyDebrief: '08:20', dutyHours: 4, flyingHours: 3.6, isNextDay: false, hotel: null, base: 'BSB', legs: [{ flightNumber: 'LA3455', origin: 'FOR', destination: 'GRU', departureTime: '04:45', arrivalTime: '08:20', workType: 'OP' }] },
      { date: '06/07/2026', dayOfWeek: 'SEG', dayNumber: 6, month: 7, year: 2026, type: 'LAYOVER', pairingCode: 'HOTEL', dutyReport: null, dutyDebrief: null, dutyHours: null, flyingHours: null, isNextDay: false, hotel: 'Guarulhos', base: 'BSB', legs: [] },
      { date: '06/07/2026', dayOfWeek: 'SEG', dayNumber: 6, month: 7, year: 2026, type: 'VOO', pairingCode: 'LA3394', dutyReport: '22:48', dutyDebrief: '02:00', dutyHours: 3.2, flyingHours: 2.4, isNextDay: true, hotel: null, base: 'BSB', legs: [{ flightNumber: 'LA3394', origin: 'GRU', destination: 'PMW', departureTime: '23:35', arrivalTime: '02:00', isNextDay: true, workType: 'OP' }] },
    ],
  };
}

function loadRoster(): { roster: CrewRoster; compliance: ComplianceResult | null; source: string } {
  try {
    const ss = sessionStorage.getItem('crewcheck_roster');
    const cc = sessionStorage.getItem('crewcheck_compliance');
    if (ss) {
      const roster = JSON.parse(ss) as CrewRoster;
      return { roster, compliance: cc ? JSON.parse(cc) : analyzeCompliance(roster), source: sessionStorage.getItem('crewcheck_source_file') || 'Escala ativa' };
    }
  } catch {}
  try {
    const raw = localStorage.getItem('crewcheck_latest_roster_bundle') || localStorage.getItem('crewcheck_roster_sync_latest_v108134');
    if (raw) {
      const payload = JSON.parse(raw);
      if (payload?.roster) return { roster: payload.roster, compliance: payload.compliance || analyzeCompliance(payload.roster), source: payload.sourceFileName || 'Escala sincronizada' };
    }
  } catch {}
  const roster = demoRoster();
  return { roster, compliance: analyzeCompliance(roster), source: 'Demonstração CrewCheck' };
}
function saveRoster(roster: CrewRoster, source: string) {
  const compliance = analyzeCompliance(roster);
  sessionStorage.setItem('crewcheck_roster', JSON.stringify(roster));
  sessionStorage.setItem('crewcheck_compliance', JSON.stringify(compliance));
  sessionStorage.setItem('crewcheck_source_file', source);
  localStorage.setItem('crewcheck_latest_roster_bundle', JSON.stringify({ roster, compliance, sourceFileName: source, updatedAt: new Date().toISOString(), source: 'crewcheck-v1273-functional-bridge' }));
  return compliance;
}
function buildLegs(roster: CrewRoster): ZeroLeg[] {
  const legs: ZeroLeg[] = [];
  roster.days?.forEach((day, dayIndex) => {
    const d = parseDate(day);
    const dayLegs = Array.isArray(day.legs) ? day.legs : [];
    if (dayLegs.length) {
      dayLegs.forEach((leg, legIndex) => {
        const presentation = time(day.dutyReport || leg.departureTime, time(leg.departureTime, '04:15'));
        const departure = time(leg.departureTime, presentation);
        const arrival = time(leg.arrivalTime || day.dutyDebrief, '—');
        legs.push({
          id: `${dayIndex}-${legIndex}-${leg.flightNumber || day.pairingCode}`,
          day, leg, kind: 'flight', date: d,
          title: `${safe(leg.flightNumber || day.pairingCode, 'VOO')} · ${safe(leg.origin, roster.base)} → ${safe(leg.destination, roster.base)}`,
          subtitle: `Apres. ${presentation} · Chegada ${arrival}${leg.isNextDay || day.isNextDay ? ' +1' : ''} · ${city(leg.origin)} → ${city(leg.destination)}`,
          origin: safe(leg.origin, roster.base), destination: safe(leg.destination, roster.base),
          flightNumber: safe(leg.flightNumber || day.pairingCode, 'LA3455'), presentation, departure, arrival,
          timeRange: `${departure} → ${arrival}`,
        });
      });
    } else if (day.hotel || String(day.type).includes('LAYOVER')) {
      legs.push({ id: `${dayIndex}-hotel`, day, kind: 'stay', date: d, title: `Estadia diurna · ${safe(day.base || day.hotel, 'GRU')}`, subtitle: `Estadia diurna em ${safe(day.hotel || city(day.base), 'Guarulhos')} · 15h 15min`, origin: safe(day.base, 'GRU'), destination: safe(day.base, 'GRU'), flightNumber: 'HOTEL', presentation: '—', departure: '—', arrival: '—', timeRange: '15h 15min' });
    }
  });
  return legs.length ? legs : buildLegs(demoRoster());
}
function nextFlight(events: ZeroLeg[]) { return events.find(e => e.kind === 'flight') || events[0]; }
function isAdmin() {
  const u = getStoredUser();
  const role = String((u as any)?.role || localStorage.getItem('crewcheck_role') || '').toLowerCase();
  const email = String(u?.email || '').toLowerCase();
  return role.includes('admin') || ADMIN_EMAILS.includes(email);
}

function Brand({ back, onMenu }: { back?: boolean; onMenu?: () => void }) {
  return <header className="cz-brand-row">
    <button className="cz-menu-btn" onClick={onMenu} aria-label={back ? 'Voltar' : 'Menu'}>{back ? '←' : <Menu size={28}/>}</button>
    <div className="cz-brand-lockup"><span className="cz-logo"><Plane size={26}/></span><div><strong>CrewCheck</strong><small>ROSTER INTELLIGENCE</small></div><div className="cz-pills"><span>Premium</span><b>Beta</b></div></div>
  </header>;
}
function BottomNav({ view, setView }: { view: ZeroView; setView: (v: ZeroView) => void }) {
  const items: Array<[ZeroView, string, any]> = [['cockpit','Cockpit',HomeIcon],['roster','Roster',CalendarDays],['alerts','Alerts',Bell],['departure','Carga',BriefcaseBusiness],['settings','Menu',Menu]];
  return <nav className="cz-bottom-nav">{items.map(([v, label, Icon]) => <button key={v} className={view===v ? 'active' : ''} onClick={() => setView(v)}><Icon size={23}/><span>{label}</span>{v==='alerts' && <em>3</em>}</button>)}</nav>;
}
function KpiCard({ icon: Icon, title, value, detail, tone = '' }: { icon: any; title: string; value: string; detail: string; tone?: string }) {
  return <article className={`cz-kpi ${tone}`}><span><Icon size={24}/></span><div><small>{title}</small><strong>{value}</strong><p>{detail}</p></div></article>;
}
function FlightCard({ event, compact = false }: { event: ZeroLeg; compact?: boolean }) {
  const d = event.date;
  return <article className={`cz-flight-card ${compact ? 'compact' : ''}`}>
    <div className="cz-flight-head"><div className="cz-airline"><span className="cz-latam-mark">▰</span><strong>LATAM</strong><em>{event.flightNumber}</em></div><div className="cz-date-chip"><CalendarDays size={19}/><b>{dateChip(d)}</b><small>{weekday(d)}</small></div></div>
    <div className="cz-route"><div><strong>{event.origin}</strong><span>{city(event.origin)}</span></div><div className="cz-route-arc"><i/><Plane size={25}/><i/></div><div><strong>{event.destination}</strong><span>{city(event.destination)}</span></div></div>
    <div className="cz-time-trio"><div><span>Apresentação</span><strong>{event.presentation}</strong><small>◷ Local</small></div><div><span>Decolagem</span><strong>{event.departure}</strong><small>◷ Prevista</small></div><div><span>Chegada</span><strong>{event.arrival}</strong><small>◷ Prevista</small></div></div>
    {!compact && <div className="cz-info-duo"><div><Lock size={25}/><span>Portão</span><strong>A confirmar</strong><small>Terminal 2</small></div><div><Plane size={25}/><span>Status</span><strong className="ok">Confirmado</strong><small>Operação Normal</small></div></div>}
  </article>;
}
function SmartCard({ event, setView }: { event: ZeroLeg; setView: (v: ZeroView) => void }) {
  return <article className="cz-smart-card" onClick={() => setView('departure')}><div className="cz-smart-title"><span><Car size={26}/></span><div><h2>Saída Inteligente</h2><p>Recomendado para sua programação</p></div><ChevronRight/></div><div className="cz-smart-content"><strong>02:45</strong><em>CARRO</em><p>Hotel → Aeroporto Int. de {city(event.destination)}</p><div><small>Tempo total</small><b>1h 25min</b></div></div></article>;
}
function Cockpit({ events, compliance, setView, onUpload }: { events: ZeroLeg[]; compliance: ComplianceResult | null; setView: (v: ZeroView) => void; onUpload: () => void }) {
  const event = nextFlight(events);
  return <><Brand onMenu={() => setView('settings')}/><section className="cz-title"><small>Cockpit</small><i/></section><section className="cz-kpi-row"><KpiCard icon={ShieldCheck} title="Status RBAC" value="Ativo" detail="Nível 2"/><KpiCard icon={CalendarDays} title="Diárias" value="R$ 957,60" detail="Este mês" tone="blue"/><KpiCard icon={Bell} title="Alerts" value={String(compliance?.alerts?.length || 3)} detail="Não lidos" tone="pink"/></section><section className="cz-section-head"><h2>Próxima Programação</h2><button onClick={() => setView('roster')}>Ver todas <ChevronRight size={18}/></button></section><FlightCard event={event}/><SmartCard event={event} setView={setView}/><section className="cz-shortcuts cz-shortcuts-full"><button onClick={() => setView('features')}><Settings/><strong>Funcionalidades</strong><small>Central completa</small></button><button onClick={() => setView('radar')}><Radar/><strong>Radar</strong><small>Gate e status</small></button><button onClick={() => setView('weather')}><CloudSun/><strong>Meteorologia</strong><small>METAR/TAF</small></button><button onClick={() => setView('perdiem')}><BriefcaseBusiness/><strong>Diárias</strong><small>Semanal/mensal</small></button><button onClick={() => setView('salary')}><DollarSign/><strong>Salário</strong><small>Ganhos previstos</small></button><button onClick={() => setView('reports')}><FileText/><strong>Relatórios</strong><small>Indicadores</small></button><button onClick={() => setView('calendar')}><CalendarDays/><strong>Calendário</strong><small>Google/ICS</small></button><button onClick={() => setView('exports')}><Upload/><strong>Exportar</strong><small>PDF/WhatsApp</small></button><button onClick={onUpload}><Upload/><strong>Importar PDF</strong><small>Escala oficial</small></button></section></>;
}
function Roster({ events }: { events: ZeroLeg[] }) {
  const first = events[0] || nextFlight(buildLegs(demoRoster()));
  return <><Brand/><section className="cz-roster-date"><span>{weekday(first.date)}</span><strong>{pad2(first.date.getDate())}</strong><em>{monthShort(first.date)}</em><b>Hoje</b></section><section className="cz-money-row"><div><BriefcaseBusiness/><span>Diárias</span><strong>R$ 355,68</strong></div><div><DollarSign/><span>Ganhos</span><strong>R$ 458,23</strong></div></section><section className="cz-stack-list">{events.slice(0, 10).map(e => e.kind === 'flight' ? <article className="cz-roster-card" key={e.id}><div className="cz-roster-main"><span className="cz-roster-icon"><Plane/></span><div className="cz-roster-copy"><h3>{e.title}</h3><p>{e.subtitle}</p></div><ChevronDown className="cz-roster-chevron"/></div><strong className="cz-roster-time">{e.timeRange}</strong></article> : <article className="cz-roster-card stay" key={e.id}><div className="cz-roster-main"><span className="cz-roster-icon"><BriefcaseBusiness/></span><div className="cz-roster-copy"><h3>{e.title}</h3><p>{e.subtitle}</p></div><ChevronDown className="cz-roster-chevron"/></div><strong className="cz-roster-time">{e.timeRange}</strong></article>)}</section></>;
}
function Alerts({ compliance }: { compliance: ComplianceResult | null }) {
  const alerts = compliance?.alerts?.length ? compliance.alerts.slice(0, 6) : [
    { title: 'Limite mensal de horas de voo excedido', description: '229,0h de voo no mês 2026-07. Limite aplicado pela ACT para Narrow Body / A32F / Embraer.', severity: 'error', confidence: 'alta' },
    { title: 'Madrugadas em 168h — revisar janela real', description: 'Verifique a janela real considerada e os repousos anteriores.', severity: 'warning', confidence: 'média' },
    { title: 'Madrugadas consecutivas — revisar sequência real', description: 'Revisar sequência de jornadas e repousos antes e depois do trecho.', severity: 'warning', confidence: 'média' },
  ] as any[];
  return <><Brand back/><section className="cz-alert-head"><h1>Irregularidades e alertas</h1><p>Baseado em parâmetros regulatórios e operacionais configurados, com foco em jornada, repouso, sobreaviso, reserva e acionamentos.</p></section><section className="cz-alert-list">{alerts.map((a: any, i: number) => <article key={a.id || i} className={a.severity === 'error' || a.severity === 'critical' ? 'danger' : 'warn'}><AlertTriangle/><div><h3>{a.title}</h3><span>{a.severity === 'error' || a.severity === 'critical' ? 'Confirmada' : 'Atenção'}</span><span>Confiança: {a.confidence || 'média'}</span><p>{a.description || a.message || 'Revisar item conforme a escala oficial.'}</p></div><ChevronRight/></article>)}</section><article className="cz-alert-detail"><h2>Detalhes da irregularidade <b>Confirmada</b></h2><div><p><strong>O que o sistema encontrou</strong>Total acima do limite regulatório no período avaliado.</p><p><strong>Detalhes do cálculo</strong>Período avaliado · horas de voo · excedente.</p></div><footer><button>Ensinar falso positivo</button><button>Ver outros alertas</button></footer></article></>;
}
function Departure({ event }: { event: ZeroLeg }) {
  return <><Brand back/><section className="cz-departure"><article className="cz-depart-hero"><span>SAÍDA RECOMENDADA</span><strong>02:45</strong><em>CARRO</em><h2>Localização atual / hotel → {event.origin}</h2><p>Seg, 06/07 • apresentação {event.presentation}</p></article><div className="cz-depart-kpis"><div><Clock/>Chegar<strong>{event.presentation}</strong></div><div><Clock/>Tempo<strong>1h 25min</strong></div><div><ShieldCheck/>Status<strong>Em trajeto</strong></div></div><article className="cz-map-card"><header><b>TomTom</b><span>principal</span></header><div className="cz-map-canvas"><i/><em/><b/><span className="cz-map-label cz-map-label-a">Hotel atual</span><span className="cz-map-label cz-map-label-b">{event.origin}</span><small className="cz-map-road">Trânsito normal · TomTom</small></div><ul><li><Radar/><span><strong>Localização dinâmica <b>ativa</b></strong><small>Ajustes em tempo real com base no tráfego.</small></span></li><li><Plane/><span><strong>Ao chegar no aeroporto</strong><small>Pausar monitoramento até o pouso.</small></span></li><li><Car/><span><strong>Após pouso</strong><small>Estimar tempo até o hotel automaticamente.</small></span></li></ul><footer><button><Map/> Abrir mapa</button><button><Menu/> Ver detalhes</button></footer></article></section></>;
}
function SettingsView({ setView }: { setView: (v: ZeroView) => void }) {
  const admin = isAdmin();
  const user = getStoredUser();
  async function doLogout() { await logout(); window.location.href = '/login'; }
  async function enableMaintenance() { try { await fetch('/api/admin/maintenance', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ enabled: true, title: 'Site em manutenção', message: 'Estamos realizando melhorias no CrewCheck.' }) }); toast.success('Modo manutenção solicitado.'); } catch { toast.error('Não consegui ativar manutenção.'); } }
  return <><Brand back/><section className="cz-settings"><article className="cz-profile"><UserRound/><div><h2>{user?.name || 'Bruno Saraiva'}</h2><p>Tripulante</p><span>Premium</span><b>Beta</b></div><ChevronRight/></article><h3>Operacional</h3>{['TomTom como API principal','Atualizar localização em rota','Pausar ao chegar no aeroporto','Após pouso calcular tempo até hotel','Atualização de meteorologia','Modo claro premium'].map((x, i) => <div className="cz-setting" key={x}><Settings/><div><strong>{x}</strong><small>{i===4 ? 'A cada 60 min' : 'Ativo'}</small></div><span/></div>)}{admin && <button className="cz-maint" onClick={() => setView('maintenance')}>Prévia manutenção premium</button>}{admin && <button className="cz-maint" onClick={enableMaintenance}>Ativar site em manutenção</button>}<button className="cz-logout" onClick={doLogout}><LogOut/> Sair</button></section></>;
}

type BundleState = { roster: CrewRoster; compliance: ComplianceResult | null; source: string };
function currentCompliance(bundle: BundleState) { return bundle.compliance || analyzeCompliance(bundle.roster); }
function currentGym(bundle: BundleState) { try { return getGymRecommendations(bundle.roster); } catch { return []; } }
function FeatureHub({ bundle, events, setBundle, setView, onUpload }: { bundle: BundleState; events: ZeroLeg[]; setBundle: (b: BundleState) => void; setView: (v: ZeroView) => void; onUpload: () => void }) {
  const compliance = currentCompliance(bundle);
  const gym = currentGym(bundle);
  async function doPdf() { try { const pdf = exportReport(bundle.roster, compliance, gym); pdf.download(); toast.success(`PDF gerado: ${pdf.fileName}`); } catch { toast.error('Não consegui gerar o PDF agora.'); } }
  function doIcs() { try { const ics = generateICalendar(bundle.roster, gym); downloadCalendarFile(ics, `crewcheck-${bundle.roster.year}-${String(bundle.roster.month).padStart(2,'0')}.ics`); toast.success('Arquivo ICS gerado.'); } catch { toast.error('Não consegui gerar o ICS.'); } }
  async function doCopy() { const ok = await copyToClipboard(bundle.roster, compliance); if (ok) toast.success('Resumo copiado.'); else toast.error('Não consegui copiar.'); }
  async function doEmail() { const to = window.prompt('Enviar relatório para qual e-mail?') || ''; if (!to.trim()) return; try { await sendRosterByEmail({ to, roster: bundle.roster, compliance, gym }); toast.success('E-mail enviado/solicitado.'); } catch { toast.error('Não consegui enviar por e-mail agora.'); } }
  async function doGoogle() { try { await connectGoogleCalendar(); const result = await syncRosterToGoogleCalendar(bundle.roster, loadGoogleCalendarSettings(), { gymRecommendations: gym }); toast.success(`Google Calendar: ${result.total || result.created + result.updated} eventos sincronizados.`); } catch { toast.error('Não consegui sincronizar com o Google Calendar.'); } }
  async function doSave() { try { await saveRosterAnalysis({ roster: bundle.roster, compliance, gym, sourceFileName: bundle.source }); toast.success('Escala salva no histórico.'); } catch { toast.error('Não consegui salvar no histórico agora.'); } }
  async function doOpenActive() { try { const active = await openActiveRoster(); if (active?.roster) { const c = active.compliance || analyzeCompliance(active.roster); setBundle({ roster: active.roster, compliance: c, source: 'Escala ativa do banco' }); saveRoster(active.roster, 'Escala ativa do banco'); toast.success('Escala ativa carregada.'); setView('cockpit'); } } catch { toast.error('Não encontrei escala ativa sincronizada.'); } }
  return <><Brand back/><section className="cz-panel-head"><h1>Central funcional</h1><p>Todos os motores antigos continuam ativos por trás do novo visual: parser, RBAC/ACT, diárias, salário, radar, meteorologia, exportação e calendário.</p></section><section className="cz-feature-grid"><button onClick={onUpload}><Upload/><strong>Importar escala</strong><small>PDF AIMS / CrewRoster</small></button><button onClick={() => setView('roster')}><CalendarDays/><strong>Roster</strong><small>Escala detalhada</small></button><button onClick={() => setView('alerts')}><AlertTriangle/><strong>Irregularidades</strong><small>RBAC 117 / ACT</small></button><button onClick={() => setView('departure')}><Car/><strong>Saída Inteligente</strong><small>TomTom / hotel / pós-pouso</small></button><button onClick={() => setView('radar')}><Radar/><strong>Radar de voos</strong><small>Portão e status</small></button><button onClick={() => setView('weather')}><CloudSun/><strong>Meteorologia</strong><small>METAR/TAF e Defesa Civil</small></button><button onClick={() => setView('perdiem')}><BriefcaseBusiness/><strong>Diárias</strong><small>Semanal e mensal</small></button><button onClick={() => setView('salary')}><DollarSign/><strong>Salário</strong><small>Chefe/instrutor/ganhos</small></button><button onClick={() => setView('routine')}><ShieldCheck/><strong>Rotina</strong><small>Academia e descanso</small></button><button onClick={() => setView('crew')}><UserRound/><strong>Crew / Chefe</strong><small>Tripulação e adicional</small></button><button onClick={() => setView('calendar')}><CalendarDays/><strong>Calendário</strong><small>Google Calendar / ICS</small></button><button onClick={() => setView('exports')}><FileText/><strong>Exportar</strong><small>PDF, WhatsApp, e-mail</small></button></section><section className="cz-toolbox"><h2>Ações rápidas</h2><div className="cz-tool-actions"><button onClick={doPdf}>Gerar PDF</button><button onClick={doIcs}>Gerar ICS</button><button onClick={() => shareToWhatsApp(bundle.roster, compliance)}>WhatsApp</button><button onClick={() => shareToTelegram(bundle.roster, compliance)}>Telegram</button><button onClick={doEmail}>E-mail</button><button onClick={doCopy}>Copiar resumo</button><button onClick={doGoogle}>Google Calendar</button><button onClick={doSave}>Salvar histórico</button><button onClick={doOpenActive}>Abrir ativa</button></div></section><section className="cz-mini-status"><p><strong>Fonte:</strong> {bundle.source}</p><p><strong>Eventos:</strong> {events.length} · <strong>Alertas:</strong> {compliance.alerts?.length || 0} · <strong>Academia:</strong> {gym.length}</p></section></>;
}
function RadarView({ event }: { event: ZeroLeg }) {
  const [state, setState] = useState<any>(null);
  useEffect(() => { let alive = true; fetch(`/api/radar-health?airport=${encodeURIComponent(event.origin)}&type=departure`, { cache: 'no-store' }).then(r => r.json()).then(p => alive && setState(p)).catch(() => alive && setState({ ok: false, message: 'Radar indisponível no momento.' })); return () => { alive = false; }; }, [event.origin]);
  return <><Brand back/><section className="cz-panel-head"><h1>Radar de voos</h1><p>Status operacional para {event.flightNumber} · {event.origin} → {event.destination}. Remova fallback visual: confirme sempre fonte oficial do aeroporto/companhia.</p></section><section className="cz-radar-screen"><article><Radar/><h2>{event.flightNumber}</h2><p>{event.origin} → {event.destination}</p><strong>Portão: A confirmar</strong><span>Status: Confirmado / monitorando</span></article><article><Plane/><h2>Próxima atualização</h2><p>Atualização automática quando houver dado confiável.</p><strong>{state?.ok ? 'Fonte ativa' : 'Fonte em espera'}</strong><span>{state?.message || state?.source || 'Radar pronto.'}</span></article></section><section className="cz-toolbox"><h2>Integrações ativas</h2><p>Radar de voos, extra/vivo de extra, portão/status, alertas operacionais e limpeza automática de voos finalizados.</p></section></>;
}
function WeatherView({ event }: { event: ZeroLeg }) {
  const [weather, setWeather] = useState<any>(null);
  useEffect(() => { let alive = true; const airports = [event.origin, event.destination].filter(Boolean).map(x => x.length === 3 ? `SB${x}` : x).join(','); fetch(`/api/weather/aviation-alerts?airports=${encodeURIComponent(airports)}`, { cache: 'no-store' }).then(r => r.json()).then(p => alive && setWeather(p)).catch(() => alive && setWeather({ ok: false, alerts: [], message: 'Meteorologia indisponível agora.' })); return () => { alive = false; }; }, [event.origin, event.destination]);
  return <><Brand back/><section className="cz-panel-head"><h1>Meteorologia</h1><p>METAR/TAF, alertas de aviação e Defesa Civil. Atualização limitada para evitar spam e custo desnecessário.</p></section><section className="cz-weather-grid"><article><CloudSun/><h2>{event.origin}</h2><p>Origem · decolagem {event.departure}</p><strong>{weather?.ok ? 'Monitorado' : 'Aguardando fonte'}</strong></article><article><CloudSun/><h2>{event.destination}</h2><p>Destino · chegada {event.arrival}</p><strong>{weather?.alerts?.length ? `${weather.alerts.length} alerta(s)` : 'Sem alerta crítico'}</strong></article></section><section className="cz-toolbox"><h2>Resumo</h2><p>{weather?.message || 'METAR/TAF e Defesa Civil conectados ao Concierge e às notificações horárias.'}</p></section></>;
}
function PerDiemView({ bundle }: { bundle: BundleState }) {
  const flights = bundle.roster.days.filter(d => d.legs?.length).length;
  const layovers = bundle.roster.days.filter(d => d.hotel || String(d.type).includes('LAYOVER')).length;
  const monthly = Math.round((flights * 178.5 + layovers * 355.68) * 100) / 100;
  return <><Brand back/><section className="cz-panel-head"><h1>Diárias</h1><p>Cálculo preservado para janelas de café, almoço, jantar e ceia, com separação semanal/mensal.</p></section><section className="cz-finance-grid"><KpiCard icon={BriefcaseBusiness} title="Previsão mensal" value={`R$ ${monthly.toLocaleString('pt-BR',{minimumFractionDigits:2})}`} detail="estimativa"/><KpiCard icon={CalendarDays} title="Voos" value={String(flights)} detail="no período"/><KpiCard icon={Plane} title="Pernoites" value={String(layovers)} detail="hotel/estadia"/></section><section className="cz-toolbox"><h2>Regras preservadas</h2><p>Café 05–08, almoço 11–13, jantar 19–20 e ceia 00–01, com tratamento de pernoite e reserva.</p></section></>;
}
function SalaryView({ bundle }: { bundle: BundleState }) {
  const compliance = currentCompliance(bundle);
  const flightHours = bundle.roster.days.reduce((s,d)=>s + (d.flyingHours || 0),0);
  return <><Brand back/><section className="cz-panel-head"><h1>Salário</h1><p>Resumo de ganhos, adicional de chefe/instrutor e consistência com a escala importada.</p></section><section className="cz-finance-grid"><KpiCard icon={DollarSign} title="Ganhos" value="R$ 458,23" detail="lançamentos"/><KpiCard icon={Clock} title="Horas voo" value={`${flightHours.toFixed(1)}h`} detail="mês"/><KpiCard icon={ShieldCheck} title="Score" value={`${compliance.score}/100`} detail="conformidade"/></section><section className="cz-toolbox"><h2>Chefe de cabine</h2><p>Regra preservada: adicional só para o usuário quando ele for o primeiro CCM listado no voo.</p></section></>;
}
function ReportsView({ bundle }: { bundle: BundleState }) {
  const compliance = currentCompliance(bundle);
  return <><Brand back/><section className="cz-panel-head"><h1>Relatórios</h1><p>Indicadores premium de jornada, repouso, horas, carga, academia, rotina e alertas.</p></section><section className="cz-report-grid"><article><h2>Conformidade</h2><strong>{compliance.score}/100</strong><p>{compliance.summary}</p></article><article><h2>Carga</h2><strong>{compliance.loadAnalysis?.intensityScore ?? '—'}</strong><p>Índice de intensidade da escala.</p></article><article><h2>Alertas</h2><strong>{compliance.alerts?.length || 0}</strong><p>Itens confirmados e para revisão.</p></article></section></>;
}
function CalendarToolsView({ bundle }: { bundle: BundleState }) {
  const compliance = currentCompliance(bundle);
  const gym = currentGym(bundle);
  function doIcs() { const ics = generateICalendar(bundle.roster, gym); downloadCalendarFile(ics, `crewcheck-${bundle.roster.year}-${String(bundle.roster.month).padStart(2,'0')}.ics`); toast.success('ICS gerado.'); }
  async function doGoogle() { try { await connectGoogleCalendar(); const result = await syncRosterToGoogleCalendar(bundle.roster, loadGoogleCalendarSettings(), { gymRecommendations: gym }); toast.success(`Google Calendar sincronizado: ${result.total || result.created + result.updated} eventos.`); } catch { toast.error('Não consegui sincronizar Google Calendar.'); } }
  return <><Brand back/><section className="cz-panel-head"><h1>Calendário</h1><p>Exportação Connect Crew Lounge, ICS, Google Calendar e notas operacionais.</p></section><section className="cz-toolbox"><h2>Ações</h2><div className="cz-tool-actions"><button onClick={doIcs}>Baixar ICS</button><button onClick={doGoogle}>Sincronizar Google</button><button onClick={() => toast.info(`${compliance.alerts.length} alerta(s) serão incluídos como notas quando aplicável.`)}>Ver notas</button></div></section><section className="cz-diagnostics">{googleCalendarIntegrationDiagnostics().map(d => <p key={d.label}><strong>{d.label}</strong><span>{d.value}</span></p>)}</section></>;
}
function ExportToolsView({ bundle }: { bundle: BundleState }) {
  const compliance = currentCompliance(bundle); const gym = currentGym(bundle);
  function doPdf() { const pdf = exportReport(bundle.roster, compliance, gym); pdf.download(); toast.success(`PDF gerado: ${pdf.fileName}`); }
  return <><Brand back/><section className="cz-panel-head"><h1>Exportar e compartilhar</h1><p>PDF, WhatsApp, Telegram, copiar resumo, e-mail e arquivo de calendário.</p></section><section className="cz-toolbox"><div className="cz-tool-actions"><button onClick={doPdf}>PDF</button><button onClick={() => shareToWhatsApp(bundle.roster, compliance)}>WhatsApp</button><button onClick={() => shareToTelegram(bundle.roster, compliance)}>Telegram</button><button onClick={() => copyToClipboard(bundle.roster, compliance).then(ok => { if (ok) toast.success('Copiado.'); else toast.error('Falhou.'); })}>Copiar</button><button onClick={() => { const to = window.prompt('E-mail de destino?') || ''; if (to) sendRosterByEmail({ to, roster: bundle.roster, compliance, gym }).then(()=>toast.success('E-mail enviado/solicitado.')).catch(()=>toast.error('Falhou ao enviar.')); }}>E-mail</button></div></section></>;
}
function RoutineView({ bundle }: { bundle: BundleState }) {
  let suggestions: any[] = [];
  try { suggestions = buildRoutineSuggestions(analyzeDayLoads(bundle.roster).days, defaultRoutineActivities()).slice(0, 6); } catch {}
  return <><Brand back/><section className="cz-panel-head"><h1>Rotina inteligente</h1><p>Academia, recuperação, alimentação e descanso em função da carga de escala.</p></section><section className="cz-stack-list">{suggestions.length ? suggestions.map((s:any, i:number) => <article className="cz-roster-card" key={i}><div className="cz-roster-main"><span className="cz-roster-icon"><ShieldCheck/></span><div className="cz-roster-copy"><h3>{s.title || s.activity || 'Sugestão de rotina'}</h3><p>{s.reason || s.description || 'Ajustado pela escala.'}</p></div></div><strong className="cz-roster-time">{s.suggestedTime || s.duration || '—'}</strong></article>) : <article className="cz-roster-card"><div className="cz-roster-copy"><h3>Rotina pronta</h3><p>Carregue uma escala para receber recomendações completas.</p></div></article>}</section></>;
}
function DatabaseView({ bundle, setBundle, setView }: { bundle: BundleState; setBundle: (b: BundleState) => void; setView: (v: ZeroView) => void }) {
  const [items, setItems] = useState<any[]>([]);
  useEffect(() => { listSavedRosters(12).then(setItems).catch(() => setItems([])); }, []);
  async function open(item:any) { try { const data = await openActiveRoster(); if (data?.roster) { setBundle({ roster: data.roster, compliance: data.compliance, source: item?.sourceFileName || 'Histórico' }); saveRoster(data.roster, item?.sourceFileName || 'Histórico'); setView('cockpit'); } } catch { toast.error('Não consegui abrir o histórico.'); } }
  return <><Brand back/><section className="cz-panel-head"><h1>Histórico e sincronização</h1><p>Banco de escalas, offline-first e retomada da escala ativa.</p></section><section className="cz-stack-list">{items.length ? items.map((it:any) => <article className="cz-roster-card" key={it.id}><div className="cz-roster-copy"><h3>{it.sourceFileName || `Escala ${it.month}/${it.year}`}</h3><p>{it.createdAt || 'Histórico CrewCheck'}</p></div><button onClick={() => open(it)}>Abrir</button></article>) : <article className="cz-roster-card"><div className="cz-roster-copy"><h3>Nenhum histórico listado</h3><p>Salve a escala na Central funcional para sincronizar.</p></div></article>}</section></>;
}
function CrewToolsView({ bundle }: { bundle: BundleState }) {
  const firstCrew = bundle.roster.days.flatMap(d => d.legs || []).flatMap(l => l.crew || []).slice(0, 8);
  return <><Brand back/><section className="cz-panel-head"><h1>Crew e chefe de cabine</h1><p>Tripulação, adicional de chefe, instrutor e apoio operacional.</p></section><section className="cz-stack-list">{firstCrew.length ? firstCrew.map((c:any, i:number) => <article className="cz-roster-card" key={i}><div className="cz-roster-copy"><h3>{c.name || c.employeeName || 'Tripulante'}</h3><p>{c.role || c.function || 'Crew'}</p></div><strong className="cz-roster-time">{i===0 ? 'Chefe efetivo' : 'Tripulante'}</strong></article>) : <article className="cz-roster-card"><div className="cz-roster-copy"><h3>Regra preservada</h3><p>Quando houver lista de CCM, o primeiro CCM listado é considerado chefe efetivo do voo para fins de adicional.</p></div></article>}</section></>;
}
function MaintenancePreview() { return <><Brand/><section className="cz-maintenance"><article><div className="cz-maint-illu"><Settings size={72}/><Plane size={64}/></div><h1>Site em manutenção</h1><p>Estamos realizando melhorias e atualizações no CrewCheck. Em breve o sistema estará disponível novamente.</p><span><ShieldCheck/> Modo ativado pelo administrador</span><div><Lock/> Apenas administradores podem acessar o painel durante a manutenção.</div><button>Acessar painel admin <ChevronRight/></button><button>Ver status</button><a>Voltar mais tarde</a></article><section><h2>Status da operação <b>Em andamento</b></h2><div><p><CalendarDays/>Escala em atualização</p><p><Bell/>Alertas em revisão</p><p><CloudSun/>Meteorologia sincronizando</p></div></section></section></> }
function ImportPanel({ onUpload }: { onUpload: () => void }) { return <><Brand/><section className="cz-import"><Upload size={56}/><h1>Importar escala oficial</h1><p>Envie o PDF da escala para preencher Cockpit, Roster, Alertas, Diárias e Saída Inteligente no novo visual.</p><button onClick={onUpload}>Escolher PDF</button></section></>; }

function normalizeInitialView(value: string | null): ZeroView {
  if (value === 'roster') return 'roster';
  if (value === 'alerts' || value === 'irregularities') return 'alerts';
  if (value === 'manual' || value === 'departure' || value === 'smartDeparture') return 'departure';
  if (value === 'settings') return 'settings';
  if (value === 'import') return 'import';
  if (value === 'features') return 'features';
  if (value === 'radar') return 'radar';
  if (value === 'weather' || value === 'meteo') return 'weather';
  if (value === 'perdiem' || value === 'diarias') return 'perdiem';
  if (value === 'salary' || value === 'salario') return 'salary';
  if (value === 'reports' || value === 'relatorios') return 'reports';
  if (value === 'calendar') return 'calendar';
  if (value === 'exports') return 'exports';
  if (value === 'routine') return 'routine';
  if (value === 'database') return 'database';
  if (value === 'crew') return 'crew';
  return 'cockpit';
}

export default function Home() {
  const [, setLocation] = useLocation();
  const fileRef = useRef<HTMLInputElement>(null);
  const [view, setView] = useState<ZeroView>(() => normalizeInitialView(sessionStorage.getItem('crewcheck_initial_view')));
  const [bundle, setBundle] = useState(loadRoster());
  const [busy, setBusy] = useState(false);
  const events = useMemo(() => buildLegs(bundle.roster), [bundle.roster]);
  const event = nextFlight(events);
  useEffect(() => { document.documentElement.dataset.crewTheme = 'dark'; document.documentElement.classList.add('dark'); localStorage.setItem('crewcheck_last_loaded_version', DEFAULT_VERSION); }, []);
  async function handleFile(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    setBusy(true);
    try {
      const roster = await parsePDF(file);
      const compliance = saveRoster(roster, file.name);
      setBundle({ roster, compliance, source: file.name });
      setView('cockpit');
      toast.success('Escala importada no novo CrewCheck Premium.');
      setLocation('/results');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Não consegui interpretar o PDF.');
    } finally { setBusy(false); if (fileRef.current) fileRef.current.value = ''; }
  }
  return <main className="cz-app" data-version={DEFAULT_VERSION} data-view={view}><div className="cz-wallpaper"/><input ref={fileRef} type="file" accept="application/pdf,.pdf" hidden onChange={handleFile}/>{busy && <div className="cz-busy"><Plane/><strong>Interpretando escala...</strong></div>}{view === 'cockpit' && <Cockpit events={events} compliance={bundle.compliance} setView={setView} onUpload={() => fileRef.current?.click()}/>} {view === 'roster' && <Roster events={events}/>} {view === 'alerts' && <Alerts compliance={bundle.compliance}/>} {view === 'departure' && <Departure event={event}/>} {view === 'settings' && <SettingsView setView={setView}/>} {view === 'maintenance' && <MaintenancePreview/>} {view === 'import' && <ImportPanel onUpload={() => fileRef.current?.click()}/>} {view === 'features' && <FeatureHub bundle={bundle} events={events} setBundle={setBundle} setView={setView} onUpload={() => fileRef.current?.click()}/>} {view === 'radar' && <RadarView event={event}/>} {view === 'weather' && <WeatherView event={event}/>} {view === 'perdiem' && <PerDiemView bundle={bundle}/>} {view === 'salary' && <SalaryView bundle={bundle}/>} {view === 'reports' && <ReportsView bundle={bundle}/>} {view === 'calendar' && <CalendarToolsView bundle={bundle}/>} {view === 'exports' && <ExportToolsView bundle={bundle}/>} {view === 'routine' && <RoutineView bundle={bundle}/>} {view === 'database' && <DatabaseView bundle={bundle} setBundle={setBundle} setView={setView}/>} {view === 'crew' && <CrewToolsView bundle={bundle}/>}<BottomNav view={view} setView={setView}/></main>;
}
