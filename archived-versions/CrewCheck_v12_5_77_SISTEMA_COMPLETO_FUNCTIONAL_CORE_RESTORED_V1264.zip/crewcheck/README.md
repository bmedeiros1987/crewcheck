# CrewCheck v12.5.77 — Functional Core Restored

Base funcional restaurada a partir da v12.5.64 estável enviada pelo usuário. Mantém parser, escala completa, rotina, METAR/TAF, radar, hotéis, academias, trânsito, saída inteligente, exportações e Android AAB corrigido.
