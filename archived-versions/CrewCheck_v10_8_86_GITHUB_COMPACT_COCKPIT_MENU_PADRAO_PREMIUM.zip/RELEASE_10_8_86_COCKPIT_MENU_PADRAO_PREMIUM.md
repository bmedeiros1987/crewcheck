# CrewCheck v10.8.86 — Cockpit Menu Padrão Premium

- Remove o menu hamburger/speed dial flutuante do Android/PWA.
- Move todos os módulos para uma Central CrewCheck dentro do Cockpit.
- Corrige abertura direta de Chefe de Cabine e Checklist Médico.
- Checklist Médico abre com rolagem automática para o formulário.
- Mantém menu inferior padrão único: Cockpit, Escala, iFlight, Saída e Conta.
- Padroniza visual da escala para não usar menu diferente do Cockpit.
- Atualiza versão interna para 10.8.86 e Android versionCode 10886.
