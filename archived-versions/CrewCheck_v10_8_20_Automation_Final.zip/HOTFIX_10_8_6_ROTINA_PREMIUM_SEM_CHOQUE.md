# CrewCheck v10.8.6 — Rotina Premium sem Choque

Melhorias desta versão:

- Rotina e descanso não aparecem mais misturados no mesmo bloco.
- Descanso/recuperação virou uma seção própria, com cor e texto próprios.
- Motor de rotina agora usa trava global de janelas por dia para evitar sobreposição entre treino, estudo, faculdade, personalizado e recuperação.
- Sugestões de rotina só são criadas quando a atividade cabe inteira dentro de uma janela livre.
- Margens de segurança continuam sendo aplicadas antes/depois de voo, reserva, sobreaviso e treinamento.
- Cards de escala separam “Rotina” de “Recuperação”.
- Próxima programação exibe status, terminal e portão somente quando for voo.
- Atividades que não são voo não exibem status, portão ou terminal.
- Exportação ICS diferencia “Rotina” de “Recuperação”.
- LGPD preservada: nenhuma senha corporativa é salva, nenhuma credencial do iFlight é enviada a provedores de status, e chaves de API seguem no backend/variáveis de ambiente.

Validado com:

```bash
npm run check
npm run build
```
