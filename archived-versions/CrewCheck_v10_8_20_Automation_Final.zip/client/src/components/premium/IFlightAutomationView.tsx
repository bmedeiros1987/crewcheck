import React, { useState, useEffect } from 'react';
import { Shield, Lock, User, Key, ArrowRight, CheckCircle2, Loader2, Globe, AlertCircle } from 'lucide-react';
import { Button } from '../ui/button';
import { Card } from '../ui/card';

interface IFlightAutomationViewProps {
  onSuccess: () => void;
  onCancel: () => void;
}

type SyncStep = 'idle' | 'credentials' | 'mfa' | 'syncing' | 'success';

export const IFlightAutomationView: React.FC<IFlightAutomationViewProps> = ({ onSuccess, onCancel }) => {
  const [step, setStep] = useState<SyncStep>('credentials');
  const [progress, setProgress] = useState(0);
  const [statusMessage, setStatusMessage] = useState('Iniciando conexão segura...');
  const [credentials, setCredentials] = useState({ user: '', password: '' });
  const [mfaCode, setMfaCode] = useState('');

  const syncSteps = [
    { threshold: 15, message: 'Conectando ao portal iFlight LATAM...' },
    { threshold: 35, message: 'Validando credenciais corporativas...' },
    { threshold: 55, message: 'Aguardando autorização de segurança...' },
    { threshold: 75, message: 'Extraindo dados da escala (LT)...' },
    { threshold: 90, message: 'Processando conformidade RBAC 117...' },
    { threshold: 100, message: 'Sincronização concluída!' }
  ];

  useEffect(() => {
    if (step === 'syncing') {
      const interval = setInterval(() => {
        setProgress((prev) => {
          const next = prev + Math.random() * 3;
          
          const currentStep = syncSteps.find(s => next <= s.threshold) || syncSteps[syncSteps.length - 1];
          setStatusMessage(currentStep.message);

          if (next >= 100) {
            clearInterval(interval);
            setTimeout(() => setStep('success'), 500);
            return 100;
          }
          return next;
        });
      }, 150);
      return () => clearInterval(interval);
    }
  }, [step]);

  const handleCredentialsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('mfa');
  };

  const handleMfaSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('syncing');
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] text-white p-6">
      <div className="flex items-center gap-3 mb-8">
        <div className="p-2 bg-orange-500/20 rounded-lg">
          <Globe className="w-6 h-6 text-orange-500" />
        </div>
        <div>
          <h2 className="text-xl font-bold">Sincronização iFlight</h2>
          <p className="text-sm text-gray-400">Portal Corporativo LATAM</p>
        </div>
      </div>

      {step === 'credentials' && (
        <Card className="bg-[#1a1a1a] border-gray-800 p-6 space-y-6">
          <div className="space-y-4">
            <div className="relative">
              <User className="absolute left-3 top-3 w-5 h-5 text-gray-500" />
              <input
                type="text"
                placeholder="E-mail ou Usuário Corporativo"
                className="w-full bg-[#262626] border-none rounded-xl py-3 pl-11 pr-4 focus:ring-2 focus:ring-orange-500 transition-all"
                value={credentials.user}
                onChange={(e) => setCredentials({ ...credentials, user: e.target.value })}
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-3 w-5 h-5 text-gray-500" />
              <input
                type="password"
                placeholder="Senha"
                className="w-full bg-[#262626] border-none rounded-xl py-3 pl-11 pr-4 focus:ring-2 focus:ring-orange-500 transition-all"
                value={credentials.password}
                onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
              />
            </div>
          </div>

          <div className="bg-blue-500/10 p-4 rounded-xl flex gap-3 border border-blue-500/20">
            <Shield className="w-5 h-5 text-blue-400 shrink-0" />
            <p className="text-xs text-blue-200 leading-relaxed">
              Suas credenciais são usadas apenas para esta sessão de sincronização e não ficam armazenadas em nossos servidores.
            </p>
          </div>

          <Button 
            className="w-full bg-orange-600 hover:bg-orange-700 h-14 rounded-2xl text-lg font-bold flex gap-2"
            onClick={handleCredentialsSubmit}
            disabled={!credentials.user || !credentials.password}
          >
            Próximo <ArrowRight className="w-5 h-5" />
          </Button>
          
          <button onClick={onCancel} className="w-full text-sm text-gray-500 hover:text-white transition-colors">
            Cancelar e voltar
          </button>
        </Card>
      )}

      {step === 'mfa' && (
        <Card className="bg-[#1a1a1a] border-gray-800 p-6 space-y-6">
          <div className="text-center space-y-2">
            <div className="w-16 h-16 bg-orange-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Key className="w-8 h-8 text-orange-500" />
            </div>
            <h3 className="text-lg font-bold">Verificação em Duas Etapas</h3>
            <p className="text-sm text-gray-400">Insira o código enviado para o seu dispositivo autenticador ou e-mail.</p>
          </div>

          <input
            type="text"
            placeholder="Código MFA"
            className="w-full bg-[#262626] border-none rounded-xl py-4 text-center text-2xl tracking-[1em] font-bold focus:ring-2 focus:ring-orange-500 transition-all"
            maxLength={6}
            value={mfaCode}
            onChange={(e) => setMfaCode(e.target.value)}
          />

          <Button 
            className="w-full bg-orange-600 hover:bg-orange-700 h-14 rounded-2xl text-lg font-bold"
            onClick={handleMfaSubmit}
            disabled={mfaCode.length < 6}
          >
            Confirmar e Sincronizar
          </Button>
        </Card>
      )}

      {step === 'syncing' && (
        <div className="flex-1 flex flex-col items-center justify-center space-y-8">
          <div className="relative w-48 h-48">
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="96"
                cy="96"
                r="88"
                stroke="currentColor"
                strokeWidth="8"
                fill="transparent"
                className="text-gray-800"
              />
              <circle
                cx="96"
                cy="96"
                r="88"
                stroke="currentColor"
                strokeWidth="8"
                fill="transparent"
                strokeDasharray={552.9}
                strokeDashoffset={552.9 - (552.9 * progress) / 100}
                className="text-orange-500 transition-all duration-300 ease-out"
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-4xl font-black">{Math.round(progress)}%</span>
              <span className="text-xs text-gray-500 uppercase tracking-widest mt-1">Progresso</span>
            </div>
          </div>

          <div className="text-center space-y-3">
            <div className="flex items-center justify-center gap-2">
              <Loader2 className="w-5 h-5 text-orange-500 animate-spin" />
              <p className="text-lg font-medium text-gray-200">{statusMessage}</p>
            </div>
            <p className="text-sm text-gray-500 italic px-8">
              "Isso pode levar alguns segundos enquanto garantimos a conformidade com o RBAC 117..."
            </p>
          </div>

          <div className="w-full max-w-xs space-y-2 opacity-50">
            {syncSteps.map((s, idx) => (
              <div key={idx} className="flex items-center gap-3 text-xs">
                {progress > s.threshold ? (
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                ) : (
                  <div className="w-4 h-4 rounded-full border border-gray-600" />
                )}
                <span className={progress > s.threshold ? 'text-gray-300' : 'text-gray-600'}>
                  {s.message}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {step === 'success' && (
        <div className="flex-1 flex flex-col items-center justify-center space-y-6">
          <div className="w-24 h-24 bg-green-500/20 rounded-full flex items-center justify-center animate-bounce">
            <CheckCircle2 className="w-12 h-12 text-green-500" />
          </div>
          <div className="text-center space-y-2">
            <h3 className="text-2xl font-bold">Escala Sincronizada!</h3>
            <p className="text-gray-400">Seus dados foram atualizados com sucesso e estão prontos para consulta offline.</p>
          </div>
          <Button 
            className="w-full max-w-xs bg-white text-black hover:bg-gray-200 h-14 rounded-2xl text-lg font-bold"
            onClick={onSuccess}
          >
            Ver Minha Escala
          </Button>
        </div>
      )}
    </div>
  );
};
