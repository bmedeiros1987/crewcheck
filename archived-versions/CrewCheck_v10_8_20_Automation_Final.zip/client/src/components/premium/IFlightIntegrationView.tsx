import React, { useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  CalendarDays,
  CheckCircle2,
  ChevronLeft,
  DownloadCloud,
  ExternalLink,
  FileText,
  Globe,
  Loader2,
  Lock,
  RefreshCw,
  ShieldCheck,
  Upload,
} from 'lucide-react';
import { toast } from 'sonner';
import type { CrewRoster } from '@/lib/pdfParser';

interface IFlightIntegrationViewProps {
  onBack: () => void;
  onSuccess: () => void;
  onFileUpload?: (file: File) => Promise<void>;
  onRosterImport?: (roster: CrewRoster, sourceFileName?: string) => Promise<void>;
}

type IFlightStatus = 'idle' | 'portal' | 'fetching' | 'success' | 'error';

type IFlightPortalOptions = {
  autoClicks: boolean;
  keepAuthorizedSession: boolean;
  silentPremiumPull: boolean;
  autoResumeAfterLogin: boolean;
  universalPdfCapture: boolean;
  maxAutomationMinutes: number;
  fromDate: string;
  toDate: string;
  periodMonth: string;
  periodYear: string;
  format: 'pdf';
  includeLegend: boolean;
  clickSend: false;
  privacyMode: 'lgpd_no_credentials';
  actions: string[];
};

type NativeIFlightPayload = {
  ok?: boolean;
  roster?: CrewRoster;
  dataBase64?: string;
  filename?: string;
  sourceFileName?: string;
  message?: string;
  error?: string;
};

declare global {
  interface Window {
    CrewCheckIFlight?: {
      openPortalAndImport?: (
        url: string,
        options?: IFlightPortalOptions,
      ) => Promise<NativeIFlightPayload | string> | NativeIFlightPayload | string;
    };
  }
}

const IFLIGHT_URL = 'https://iflightla.ibsplc.aero/iflight-cwp/web/getMainPage';
const MONTH_NAMES: Record<string, string> = {
  '01': 'Jan',
  '02': 'Feb',
  '03': 'Mar',
  '04': 'Apr',
  '05': 'May',
  '06': 'Jun',
  '07': 'Jul',
  '08': 'Aug',
  '09': 'Sep',
  '10': 'Oct',
  '11': 'Nov',
  '12': 'Dec',
};

function lastDayOfMonth(year: string, month: string) {
  const yearNumber = Number(year) || new Date().getFullYear();
  const monthNumber = Number(month) || new Date().getMonth() + 1;
  return String(new Date(yearNumber, monthNumber, 0).getDate()).padStart(2, '0');
}

function formatIFlightDate(day: string, month: string, year: string) {
  return `${day}-${MONTH_NAMES[month] || 'Jan'}-${year || new Date().getFullYear()}`;
}

async function parseBase64Pdf(filename: string, dataBase64: string): Promise<CrewRoster> {
  const response = await fetch('/api/parse-pdf', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ filename, dataBase64 }),
  });
  const payload = await response.json().catch(() => null);
  if (!response.ok || !payload?.ok || !payload?.roster) {
    throw new Error(payload?.message || payload?.detail || 'Não consegui interpretar o PDF baixado pelo iFlight.');
  }
  return payload.roster as CrewRoster;
}

const IFlightIntegrationView: React.FC<IFlightIntegrationViewProps> = ({ onBack, onSuccess, onFileUpload, onRosterImport }) => {
  const now = new Date();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [status, setStatus] = useState<IFlightStatus>('idle');
  const [message, setMessage] = useState('Sincronização Premium Segura pronta. Durante login/MFA, a automação fica pausada para não atrapalhar digitação. Após acessar o iFlight, use Auto/PDF para o CrewCheck tentar gerar Roster Report em PDF/LT, capturar e importar. O CrewCheck não salva senha nem captura credenciais.');
  const [periodMonth, setPeriodMonth] = useState(String(now.getMonth() + 1).padStart(2, '0'));
  const [periodYear, setPeriodYear] = useState(String(now.getFullYear()));
  const [includeLegend, setIncludeLegend] = useState(false);
  const [autoClicks, setAutoClicks] = useState(true);
  const [keepAuthorizedSession, setKeepAuthorizedSession] = useState(true);
  const [silentPremiumPull, setSilentPremiumPull] = useState(true);

  const isBusy = status === 'fetching' || status === 'portal';
  const hasNativeBridge = typeof window !== 'undefined' && Boolean(window.CrewCheckIFlight?.openPortalAndImport);
  const months = useMemo(() => ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'], []);
  const fromDate = formatIFlightDate('01', periodMonth, periodYear);
  const toDate = formatIFlightDate(lastDayOfMonth(periodYear, periodMonth), periodMonth, periodYear);

  const portalOptions: IFlightPortalOptions = {
    autoClicks,
    keepAuthorizedSession,
    silentPremiumPull,
    autoResumeAfterLogin: true,
    universalPdfCapture: true,
    maxAutomationMinutes: 8,
    fromDate,
    toDate,
    periodMonth,
    periodYear,
    format: 'pdf',
    includeLegend,
    clickSend: false,
    privacyMode: 'lgpd_no_credentials',
    actions: ['wait_user_login_mfa', 'reuse_authorized_session', 'auto_resume_after_login', 'open_menu', 'open_roster_calendar', 'open_roster_report', 'fill_period', 'select_pdf', 'set_lt', 'run_report', 'monitor_pdf_download', 'capture_blob_pdf', 'intercept_fetch_xhr', 'return_to_crewcheck'],
  };

  const finishRosterImport = async (roster: CrewRoster, sourceFileName: string) => {
    if (!onRosterImport) {
      setStatus('success');
      setMessage('Escala recebida automaticamente. Abra a tela de escala para conferir.');
      onSuccess();
      return;
    }
    setStatus('fetching');
    setMessage('PDF recebido. Interpretando escala e montando painel...');
    await onRosterImport(roster, sourceFileName);
    setStatus('success');
    setMessage('Escala iFlight sincronizada com sucesso.');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setStatus('fetching');
    setMessage(`Processando ${file.name}...`);
    try {
      if (onFileUpload) {
        await onFileUpload(file);
        setStatus('success');
        setMessage('Escala iFlight sincronizada com sucesso.');
        onSuccess();
        return;
      }
      setStatus('success');
      setMessage('PDF selecionado. Conclua a análise na tela de escala.');
      onSuccess();
    } catch (error) {
      setStatus('error');
      setMessage(error instanceof Error ? error.message : 'Não foi possível importar o PDF do iFlight.');
    } finally {
      e.target.value = '';
    }
  };

  async function handleOpenPortalFlow() {
    if (hasNativeBridge && window.CrewCheckIFlight?.openPortalAndImport) {
      setStatus('portal');
      setMessage('Modo Automático iniciado. Vou reutilizar a sessão autorizada quando existir. Se o iFlight pedir login/MFA, conclua somente essa etapa no portal oficial; depois eu continuo até gerar PDF em LT, capturar e importar.');
      try {
        const nativeResult = await window.CrewCheckIFlight.openPortalAndImport(IFLIGHT_URL, portalOptions);
        const payload: NativeIFlightPayload = typeof nativeResult === 'string' ? JSON.parse(nativeResult) : nativeResult;
        if (!payload?.ok) throw new Error(payload?.error || payload?.message || 'O portal foi fechado sem retornar o PDF da escala.');
        if (payload.roster) {
          await finishRosterImport(payload.roster, payload.sourceFileName || payload.filename || `iFlight_${periodYear}_${periodMonth}.pdf`);
          return;
        }
        if (payload.dataBase64) {
          const filename = payload.filename || `iFlight_${periodYear}_${periodMonth}.pdf`;
          const roster = await parseBase64Pdf(filename, payload.dataBase64);
          await finishRosterImport(roster, filename);
          return;
        }
        throw new Error('O portal retornou sem PDF e sem escala interpretada.');
      } catch (error) {
        const rawMessage = error instanceof Error ? error.message : 'Não foi possível concluir a importação pelo portal.';
        const isSso403 = /app_not_configured_for_user|service is not configured|403/i.test(rawMessage);
        const errorMessage = isSso403
          ? 'O iFlight/Google retornou 403. Verifique se a conta corporativa correta tem permissão. Como fallback, baixe o PDF no portal e importe manualmente.'
          : rawMessage;
        setStatus('error');
        setMessage(errorMessage);
        toast.error(errorMessage);
      }
      return;
    }

    setStatus('portal');
    setMessage('Na versão Web, o navegador não permite controlar/capturar outro domínio automaticamente. No Android, o Premium Pull roda dentro do CrewCheck e consegue reutilizar a sessão autorizada. Aqui, use o portal externo e importe o PDF manualmente.');
    window.open(IFLIGHT_URL, '_blank', 'noopener,noreferrer');
    toast.info('Baixe o PDF no iFlight e volte para importar manualmente.');
  }

  const statusTone = status === 'success'
    ? 'border-emerald-300/30 bg-emerald-400/10 text-emerald-50'
    : status === 'error'
      ? 'border-rose-300/30 bg-rose-400/10 text-rose-50'
      : 'border-cyan-300/25 bg-cyan-300/10 text-cyan-50';

  return (
    <div className="min-h-screen overflow-hidden bg-[#030914] pb-24 text-white crewcheck-iflight-screen">
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_12%_0%,rgba(249,115,22,0.18),transparent_30rem),radial-gradient(circle_at_86%_4%,rgba(14,165,233,0.16),transparent_28rem),linear-gradient(180deg,#030914_0%,#07111f_58%,#020817_100%)]" />
      </div>

      <div className="relative z-10 mx-auto max-w-5xl px-5 py-6">
        <header className="flex items-center justify-between gap-4 rounded-[1.6rem] border border-white/10 bg-white/[0.065] px-4 py-3 shadow-2xl shadow-black/25 backdrop-blur-2xl">
          <button onClick={onBack} className="flex min-w-0 items-center gap-3 text-left">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-white/10 text-orange-100"><ChevronLeft className="h-5 w-5" /></span>
            <span className="min-w-0">
              <h2 className="truncate text-lg font-black">Piloto iFlight</h2>
              <p className="mt-1 truncate text-xs font-black uppercase tracking-[0.18em] text-orange-100/60">automação segura · login/MFA no portal oficial</p>
            </span>
          </button>
          <img src="/icons/crewcheck-icon.svg" alt="CrewCheck" className="h-11 w-11 rounded-2xl" />
        </header>

        <section className="mt-5 rounded-[2rem] border border-white/10 bg-white/[0.065] p-5 shadow-2xl shadow-black/25 backdrop-blur-2xl sm:p-6">
          <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_20rem]">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.2em] text-orange-100/65">sincronização premium segura</p>
              <h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">iFlight AutoPilot Seguro · Login livre</h1>
              <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-300">Três caminhos no mesmo fluxo: Automático com sessão já autorizada, Assistido quando houver login/MFA e Caixa de Entrada para importar PDF em um toque. O CrewCheck não salva senha, não lê MFA e captura apenas o PDF autorizado da escala em LT.</p>
              <div className={`mt-4 rounded-2xl border px-4 py-3 text-sm leading-6 ${statusTone}`}>{isBusy && <Loader2 className="mr-2 inline h-4 w-4 animate-spin" />}{message}</div>

              <div className="mt-4 grid gap-2 rounded-[1.4rem] border border-white/10 bg-white/[0.045] p-3 text-xs font-bold leading-5 text-slate-300 sm:grid-cols-4">
                <span className="rounded-2xl bg-white/10 px-3 py-2"><Lock className="mr-1 inline h-3.5 w-3.5 text-cyan-200" /> Login/MFA manual</span>
                <span className="rounded-2xl bg-white/10 px-3 py-2"><Globe className="mr-1 inline h-3.5 w-3.5 text-cyan-200" /> Roster Calendar</span>
                <span className="rounded-2xl bg-white/10 px-3 py-2"><FileText className="mr-1 inline h-3.5 w-3.5 text-cyan-200" /> PDF em LT</span>
                <span className="rounded-2xl bg-white/10 px-3 py-2"><CheckCircle2 className="mr-1 inline h-3.5 w-3.5 text-emerald-200" /> Importação automática</span>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-3">
                <div className="rounded-[1.35rem] border border-cyan-200/15 bg-cyan-300/10 p-4"><b className="text-cyan-50">Automático</b><p className="mt-1 text-xs leading-5 text-slate-300">Usa sessão já autorizada e tenta baixar sem mostrar a movimentação.</p></div>
                <div className="rounded-[1.35rem] border border-emerald-200/15 bg-emerald-300/10 p-4"><b className="text-emerald-50">Assistido</b><p className="mt-1 text-xs leading-5 text-slate-300">Você só faz login/MFA oficial; o CrewCheck continua o restante.</p></div>
                <div className="rounded-[1.35rem] border border-amber-200/15 bg-amber-300/10 p-4"><b className="text-amber-50">Caixa de Entrada</b><p className="mt-1 text-xs leading-5 text-slate-300">Fallback confiável: PDF baixado, compartilhado ou selecionado em um toque.</p></div>
              </div>

              <div className="mt-5 grid gap-3 sm:grid-cols-3">
                <button onClick={handleOpenPortalFlow} disabled={status === 'fetching'} className="flex min-h-[4rem] items-center justify-center gap-3 rounded-2xl bg-cyan-300 px-5 py-4 text-base font-black text-[#07111f] shadow-lg shadow-cyan-950/30 transition hover:bg-cyan-200 disabled:cursor-wait disabled:opacity-70">
                  <DownloadCloud className="h-5 w-5" /> {hasNativeBridge ? 'Automático' : 'Abrir iFlight'}
                </button>
                <button type="button" onClick={handleOpenPortalFlow} disabled={status === 'fetching'} className="flex min-h-[4rem] items-center justify-center gap-3 rounded-2xl border border-emerald-300/25 bg-emerald-300/12 px-5 py-4 text-base font-black text-emerald-50 shadow-lg shadow-emerald-950/20 transition hover:bg-emerald-300/18 disabled:cursor-wait disabled:opacity-70">
                  <ShieldCheck className="h-5 w-5" /> Assistido
                </button>
                <button onClick={() => fileInputRef.current?.click()} disabled={status === 'fetching'} className="flex min-h-[4rem] items-center justify-center gap-3 rounded-2xl border border-white/10 bg-white/10 px-5 py-4 text-base font-black text-white transition hover:bg-white/15 disabled:cursor-wait disabled:opacity-70">
                  <Upload className="h-5 w-5" /> Caixa de Entrada manual
                </button>
                <input ref={fileInputRef} type="file" accept=".pdf,application/pdf" onChange={handleFileUpload} disabled={status === 'fetching'} className="sr-only" />
              </div>
            </div>

            <div className="rounded-[1.5rem] border border-cyan-300/15 bg-[#07111f]/70 p-4">
              <div className="mb-3 flex items-center gap-2 text-sm font-black text-cyan-100"><CalendarDays className="h-4 w-4" /> Período</div>
              <div className="grid gap-3">
                <label className="block">
                  <span className="text-xs font-black uppercase tracking-[0.16em] text-cyan-100/70">Mês</span>
                  <select value={periodMonth} onChange={(event) => setPeriodMonth(event.target.value)} className="mt-2 h-12 w-full rounded-2xl border border-white/10 bg-[#07111f] px-4 text-sm font-bold text-white outline-none focus:border-cyan-300">
                    {months.map((month) => <option key={month} value={month}>{month}</option>)}
                  </select>
                </label>
                <label className="block">
                  <span className="text-xs font-black uppercase tracking-[0.16em] text-cyan-100/70">Ano</span>
                  <input value={periodYear} onChange={(event) => setPeriodYear(event.target.value.replace(/\D/g, '').slice(0, 4))} inputMode="numeric" className="mt-2 h-12 w-full rounded-2xl border border-white/10 bg-[#07111f] px-4 text-sm font-bold text-white outline-none focus:border-cyan-300" />
                </label>
                <div className="rounded-2xl border border-white/10 bg-white/[0.055] p-3 text-xs leading-5 text-slate-300">
                  <strong className="text-white">{fromDate}</strong> até <strong className="text-white">{toDate}</strong><br />Formato: <strong className="text-white">PDF</strong> · Fuso: <strong className="text-white">LT</strong>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="mt-4 grid gap-4 md:grid-cols-3">
          <ToggleCard checked={autoClicks} onChange={setAutoClicks} title="Piloto automático" text="Após login/MFA, navega sozinho até Roster Report, seleciona PDF/LT e captura o download." />
          <ToggleCard checked={keepAuthorizedSession} onChange={setKeepAuthorizedSession} title="Manter sessão autorizada" text="Não salva senha; apenas preserva a sessão oficial do iFlight para tentar sincronizar sem novo login enquanto ela estiver válida." />
          <ToggleCard checked={silentPremiumPull} onChange={setSilentPremiumPull} title="Tela mascarada premium" text="Esconde a movimentação do portal e mostra somente progresso amigável para o usuário." />
          <ToggleCard checked={includeLegend} onChange={setIncludeLegend} title="Legenda" text="Inclui legenda no relatório quando o portal disponibilizar essa opção." />
          <div className="rounded-[1.5rem] border border-emerald-300/20 bg-emerald-400/10 p-4 text-sm leading-6 text-emerald-50/80 md:col-span-2"><ShieldCheck className="mb-2 h-5 w-5" /><strong>LGPD:</strong> senha e MFA não são capturados. A sessão autorizada pode ser preservada localmente pelo WebView, e o usuário pode encerrar a sessão pelo próprio portal quando quiser.</div>
        </section>

        <section className="mt-4 grid gap-4 md:grid-cols-3">
          <div className="rounded-[1.5rem] border border-cyan-300/20 bg-cyan-300/10 p-4 text-sm leading-6 text-cyan-50/85"><DownloadCloud className="mb-2 h-5 w-5" /><strong>Concorrência:</strong> modo automático nativo para Android, com captura de PDF e fallback manual.</div>
          <div className="rounded-[1.5rem] border border-orange-300/20 bg-orange-300/10 p-4 text-sm leading-6 text-orange-50/85"><RefreshCw className="mb-2 h-5 w-5" /><strong>Anti-loop:</strong> cliques repetidos são bloqueados por etapa para evitar ficar preso nas mesmas abas.</div>
          <div className="rounded-[1.5rem] border border-white/10 bg-white/[0.055] p-4 text-sm leading-6 text-slate-200"><Upload className="mb-2 h-5 w-5" /><strong>Fallback:</strong> se o portal bloquear WebView, use Chrome e compartilhe o PDF com o CrewCheck.</div>
        </section>

        <section className="mt-4 rounded-[1.7rem] border border-white/10 bg-white/[0.055] p-4 text-sm leading-6 text-slate-300 shadow-xl shadow-black/20 backdrop-blur-2xl">
          <AlertCircle className="mr-2 inline h-4 w-4 text-orange-200" />
          Fluxo Premium Pull no Android: reutiliza sessão autorizada quando disponível → Roster Calendar → Roster Report → PDF → LT → Run → captura do PDF. Se o iFlight exigir login/MFA, você faz essa etapa sem interferência do app; depois toque em Auto/PDF para continuar. Não usa Send e não salva senha.
        </section>

        <a href={IFLIGHT_URL} target="_blank" rel="noopener noreferrer" className="mt-4 inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/10 px-5 py-3 text-sm font-black text-white hover:bg-white/15">
          Abrir portal externo <ExternalLink className="h-4 w-4" />
        </a>
      </div>
    </div>
  );
};

function ToggleCard({ checked, onChange, title, text }: { checked: boolean; onChange: (value: boolean) => void; title: string; text: string }) {
  return (
    <label className="flex cursor-pointer items-start gap-3 rounded-[1.5rem] border border-white/10 bg-white/[0.055] p-4 text-sm text-slate-200 shadow-xl shadow-black/15 backdrop-blur-xl">
      <input checked={checked} onChange={(event) => onChange(event.target.checked)} type="checkbox" className="mt-1 h-4 w-4 accent-cyan-300" />
      <span><strong className="text-white">{title}</strong><br /><span className="text-slate-400">{text}</span></span>
    </label>
  );
}

export default IFlightIntegrationView;
