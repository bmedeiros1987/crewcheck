# CrewCheck v11.1.66 — Twilio Premium + ElevenLabs PT-BR

Implementação do Twilio como provedor premium de ligação do Despertador CrewCheck:

- Gratuito continua recebendo apenas Telegram.
- Premium/Admin podem usar ligação telefônica real via Twilio.
- A ligação Twilio prioriza MP3 ElevenLabs em português brasileiro.
- O backend não cai automaticamente para inglês/americano.
- Infobip continua como fallback técnico opcional.
- CallMeBot continua como fallback técnico opcional.
- O teste de ligação premium não dispara áudio no Telegram.
- O endpoint TwiML assinado entrega áudio temporário para a Twilio tocar na chamada.

Variáveis principais no Render:

```env
CREWCHECK_WAKEUP_CALL_PROVIDER=twilio
CREWCHECK_WAKEUP_CALL_PREMIUM_ONLY=true
CREWCHECK_WAKEUP_FREE_CHANNEL=telegram

TWILIO_ENABLED=true
TWILIO_ACCOUNT_SID=...
TWILIO_AUTH_TOKEN=...
TWILIO_FROM_NUMBER=+18782256674
TWILIO_TO_PHONE=+556196071663
TWILIO_TIMEOUT_SECONDS=45
TWILIO_STATUS_CALLBACK_ENABLED=true

CREWCHECK_TWILIO_USE_ELEVENLABS_AUDIO=true
CREWCHECK_TWILIO_TTS_FALLBACK=false
CREWCHECK_TWILIO_ALLOW_ENGLISH_FALLBACK=false

ELEVENLABS_API_KEY=...
ELEVENLABS_TTS_VOICE_ID=...
ELEVENLABS_TTS_MODEL=eleven_multilingual_v2
PUBLIC_APP_URL=https://seu-dominio.onrender.com
```
