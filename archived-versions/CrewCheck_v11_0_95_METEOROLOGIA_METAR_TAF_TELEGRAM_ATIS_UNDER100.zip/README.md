# CrewCheck v11.0.95

Meteorologia premium para pilotos: METAR/TAF via Aviation Weather Center, favoritos, pesquisa por ICAO/IATA/cidade/fonético, Concierge Telegram com leitura estilo ATIS e organização de menus.


## Principais ajustes

- Menu Regulamentação abre uma calculadora própria, não apenas a lista de alertas automáticos.
- Calculadora de Limite de Jornada: apresentação, tipo de tripulação, etapas, doméstico/internacional, extensão e margem de corte.
- Calculadora de Sobreaviso: início do SAV, apresentação/acionamento e teto combinado parametrizado, padrão 16h.
- Calculadora de Reserva: início da reserva, acionamento/apresentação e limite por jornada/teto combinado.
- Resultados com corte dos motores e encerramento da jornada.
- Alertas automáticos da escala continuam disponíveis, mas separados da consulta manual.
- Redução de falso positivo por flyingHours contaminado: quando há pernas legíveis, a métrica usa a soma das pernas, não o total bruto do PDF.
- Produção Android mantém R8/ProGuard, shrinkResources e mapping.txt.

## Android

- versionName: 11.0.94
- versionCode: 11094