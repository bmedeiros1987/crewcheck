# CrewCheck v11.1.50 · CallMeBot no Despertador Premium

Atualização cumulativa sobre a v11.1.49.

## Novidade principal

- Integração CallMeBot no despertador de apresentação/pernoite.
- Permite chamada por Telegram Voice (`start.php`) usando @Telegram/telefone autorizado.
- Permite chamada por telefone/apikey (`call.php`) quando o usuário informa telefone e chave CallMeBot.
- A apikey não é exposta no front-end depois de salva: o app retorna apenas máscara.
- Novo botão **Testar ligação** em Configurações > Telegram > Despertador por chamada.
- O fluxo continua com mensagem Telegram, botões **Já acordei** e **Soneca**, e mantém o aviso de usar também o despertador nativo do celular.

## Variáveis opcionais de ambiente

Use variáveis no Render somente para fallback global. Para usuário final, a configuração pode ser feita no próprio menu do app.

- `CREWCHECK_WAKEUP_CALL_PROVIDER=callmebot`
- `CALLMEBOT_MODE=phone` ou `telegram` ou `auto`
- `CALLMEBOT_PHONE`
- `CALLMEBOT_API_KEY`
- `CALLMEBOT_TELEGRAM_CALL_USER`

## Versão

- versionName: 11.1.50
- versionCode: 11150
- Padrão: UNDER100
