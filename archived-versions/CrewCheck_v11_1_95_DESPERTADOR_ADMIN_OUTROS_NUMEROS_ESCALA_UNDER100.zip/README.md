# CrewCheck v11.1.95

Hotfix do Despertador Admin personalizado.

## Principais ajustes

- Despertador Admin agora usa canal administrativo direto da Infobip.
- Permite ligação imediata ou agendada para outros números informados no painel Admin.
- Não herda telefone do Perfil do admin nem bloqueia pelo plano do usuário de destino.
- Mantém o endpoint protegido: somente login reconhecido como administrador pode usar.
- Se o menu estiver em cache mas o backend não reconhecer admin, retorna orientação para configurar `CREWCHECK_ADMIN_EMAILS` no Render.
- Mantém Google Calendar Sync Seguro, Reserva acionada como voo, WhatsApp Import, FreeCurrencyAPI, Infobip principal e parser por continuidade física.
