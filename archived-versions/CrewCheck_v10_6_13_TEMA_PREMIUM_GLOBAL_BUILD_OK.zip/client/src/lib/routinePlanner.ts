import type { DayLoadAnalysis } from './complianceEngine';

export type RoutineActivityType = 'musculacao' | 'corrida' | 'caminhada' | 'crossfit' | 'estudo' | 'faculdade' | 'personalizado';
export type RoutineIntensity = 'baixa' | 'moderada' | 'alta';
export type RoutinePeriod = 'manha' | 'tarde' | 'noite' | 'qualquer';

export interface RoutineActivityConfig {
  id: string;
  type: RoutineActivityType;
  name: string;
  durationMinutes: number;
  intensity: RoutineIntensity;
  frequencyPerWeek: number;
  preferredPeriod: RoutinePeriod;
  notes?: string;
}

export interface RoutineSuggestion {
  id: string;
  date: string;
  dayOfWeek: string;
  activityName: string;
  activityType: RoutineActivityType;
  durationMinutes: number;
  startTime: string;
  endTime: string;
  intensity: RoutineIntensity;
  score: number;
  suitability: 'ideal' | 'boa' | 'moderada' | 'evitar';
  confidence: 'alta' | 'media' | 'baixa';
  reason: string;
  caution: string;
  dayLabel: string;
}

const DEFAULT_ROUTINE_ACTIVITIES: RoutineActivityConfig[] = [
  { id: 'musculacao-60', type: 'musculacao', name: 'Musculação', durationMinutes: 60, intensity: 'moderada', frequencyPerWeek: 3, preferredPeriod: 'manha' },
  { id: 'caminhada-45', type: 'caminhada', name: 'Caminhada', durationMinutes: 45, intensity: 'baixa', frequencyPerWeek: 2, preferredPeriod: 'qualquer' },
  { id: 'estudo-90', type: 'estudo', name: 'Estudo', durationMinutes: 90, intensity: 'baixa', frequencyPerWeek: 3, preferredPeriod: 'noite' },
];

export function defaultRoutineActivities(): RoutineActivityConfig[] {
  return DEFAULT_ROUTINE_ACTIVITIES.map((item) => ({ ...item }));
}

export function getActivityLabel(type: RoutineActivityType): string {
  const labels: Record<RoutineActivityType, string> = {
    musculacao: 'Musculação',
    corrida: 'Corrida',
    caminhada: 'Caminhada',
    crossfit: 'Crossfit',
    estudo: 'Estudo',
    faculdade: 'Faculdade',
    personalizado: 'Personalizado',
  };
  return labels[type];
}

export function getActivityDefaultIntensity(type: RoutineActivityType): RoutineIntensity {
  if (type === 'crossfit' || type === 'corrida') return 'alta';
  if (type === 'musculacao') return 'moderada';
  return 'baixa';
}

export function getActivityDefaultDuration(type: RoutineActivityType): number {
  const defaults: Record<RoutineActivityType, number> = {
    musculacao: 60,
    corrida: 45,
    caminhada: 45,
    crossfit: 60,
    estudo: 90,
    faculdade: 120,
    personalizado: 60,
  };
  return defaults[type];
}

export function buildRoutineSuggestions(days: DayLoadAnalysis[], activities: RoutineActivityConfig[]): RoutineSuggestion[] {
  const chronological = [...days].sort((a, b) => parseRosterDate(a.date).getTime() - parseRosterDate(b.date).getTime());
  const suggestions: RoutineSuggestion[] = [];
  const usedSlots = new Set<string>();
  if (!chronological.length || !activities.length) return suggestions;

  const weeks = splitDaysByRosterWeek(chronological);

  activities.forEach((activity) => {
    const desiredPerWeek = Math.max(1, Math.min(7, Number(activity.frequencyPerWeek) || 1));

    weeks.forEach((weekDays, weekIndex) => {
      const ranked = weekDays
        .map((day) => {
          const globalIndex = chronological.findIndex((item) => item.date === day.date);
          const previous = chronological[globalIndex - 1] || null;
          const next = chronological[globalIndex + 1] || null;
          return scoreDayForActivity(day, activity, previous, next);
        })
        .sort((a, b) => b.score - a.score || parseRosterDate(a.day.date).getTime() - parseRosterDate(b.day.date).getTime());

      let count = 0;
      for (const option of ranked) {
        if (count >= desiredPerWeek) break;
        // Mesmo quando a semana está pesada, gerar pelo menos uma recomendação prudente para a escala inteira.
        if (option.score < 35 && isPhysicalActivity(activity.type) && count > 0) continue;
        const slot = pickTimeSlot(option.day, activity, usedSlots);
        if (!slot) continue;
        const key = `${option.day.date}-${slot.startTime}-${activity.id}`;
        if (usedSlots.has(key)) continue;
        usedSlots.add(key);
        const safeWindowNote = slot.strategy ? `janela segura ${slot.strategy}` : 'janela segura fora da programação';
        suggestions.push({
          id: `${activity.id}-w${weekIndex}-${option.day.date}-${count}`,
          date: option.day.date,
          dayOfWeek: option.day.dayOfWeek,
          activityName: activity.name || getActivityLabel(activity.type),
          activityType: activity.type,
          durationMinutes: activity.durationMinutes,
          startTime: slot.startTime,
          endTime: addMinutes(slot.startTime, activity.durationMinutes),
          intensity: activity.intensity,
          score: option.score,
          suitability: scoreToSuitability(option.score),
          confidence: option.confidence,
          reason: [option.reason, safeWindowNote].filter(Boolean).join(' · '),
          caution: [option.caution, slot.caution].filter(Boolean).join(' · '),
          dayLabel: option.day.label,
        });
        count++;
      }
    });
  });

  return suggestions
    .sort((a, b) => parseRosterDate(a.date).getTime() - parseRosterDate(b.date).getTime() || a.startTime.localeCompare(b.startTime))
    .slice(0, 180);
}

function splitDaysByRosterWeek(days: DayLoadAnalysis[]): DayLoadAnalysis[][] {
  const weeks: DayLoadAnalysis[][] = [];
  let current: DayLoadAnalysis[] = [];
  days.forEach((day, index) => {
    const date = parseRosterDate(day.date);
    const startsNewWeek = index > 0 && date.getDay() === 1;
    if (startsNewWeek && current.length) {
      weeks.push(current);
      current = [];
    }
    current.push(day);
  });
  if (current.length) weeks.push(current);
  return weeks;
}

function scoreDayForActivity(day: DayLoadAnalysis, activity: RoutineActivityConfig, previous: DayLoadAnalysis | null, next: DayLoadAnalysis | null) {
  const demand = activityDemand(activity);
  let score = 48;
  const reasons: string[] = [];
  const cautions: string[] = [];

  if (day.isDayOff) {
    score += 30;
    reasons.push('dia de recuperação/folga');
  }
  if (day.type === 'LAYOVER') {
    score += isPhysicalActivity(activity.type) ? 22 : 26;
    reasons.push('inativo/pernoite com janela boa para encaixar rotina');
  }
  if (day.type === 'OTHER') {
    score -= 18;
    cautions.push('dia sem programação lida com alta confiança');
  }
  if (day.fatigueScore >= 70) {
    score -= demand.high * 0.38;
    cautions.push('dia operacional pesado');
  } else if (day.fatigueScore >= 45) {
    score -= demand.high * 0.18;
  } else {
    score += 12;
    reasons.push('carga leve permite encaixar atividade');
  }
  if (!day.isDayOff && day.type !== 'LAYOVER' && day.dutyHours > 0 && day.dutyHours <= 4 && activity.durationMinutes <= 120) {
    score += 16;
    reasons.push('programação curta com janela útil no mesmo dia');
  }
  if (!day.isDayOff && day.type !== 'LAYOVER' && day.dutyHours > 4 && day.dutyHours <= 7 && activity.durationMinutes <= 60 && activity.intensity !== 'alta') {
    score += 8;
    reasons.push('atividade curta cabe em dia operacional moderado');
  }
  if (day.isNightDuty || day.isLateFinish) {
    score -= demand.sleep * 0.35;
    cautions.push('término tarde/madrugada: proteger sono');
  }
  if (day.isEarlyStart) {
    score -= demand.sleep * 0.22;
    cautions.push('apresentação cedo');
  }
  if (day.restBefore !== null && day.restBefore < 14) {
    score -= demand.sleep * 0.28;
    cautions.push(`repouso anterior curto (${day.restBefore}h)`);
  }
  if (day.restAfter !== null && day.restAfter < 14) {
    score -= demand.sleep * 0.38;
    cautions.push(`repouso posterior justo (${day.restAfter}h)`);
  }
  if (previous && previous.fatigueScore >= 70) {
    score -= demand.high * 0.2;
    cautions.push('vem de dia pesado');
  }
  if (next && next.fatigueScore >= 70) {
    score -= demand.high * 0.24;
    cautions.push('próximo dia é pesado');
  }
  if (activity.durationMinutes >= 120 && !day.isDayOff && day.type !== 'LAYOVER' && day.dutyHours > 4) {
    score -= 20;
    cautions.push('atividade longa em dia operacional');
  }
  if (!isPhysicalActivity(activity.type)) {
    score += day.isDayOff ? -5 : 8;
    if (day.isLateFinish || day.isNightDuty) score -= 10;
    reasons.push('atividade cognitiva pode caber em janela leve');
  }
  if (activity.type === 'crossfit' && !day.isDayOff) {
    score -= 25;
    cautions.push('crossfit exige margem alta de recuperação');
  }
  if (activity.type === 'caminhada') {
    score += 10;
    reasons.push('baixo impacto e boa opção de recuperação ativa');
  }

  score = Math.round(clamp(score, 0, 100));
  const confidence: RoutineSuggestion['confidence'] = day.type === 'OTHER' ? 'baixa' : day.type === 'LAYOVER' ? 'media' : 'alta';
  return {
    day,
    score,
    confidence,
    reason: reasons.length ? reasons.slice(0, 3).join(' · ') : 'janela compatível com a carga do dia',
    caution: cautions.length ? cautions.slice(0, 3).join(' · ') : 'manter hidratação, alimentação e margem para deslocamento/sono',
  };
}

function activityDemand(activity: RoutineActivityConfig) {
  let high = 35;
  let sleep = 30;
  if (activity.intensity === 'alta') { high += 35; sleep += 25; }
  if (activity.intensity === 'moderada') { high += 16; sleep += 12; }
  if (activity.durationMinutes >= 90) { high += 12; sleep += 8; }
  if (activity.durationMinutes >= 120) { high += 15; sleep += 12; }
  if (activity.type === 'crossfit') { high += 24; sleep += 16; }
  if (activity.type === 'corrida') { high += 14; sleep += 8; }
  if (activity.type === 'caminhada') { high -= 18; sleep -= 12; }
  if (!isPhysicalActivity(activity.type)) { high -= 16; sleep += 8; }
  return { high: clamp(high, 10, 100), sleep: clamp(sleep, 10, 100) };
}

type RoutineTimeSlot = {
  startTime: string;
  strategy: string;
  caution?: string;
};

function pickTimeSlot(day: DayLoadAnalysis, activity: RoutineActivityConfig, usedSlots: Set<string>): RoutineTimeSlot | null {
  const candidates = buildSafeCandidateTimes(day, activity);
  for (const slot of candidates) {
    const key = `${day.date}-${slot.startTime}-${activity.type}`;
    if (!usedSlots.has(key)) return slot;
  }
  return null;
}

function buildSafeCandidateTimes(day: DayLoadAnalysis, activity: RoutineActivityConfig): RoutineTimeSlot[] {
  const duration = Math.max(15, Math.min(240, Number(activity.durationMinutes) || 60));
  const blocked = getBlockedWindows(day, activity);
  const preferredCandidates = candidateTimes(day, activity);
  const gridCandidates = buildPeriodGrid(activity.preferredPeriod);
  const rawCandidates = uniqueTimes([...preferredCandidates, ...gridCandidates]);
  const safe: RoutineTimeSlot[] = [];

  for (const time of rawCandidates) {
    const start = timeToMinutes(time);
    const end = start + duration;
    if (!isReasonableRoutineWindow(start, end)) continue;
    if (blocked.some((window) => windowsOverlap(start, end, window.start, window.end))) continue;
    safe.push({ startTime: time, strategy: describeSlotStrategy(start, blocked) });
  }

  // Em dias com programação, acrescenta automaticamente uma janela premium antes/depois
  // do compromisso real, respeitando margem para deslocamento, alimentação e sono.
  for (const window of blocked) {
    const beforeEnd = Math.max(0, window.start - 15);
    const beforeStart = beforeEnd - duration;
    if (isReasonableRoutineWindow(beforeStart, beforeEnd) && !blocked.some((item) => windowsOverlap(beforeStart, beforeEnd, item.start, item.end))) {
      safe.push({
        startTime: minutesToTime(roundDownToStep(beforeStart, 15)),
        strategy: 'antes da programação, com margem de segurança',
        caution: makeTimingCaution(day),
      });
    }

    const afterStart = roundUpToStep(window.end + 15, 15);
    const afterEnd = afterStart + duration;
    if (isReasonableRoutineWindow(afterStart, afterEnd) && !blocked.some((item) => windowsOverlap(afterStart, afterEnd, item.start, item.end))) {
      safe.push({
        startTime: minutesToTime(afterStart),
        strategy: 'depois da programação, sem choque de horário',
        caution: makeTimingCaution(day),
      });
    }
  }

  return dedupeSlots(safe)
    .sort((a, b) => slotScore(a, day, activity) - slotScore(b, day, activity));
}

function candidateTimes(day: DayLoadAnalysis, activity: RoutineActivityConfig): string[] {
  const byPeriod: Record<RoutinePeriod, string[]> = {
    manha: ['07:00', '08:00', '09:00', '10:00'],
    tarde: ['13:30', '14:30', '15:30', '16:30'],
    noite: ['18:00', '18:30', '19:30', '20:00'],
    qualquer: ['07:30', '09:00', '10:30', '14:30', '16:00', '18:30'],
  };
  let candidates = byPeriod[activity.preferredPeriod] || byPeriod.qualquer;
  if (day.isEarlyStart) candidates = ['15:30', '16:30', '17:30', '18:30'];
  if (day.isLateFinish || day.isNightDuty) candidates = isPhysicalActivity(activity.type) ? ['10:30', '14:30', '15:30'] : ['11:00', '15:00', '16:00'];
  if (day.dutyHours > 0 && day.dutyHours <= 4 && !day.isLateFinish && !day.isNightDuty) candidates = activity.preferredPeriod === 'manha' ? ['07:00', '08:00'] : ['13:30', '15:00', '17:30'];
  if (day.isDayOff) candidates = activity.preferredPeriod === 'noite' ? ['18:00', '19:00'] : activity.preferredPeriod === 'tarde' ? ['14:00', '15:30', '16:30'] : ['08:00', '09:30', '10:30', '15:30'];
  if (day.type === 'LAYOVER') candidates = activity.preferredPeriod === 'manha' ? ['09:00', '10:00'] : ['10:00', '15:00', '17:30'];
  return candidates;
}

function getBlockedWindows(day: DayLoadAnalysis, activity: RoutineActivityConfig): { start: number; end: number; label: string }[] {
  const start = timeToMinutesOrNull(day.dutyStartTime);
  const endRaw = timeToMinutesOrNull(day.dutyEndTime);
  if (start === null || endRaw === null) return [];

  const isStandbyOrReserve = ['HSB', 'HSBE', 'ASB', 'RES'].includes(String(day.type || '').toUpperCase());
  const isOperational = day.type === 'VOO' || day.dutyHours > 0;
  const beforeBuffer = isStandbyOrReserve ? 90 : isOperational ? 75 : 45;
  const afterBuffer = isStandbyOrReserve ? 75 : isOperational ? 90 : 45;
  let end = endRaw;
  if (day.isDutyNextDay || end <= start) end = 24 * 60;

  const startWithBuffer = Math.max(0, start - beforeBuffer);
  const endWithBuffer = Math.min(24 * 60, end + afterBuffer);
  const label = isStandbyOrReserve ? 'sobreaviso/reserva' : isOperational ? 'programação' : 'atividade';

  // Atividades intensas recebem uma margem extra automática.
  const extra = activity.intensity === 'alta' ? 30 : activity.durationMinutes >= 90 ? 15 : 0;
  return [{ start: Math.max(0, startWithBuffer - extra), end: Math.min(24 * 60, endWithBuffer + extra), label }];
}

function buildPeriodGrid(period: RoutinePeriod): string[] {
  const ranges: Record<RoutinePeriod, Array<[number, number]>> = {
    manha: [[6 * 60, 11 * 60]],
    tarde: [[12 * 60 + 30, 17 * 60 + 30]],
    noite: [[18 * 60, 21 * 60 + 30]],
    qualquer: [[6 * 60 + 30, 11 * 60], [13 * 60, 17 * 60 + 30], [18 * 60, 21 * 60]],
  };
  const output: string[] = [];
  for (const [start, end] of ranges[period] || ranges.qualquer) {
    for (let minute = start; minute <= end; minute += 30) output.push(minutesToTime(minute));
  }
  return output;
}

function describeSlotStrategy(start: number, blocked: { start: number; end: number; label: string }[]): string {
  if (!blocked.length) return 'em dia sem janela bloqueada pela escala';
  const window = blocked[0];
  if (start < window.start) return `antes de ${window.label}`;
  if (start >= window.end) return `após ${window.label}`;
  return 'fora da programação';
}

function makeTimingCaution(day: DayLoadAnalysis): string {
  const start = day.dutyStartTime || '--:--';
  const end = day.dutyEndTime || '--:--';
  const prefix = ['HSB', 'HSBE'].includes(String(day.type || '').toUpperCase()) ? 'sobreaviso' : ['ASB', 'RES'].includes(String(day.type || '').toUpperCase()) ? 'reserva' : 'programação';
  return `Horário da ${prefix} considerado: ${start}–${end}${day.isDutyNextDay ? ' (+1)' : ''}. A sugestão evita choque com esta janela e inclui margem.`;
}

function isReasonableRoutineWindow(start: number, end: number): boolean {
  return start >= 5 * 60 + 30 && end <= 23 * 60 && end > start;
}

function windowsOverlap(aStart: number, aEnd: number, bStart: number, bEnd: number): boolean {
  return aStart < bEnd && bStart < aEnd;
}

function timeToMinutesOrNull(time: string | null | undefined): number | null {
  if (!time) return null;
  const [h, m] = time.replace('(+1)', '').split(':').map(Number);
  if (Number.isNaN(h) || Number.isNaN(m)) return null;
  return h * 60 + m;
}

function timeToMinutes(time: string): number {
  return timeToMinutesOrNull(time) ?? 0;
}

function minutesToTime(total: number): string {
  const dayMinutes = ((total % 1440) + 1440) % 1440;
  return `${String(Math.floor(dayMinutes / 60)).padStart(2, '0')}:${String(dayMinutes % 60).padStart(2, '0')}`;
}

function roundDownToStep(value: number, step: number): number {
  return Math.floor(value / step) * step;
}

function roundUpToStep(value: number, step: number): number {
  return Math.ceil(value / step) * step;
}

function uniqueTimes(values: string[]): string[] {
  return Array.from(new Set(values.filter(Boolean)));
}

function dedupeSlots(slots: RoutineTimeSlot[]): RoutineTimeSlot[] {
  const seen = new Set<string>();
  const output: RoutineTimeSlot[] = [];
  for (const slot of slots) {
    if (seen.has(slot.startTime)) continue;
    seen.add(slot.startTime);
    output.push(slot);
  }
  return output;
}

function slotScore(slot: RoutineTimeSlot, day: DayLoadAnalysis, activity: RoutineActivityConfig): number {
  const start = timeToMinutes(slot.startTime);
  const targets: Record<RoutinePeriod, number> = { manha: 9 * 60, tarde: 15 * 60, noite: 19 * 60, qualquer: 15 * 60 };
  let score = Math.abs(start - (targets[activity.preferredPeriod] || targets.qualquer));
  if (day.isLateFinish || day.isNightDuty) score += start < 10 * 60 ? 80 : 0;
  if (day.isEarlyStart) score += start < 15 * 60 ? 90 : 0;
  if (activity.intensity === 'alta' && start >= 20 * 60) score += 90;
  return score;
}

function scoreToSuitability(score: number): RoutineSuggestion['suitability'] {
  if (score >= 78) return 'ideal';
  if (score >= 62) return 'boa';
  if (score >= 42) return 'moderada';
  return 'evitar';
}

export function isPhysicalActivity(type: RoutineActivityType): boolean {
  return ['musculacao', 'corrida', 'caminhada', 'crossfit', 'personalizado'].includes(type);
}

function parseRosterDate(value: string): Date {
  const [day, month, year] = value.split('/').map(Number);
  return new Date(year, month - 1, day);
}

function addMinutes(time: string, minutes: number): string {
  const [h, m] = time.split(':').map(Number);
  const total = h * 60 + m + minutes;
  const dayMinutes = ((total % 1440) + 1440) % 1440;
  return `${String(Math.floor(dayMinutes / 60)).padStart(2, '0')}:${String(dayMinutes % 60).padStart(2, '0')}`;
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}
