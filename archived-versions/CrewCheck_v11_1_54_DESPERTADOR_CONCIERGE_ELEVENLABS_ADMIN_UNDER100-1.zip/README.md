# CrewCheck v11.1.54 — Despertador CrewCheck Concierge Voice

Versão com mensagem de ligação em padrão concierge: tom informal, hora atual, horário de apresentação, destino e tempo restante. Mantém CallMeBot como provedor técnico white label e adiciona voz ElevenLabs para administradores via Telegram Voice quando ELEVENLABS_API_KEY estiver configurada.

Principais ajustes:
- Script dinâmico do Despertador CrewCheck no backend.
- Contexto operacional na chamada: hora atual, apresentação, destino e tempo restante.
- Teste de chamada usa o mesmo padrão de mensagem.
- Card de pernoite envia destino junto no alerta Telegram.
- Admin com ElevenLabs pode usar MP3 premium na própria chamada Telegram do CallMeBot e também receber cópia em voz no Telegram.
- Payload segue pequeno, sem reenviar preferências gigantes.

Observação: no modo Telegram Voice, o CallMeBot aceita texto TTS ou URL de arquivo MP3. Para admin, o CrewCheck gera MP3 ElevenLabs temporário e passa a URL para a chamada; no modo telefone/apikey, mantém texto TTS.
