# CrewCheck v11.0.21 — PDF iPad mais confiável, Extra e estratégia sem custo adicional

## Objetivo
Correções focadas no caminho mais justo e com menor custo operacional: melhorar a importação manual do PDF oficial, evitar leituras erradas em iPad/iPhone e padronizar a nomenclatura de Extra sem depender de novas integrações pagas.

## Ajustes
- iPad/iPhone: CrewRosterReport e PDFs oficiais passam a priorizar leitura segura do servidor.
- Quando a leitura segura falhar em iPad/iPhone ou arquivo CrewRosterReport/iFlight/CWP, o app não usa fallback local que pode bagunçar a escala.
- Mensagens de importação orientam o usuário a salvar o PDF oficial em Arquivos antes de importar.
- Nomenclatura visual ajustada: “Vivo de Extra”/“Voo de Extra” substituído por “Extra”.
- Na escala, PS aparece como “Extra / passageiro”.
- Textos administrativos do iFlight ajustados: no iPad/navegador comum, o caminho confiável é PDF oficial; Android/Admin ainda pode tentar captura autorizada quando possível.
- Versão Android atualizada para 11.0.21 / 11021.

## Observação
A importação automática direta do iFlight em iPad/Web continua limitada pelo próprio portal e pelo navegador. O caminho mais estável, justo e sem custo extra é melhorar a leitura do PDF oficial salvo pelo usuário.
