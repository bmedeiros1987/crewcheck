# CrewCheck v11.0.21 — Grátis ampliado + tempo estimado com trânsito atual

## Objetivo
Refinar a linguagem da Saída Inteligente e ampliar a proposta do plano gratuito para todas as funcionalidades que não geram custo direto de manutenção.

## Ajustes aplicados

- Substituído texto de fonte/rota para **Tempo estimado com trânsito atual** quando houver fonte de rota disponível.
- Removidos textos técnicos ou comerciais desnecessários em áreas de uso diário.
- Comparativo de planos revisado:
  - ferramentas locais e sem custo direto ficam no plano grátis;
  - Premium fica reservado para fontes externas, sincronizações, suporte e continuidade do projeto.
- Saída Inteligente agora comunica melhor quando usa estimativa local, trânsito atual, transporte público ou corrida por app.
- Textos de exportação, suporte, relatórios e rotina foram suavizados para não parecerem bloqueio artificial por assinatura.
- Mantida a tela de assinatura limpa, com detalhes em “Saiba mais”.

## Validação

- `npm run check` OK
- `npm run build` OK
- `node --check server.mjs` OK

## Android

- versionName: 11.0.21
- versionCode: 11021
