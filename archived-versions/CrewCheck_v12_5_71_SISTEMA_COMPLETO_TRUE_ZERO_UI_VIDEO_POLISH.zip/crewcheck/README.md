# CrewCheck v12.5.71 — True Zero UI Polish

Lapidação visual do rebuild zero no padrão dark aviation premium aprovado.

- Cockpit/Roster/Alerts/Saída/Configurações preservam as funcionalidades.
- Mapa TomTom visual refinado.
- Roster e cards com melhor legibilidade.
- Configurações com contraste reforçado.
- Cache/PWA atualizado para v12.5.71.
