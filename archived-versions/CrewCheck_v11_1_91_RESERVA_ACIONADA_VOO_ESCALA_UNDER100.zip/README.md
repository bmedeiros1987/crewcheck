# CrewCheck v11.1.91 — Reserva acionada exibida como voo

Base: v11.1.90.

## Hotfix principal

Corrige o cenário em que o tripulante já foi acionado durante ASB/HSB/RES e a escala contém pernas LA no mesmo dia.

Exemplo real tratado:

- 02Jul
- ASB 12:00–14:45 BSB
- LA3794 14:45 BSB–CWB
- LA3111 17:35 CWB–BSB

Antes, o Cockpit podia tratar o próximo item como reserva pura ou separar a reserva do voo. Agora o parser e o Cockpit tratam como **voo acionado por reserva**, preservando o início da disponibilidade para Saída Inteligente/despertador e exibindo o voo no card principal.

## Ajustes técnicos

- Parser AIMS detecta ASB/RES/HSB/HSBE antes de LA no mesmo bloco e gera dia acionado com pernas.
- Reconciliação física mescla reserva pura + voo contíguo no mesmo dia quando o fim da reserva encosta no início operacional do voo.
- Cockpit mostra status `Reserva acionada` ou `Sobreaviso acionado` quando há pernas LA.
- Próxima programação deixa de exibir reserva pura quando a reserva já foi convertida em voo.
- Mantidos WhatsApp Import, FreeCurrencyAPI, Infobip como VOIP principal e parser por continuidade física.

## Validação

- `node --check server.mjs`: OK
- `npm run build`: OK
- ZIP: 99 arquivos, sem `node_modules` e sem `dist`
