# CrewCheck v11.1.94 — Alertas operacionais de portão/status e meteorologia

Base: v11.1.91.

## Principais correções

- Cards da escala exibem limite de regulamentação quando aplicável:
  - RBAC 117 B.1 por hora de início e número de etapas.
  - Reserva acionada conta desde o início da reserva/apresentação.
  - Reserva/sobreaviso sem voo mostra janela lida e alerta de referência operacional.
- Menu web padronizado com visual Premium claro da tela Operacional, respeitando modo claro/escuro/sistema.
- Meteorologia operacional volta a aparecer nos cards da escala para piloto e comissário.
- Despertador/VOIP recebe fuso configurado pelo usuário, evitando exibição em UTC quando o sistema estiver em BSB.
- Google Calendar/ICS ganha modo recomendado “Voo + folgas”.
- Exportação padrão fica limpa: rotina, tripulação, diárias e detalhes ficam dentro do evento principal, sem criar compromissos separados.
- Deduplicação da escala reforçada e bloqueio para não criar sobreaviso/reserva aleatória a partir de texto residual do PDF.

## Validação local

- `node --check server.mjs` OK.
- Sintaxe TS/TSX validada por `typescript.transpileModule` nos arquivos principais.
- `npm run build` depende do `vite` instalado no ambiente do deploy.

## Mantido

- Infobip como ligação Premium.
- WhatsApp Premium/trial limitado e importação preparada.
- FreeCurrencyAPI.
- Parser por continuidade física da escala.


## v11.1.94
- Reancora jornadas por continuidade física, preservando voos que cruzam meia-noite.
- Separa nova jornada somente com repouso/pernoite >=12h entre programações na mesma localidade.
- Evita teletransporte visual: perna após meia-noite aparece no dia operacional correto.
- Deduplicação reforçada dos cards de voo e eventos de escala.
- Mantém v11.1.92: cards com regulamentação, menu Premium, meteorologia, fuso BSB, WhatsApp/Infobip e calendário limpo.
- Orientação Play Console: app pago em teste fechado/aberto cobra o testador; teste interno instala grátis.


## v11.1.94

- Monitor operacional em tempo quase real para voos próximos da escala.
- Notificação por mudança de portão, terminal, status confirmado/cancelado/embarque próximo/última chamada/atraso.
- Alerta meteorológico aeronáutico por METAR/TAF para aeroportos da escala.
- Endpoint `/api/operational-alerts/check` para app, Android/foreground e Telegram.
- Preferências novas em Configurações > Alertas: Monitor operacional, Status do voo e Meteorologia aeronáutica.
- Mantidas as correções anteriores: parser anti-teletransporte, fuso, calendário limpo, Infobip, WhatsApp Premium e FreeCurrencyAPI.
