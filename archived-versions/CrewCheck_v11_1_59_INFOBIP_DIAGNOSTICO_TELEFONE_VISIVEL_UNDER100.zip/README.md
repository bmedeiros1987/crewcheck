# CrewCheck v11.1.59 — Diagnóstico Infobip e telefone visível

Correção focada no teste de ligação premium:
- Mostra o campo **Telefone da ligação premium** diretamente no fluxo principal do Despertador CrewCheck.
- O teste Infobip agora envia telefone ao backend e não depende apenas do @Telegram.
- Mensagem de erro agora mostra o motivo real: falta de INFOBIP_BASE_URL, INFOBIP_API_KEY, INFOBIP_FROM_NUMBER ou telefone de destino.
- Backend retorna tentativas/diagnóstico do Infobip para evitar alerta genérico.
- Mantém gratuito = Telegram e Premium/Admin = Telegram + ligação.
- Mantém abertura Full HD, payload pequeno, CallMeBot fallback e ElevenLabs Admin.
