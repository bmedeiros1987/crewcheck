// CrewCheck v10.8.43 — runtime premium para permissões Android, notificações locais e radar privado.

declare global {
  interface Window {
    AndroidCrewCheckNative?: any;
    CrewCheckNative?: any;
    CrewCheckPremium?: any;
  }
}

function bridge(): any {
  return window.CrewCheckNative || window.AndroidCrewCheckNative || null;
}

async function requestLocation(): Promise<boolean> {
  const native = bridge();
  try {
    if (native?.requestLocation) return Boolean(native.requestLocation());
    if (!navigator.geolocation) return false;
    await new Promise<void>((resolve, reject) => navigator.geolocation.getCurrentPosition(() => resolve(), reject, { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 }));
    return true;
  } catch {
    return false;
  }
}

async function requestNotifications(): Promise<boolean> {
  const native = bridge();
  try {
    if (native?.requestNotifications) return Boolean(native.requestNotifications());
    if ('Notification' in window && Notification.permission !== 'granted') return (await Notification.requestPermission()) === 'granted';
    return 'Notification' in window && Notification.permission === 'granted';
  } catch {
    return false;
  }
}

function permissionStatus(): { location?: boolean; notifications?: boolean } {
  const native = bridge();
  try {
    if (native?.permissionStatus) {
      const raw = native.permissionStatus();
      if (typeof raw === 'string') return JSON.parse(raw);
      if (raw && typeof raw === 'object') return raw;
    }
  } catch {}
  return {
    location: undefined,
    notifications: 'Notification' in window ? Notification.permission === 'granted' : undefined,
  };
}

function notify(title: string, body: string): boolean {
  const native = bridge();
  try {
    if (native?.notify) return Boolean(native.notify(title, body));
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(title, { body });
      return true;
    }
  } catch {}
  return false;
}

function scheduleNotification(title: string, body: string, epochMillis: number): boolean {
  const native = bridge();
  try {
    if (native?.scheduleNotification) return Boolean(native.scheduleNotification(title, body, String(Math.round(epochMillis))));
  } catch {}
  const delay = Math.max(0, Number(epochMillis) - Date.now());
  if (delay <= 2147483647) window.setTimeout(() => notify(title, body), delay);
  return true;
}

async function fetchFlightStatus(flight: string, date?: string) {
  const params = new URLSearchParams({ flight, flightNumber: flight });
  if (date) params.set('date', date);
  const response = await fetch(`/api/radar/private-status?${params.toString()}`, { cache: 'no-store', credentials: 'same-origin' });
  return response.json();
}

function installDelegates() {
  document.addEventListener('click', (event) => {
    const target = event.target as HTMLElement | null;
    const button = target?.closest('button,a,[role="button"]') as HTMLElement | null;
    const text = String(button?.textContent || target?.textContent || '').toLowerCase();
    if (!text) return;
    if (text.includes('ativar localização') || text.includes('ativar localizacao') || text.includes('liberar localização') || text.includes('liberar localizacao')) {
      void requestLocation().then((ok) => window.dispatchEvent(new CustomEvent('crewcheck:location-permission', { detail: { ok } })));
    }
    if (text.includes('ativar notificação') || text.includes('ativar notificacao') || text.includes('liberar notificação') || text.includes('liberar notificacao')) {
      void requestNotifications().then((ok) => window.dispatchEvent(new CustomEvent('crewcheck:notification-permission', { detail: { ok } })));
    }
  }, true);
}

window.CrewCheckPremium = {
  version: '10.8.43',
  requestLocation,
  requestNotifications,
  permissionStatus,
  notify,
  scheduleNotification,
  fetchFlightStatus,
  scheduleLeaveReminder(title: string, body: string, departureEpochMillis: number, offsetMinutes = 90) {
    return scheduleNotification(title || 'Hora de sair', body || 'CrewCheck calculou sua saída para a próxima programação.', Number(departureEpochMillis) - offsetMinutes * 60_000);
  },
};

installDelegates();

export {};
