import fs from 'node:fs';

const read = (p) => fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : '';
const fail = (msg) => { console.error(`✗ ${msg}`); process.exit(1); };
const ok = (msg) => console.log(`✓ ${msg}`);

const pkg = JSON.parse(read('package.json') || '{}');
if (pkg.version !== '10.8.41') fail(`package.json precisa estar em 10.8.41, encontrado ${pkg.version}`);
ok('package.json 10.8.41');

const gradle = read('android-wrapper/app/build.gradle');
if (!/applicationId\s+'com\.crewcheck\.app'/.test(gradle)) fail('applicationId com.crewcheck.app ausente');
if (!/versionCode\s+10841/.test(gradle)) fail('versionCode 10841 ausente');
if (!/versionName\s+'10\.8\.41'/.test(gradle)) fail('versionName 10.8.41 ausente');
ok('Android package/versionCode/versionName compatíveis com atualização Play');

const manifest = read('android-wrapper/app/src/main/AndroidManifest.xml');
if (!manifest.includes('android.permission.ACCESS_FINE_LOCATION')) fail('permissão de localização fina ausente');
if (!manifest.includes('android.permission.ACCESS_COARSE_LOCATION')) fail('permissão de localização aproximada ausente');
if (!manifest.includes('android.permission.POST_NOTIFICATIONS')) fail('POST_NOTIFICATIONS ausente');
ok('permissões Android de localização/notificação presentes');

const mainActivity = read('android-wrapper/app/src/main/java/com/crewcheck/app/MainActivity.java');
if (!/NOTIFICATION_PERMISSION_REQUEST_CODE/.test(mainActivity)) fail('ponte de permissão de notificação ausente no Android');
if (!/LOCATION_PERMISSION_REQUEST_CODE/.test(mainActivity)) fail('ponte de permissão de localização ausente no Android');
if (!/AndroidCrewCheckNative/.test(mainActivity)) fail('bridge nativa AndroidCrewCheckNative ausente');
ok('bridge nativa Android presente');

const server = read('server.mjs');
if (server) {
  if (!server.includes('/api/radar/private-status')) fail('endpoint /api/radar/private-status ausente');
  ok('endpoint privado de radar presente');
} else {
  console.warn('⚠ server.mjs não encontrado para validar radar backend');
}

let allTextFiles = '';
if (fs.existsSync('client/src/lib')) {
  allTextFiles = fs.readdirSync('client/src/lib', { withFileTypes: true })
    .filter((d) => d.isFile())
    .map((d) => read(`client/src/lib/${d.name}`))
    .join('\n');
}

if (!/109\.44|meal|diaria|diária|ASB|RES/i.test(allTextFiles)) console.warn('⚠ não confirmei regras de diária por texto');
ok('validação v10.8.41 concluída');
