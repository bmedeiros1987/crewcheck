import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const fail = (msg) => { console.error(`✗ ${msg}`); process.exit(1); };
const ok = (msg) => console.log(`✓ ${msg}`);

const pkg = JSON.parse(read('package.json'));
if (pkg.version !== '10.8.42') fail(`package.json precisa estar em 10.8.42, encontrado ${pkg.version}`);
if (pkg.scripts?.['validate:10842'] !== 'node scripts/validate-v10.8.42.mjs') fail('script validate:10842 ausente');
ok('package.json 10.8.42');

const lock = JSON.parse(read('package-lock.json'));
if (lock.version !== '10.8.42' || lock.packages?.['']?.version !== '10.8.42') fail('package-lock precisa estar em 10.8.42');
ok('package-lock 10.8.42');

const gradle = read('android-wrapper/app/build.gradle');
if (!/applicationId\s+'com\.crewcheck\.app'/.test(gradle)) fail('applicationId com.crewcheck.app ausente');
if (!/versionCode\s+10842/.test(gradle)) fail('versionCode 10842 ausente');
if (!/versionName\s+'10\.8\.42'/.test(gradle)) fail('versionName 10.8.42 ausente');
ok('Android package/version OK');

const manifest = read('android-wrapper/app/src/main/AndroidManifest.xml');
for (const permission of ['android.permission.INTERNET', 'android.permission.ACCESS_FINE_LOCATION', 'android.permission.ACCESS_COARSE_LOCATION', 'android.permission.POST_NOTIFICATIONS']) {
  if (!manifest.includes(permission)) fail(`permissão ${permission} ausente`);
}
if (!manifest.includes('CrewCheckNotificationReceiver')) fail('receiver de notificações ausente');
ok('Manifest permissões Android OK');

const mainActivity = read('android-wrapper/app/src/main/java/com/crewcheck/app/MainActivity.java');
for (const marker of ['requestLocation', 'requestNotifications', 'scheduleNotification', 'permissionStatus']) {
  if (!mainActivity.includes(marker)) fail(`bridge nativa ${marker} ausente`);
}
ok('Bridge Android localização/notificação OK');

const app = read('client/src/App.tsx');
const radarSurface = app + '\n' + read('client/src/lib/crewcheckPremiumRuntime.ts') + '\n' + read('client/src/pages/Home.tsx') + '\n' + read('client/src/pages/Results.tsx');
if (!app.includes('crewcheck_last_loaded_version') || !app.includes('10.8.42')) fail('App.tsx não atualizou cache/versão 10.8.42');
if (!radarSurface.includes('/api/radar/private-status')) fail('frontend sem endpoint /api/radar/private-status');
ok('App versão/radar privado OK');

const runtime = read('client/src/lib/crewcheckPremiumRuntime.ts');
for (const marker of ["version: '10.8.42'", 'requestLocation', 'requestNotifications', 'scheduleLeaveReminder']) {
  if (!runtime.includes(marker)) fail(`runtime premium sem marcador ${marker}`);
}
ok('Runtime premium Android OK');

const home = read('client/src/pages/Home.tsx');
if (!home.includes("const APP_VERSION = '10.8.42'")) fail('Home.tsx não mostra 10.8.42');
const auth = read('client/src/pages/AuthPage.tsx');
if (!auth.includes("const APP_VERSION = '10.8.42'")) fail('AuthPage.tsx não mostra 10.8.42');
ok('Versão visível no app OK');

const workflow = read('.github/workflows/android-apk-aab.yml');
for (const marker of ['CREWCHECK_UPLOAD_KEYSTORE_BASE64', ':app:bundleRelease', ':app:assembleRelease', ':app:assembleDebug', 'validate:10842']) {
  if (!workflow.includes(marker)) fail(`workflow sem marcador ${marker}`);
}
ok('Workflow APK/AAB OK');

console.log('\nCrewCheck v10.8.42 validado com sucesso.');
