import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const fail = (msg) => { console.error(`✗ ${msg}`); process.exit(1); };
const ok = (msg) => console.log(`✓ ${msg}`);

const pkg = JSON.parse(read('package.json'));
if (pkg.version !== '10.8.43') fail(`package.json precisa estar em 10.8.43, encontrado ${pkg.version}`);
if (pkg.scripts?.['validate:10843'] !== 'node scripts/validate-v10.8.43.mjs') fail('script validate:10843 ausente');
ok('package.json 10.8.43');

const lock = JSON.parse(read('package-lock.json'));
if (lock.version !== '10.8.43' || lock.packages?.['']?.version !== '10.8.43') fail('package-lock precisa estar em 10.8.43');
ok('package-lock 10.8.43');

const gradle = read('android-wrapper/app/build.gradle');
if (!/applicationId\s+'com\.crewcheck\.app'/.test(gradle)) fail('applicationId com.crewcheck.app ausente');
if (!/versionCode\s+10843/.test(gradle)) fail('versionCode 10843 ausente');
if (!/versionName\s+'10\.8\.43'/.test(gradle)) fail('versionName 10.8.43 ausente');
ok('Android package/version OK');

const manifest = read('android-wrapper/app/src/main/AndroidManifest.xml');
for (const permission of ['android.permission.INTERNET', 'android.permission.ACCESS_FINE_LOCATION', 'android.permission.ACCESS_COARSE_LOCATION', 'android.permission.POST_NOTIFICATIONS']) {
  if (!manifest.includes(permission)) fail(`permissão ${permission} ausente`);
}
if (!manifest.includes('CrewCheckNotificationReceiver')) fail('receiver de notificações ausente');
ok('Manifest permissões Android OK');

const mainActivity = read('android-wrapper/app/src/main/java/com/crewcheck/app/MainActivity.java');
for (const marker of ['requestLocation', 'requestNotifications', 'scheduleNotification', 'permissionStatus', 'dispatchCrewCheckPermissionStatus', 'hasCrewCheckLocationPermission', 'hasCrewCheckNotificationPermission']) {
  if (!mainActivity.includes(marker)) fail(`bridge/permissão nativa ${marker} ausente`);
}
if (mainActivity.includes('requestNotificationPermissionIfNeeded();\n    }')) fail('pedido automático de notificação no onCreate ainda parece ativo');
ok('Bridge Android localização/notificação confirmável OK');

const app = read('client/src/App.tsx');
const runtime = read('client/src/lib/crewcheckPremiumRuntime.ts');
const home = read('client/src/pages/Home.tsx');
const dashboard = read('client/src/components/premium/Dashboard.tsx');
const css = read('client/src/index.css');

if (!app.includes('crewcheck_last_loaded_version') || !app.includes('10.8.43')) fail('App.tsx não atualizou cache/versão 10.8.43');
if (!runtime.includes("version: '10.8.43'")) fail('runtime premium não está em 10.8.43');
for (const marker of ['permissionStatus', 'requestLocation', 'requestNotifications', 'scheduleLeaveReminder']) {
  if (!runtime.includes(marker)) fail(`runtime premium sem marcador ${marker}`);
}
ok('Runtime premium Android OK');

if (!home.includes("const APP_VERSION = '10.8.43'")) fail('Home.tsx não mostra 10.8.43');
const auth = read('client/src/pages/AuthPage.tsx');
if (!auth.includes("const APP_VERSION = '10.8.43'")) fail('AuthPage.tsx não mostra 10.8.43');
ok('Versão visível no app OK');

for (const marker of ['crewcheck:permissions-updated', 'localização permitida', 'notificações permitidas', 'readCrewCheckPermissionStatus']) {
  if (!home.includes(marker) && !dashboard.includes(marker)) fail(`UI sem marcador de permissão ${marker}`);
}
ok('UI confirma localização/notificações OK');

for (const marker of ['--cc-bottom-safe-gesture', 'bottom: 0 !important', 'padding-bottom: calc(8.6rem', 'border-radius: 1.85rem 1.85rem 0 0']) {
  if (!css.includes(marker)) fail(`CSS safe-area/menu sem marcador ${marker}`);
}
ok('Menu inferior safe-area premium OK');

const workflow = read('.github/workflows/android-apk-aab.yml');
for (const marker of ['CREWCHECK_UPLOAD_KEYSTORE_BASE64', ':app:bundleRelease', ':app:assembleRelease', ':app:assembleDebug', 'validate:10843']) {
  if (!workflow.includes(marker)) fail(`workflow sem marcador ${marker}`);
}
ok('Workflow APK/AAB OK');

console.log('\nCrewCheck v10.8.43 validado com sucesso.');
