# CrewCheck v10.8.43 — Android Safe Area + Permissões Confirmáveis

Hotfix aplicado sobre a v10.8.42 para resolver o print enviado no Android.

## Correções

- Menu inferior ajustado para ficar mais baixo, preso ao rodapé, com faixa segura abaixo dos botões.
- O menu mantém espaço branco/escuro sob os ícones para não competir com a barra de gestos/funções do Android.
- Saída Inteligente agora solicita permissão nativa de localização antes de chamar geolocation no WebView.
- O app confirma e exibe status de localização: pendente ou permitida.
- O app confirma e exibe status de notificações: pendente ou permitida.
- O wrapper Android dispara evento `crewcheck:permissions-updated` após resposta do usuário.
- Notificações deixam de ser solicitadas automaticamente ao abrir; passam a ser pedidas por ação explícita do usuário.

## Android

- Package: `com.crewcheck.app`
- VersionCode: `10843`
- VersionName: `10.8.43`
