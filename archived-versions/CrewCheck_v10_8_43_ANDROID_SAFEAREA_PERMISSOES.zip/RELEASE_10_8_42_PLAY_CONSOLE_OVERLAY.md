# CrewCheck v10.8.42 — Play Console Overlay

Atualização preparada por cima dos arquivos enviados como base Play Console:

- Fonte enviado: `CrewCheck_v10_8_20_Final_VC10820_VN24.zip`
- Artefato Android enviado: `CrewCheck_v10_8_20_PREMIUM_AUTOMATION`
- Package preservado: `com.crewcheck.app`
- VersionCode novo: `10842`
- VersionName novo: `10.8.42`

## Correções mantidas/aplicadas

- Radar privado de voos no backend, sem abrir sites externos ao usuário.
- Saída Inteligente com ponte nativa Android para permissão de localização.
- Permissão Android para notificações e agendamento local de alertas.
- Diárias confiáveis com reserva/ASB sem herdar horário de HSB/sobreaviso.
- Apresentação antes do voo; fora de base contratual usa apresentação 1h antes quando não houver horário explícito.
- Salário com gratificação de chefe apenas quando o usuário for o primeiro CCM da lista.
- Escala exibindo tripulação quando a lista de tripulantes vier no PDF/escala.
- Workflow GitHub Actions para gerar APK debug, APK release e AAB release assinado.

## Assinatura

O AAB/APK novo precisa ser assinado com a mesma chave de upload/app signing aceita no Play Console.
Os secrets usados pelo workflow são:

- `CREWCHECK_UPLOAD_KEYSTORE_BASE64`
- `CREWCHECK_STORE_PASSWORD`
- `CREWCHECK_KEY_ALIAS`
- `CREWCHECK_KEY_PASSWORD`
