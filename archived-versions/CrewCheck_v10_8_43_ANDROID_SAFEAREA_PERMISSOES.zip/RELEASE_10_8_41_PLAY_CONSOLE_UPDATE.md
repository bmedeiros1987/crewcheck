# CrewCheck v10.8.41 — Play Console Update Android Premium

Base de compatibilidade enviada pelo usuário:

- Última versão no Play Console: `10.8.20`
- Package name: `com.crewcheck.app`
- VersionCode anterior: `10820`
- Nova versão preparada: `10.8.41`
- Novo versionCode: `10841`

Esta versão mantém o mesmo `applicationId` para permitir atualização por cima do app já publicado no Google Play, aumentando o `versionCode` para ser aceita como atualização.

Correções consolidadas nesta linha:

- Android Radar pelo endpoint interno `/api/radar/private-status`.
- Saída Inteligente com ponte nativa Android para localização.
- Permissão Android `POST_NOTIFICATIONS` para Android 13+.
- Diárias conservadoras para ASB/RES, evitando herdar horário de HSB.
- Apresentação de voo antes da decolagem; fora de base usa fallback de 1h antes quando ausente.
- Salário com gratificação de chefe somente se o usuário for o primeiro CCM da tripulação.
- Leitura e exibição de tripulação do voo quando a escala fornecer a seção de crew/tripulação.
- Radar privado sem disponibilizar Kayak/Google Flights/FlightStats para o usuário.

Observação: o AAB final deve ser assinado com a mesma chave de upload usada no Play Console.
