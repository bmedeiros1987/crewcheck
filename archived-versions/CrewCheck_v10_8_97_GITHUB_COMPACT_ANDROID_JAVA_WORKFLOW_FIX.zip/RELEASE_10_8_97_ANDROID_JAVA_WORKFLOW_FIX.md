# CrewCheck v10.8.97 — Android Java + Workflow shell-only

## Correções
- Corrigido erro do build Android em `MainActivity.java` causado por escapes Java/JavaScript dentro da automação iFlight.
- Substituído workflow Android por versão shell-only, sem `actions/checkout`, `setup-java`, `setup-android`, `setup-gradle` ou `upload-artifact`.
- Remove avisos de ações Node.js 20 do workflow Android.
- Baixa Android command-line tools, SDK 35 e Gradle 8.10.2 diretamente.
- Publica APK/AAB como assets de uma release fixa: `crewcheck-android-v10.8.97-latest`.
- Android atualizado para `versionCode 10897` e `versionName 10.8.97`.

## Observação
O aviso de Node.js 20 era um warning do runner por causa das actions JavaScript; a falha real estava no build debug, causada por Java/escapes no wrapper Android.
