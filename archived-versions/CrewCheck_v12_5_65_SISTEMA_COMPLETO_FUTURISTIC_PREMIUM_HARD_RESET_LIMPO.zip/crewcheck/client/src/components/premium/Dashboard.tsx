import React from 'react';
import {
  AlertTriangle,
  Bell,
  CalendarDays,
  Car,
  ChevronRight,
  Clock,
  CreditCard,
  FileText,
  Home as HomeIcon,
  Map,
  Menu,
  Moon,
  Plane,
  Radar,
  ShieldCheck,
  Sparkles,
  SunMedium,
  TrendingUp,
  Wifi,
} from 'lucide-react';

interface DashboardProps {
  user: {
    name: string;
    company: string;
    avatar?: string;
    base?: string;
    requiresDeparture?: boolean;
  };
  nextEvent?: {
    title: string;
    time: string;
    endTime: string;
    date: string;
    presentationTime?: string;
    departureTime?: string;
    route?: string;
    status?: string;
    gate?: string;
    gateSource?: string;
    terminal?: string;
    registration?: string;
    aircraftIcao?: string;
    estimatedArrival?: string;
    landingCountdown?: string;
    countdown?: string;
    source?: string;
    flightNumber?: string;
    isFlight?: boolean;
    targetIso?: string;
    smartDepartureTargetIso?: string;
    origin?: string;
    destination?: string;
    base?: string;
    requiresDeparture?: boolean;
    relation?: 'current' | 'today' | 'tomorrow' | 'future' | 'rest_followup' | 'fallback';
    relationLabel?: string;
    dayContext?: string;
    isToday?: boolean;
    isTomorrow?: boolean;
    isInProgress?: boolean;
    isAfterRest?: boolean;
    actualDateIso?: string;
  };
  onNavigate: (view: string) => void;
  onOpenMenu?: () => void;
  onToggleTheme?: () => void;
  currentMonthLabel?: string;
  perDiemForecastLabel?: string;
  perDiemForecastDetail?: string;
  todayDutyLabel?: string;
  todayDutyDetail?: string;
  weeklyDutyLabel?: string;
  weeklyDutyDetail?: string;
  weeklyDutyProgress?: number;
  canAccessC32FAcademy?: boolean;
  pendingOffline?: number;
  hasRoster?: boolean;
  alertsCount?: number;
  daysLoaded?: number;
  complianceScore?: number;
  seatForecast?: {
    symbol?: string;
    title?: string;
    route?: string;
    flight?: string;
    score?: string;
    riskLabel?: string;
    source?: string;
    updatedAt?: string;
    empty?: boolean;
  };
}

const APP_VERSION = '12.5.65';

type QuickActionProps = {
  icon: React.ReactNode;
  label: string;
  hint: string;
  tone?: 'cyan' | 'violet' | 'green' | 'amber' | 'pink';
  onClick: () => void;
};

function splitRoute(nextEvent?: DashboardProps['nextEvent']) {
  const raw = `${nextEvent?.route || nextEvent?.title || ''}`.toUpperCase();
  const match = raw.match(/\b([A-Z]{3})\b\s*(?:→|->|>|-|–|—|\/|\\)\s*\b([A-Z]{3})\b/);
  const origin = String(nextEvent?.origin || match?.[1] || '').toUpperCase().replace(/[^A-Z]/g, '').slice(0, 3);
  const destination = String(nextEvent?.destination || match?.[2] || '').toUpperCase().replace(/[^A-Z]/g, '').slice(0, 3);
  return { origin: origin || '—', destination: destination || '—' };
}

function sanitizeFlight(value?: string) {
  const match = String(value || '').match(/\b[A-Z]{2}\s?\d{3,4}\b/i);
  return match ? match[0].replace(/\s+/, '').toUpperCase() : '';
}

function airlineLabel(flight?: string) {
  const clean = String(flight || '').toUpperCase();
  if (/^(LA|JJ)\d/.test(clean)) return 'LATAM';
  if (/^G3\d/.test(clean)) return 'GOL';
  if (/^AD\d/.test(clean)) return 'AZUL';
  if (/^TP\d/.test(clean)) return 'TAP';
  return 'CrewCheck';
}

function safeTime(value?: string, fallback = '—') {
  const match = String(value || '').match(/\b\d{1,2}:\d{2}\b/);
  return match ? match[0].padStart(5, '0') : fallback;
}

function cleanValue(value?: string | null, fallback = '—') {
  const text = String(value || '').trim();
  if (!text || /^[-—]+$/.test(text)) return fallback;
  return text;
}

function cityName(code?: string) {
  const map: Record<string, string> = {
    BSB: 'Brasília', GRU: 'São Paulo', CGH: 'São Paulo', VCP: 'Campinas', FOR: 'Fortaleza', GIG: 'Rio de Janeiro', SDU: 'Rio de Janeiro', CNF: 'Belo Horizonte',
    SSA: 'Salvador', REC: 'Recife', POA: 'Porto Alegre', CWB: 'Curitiba', FLN: 'Florianópolis', MAO: 'Manaus', BEL: 'Belém', AJU: 'Aracaju',
    VIX: 'Vitória', NAT: 'Natal', JPA: 'João Pessoa', SLZ: 'São Luís', THE: 'Teresina', MCP: 'Macapá', RAO: 'Ribeirão Preto', UDI: 'Uberlândia',
    MIA: 'Miami', JFK: 'Nova York', LAX: 'Los Angeles', SCL: 'Santiago', EZE: 'Buenos Aires', MVD: 'Montevidéu', LIM: 'Lima', BOG: 'Bogotá', MAD: 'Madrid', BCN: 'Barcelona', LIS: 'Lisboa', MXP: 'Milão', LHR: 'Londres', CDG: 'Paris', FRA: 'Frankfurt', AMS: 'Amsterdã', FCO: 'Roma', DOH: 'Doha', DXB: 'Dubai',
  };
  const key = String(code || '').toUpperCase();
  return map[key] || (key === '—' ? '—' : key);
}

function formatEventDate(nextEvent?: DashboardProps['nextEvent'], short = false) {
  const candidates = [nextEvent?.actualDateIso, nextEvent?.targetIso, nextEvent?.date].filter(Boolean) as string[];
  for (const candidate of candidates) {
    const iso = candidate.length <= 10 ? `${candidate}T12:00:00` : candidate;
    const date = new Date(iso);
    if (!Number.isNaN(date.getTime())) {
      if (short) return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}`;
      return date.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: '2-digit' }).replace(/^./, (m) => m.toUpperCase());
    }
  }
  const text = String(nextEvent?.date || '—').trim();
  return text || '—';
}

function addMinutesToIso(iso?: string, minutes = 0) {
  if (!iso) return '';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '';
  return new Date(date.getTime() + minutes * 60000).toISOString();
}

function formatIsoTime(iso?: string) {
  if (!iso) return '';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

function shouldShowRealProgram(hasRoster: boolean, nextEvent?: DashboardProps['nextEvent']) {
  const text = `${nextEvent?.title || ''} ${nextEvent?.time || ''} ${nextEvent?.date || ''} ${nextEvent?.source || ''}`.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  return Boolean(hasRoster && nextEvent && !/importe sua escala|pdf exportado|escala antiga|historico/.test(text) && nextEvent.time !== 'PDF');
}

const Dashboard: React.FC<DashboardProps> = ({
  user,
  nextEvent,
  onNavigate,
  onOpenMenu,
  onToggleTheme,
  perDiemForecastLabel = '—',
  perDiemForecastDetail = 'Este mês',
  todayDutyLabel = '—',
  todayDutyDetail = 'Sem jornada hoje',
  weeklyDutyLabel = '—',
  weeklyDutyDetail = 'Horas da semana',
  weeklyDutyProgress = 0,
  pendingOffline = 0,
  hasRoster = false,
  alertsCount = 0,
  daysLoaded = 0,
  complianceScore = 100,
}) => {
  const hasRealProgram = shouldShowRealProgram(hasRoster, nextEvent);
  const route = splitRoute(nextEvent);
  const flightNumber = hasRealProgram ? (sanitizeFlight(nextEvent?.flightNumber || nextEvent?.title) || cleanValue(nextEvent?.title, 'Programação')) : 'Importar PDF';
  const isFlight = hasRealProgram && Boolean(nextEvent?.isFlight || sanitizeFlight(nextEvent?.flightNumber || nextEvent?.title));
  const airline = isFlight ? airlineLabel(flightNumber) : 'Escala';
  const eventDateShort = formatEventDate(nextEvent, true);
  const eventDateLong = formatEventDate(nextEvent, false);
  const presentation = hasRealProgram ? safeTime(nextEvent?.presentationTime || nextEvent?.time, '—') : '—';
  const departure = hasRealProgram ? safeTime(nextEvent?.departureTime || nextEvent?.time, '—') : '—';
  const arrival = hasRealProgram ? safeTime(nextEvent?.estimatedArrival || nextEvent?.endTime, '—') : '—';
  const gate = isFlight ? cleanValue(nextEvent?.gate, 'A confirmar') : '—';
  const terminal = cleanValue(nextEvent?.terminal, gate === 'A confirmar' ? 'Aguardando radar' : 'Terminal');
  const status = isFlight ? cleanValue(nextEvent?.status, 'Confirmado') : 'Aguardando escala';
  const departureTargetIso = nextEvent?.smartDepartureTargetIso || nextEvent?.targetIso || '';
  const fallbackLeave = departureTargetIso ? addMinutesToIso(departureTargetIso, -90) : '';
  const smartLeave = hasRealProgram && isFlight ? (formatIsoTime(fallbackLeave) || '—') : '—';
  const commuteAirport = route.origin !== '—' ? route.origin : (user.base || nextEvent?.base || 'BSB');
  const complianceLabel = Number.isFinite(complianceScore) ? `${Math.round(complianceScore)}%` : 'Ativo';

  return (
    <div className="cc1265-app-shell cc1265-dashboard" data-version={APP_VERSION}>
      <div className="cc1265-wallpaper" aria-hidden="true" />

      <header className="cc1265-topbar">
        <button type="button" className="cc1265-icon-btn" onClick={onOpenMenu} aria-label="Abrir menu">
          <Menu size={22} />
        </button>
        <div className="cc1265-brand">
          <div className="cc1265-logo"><Plane size={23} /></div>
          <div className="cc1265-brand-text">
            <strong>CrewCheck</strong>
            <small>Roster Intelligence</small>
          </div>
          <span className="cc1265-pill muted">Premium</span>
          <span className="cc1265-pill beta">Beta</span>
        </div>
        <button type="button" className="cc1265-icon-btn" onClick={onToggleTheme} aria-label="Alternar tema">
          <Moon size={20} className="cc1265-dark-only" />
          <SunMedium size={20} className="cc1265-light-only" />
        </button>
      </header>

      <main className="cc1265-content">
        <section className="cc1265-hero-title">
          <div>
            <p>Cockpit</p>
            <h1>Olá, {(user.name || 'Bruno Saraiva').split(/\s+/).filter(Boolean)[0] || 'Bruno'}.</h1>
          </div>
          {pendingOffline > 0 && <button type="button" onClick={() => onNavigate('history')} className="cc1265-sync-chip">{pendingOffline} offline</button>}
        </section>

        <section className="cc1265-kpi-row" aria-label="Resumo operacional">
          <KpiCard icon={<ShieldCheck />} label="Status RBAC" value={complianceLabel === '100%' ? 'Ativo' : complianceLabel} detail="Conformidade" tone="green" onClick={() => onNavigate('regulation')} />
          <KpiCard icon={<CreditCard />} label="Diárias" value={perDiemForecastLabel} detail={perDiemForecastDetail || 'Este mês'} tone="violet" onClick={() => onNavigate('perdiem')} />
          <KpiCard icon={<Bell />} label="Alerts" value={String(alertsCount || 0)} detail={alertsCount ? 'Não lidos' : 'Tudo certo'} tone="pink" onClick={() => onNavigate('alerts')} />
        </section>

        <section className="cc1265-card cc1265-next-card" aria-label="Próxima programação">
          <div className="cc1265-section-head">
            <div>
              <span>Próxima Programação</span>
              <h2>{hasRealProgram ? (isFlight ? 'Próximo voo' : 'Próxima atividade') : 'Importe sua escala'}</h2>
            </div>
            <button type="button" onClick={() => onNavigate('roster')}>Ver todas <ChevronRight size={17} /></button>
          </div>

          {!hasRealProgram ? (
            <div className="cc1265-empty-card">
              <Plane size={32} />
              <strong>Nenhuma escala ativa carregada.</strong>
              <p>Importe o PDF oficial para montar o cockpit, roster, diárias e alertas com dados reais.</p>
              <button type="button" onClick={() => onNavigate('import')}>Importar PDF</button>
            </div>
          ) : (
            <>
              <div className="cc1265-flight-topline">
                <div className="cc1265-airline">
                  <span className="cc1265-airline-mark">◆</span>
                  <strong>{airline}</strong>
                  <b>{flightNumber}</b>
                </div>
                <div className="cc1265-date-chip"><CalendarDays size={16} /><span>{eventDateShort}</span><small>{eventDateLong}</small></div>
              </div>

              <div className="cc1265-route">
                <div><b>{route.origin}</b><small>{cityName(route.origin)}</small></div>
                <div className="cc1265-route-mid"><i /><Plane size={27} /><i /></div>
                <div><b>{route.destination}</b><small>{cityName(route.destination)}</small></div>
              </div>

              <div className="cc1265-time-grid">
                <TimeBlock label={isFlight ? 'Apresentação' : 'Início'} value={presentation} tone="violet" />
                <TimeBlock label={isFlight ? 'Decolagem' : 'Fim'} value={departure} tone="cyan" />
                <TimeBlock label={isFlight ? 'Chegada' : 'Tipo'} value={isFlight ? arrival : 'Atividade'} tone="green" />
              </div>

              <div className="cc1265-info-grid two">
                <InfoBlock icon={<Map />} label="Portão" value={gate} detail={terminal} tone="violet" />
                <InfoBlock icon={<Plane />} label="Status" value={status} detail="Operação Normal" tone="green" />
              </div>
            </>
          )}
        </section>

        <section className={`cc1265-card cc1265-smart-card ${isFlight ? 'is-active' : 'is-muted'}`} aria-label="Saída Inteligente">
          <div className="cc1265-smart-head">
            <div className="cc1265-smart-icon"><Car size={27} /></div>
            <div>
              <span>Saída Inteligente</span>
              <h2>{isFlight ? smartLeave : '—'}</h2>
              <p>{isFlight ? 'Localização atual / hotel → aeroporto de apresentação' : 'Sem deslocamento operacional pendente'}</p>
            </div>
            <em>{isFlight ? 'CARRO' : 'PAUSADO'}</em>
          </div>
          <div className="cc1265-smart-route">
            <b>{isFlight ? `Localização atual / hotel → ${commuteAirport}` : 'Aguardando próxima programação'}</b>
            <span>{isFlight ? `${cityName(commuteAirport)} · TomTom principal · alvo ${presentation}` : 'Folga, descanso ou escala não carregada não geram saída.'}</span>
          </div>
          <div className="cc1265-info-grid three">
            <InfoBlock icon={<Clock />} label="Chegar" value={presentation} detail="Apresentação" tone="cyan" />
            <InfoBlock icon={<Car />} label="Tempo" value="1h 25min" detail="Estimativa segura" tone="violet" />
            <InfoBlock icon={<ShieldCheck />} label="Status" value={isFlight ? 'Pronto' : 'Pausado'} detail={isFlight ? 'Monitorável' : 'Sem voo'} tone="green" />
          </div>
          <div className="cc1265-actions-row">
            <button type="button" onClick={() => onNavigate('departure')}>Abrir Saída <ChevronRight size={17} /></button>
            <button type="button" className="secondary" onClick={() => onNavigate('flightboard')}>Radar</button>
          </div>
        </section>

        <section className="cc1265-module-grid" aria-label="Módulos rápidos">
          <QuickAction icon={<Radar />} label="Radar" hint="Portão e status" tone="violet" onClick={() => onNavigate('flightboard')} />
          <QuickAction icon={<Wifi />} label="Meteorologia" hint="METAR/TAF" tone="cyan" onClick={() => onNavigate('weather')} />
          <QuickAction icon={<CreditCard />} label="Diárias" hint="Previsão" tone="green" onClick={() => onNavigate('perdiem')} />
          <QuickAction icon={<TrendingUp />} label="Salário" hint="Resumo" tone="amber" onClick={() => onNavigate('salary')} />
          <QuickAction icon={<FileText />} label="Relatórios" hint="Exportações" tone="pink" onClick={() => onNavigate('reports')} />
        </section>

        <section className="cc1265-mini-strip">
          <span><CalendarDays size={15} /> {daysLoaded || 0} dias carregados</span>
          <span><Clock size={15} /> {todayDutyLabel} · {todayDutyDetail}</span>
          <span><Sparkles size={15} /> {weeklyDutyLabel} · {weeklyDutyDetail}</span>
        </section>
      </main>
    </div>
  );
};

function KpiCard({ icon, label, value, detail, tone, onClick }: { icon: React.ReactNode; label: string; value: string; detail: string; tone: string; onClick: () => void }) {
  return <button type="button" className={`cc1265-kpi tone-${tone}`} onClick={onClick}>
    <span>{icon}</span>
    <small>{label}</small>
    <b>{value || '—'}</b>
    <em>{detail || '—'}</em>
  </button>;
}

function TimeBlock({ label, value, tone }: { label: string; value: string; tone: string }) {
  return <div className={`cc1265-time-block tone-${tone}`}>
    <small>{label}</small>
    <b>{value || '—'}</b>
    <span><Clock size={13} /> Local</span>
  </div>;
}

function InfoBlock({ icon, label, value, detail, tone }: { icon: React.ReactNode; label: string; value: string; detail: string; tone: string }) {
  return <div className={`cc1265-info-block tone-${tone}`}>
    <span>{icon}</span>
    <small>{label}</small>
    <b>{value || '—'}</b>
    <em>{detail || '—'}</em>
  </div>;
}

function QuickAction({ icon, label, hint, tone = 'cyan', onClick }: QuickActionProps) {
  return <button type="button" className={`cc1265-module tone-${tone}`} onClick={onClick}>
    <span>{icon}</span>
    <b>{label}</b>
    <small>{hint}</small>
    <ChevronRight size={17} />
  </button>;
}

export default Dashboard;
