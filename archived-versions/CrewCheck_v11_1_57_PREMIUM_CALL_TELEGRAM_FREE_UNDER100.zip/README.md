# CrewCheck v11.1.57 — Premium Call Gate + Telegram gratuito

Atualização sobre o Despertador CrewCheck:

- Ligações automáticas por Infobip/CallMeBot ficam restritas a usuários Premium/Admin.
- Usuários gratuitos continuam recebendo alerta pelo Telegram, com confirmação/soneca quando disponível.
- Backend bloqueia a chamada mesmo que alguém tente salvar preferências antigas ou chamar o endpoint manualmente.
- Tela de Configurações explica: gratuito = Telegram; Premium = Telegram + ligação concierge.
- Mantidos: Infobip Voice TTS, CallMeBot fallback, ElevenLabs Admin, abertura Full HD 1080x1920 e payload pequeno.
- Cache PWA atualizado para 11.1.57.
