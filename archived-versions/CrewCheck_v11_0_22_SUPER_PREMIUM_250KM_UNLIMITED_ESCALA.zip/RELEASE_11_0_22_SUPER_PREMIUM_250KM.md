# CrewCheck v11.0.22 — Super Premium 250 km + Unlimited

## O que foi corrigido

- **Saída Inteligente por raio operacional de 250 km**
  - O modo Auto agora aplica a regra: até 250 km compara meios terrestres; acima de 250 km só considera voo quando o usuário ativar essa preferência.
  - O backend passa a devolver `distancePolicy` com distância operacional, raio configurado, decisão tomada e modais comparados.
  - Adicionado suporte a `TWO_WHEELER`/moto-app como opção terrestre.

- **Opções de deslocamento atualizadas**
  - Botões: Auto 250 km, Carro, Transporte, Uber/99, Moto/app, Carro + voo, Uber/99 + voo e Transporte + voo.
  - Toggle salvo em `crewcheck_departure_auto_flight_over_250`.
  - A requisição `/api/smart-departure` envia `autoFlightOver250` e `longDistancePolicy`.

- **Premium Unlimited pelo sistema**
  - Novo endpoint administrativo: `POST /api/admin/billing/grant-unlimited`.
  - Novo card no Dashboard Admin para liberar Premium Unlimited informando o e-mail do usuário já cadastrado.
  - O status `premium_lifetime`/`lifetime` agora é reconhecido como acesso Premium real, não apenas via variável de ambiente.
  - Registro de auditoria em `crewcheck_audit_logs` com e-mail mascarado.

- **Escala sem sobreposição**
  - O card mobile da escala deixou de expandir detalhes dentro de um `<button>`, evitando conflito de layout em Android/iPad.
  - CSS premium reforçado para impedir overflow, truncamento errado e cards sobrescritos.
  - Ajustes responsivos para telas pequenas e iPad.

## Validação realizada

- `npm run check` concluído com sucesso.
- `npm run build` concluído com sucesso.
- `node --check server.mjs` concluído com sucesso.

## Observações

- Para liberar Unlimited, o usuário precisa já ter cadastro no CrewCheck. Se o e-mail não existir, o painel retorna aviso para cadastrar primeiro.
- O valor do raio pode ser alterado no Render pela variável `CREWCHECK_LONG_DISTANCE_THRESHOLD_KM`, mas o padrão desta versão é 250 km.
