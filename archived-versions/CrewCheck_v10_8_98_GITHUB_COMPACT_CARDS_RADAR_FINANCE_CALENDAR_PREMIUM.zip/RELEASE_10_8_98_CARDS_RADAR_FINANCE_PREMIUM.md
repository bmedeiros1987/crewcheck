# CrewCheck v10.8.98 — Cards, Radar, Diárias e Calendar Premium

## Ajustes visuais
- Cards do sistema padronizados no padrão premium dos cards de Rotina.
- Badge de porcentagem da rotina deixa de ficar branco/ilegível.
- Cards de Ajuda/Suporte ajustados para o padrão premium.
- Correções de legibilidade em Diária Internacional e Base Virtual.
- Menu inferior ganhou opção de encolher/expandir e modo paisagem mais compacto.

## Escala
- Subtítulo do voo volta a priorizar apresentação quando aplicável.
- Decolagem, chegada e apresentação aparecem em Mais detalhes do card.
- Data no modo paisagem reorganizada: dia da semana, número e mês.

## Radar
- Radar passa a funcionar mesmo sem API ativa: usa voos lidos da escala importada como fallback offline e abre busca externa.

## Configurações e perfil
- Configurações abrem em atalhos/manual, não direto no perfil.
- Foto de perfil passa a ter espelho local por e-mail para melhorar sincronização entre dispositivos quando a conta estiver disponível.

## Diárias
- Fechamentos reais informados pelo administrador entram como calibração prioritária.
- Semanas 13/05, 20/05, 27/05 e 03/06 calibradas com valores reais informados.

## Google Calendar
- Exportação/sincronização passa a remover somente eventos com marca CrewCheck ou propriedade privada do CrewCheck.
- Eventos pessoais no calendário são preservados.

## Versão
- App: 10.8.98
- Android: versionCode 10898 / versionName 10.8.98
