# CrewCheck v11.1.07 · Telegram Voice Note Amigo + Check-in + Bash rápido

Hotfix cumulativo baseado na v11.1.06.

## Ajustes desta versão

- Concierge do Telegram volta a enviar áudio no formato padrão de **voice note**.
- O problema corrigido é o conteúdo do áudio: menos boletim, menos robótico, mais parecido com um amigo mandando áudio.
- Modo ATIS fica reservado somente para Meteorologia, METAR e TAF.
- Respostas de escala traduzem siglas antes de falar: ASB, HSB, DO, PS, MT, RCFI, CBF, EMER, aeroportos e voos.
- Reserva e voo extra na base lembram, em tom natural, de preencher o formulário de check-in.
- Bash rápido mantido sem `npm install` e sem `npm run build` no Termux por padrão.

## Android

- versionName: 11.1.07
- versionCode: 11107

## Validação recomendada

```bash
node --check server.mjs
npm run check
npm run build
```

## Variável opcional no Render

Para forçar voice note, deixe:

```bash
TELEGRAM_CONCIERGE_AUDIO_SEND_MODE=voice
```
