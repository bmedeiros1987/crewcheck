import type { CrewRoster } from './pdfParser';
import type { ComplianceResult, GymRecommendation } from './complianceEngine';
import { authFetch, getStoredUser } from './authClient';

export interface DatabaseStatus {
  ok: boolean;
  connected?: boolean;
  databaseConfigured?: boolean;
  database?: string;
  user_name?: string;
  now?: string;
  message?: string;
  detail?: string;
  storage?: {
    provider?: string;
    mode?: string;
    configured?: boolean;
    databasePrimary?: boolean;
    bucket?: string | null;
    urlConfigured?: boolean;
    secretConfigured?: boolean;
    publishableConfigured?: boolean;
    jwksConfigured?: boolean;
    maxFileBytes?: number;
    freeBackupLimit?: number;
    freeTelegramBackupLimit?: number;
    premiumBackupPriority?: boolean;
  };
}

export interface SavedRosterSummary {
  id: string;
  createdAt: string;
  crewName: string | null;
  crewId: string | null;
  base: string | null;
  rank: string | null;
  airline: string | null;
  year: number | null;
  month: number | null;
  sourceFileName: string | null;
  score: number | null;
  intensityScore: number | null;
  alertsCount: number;
  criticalAlertsCount: number;
  checksum: string | null;
  isActive?: boolean;
  activeAt?: string | null;
  deletedAt?: string | null;
  importStatus?: string | null;
  storageProvider?: string | null;
  sourceStoragePath?: string | null;
  sourceFileSizeBytes?: number | null;
  storageUploadedAt?: string | null;
  storageReady?: boolean;
}

export interface SaveRosterPayload {
  roster: CrewRoster;
  compliance: ComplianceResult;
  gym: GymRecommendation[];
  sourceFileName?: string | null;
  checksum?: string;
  sourceFileDataBase64?: string | null;
  sourceMimeType?: string | null;
  sourceFileSize?: number | null;
}

async function jsonFetch<T>(url: string, init?: RequestInit): Promise<T> {
  return authFetch<T>(url, init);
}

export async function getDatabaseStatus(): Promise<DatabaseStatus> {
  return jsonFetch<DatabaseStatus>('/api/db/status');
}

export async function listSavedRosters(limit = 72): Promise<SavedRosterSummary[]> {
  const local = getLocalRosterSummaries(limit);
  try {
    const payload = await jsonFetch<{ ok: boolean; rosters: SavedRosterSummary[] }>(`/api/rosters?limit=${limit}&manager=1`);
    let online = payload.rosters || [];
    if (!online.some((item) => item.isActive)) {
      try {
        const active = await jsonFetch<{ ok: boolean; roster?: SavedRosterSummary | null }>(`/api/rosters/active`, { cache: 'no-store' });
        if (active?.roster?.id) online = [active.roster, ...online];
      } catch {
        // Alguns backends antigos ainda não expõem /active; o histórico local cobre o iOS.
      }
    }
    const seen = new Set<string>();
    const merged: SavedRosterSummary[] = [];
    for (const item of [...online, ...local]) {
      const key = item.checksum || `${item.year || ''}:${item.month || ''}:${item.crewId || item.crewName || item.id}`;
      if (seen.has(key)) continue;
      seen.add(key);
      merged.push(item);
    }
    return merged.sort((a, b) => Number(Boolean(b.isActive)) - Number(Boolean(a.isActive)) || String(b.year || 0).localeCompare(String(a.year || 0)) || Number(b.month || 0) - Number(a.month || 0) || String(b.createdAt || '').localeCompare(String(a.createdAt || ''))).slice(0, limit);
  } catch {
    return local;
  }
}

export async function saveRosterAnalysis(payload: SaveRosterPayload): Promise<SavedRosterSummary> {
  const result = await jsonFetch<{ ok: boolean; roster: SavedRosterSummary }>('/api/rosters', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
  return result.roster;
}

export async function openSavedRoster(id: string): Promise<{ roster: CrewRoster; compliance: ComplianceResult; gym: GymRecommendation[] }> {
  const local = findLocalRoster(id);
  if (id.startsWith('local-') || id.startsWith('offline-')) {
    if (local) return { roster: local.roster, compliance: local.compliance, gym: local.gym || [] };
  }
  try {
    const payload = await jsonFetch<{ ok: boolean; data: { roster: CrewRoster; compliance: ComplianceResult; gym: GymRecommendation[] } }>(`/api/rosters/${id}`);
    return payload.data;
  } catch (error) {
    if (local) return { roster: local.roster, compliance: local.compliance, gym: local.gym || [] };
    throw error;
  }
}

export async function openActiveRoster(): Promise<{ roster: CrewRoster; compliance: ComplianceResult; gym: GymRecommendation[]; summary?: SavedRosterSummary | null }> {
  const local = getLocalRosterSummaries(1)[0];
  try {
    const payload = await jsonFetch<{ ok: boolean; roster?: SavedRosterSummary | null; data?: { roster: CrewRoster; compliance: ComplianceResult; gym: GymRecommendation[] } }>(`/api/rosters/active`, { cache: 'no-store' });
    if (payload?.data?.roster?.days?.length) {
      return { roster: payload.data.roster, compliance: payload.data.compliance, gym: payload.data.gym || [], summary: payload.roster || null };
    }
    throw new Error('Escala ativa não retornou dados.');
  } catch (error) {
    if (local?.id) {
      const data = await openSavedRoster(local.id);
      return { ...data, summary: local };
    }
    throw error;
  }
}


export async function deleteRosterAnalysis(id: string): Promise<boolean> {
  if (id.startsWith('local-') || id.startsWith('offline-')) {
    deleteLocalRoster(id);
    return true;
  }
  try {
    const payload = await jsonFetch<{ ok: boolean }>(`/api/rosters/${id}`, { method: 'DELETE' });
    deleteLocalRoster(id);
    return Boolean(payload.ok);
  } catch (error) {
    const local = findLocalRoster(id);
    if (local) {
      deleteLocalRoster(id);
      return true;
    }
    throw error;
  }
}

export async function activateRosterAnalysis(id: string): Promise<SavedRosterSummary | null> {
  if (id.startsWith('local-') || id.startsWith('offline-')) return null;
  const payload = await jsonFetch<{ ok: boolean; roster?: SavedRosterSummary }>(`/api/rosters/${id}/activate`, { method: 'POST' });
  return payload.roster || null;
}

export interface StoredPeriodStats {
  id: string;
  period: string;
  year: number | null;
  month: number | null;
  daysAnalyzed: number;
  flightSegments: number;
  daysOff: number;
  layovers: number;
  standby: number;
  reserve: number;
  gymGoodDays: number;
  gymAvoidDays: number;
  heavyDays: number;
  score: number;
  intensityScore: number;
  alertsCount: number;
  criticalAlertsCount: number;
}

export interface StoredStatsBlock {
  mode: 'personal' | 'global';
  summary: {
    rostersCount: number;
    firstPeriod: string | null;
    lastPeriod: string | null;
    avgScore: number;
    avgIntensity: number;
    avgAlerts: number;
    avgCriticalAlerts: number;
    avgFlightSegments: number;
    avgDaysOff: number;
    avgLayovers: number;
    avgGymGoodDays: number;
    avgHeavyDays: number;
  };
  periods: StoredPeriodStats[];
  disclaimer: string;
}

export interface StoredStatsResponse {
  ok: boolean;
  personal: StoredStatsBlock;
  global: StoredStatsBlock;
  notice: string;
}

export async function getStoredStats(): Promise<StoredStatsResponse> {
  try {
    return await jsonFetch<StoredStatsResponse>('/api/stats');
  } catch {
    return buildLocalStoredStats();
  }
}


const LEGACY_LOCAL_HISTORY_KEY = 'crewcheck_local_history_v1';

function localHistoryKey(): string {
  try {
    const user = getStoredUser();
    const raw = String(user?.id || user?.email || 'anon').trim().toLowerCase();
    const safe = raw.replace(/[^a-z0-9_-]+/g, '_').slice(0, 80) || 'anon';
    return `crewcheck_local_history_v11_${safe}`;
  } catch {
    return 'crewcheck_local_history_v11_anon';
  }
}


type LocalHistoryItem = {
  id: string;
  checksum: string;
  createdAt: string;
  sourceFileName?: string | null;
  roster: CrewRoster;
  compliance: ComplianceResult;
  gym: GymRecommendation[];
};


function safeStorageScope(): string {
  try {
    const user = getStoredUser();
    const raw = String(user?.id || user?.email || 'anon').trim().toLowerCase();
    return raw.replace(/[^a-z0-9_-]+/g, '_').slice(0, 80) || 'anon';
  } catch {
    return 'anon';
  }
}

function localHistoryKeys(): string[] {
  const scope = safeStorageScope();
  const keys = new Set<string>([
    localHistoryKey(),
    `crewcheck_local_history_v11_${scope}`,
    'crewcheck_local_history_v11_anon',
    LEGACY_LOCAL_HISTORY_KEY,
  ]);
  try {
    for (let i = 0; i < localStorage.length; i += 1) {
      const key = localStorage.key(i) || '';
      if (/^crewcheck_local_history_/i.test(key)) keys.add(key);
    }
  } catch {
    // iOS modo privado pode bloquear enumeração do localStorage.
  }
  return Array.from(keys).filter(Boolean);
}

function normalizeLocalHistoryItem(raw: any, index = 0): LocalHistoryItem | null {
  const roster = raw?.roster || raw?.data?.roster;
  if (!roster?.days?.length) return null;
  const compliance = raw?.compliance || raw?.data?.compliance || ({ score: 0, alerts: [] } as any);
  const gym = Array.isArray(raw?.gym) ? raw.gym : Array.isArray(raw?.data?.gym) ? raw.data.gym : [];
  const checksum = String(raw?.checksum || `${roster?.crewId || roster?.crewName || 'crew'}:${roster?.year || '0000'}:${String(roster?.month || '00').padStart(2, '0')}`);
  return {
    id: String(raw?.id || `local-recovered-${checksum}-${index}`).replace(/[^a-zA-Z0-9:_-]/g, '-'),
    checksum,
    createdAt: raw?.createdAt || raw?.updatedAt || new Date().toISOString(),
    sourceFileName: raw?.sourceFileName || raw?.filename || raw?.source || 'Escala recuperada do dispositivo',
    roster,
    compliance,
    gym,
  };
}

function readLocalHistory(): LocalHistoryItem[] {
  const seen = new Set<string>();
  const items: LocalHistoryItem[] = [];
  for (const key of localHistoryKeys()) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) continue;
      const parsed = JSON.parse(raw);
      const list = Array.isArray(parsed) ? parsed : [parsed];
      list.forEach((entry, index) => {
        const item = normalizeLocalHistoryItem(entry, index);
        if (!item) return;
        const dedupe = item.checksum || periodHistoryKey(item);
        if (seen.has(dedupe)) return;
        seen.add(dedupe);
        items.push(item);
      });
    } catch {
      // Ignora chaves antigas/corrompidas.
    }
  }
  return items.sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
}

function findLocalRoster(id: string): LocalHistoryItem | null {
  return readLocalHistory().find((item) => item.id === id || item.checksum === id) || null;
}

function deleteLocalRoster(id: string): void {
  for (const key of localHistoryKeys()) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) continue;
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) continue;
      const next = parsed.filter((entry: any) => {
        const item = normalizeLocalHistoryItem(entry);
        return item && item.id !== id && item.checksum !== id;
      });
      localStorage.setItem(key, JSON.stringify(next));
    } catch {
      // LocalStorage pode estar indisponível no modo privado.
    }
  }
}

function readLocalActiveRosterSnapshots(): LocalHistoryItem[] {
  const scope = safeStorageScope();
  const keys = new Set<string>([
    `crewcheck_active_roster_snapshot_${scope}`,
    `crewcheck_latest_roster_bundle_${scope}`,
    `crewcheck_roster_sync_latest_v11_${scope}`,
    'crewcheck_last_roster_bundle_v11107',
    'crewcheck_last_roster_bundle_v11102',
    'crewcheck_last_roster_bundle_v11101',
    'crewcheck_last_roster_bundle_v11100',
    'crewcheck_last_roster_bundle_v11099',
    'crewcheck_last_roster_bundle_v11098',
    'crewcheck_roster_sync_latest_v11_anon',
    'crewcheck_latest_roster_bundle_anon',
    'crewcheck_active_roster_snapshot_anon',
    'crewcheck_latest_roster_bundle',
  ]);
  try {
    for (let i = 0; i < localStorage.length; i += 1) {
      const key = localStorage.key(i) || '';
      if (/crewcheck_(active_roster_snapshot|latest_roster_bundle|last_roster_bundle|roster_sync_latest)/i.test(key)) keys.add(key);
    }
  } catch {}
  const seen = new Set<string>();
  const out: LocalHistoryItem[] = [];
  Array.from(keys).forEach((key, index) => {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) return;
      const payload = JSON.parse(raw);
      const item = normalizeLocalHistoryItem({ ...payload, id: `local-active-${scope}-${index}`, sourceFileName: payload.sourceFileName || 'Escala ativa recuperada no iOS' }, index);
      if (!item) return;
      const dedupe = item.checksum || periodHistoryKey(item);
      if (seen.has(dedupe)) return;
      seen.add(dedupe);
      out.push(item);
    } catch {}
  });
  return out.sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
}

function readLocalActiveRosterSnapshot(): LocalHistoryItem | null {
  return readLocalActiveRosterSnapshots()[0] || null;
}

function getLocalRosterSummaries(limit: number): SavedRosterSummary[] {
  const seen = new Set<string>();
  const activeSnapshots = readLocalActiveRosterSnapshots();
  const sourceItems = [...activeSnapshots, ...readLocalHistory()];
  const unique = sourceItems.filter((item) => {
    const key = periodHistoryKey(item);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, limit);
  return unique.map((item) => ({
    id: item.id,
    createdAt: item.createdAt,
    crewName: item.roster.crewName || null,
    crewId: item.roster.crewId || null,
    base: item.roster.base || null,
    rank: item.roster.rank || null,
    airline: item.roster.airline || null,
    year: Number(item.roster.year) || null,
    month: Number(item.roster.month) || null,
    sourceFileName: item.sourceFileName || null,
    score: Number(item.compliance?.score ?? 0),
    intensityScore: Number(item.compliance?.loadAnalysis?.intensityScore ?? 0),
    alertsCount: Array.isArray(item.compliance?.alerts) ? item.compliance.alerts.length : 0,
    criticalAlertsCount: Array.isArray(item.compliance?.alerts) ? item.compliance.alerts.filter((a: any) => a?.severity === 'error').length : 0,
    checksum: item.checksum,
    isActive: item.id.startsWith('local-active-'),
    importStatus: item.id.startsWith('local-active-') ? 'local_active_ios' : 'local',
    storageReady: false,
  }));
}

function periodHistoryKey(item: LocalHistoryItem): string {
  return `${item.roster.crewId || item.roster.crewName || 'crew'}:${item.roster.year || '0000'}:${item.roster.month || '00'}`;
}

function buildLocalStoredStats(): StoredStatsResponse {
  const seenPeriods = new Set<string>();
  const historyByPeriod = readLocalHistory().filter((item) => {
    const key = periodHistoryKey(item);
    if (seenPeriods.has(key)) return false;
    seenPeriods.add(key);
    return true;
  });
  const periods = historyByPeriod.map((item) => {
    const roster = item.roster;
    const compliance = item.compliance;
    const gym = item.gym || [];
    const days = Array.isArray(roster.days) ? roster.days : [];
    const alerts = Array.isArray(compliance?.alerts) ? compliance.alerts : [];
    const month = Number(roster.month) || null;
    const year = Number(roster.year) || null;
    return {
      id: item.id,
      period: month && year ? `${String(month).padStart(2, '0')}/${year}` : 'Local',
      year,
      month,
      daysAnalyzed: days.length,
      flightSegments: days.reduce((sum, day) => sum + (day.legs?.length || 0), 0),
      daysOff: days.filter((day) => ['DO', 'DR', 'DOF'].includes(day.type) || ['DOP', 'DOPR', 'VC', 'FOLGA'].includes(String(day.pairingCode || '').toUpperCase())).length,
      layovers: days.filter((day) => day.type === 'LAYOVER').length,
      standby: days.filter((day) => day.type === 'HSB' || day.type === 'HSBE').length,
      reserve: days.filter((day) => day.type === 'ASB' || day.type === 'RES').length,
      gymGoodDays: gym.filter((g: any) => g.priority === 'high').length,
      gymAvoidDays: gym.filter((g: any) => g.priority === 'avoid' || g.priority === 'low').length,
      heavyDays: compliance?.loadAnalysis?.hardestDays?.length || 0,
      score: Number(compliance?.score ?? 0),
      intensityScore: Number(compliance?.loadAnalysis?.intensityScore ?? 0),
      alertsCount: alerts.length,
      criticalAlertsCount: alerts.filter((a: any) => a?.severity === 'error').length,
    };
  });
  const summary = summarizePeriods(periods);
  const block: StoredStatsBlock = {
    mode: 'personal',
    summary,
    periods,
    disclaimer: 'Histórico local deste aparelho. Comparativo superficial e não oficial.',
  };
  return {
    ok: true,
    personal: block,
    global: { mode: 'global', summary: summarizePeriods([]), periods: [], disclaimer: 'Comparativo geral indisponível sem conexão com o banco.' },
    notice: 'Dados locais/superficiais. Não use como prova, documento oficial ou argumento perante empresa/terceiros.',
  };
}

function summarizePeriods(periods: StoredPeriodStats[]): StoredStatsBlock['summary'] {
  const avg = (selector: (item: StoredPeriodStats) => number) => periods.length ? Math.round(periods.reduce((sum, item) => sum + selector(item), 0) / periods.length) : 0;
  return {
    rostersCount: periods.length,
    firstPeriod: periods[0]?.period || null,
    lastPeriod: periods[periods.length - 1]?.period || null,
    avgScore: avg((p) => p.score),
    avgIntensity: avg((p) => p.intensityScore),
    avgAlerts: avg((p) => p.alertsCount),
    avgCriticalAlerts: avg((p) => p.criticalAlertsCount),
    avgFlightSegments: avg((p) => p.flightSegments),
    avgDaysOff: avg((p) => p.daysOff),
    avgLayovers: avg((p) => p.layovers),
    avgGymGoodDays: avg((p) => p.gymGoodDays),
    avgHeavyDays: avg((p) => p.heavyDays),
  };
}
