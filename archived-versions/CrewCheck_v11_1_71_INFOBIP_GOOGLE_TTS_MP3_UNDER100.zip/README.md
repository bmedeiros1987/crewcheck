# CrewCheck v11.1.71 — Infobip + Google TTS MP3

Despertador Premium usando Infobip para a ligação e TTS API/Google para gerar o áudio MP3 em português. Mantém conversor de moedas corrigido, botões legíveis e Regulamentação com pernas 1 a 5.
