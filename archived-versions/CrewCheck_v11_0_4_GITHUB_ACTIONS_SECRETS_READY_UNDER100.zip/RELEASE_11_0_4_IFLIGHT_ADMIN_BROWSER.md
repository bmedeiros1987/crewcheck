# CrewCheck v11.0.4 — iFlight Admin Browser

## Objetivo

Reforçar o iFlight somente para administrador e melhorar o fluxo de download automático autorizado da escala.

## Ajustes

- iFlight permanece oculto para usuários comuns.
- Usuário comum continua com importação manual de PDF oficial.
- Admin ganha seletor de portal oficial: iFlight Crew e iFlight CWP.
- Android WebView preserva o portal CWP quando escolhido.
- Se o portal Crew retornar 403 no Android, o app tenta o CWP automaticamente antes de exibir erro final.
- Toolbar nativa ganhou botão CWP.
- Mensagens deixam claro que o CrewCheck não burla permissão; usa apenas sessão oficial autorizada.
- Modo Web/PWA informa limitação real do navegador: não há navegador interno completo quando o portal bloqueia iframe/CORS/SSO.

## Versão Android

- versionName: 11.0.4
- versionCode: 11004

## Validação

- npm run check
- npm run build
