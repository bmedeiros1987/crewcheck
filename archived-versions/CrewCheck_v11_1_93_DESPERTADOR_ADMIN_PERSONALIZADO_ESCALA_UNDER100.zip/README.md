# CrewCheck v11.1.93 — Despertador Admin personalizado

Hotfix baseado na v11.1.92 com painel administrativo para usar o Despertador Inteligente em outras atividades, outros números e mensagens personalizadas. Mantém Google Calendar Sync Seguro, reserva acionada como voo, WhatsApp Import, FreeCurrencyAPI, Infobip principal e parser por continuidade física.
