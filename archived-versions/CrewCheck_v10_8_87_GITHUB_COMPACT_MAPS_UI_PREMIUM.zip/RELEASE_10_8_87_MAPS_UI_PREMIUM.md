# CrewCheck v10.8.87 — Saída Inteligente: UI + Google Maps

## Correções
- Removido o botão rosa/claro que ficava ilegível no modo claro.
- Botões de corrida e rota agora usam o mesmo padrão premium do sistema.
- Aviso técnico `REQUEST_DENIED` deixou de aparecer para o usuário comum.
- Saída Inteligente agora mostra mensagem acessível quando o trânsito em tempo real ainda não está configurado.
- Versão interna atualizada para 10.8.87.
- Android atualizado para versionCode 10887 e versionName 10.8.87.

## Google Maps
Configure no Render:
- GOOGLE_MAPS_API_KEY
- GOOGLE_ROUTES_API_KEY
- GOOGLE_GEOCODING_API_KEY
- CREWCHECK_PUBLIC_URL=https://crewcheck.online
