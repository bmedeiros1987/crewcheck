# Guia rápido — Google Maps no CrewCheck

## Objetivo
Ativar a Saída Inteligente com estimativas mais precisas de rota, trânsito e validação de endereço.

## APIs que devem estar ativadas no Google Cloud
- Routes API
- Directions API
- Geocoding API

## Variáveis no Render
Configure em Environment:

GOOGLE_MAPS_API_KEY=sua_chave
GOOGLE_ROUTES_API_KEY=sua_chave
GOOGLE_GEOCODING_API_KEY=sua_chave
CREWCHECK_PUBLIC_URL=https://crewcheck.online

Depois clique em:
Manual Deploy → Clear build cache & deploy

## Segurança da chave
Para funcionar no backend do Render, a chave não deve depender apenas de restrição por site/referrer.
O mais seguro é restringir por APIs permitidas e monitorar cota/orçamento.
