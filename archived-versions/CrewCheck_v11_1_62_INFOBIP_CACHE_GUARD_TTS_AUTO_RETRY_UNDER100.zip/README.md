# CrewCheck v11.1.62 — Infobip cache/deploy guard + TTS auto retry

Correção de diagnóstico para impedir confusão com cache/backend antigo.

- Mantém ligação apenas para Premium/Admin.
- Gratuito permanece no Telegram.
- Teste de ligação força Infobip/VoIP e não envia áudio no Telegram.
- Infobip TTS tenta auto, pt-BR, pt e en, sem mensagem antiga fixa de `INFOBIP_LANGUAGE=pt`.
- `/api/health` e `/healthz` agora expõem `version: 11.1.62` para confirmar que o Render subiu a versão certa.
- Service worker/cache atualizado para 11.1.62.
