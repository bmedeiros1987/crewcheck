import { useEffect } from 'react';
import Home from './Home';

export default function Results() {
  useEffect(() => {
    const requested = sessionStorage.getItem('crewcheck_initial_view');
    if (!requested) sessionStorage.setItem('crewcheck_initial_view', 'cockpit');
  }, []);
  return <Home />;
}
