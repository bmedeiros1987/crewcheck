# CrewCheck v11.1.82

Hotfix premium: parser por continuidade física da escala AIMS, preservando múltiplas programações no mesmo dia, pernoite diurno >=12h e continuidade aeroportuária sem teletransporte operacional.
