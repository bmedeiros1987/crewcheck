import { Activity, CalendarDays, Cloud, Lock, Menu, Plane, ShieldCheck, Wrench } from 'lucide-react';

type MaintenanceState = {
  enabled?: boolean;
  title?: string;
  message?: string;
  status?: string;
  updatedAt?: string | null;
};

export default function MaintenanceModePage({ state, onAdminAccess }: { state?: MaintenanceState; onAdminAccess?: () => void }) {
  return (
    <main className="cc1266-maintenance-page" data-version="12.5.66">
      <div className="cc1266-wallpaper" aria-hidden="true" />
      <header className="cc1266-maintenance-header">
        <button type="button" className="cc1266-icon-button" aria-label="Menu"><Menu size={25} /></button>
        <div className="cc1266-brand-mini">
          <span className="cc1266-logo"><Plane size={22} /></span>
          <div><strong>CrewCheck</strong><div><span>Premium</span><b>Beta</b></div></div>
        </div>
      </header>
      <section className="cc1266-maintenance-hero">
        <div className="cc1266-maintenance-illustration" aria-hidden="true">
          <Plane className="plane" />
          <Wrench className="wrench" />
          <div className="tower" />
          <div className="barrier" />
        </div>
        <h1>{state?.title || 'Site em manutenção'}</h1>
        <p>{state?.message || 'Estamos realizando melhorias e atualizações no CrewCheck. Em breve o sistema estará disponível novamente.'}</p>
        <span className="cc1266-maintenance-badge"><ShieldCheck size={18} /> Modo ativado pelo administrador</span>
        <div className="cc1266-maintenance-lock"><Lock size={24} /> Apenas administradores podem acessar o painel durante a manutenção.</div>
        <button type="button" onClick={onAdminAccess} className="cc1266-primary-action"><Lock size={20} /> Acessar painel admin <span>›</span></button>
        <button type="button" className="cc1266-secondary-action"><Activity size={20} /> Ver status</button>
        <button type="button" className="cc1266-link-action">Voltar mais tarde</button>
      </section>
      <section className="cc1266-maintenance-status">
        <div className="cc1266-section-row"><h2>Status da operação</h2><span><i /> {state?.status || 'Em andamento'}</span></div>
        <div className="cc1266-status-grid">
          <div><CalendarDays /><strong>Escala em atualização</strong><em /></div>
          <div><Activity /><strong>Alertas em revisão</strong><em /></div>
          <div><Cloud /><strong>Meteorologia sincronizando</strong><em /></div>
        </div>
      </section>
      <footer className="cc1266-maintenance-footer"><ShieldCheck size={18} /> Manutenção segura para garantir a melhor experiência para sua operação.</footer>
    </main>
  );
}
