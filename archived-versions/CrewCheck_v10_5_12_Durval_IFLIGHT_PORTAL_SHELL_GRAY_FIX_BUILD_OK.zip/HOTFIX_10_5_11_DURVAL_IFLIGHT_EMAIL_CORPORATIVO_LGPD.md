# CrewCheck v10.5.11 Durval — iFlight e e-mail corporativo

## Ajustes

- Tela interna iFlight passa a indicar claramente que o usuário está dentro do CrewCheck.
- Aviso fixo: usar e-mail corporativo LATAM somente no portal oficial iFlight/Google SSO.
- Login e MFA continuam manuais e não são lidos, salvos ou enviados ao backend do CrewCheck.
- Cadastro do CrewCheck bloqueia e-mails `@latam.com` no frontend e no backend.
- Endpoint legado de importação por usuário/senha corporativos foi desativado por privacidade/LGPD.
- Fluxo iFlight mantido: WebView interna, cliques autorizados após autenticação, LT antes do Run, formato PDF, captura e importação automática do PDF.

## LGPD

O CrewCheck não grava usuário corporativo, senha, MFA, cookies ou sessão do iFlight em localStorage, banco de dados ou logs.
