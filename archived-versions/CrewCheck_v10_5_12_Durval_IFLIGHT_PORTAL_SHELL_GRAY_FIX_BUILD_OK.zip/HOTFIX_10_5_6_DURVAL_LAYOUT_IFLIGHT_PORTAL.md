# HOTFIX v10.5.7 Durval — Layout padronizado e iFlight Portal Assistido

Este pacote padroniza o layout premium escuro do CrewCheck e reorganiza o fluxo iFlight.

## Incluído

- Versão exibida como **CrewCheck v10.5.7 Durval**.
- Tela iFlight redesenhada para seguir o mesmo padrão visual premium do dashboard.
- Fluxo principal: abrir portal iFlight, login corporativo normal, MFA manual, baixar PDF e importar no CrewCheck.
- Botão **Abrir iFlight** com fallback seguro para nova aba no navegador.
- Botão **Importar PDF baixado** destacado no mesmo fluxo.
- Suporte preparado para bridge nativa Android `window.CrewCheckIFlight.openPortalAndImport(url)`, permitindo que o app abra o portal em WebView, aguarde o usuário baixar o PDF e devolva o PDF em base64 para importação automática.
- Modo de conector corporativo autorizado mantido com `IFLIGHT_CONNECTOR_URL` e MFA manual.
- Senha corporativa e código MFA continuam sem gravação em banco, histórico ou localStorage.

## Observação técnica

No navegador web comum, por segurança, um site não consegue ler automaticamente um PDF baixado por outro domínio. Por isso, o fluxo 100% automático depende de um wrapper Android com bridge nativa ou de conector/API corporativa autorizada. O fluxo PDF permanece funcional e seguro.
