# HOTFIX v10.5.5 Durval — iFlight com MFA manual autorizado

Esta versão ajusta o fluxo iFlight para aceitar a intenção correta: usuário e senha corporativos informados pelo próprio tripulante, com MFA manual quando o portal solicitar.

## O que mudou

- Botão iFlight mantém usuário e senha corporativos apenas em memória durante a tentativa.
- Novo estado visual “MFA manual necessário”.
- Campo para código MFA/OTP recebido pelo usuário.
- O código MFA não é salvo em banco, histórico ou localStorage.
- Endpoint `/api/iflight/import` agora aceita `step`, `mfaCode` e `challengeSessionId`.
- Protocolo preparado para conector corporativo autorizado retornar `requiresMfa`, `challengeSessionId`, `roster` ou `dataBase64`.
- Mensagens do sistema deixam claro que o fluxo não automatiza, não burla e não contorna autenticação.

## Protocolo esperado do conector autorizado

Primeira chamada do CrewCheck para `IFLIGHT_CONNECTOR_URL`:

```json
{
  "username": "usuario",
  "password": "senha",
  "periodMonth": "06",
  "periodYear": "2026",
  "step": "start",
  "source": "crewcheck",
  "mfaMode": "manual_user_supplied"
}
```

Se o portal exigir MFA, o conector pode responder:

```json
{
  "ok": true,
  "requiresMfa": true,
  "challengeSessionId": "sessao-temporaria",
  "message": "Informe o código MFA recebido no autenticador."
}
```

Depois o CrewCheck envia:

```json
{
  "username": "usuario",
  "password": "senha",
  "periodMonth": "06",
  "periodYear": "2026",
  "step": "mfa",
  "challengeSessionId": "sessao-temporaria",
  "mfaCode": "123456",
  "source": "crewcheck",
  "mfaMode": "manual_user_supplied"
}
```

O conector deve devolver `roster` já normalizado ou `dataBase64` com o PDF da escala para o parser do CrewCheck.
