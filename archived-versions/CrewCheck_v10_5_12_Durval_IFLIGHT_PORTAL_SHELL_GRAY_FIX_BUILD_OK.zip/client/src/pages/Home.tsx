import { useCallback, useEffect, useRef, useState, type ChangeEvent, type DragEvent, type ReactNode, type RefObject } from 'react';
import { useLocation } from 'wouter';
import {
  AlertTriangle,
  ArrowLeft,
  BarChart3,
  Bell,
  CalendarDays,
  Camera,
  CheckCircle2,
  ChevronRight,
  CloudUpload,
  Database,
  Download as DownloadIcon,
  Dumbbell,
  FileText,
  FolderOpen,
  History,
  Loader2,
  Lock,
  LogOut,
  Plane,
  Radar,
  RefreshCw,
  Settings,
  Shield,
  Sparkles,
  StickyNote,
  TrendingUp,
  Trash2,
  Upload,
  UserRound,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { analyzeCompliance, getGymRecommendations } from '@/lib/complianceEngine';
import { detectAndMarkLayovers } from '@/lib/layoverDetection';
import { normalizeRosterSchedule } from '@/lib/rosterNormalizer';
import type { CrewRoleSelection } from '@/lib/actRules';
import { parsePDF, type CrewRoster } from '@/lib/pdfParser';
import { getStoredUser, logout } from '@/lib/authClient';
import { syncPendingRosters, getPendingOfflineCount } from '@/lib/offlineSync';
import { getDatabaseStatus, listSavedRosters, openSavedRoster, type DatabaseStatus, type SavedRosterSummary } from '@/lib/databaseClient';
import Dashboard from '../components/premium/Dashboard';
import CalendarView from '../components/premium/CalendarView';
import IFlightIntegrationView from '../components/premium/IFlightIntegrationView';

type HomeView = 'home' | 'import' | 'history' | 'calendar' | 'iflight' | 'routine' | 'settings' | 'notes' | 'more';
type ResultsView = 'summary' | 'roster' | 'alerts' | 'irregularities' | 'gym' | 'fatigue' | 'metrics' | 'glossary' | 'statistics' | 'settings' | 'manual';

type NativePdfPayload = {
  ok?: boolean;
  filename?: string;
  sourceFileName?: string;
  dataBase64?: string;
};

const RESULT_VIEWS = new Set<ResultsView>(['summary', 'roster', 'alerts', 'irregularities', 'gym', 'fatigue', 'metrics', 'glossary', 'statistics', 'settings', 'manual']);

async function fileToBase64Payload(file: File): Promise<string> {
  const buffer = await new Promise<ArrayBuffer>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => reader.result instanceof ArrayBuffer ? resolve(reader.result) : reject(new Error('Arquivo inválido.'));
    reader.onerror = () => reject(reader.error || new Error('Falha ao ler arquivo.'));
    reader.readAsArrayBuffer(file);
  });
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

function base64ToPdfFile(filename: string, dataBase64: string): File {
  const binary = atob(dataBase64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return new File([bytes], filename || 'iFlight_RosterReport.pdf', { type: 'application/pdf' });
}

async function parsePdfViaServer(file: File): Promise<CrewRoster> {
  const dataBase64 = await fileToBase64Payload(file);
  const response = await fetch('/api/parse-pdf', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ filename: file.name, dataBase64 }),
  });
  const payload = await response.json().catch(() => null);
  if (!response.ok || !payload?.ok || !payload?.roster) {
    throw new Error(payload?.message || payload?.detail || 'Parser servidor indisponível.');
  }
  return payload.roster as CrewRoster;
}

function hasCurrentRosterSession() {
  return Boolean(sessionStorage.getItem('crewcheck_roster') && sessionStorage.getItem('crewcheck_compliance'));
}

function setInitialResultsView(view?: ResultsView) {
  if (view && RESULT_VIEWS.has(view)) sessionStorage.setItem('crewcheck_initial_view', view);
}

export default function Home() {
  const [, setLocation] = useLocation();
  const [currentView, setCurrentView] = useState<HomeView>('home');
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [roleSelection, setRoleSelection] = useState<CrewRoleSelection>('auto');
  const [savedRosters, setSavedRosters] = useState<SavedRosterSummary[]>([]);
  const [savedLoading, setSavedLoading] = useState(true);
  const [dbStatus, setDbStatus] = useState<DatabaseStatus | null>(null);
  const [openingSavedId, setOpeningSavedId] = useState<string | null>(null);
  const [pendingOffline, setPendingOffline] = useState(getPendingOfflineCount());
  const [profileAvatar, setProfileAvatar] = useState(() => localStorage.getItem('crewcheck_profile_avatar') || '');
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const nativePdfImportingRef = useRef(false);

  const user = getStoredUser();

  const refreshSavedRosters = useCallback(async () => {
    setSavedLoading(true);
    try {
      const [statusResult, historyResult] = await Promise.allSettled([
        getDatabaseStatus(),
        listSavedRosters(8),
      ]);
      if (statusResult.status === 'fulfilled') setDbStatus(statusResult.value);
      else setDbStatus({ ok: false, connected: false, databaseConfigured: false, message: 'Banco indisponível. Histórico local ativo.' });
      if (historyResult.status === 'fulfilled') setSavedRosters(historyResult.value);
      else setSavedRosters([]);
      setPendingOffline(getPendingOfflineCount());
    } finally {
      setSavedLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshSavedRosters();
  }, [refreshSavedRosters]);

  const handleOpenSavedRoster = useCallback(async (id: string, targetView: ResultsView = 'summary') => {
    setOpeningSavedId(id);
    try {
      const data = await openSavedRoster(id);
      sessionStorage.setItem('crewcheck_roster', JSON.stringify(normalizeRosterSchedule(detectAndMarkLayovers(data.roster))));
      sessionStorage.setItem('crewcheck_compliance', JSON.stringify(data.compliance));
      sessionStorage.setItem('crewcheck_gym', JSON.stringify(data.gym || []));
      sessionStorage.setItem('crewcheck_role_selection', roleSelection);
      const summary = savedRosters.find((item) => item.id === id);
      sessionStorage.setItem('crewcheck_source_file', summary?.sourceFileName || 'Escala salva');
      setInitialResultsView(targetView);
      toast.success('Escala salva carregada.');
      setLocation('/results');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Não foi possível abrir a escala salva.');
    } finally {
      setOpeningSavedId(null);
    }
  }, [roleSelection, savedRosters, setLocation]);

  async function handleLogout() {
    try {
      await logout();
    } finally {
      sessionStorage.clear();
      setLocation('/login');
    }
  }

  async function handleSyncPending() {
    try {
      const result = await syncPendingRosters();
      await refreshSavedRosters();
      setPendingOffline(result.remaining);
      if (result.synced > 0) toast.success(`${result.synced} escala(s) sincronizada(s).`);
      if (result.remaining > 0) toast.warning(`${result.remaining} pendência(s) ainda offline.`);
      if (!result.synced && !result.remaining) toast.info('Nenhuma pendência offline para sincronizar.');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Falha ao sincronizar pendências offline.');
    }
  }

  const goToResults = useCallback((view: ResultsView = 'summary') => {
    if (hasCurrentRosterSession()) {
      setInitialResultsView(view);
      setLocation('/results');
      return;
    }
    if (savedRosters[0]) {
      void handleOpenSavedRoster(savedRosters[0].id, view);
      return;
    }
    toast.info('Carregue uma escala primeiro para abrir esta função.');
    setCurrentView('import');
  }, [handleOpenSavedRoster, savedRosters, setLocation]);

  const handleDashboardNavigate = useCallback((view: string) => {
    const map: Record<string, () => void> = {
      home: () => setCurrentView('home'),
      import: () => setCurrentView('import'),
      roster: () => goToResults('roster'),
      calendar: () => setCurrentView('calendar'),
      irregularities: () => goToResults('irregularities'),
      routine: () => goToResults('gym'),
      iflight: () => setCurrentView('iflight'),
      history: () => setCurrentView('history'),
      reports: () => goToResults('metrics'),
      alerts: () => goToResults('alerts'),
      notes: () => setCurrentView('notes'),
      settings: () => setCurrentView('settings'),
      sync: () => void handleSyncPending(),
      more: () => setCurrentView('more'),
    };
    (map[view] || (() => setCurrentView('more')))();
  }, [goToResults]);

  const commitRoster = useCallback(async (inputRoster: CrewRoster, sourceFileName: string, targetView: ResultsView = 'summary') => {
    const roster = normalizeRosterSchedule(detectAndMarkLayovers(inputRoster));
    const compliance = analyzeCompliance(roster, roleSelection);
    const gym = getGymRecommendations(roster, roleSelection);

    sessionStorage.setItem('crewcheck_roster', JSON.stringify(roster));
    sessionStorage.setItem('crewcheck_compliance', JSON.stringify(compliance));
    sessionStorage.setItem('crewcheck_gym', JSON.stringify(gym));
    sessionStorage.setItem('crewcheck_role_selection', roleSelection);
    sessionStorage.setItem('crewcheck_source_file', sourceFileName);
    sessionStorage.setItem('crewcheck_auto_sync_pending', '1');
    sessionStorage.setItem('crewcheck_auto_db_save_pending', '1');
    setInitialResultsView(targetView);

    toast.success('Escala interpretada com sucesso.');
    setLocation('/results');
  }, [roleSelection, setLocation]);

  const handleRosterImport = useCallback(async (roster: CrewRoster, sourceFileName = 'iFlight LATAM') => {
    await commitRoster(roster, sourceFileName, 'roster');
  }, [commitRoster]);

  const handleFile = useCallback(async (file: File) => {
    const fileNameLower = (file.name || '').toLowerCase();
    const looksLikePdf = fileNameLower.endsWith('.pdf') || file.type === 'application/pdf' || file.type === 'application/octet-stream' || fileNameLower.includes('pdf');
    if (!looksLikePdf) {
      setError('Por favor, envie um arquivo PDF no formato CrewRosterReport ou AIMS. No iPhone, use Arquivos > iCloud/No iPhone e selecione o PDF original.');
      return;
    }
    if (!file.size || file.size < 50) {
      setError('O PDF selecionado parece vazio ou não foi liberado pelo iOS. Tente salvar o arquivo em Arquivos > No iPhone e selecionar novamente.');
      return;
    }

    setFileName(file.name);
    setIsProcessing(true);
    setError(null);

    try {
      let roster: CrewRoster;
      try {
        roster = await parsePdfViaServer(file);
      } catch (serverError) {
        console.warn('Server PDF parser failed; trying local parser fallback', serverError);
        try {
          roster = await parsePDF(file);
          toast.info('PDF interpretado pelo modo local do app.');
        } catch (localError) {
          console.error('Local PDF parser fallback failed', localError);
          const serverMessage = serverError instanceof Error ? serverError.message : 'Parser servidor indisponível.';
          const localMessage = localError instanceof Error ? localError.message : 'Parser local indisponível.';
          throw new Error(`${serverMessage} Fallback local: ${localMessage}`);
        }
      }
      await commitRoster(roster, file.name, 'summary');
    } catch (err) {
      console.error('Error parsing PDF:', err);
      const message = err instanceof Error ? err.message : '';
      setError(`Não consegui interpretar este PDF. ${message ? `Detalhe: ${message}. ` : ''}Tente salvar o arquivo localmente e selecionar novamente pelo botão Escolher PDF. Se for escala em formato ticket, confira se o PDF tem texto selecionável.`);
    } finally {
      setIsProcessing(false);
    }
  }, [commitRoster]);

  useEffect(() => {
    async function importNativePdf(payload?: NativePdfPayload) {
      if (!payload?.dataBase64 || nativePdfImportingRef.current) return;
      nativePdfImportingRef.current = true;
      const filename = payload.filename || payload.sourceFileName || 'iFlight_RosterReport.pdf';
      setCurrentView('import');
      setFileName(filename);
      setIsProcessing(true);
      setError(null);
      toast.info('PDF recebido do iFlight. Importando escala...');
      try {
        const file = base64ToPdfFile(filename, payload.dataBase64);
        let roster: CrewRoster;
        try {
          roster = await parsePdfViaServer(file);
        } catch (serverError) {
          console.warn('Server PDF parser failed for native PDF; trying local parser fallback', serverError);
          roster = await parsePDF(file);
        }
        await commitRoster(roster, filename, 'roster');
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Erro desconhecido.';
        setError(`Recebi o PDF do iFlight, mas não consegui interpretar. Detalhe: ${message}`);
        toast.error('Não consegui interpretar o PDF recebido do iFlight.');
      } finally {
        setIsProcessing(false);
        const win = window as Window & { __crewcheckPendingNativePdf?: NativePdfPayload };
        delete win.__crewcheckPendingNativePdf;
        nativePdfImportingRef.current = false;
      }
    }

    const handler = (event: Event) => {
      void importNativePdf((event as CustomEvent<NativePdfPayload>).detail);
    };

    window.addEventListener('crewcheck:native-pdf', handler as EventListener);
    const win = window as Window & { __crewcheckPendingNativePdf?: NativePdfPayload };
    if (win.__crewcheckPendingNativePdf) void importNativePdf(win.__crewcheckPendingNativePdf);
    return () => window.removeEventListener('crewcheck:native-pdf', handler as EventListener);
  }, [commitRoster]);

  const handleDrop = useCallback((event: DragEvent) => {
    event.preventDefault();
    setIsDragging(false);
    const file = event.dataTransfer.files?.[0];
    if (file) void handleFile(file);
  }, [handleFile]);

  const handleFileInput = useCallback((event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) void handleFile(file);
    event.target.value = '';
  }, [handleFile]);

  if (currentView === 'calendar') return <CalendarView onBack={() => setCurrentView('home')} />;
  if (currentView === 'iflight') return <IFlightIntegrationView onBack={() => setCurrentView('home')} onSuccess={() => goToResults('roster')} onFileUpload={handleFile} onRosterImport={handleRosterImport} />;

  if (currentView === 'import') {
    return (
      <ImportScreen
        userLabel={user?.name || user?.email || 'Usuário'}
        roleSelection={roleSelection}
        onRoleSelectionChange={setRoleSelection}
        isDragging={isDragging}
        isProcessing={isProcessing}
        error={error}
        fileName={fileName}
        fileInputRef={fileInputRef}
        onBack={() => setCurrentView('home')}
        onDrop={handleDrop}
        onDragOver={(event) => { event.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onFileInput={handleFileInput}
        onLogout={handleLogout}
      />
    );
  }

  if (currentView === 'history') {
    return <HistoryScreen rosters={savedRosters} loading={savedLoading} dbStatus={dbStatus} openingId={openingSavedId} onBack={() => setCurrentView('home')} onOpen={(id) => void handleOpenSavedRoster(id, 'summary')} onRefresh={refreshSavedRosters} />;
  }

  if (currentView === 'routine') {
    return <SimplePanel title="Minha Rotina" icon={Dumbbell} onBack={() => setCurrentView('home')} description="A rotina agora é calculada dentro da própria escala, considerando folgas, pernoites, sobreavisos, voos e intensidade do mês." actions={[{ label: 'Abrir rotina na escala', onClick: () => goToResults('gym') }, { label: 'Importar nova escala', onClick: () => setCurrentView('import') }]} />;
  }

  if (currentView === 'notes') {
    return <NotesPanel onBack={() => setCurrentView('home')} />;
  }

  if (currentView === 'settings') {
    return <SettingsHomePanel userLabel={user?.name || user?.email || 'Tripulante'} avatar={profileAvatar} onAvatarChange={(value) => { setProfileAvatar(value); if (value) localStorage.setItem('crewcheck_profile_avatar', value); else localStorage.removeItem('crewcheck_profile_avatar'); }} onBack={() => setCurrentView('home')} onOpenIFlight={() => setCurrentView('iflight')} onLogout={handleLogout} />;
  }

  if (currentView === 'more') {
    return <MorePanel onBack={() => setCurrentView('home')} onNavigate={handleDashboardNavigate} onLogout={handleLogout} pendingOffline={pendingOffline} />;
  }

  return (
    <div className="relative min-h-screen bg-[#08111f]">
      <Dashboard
        user={{ name: user?.name || user?.email || 'Tripulante', company: 'LATAM Brasil · CrewCheck Premium', base: user?.base || undefined, avatar: profileAvatar || undefined }}
        nextEvent={{ title: savedRosters[0]?.sourceFileName || 'Importe sua escala', time: savedRosters[0] ? 'Abrir' : 'PDF', endTime: savedRosters[0] ? 'histórico' : 'novo', date: savedRosters[0] ? `${monthLabel(savedRosters[0].month, savedRosters[0].year)} · ${savedRosters[0].base || 'Base'}` : 'CrewRosterReport / AIMS' }}
        onNavigate={handleDashboardNavigate}
      />

      <div className="fixed right-4 top-24 z-[60] flex flex-col gap-2">
        <button onClick={() => setCurrentView('import')} className="rounded-2xl bg-cyan-300 px-4 py-3 text-xs font-black uppercase tracking-[0.14em] text-[#07111f] shadow-2xl shadow-cyan-950/30 active:scale-95">
          <CloudUpload className="mr-2 inline h-4 w-4" /> Nova escala
        </button>
        <button onClick={handleLogout} className="rounded-2xl border border-white/10 bg-white/10 px-4 py-3 text-xs font-black uppercase tracking-[0.14em] text-white backdrop-blur-xl active:scale-95">
          <LogOut className="mr-2 inline h-4 w-4" /> Sair
        </button>
      </div>
    </div>
  );
}

function ImportScreen({ userLabel, roleSelection, onRoleSelectionChange, isDragging, isProcessing, error, fileName, fileInputRef, onBack, onDrop, onDragOver, onDragLeave, onFileInput, onLogout }: {
  userLabel: string;
  roleSelection: CrewRoleSelection;
  onRoleSelectionChange: (value: CrewRoleSelection) => void;
  isDragging: boolean;
  isProcessing: boolean;
  error: string | null;
  fileName: string | null;
  fileInputRef: RefObject<HTMLInputElement>;
  onBack: () => void;
  onDrop: (event: DragEvent) => void;
  onDragOver: (event: DragEvent) => void;
  onDragLeave: () => void;
  onFileInput: (event: ChangeEvent<HTMLInputElement>) => void;
  onLogout: () => void;
}) {
  return (
    <div className="min-h-screen overflow-hidden bg-[#07111F] text-white">
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,rgba(59,130,246,0.35),transparent_28%),radial-gradient(circle_at_80%_0%,rgba(236,72,153,0.25),transparent_32%),linear-gradient(135deg,#07111F_0%,#0B1730_45%,#0A1020_100%)]" />
        <div className="absolute inset-0 opacity-[0.08]" style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,0.85) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.85) 1px, transparent 1px)', backgroundSize: '64px 64px' }} />
      </div>

      <div className="relative z-10">
        <header className="container py-6">
          <div className="flex items-center justify-between gap-4 rounded-3xl border border-white/10 bg-white/[0.06] px-5 py-4 shadow-2xl shadow-black/20 backdrop-blur-xl">
            <button onClick={onBack} className="flex items-center gap-3 text-left">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10 text-cyan-100"><ArrowLeft className="h-5 w-5" /></div>
              <div>
                <h1 className="text-lg font-black tracking-tight">Nova escala</h1>
                <p className="text-xs uppercase tracking-[0.24em] text-cyan-100/70">CrewCheck v10.5.10 Durval</p>
              </div>
            </button>
            <div className="hidden items-center gap-2 md:flex">
              <Badge className="border-white/10 bg-white/10 text-cyan-100 hover:bg-white/10"><Lock className="mr-1.5 h-3.5 w-3.5" /> Conta protegida</Badge>
              <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/10 px-3 py-1 text-sm text-cyan-100"><UserRound className="h-4 w-4" /><span className="max-w-[11rem] truncate">{userLabel}</span></div>
              <button onClick={onLogout} className="rounded-full border border-white/10 bg-white/10 px-3 py-1 text-xs font-black text-cyan-100 hover:bg-white/15"><LogOut className="mr-1 inline h-3.5 w-3.5" /> Sair</button>
            </div>
          </div>
        </header>

        <main className="container pb-16 pt-6 md:pb-24 md:pt-10">
          <section className="grid items-center gap-10 lg:grid-cols-[1.05fr_0.95fr]">
            <div>
              <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-cyan-300/20 bg-cyan-300/10 px-4 py-2 text-sm text-cyan-100 shadow-lg shadow-cyan-950/30"><Sparkles className="h-4 w-4" /> Leitura premium do CrewRosterReport/AIMS com LGPD</div>
              <h2 className="max-w-4xl text-4xl font-black leading-[1.04] tracking-tight md:text-6xl">Transforme sua escala em painel, alertas, rotina e calendário.</h2>
              <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-200/80">Envie o PDF da escala. O CrewCheck interpreta voos, folgas, sobreavisos, pernoites, treinamentos e pontos de atenção com salvamento offline-first.</p>
              <div className="mt-8 grid max-w-3xl grid-cols-2 gap-3 md:grid-cols-4">
                <Kpi icon={Radar} value="PDF" label="linhas, colunas e ticket" />
                <Kpi icon={Shield} value="ACT" label="piloto ou comissário" />
                <Kpi icon={CalendarDays} value="Google" label="calendário sem duplicar" />
                <Kpi icon={Dumbbell} value="Rotina" label="sugestão dentro da escala" />
              </div>
            </div>

            <Card className="relative overflow-hidden rounded-[2rem] border-white/10 bg-white/[0.08] p-4 text-white shadow-2xl shadow-black/30 backdrop-blur-2xl">
              <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-cyan-300 via-fuchsia-400 to-amber-300" />
              <div className="rounded-[1.5rem] border border-white/10 bg-[#0B1730]/70 p-5 md:p-7">
                <div className="mb-5 flex items-center justify-between gap-4">
                  <div><p className="text-sm font-semibold text-cyan-100">Upload seguro</p><h3 className="text-2xl font-black tracking-tight">Analisar escala</h3></div>
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-300/15 text-cyan-200"><FileText className="h-6 w-6" /></div>
                </div>

                <div className="mb-5 rounded-[1.2rem] border border-white/10 bg-white/[0.06] p-4">
                  <div className="mb-3 flex items-center justify-between gap-3"><div><p className="text-sm font-bold text-cyan-100">ACT aplicável</p><p className="text-xs leading-5 text-slate-300">O sistema tenta identificar pelo PDF, mas você pode forçar a função correta.</p></div><Badge className="border-cyan-300/20 bg-cyan-300/10 text-cyan-100 hover:bg-cyan-300/10">2025/2027</Badge></div>
                  <select value={roleSelection} onChange={(event) => onRoleSelectionChange(event.target.value as CrewRoleSelection)} className="h-12 w-full rounded-2xl border border-white/15 bg-[#07111F] px-4 text-sm font-bold text-white outline-none focus:border-cyan-300">
                    <option value="auto">Detectar automaticamente pela escala</option>
                    <option value="cabin">Aplicar ACT Comissários</option>
                    <option value="pilot">Aplicar ACT Pilotos</option>
                  </select>
                </div>

                <div onDragOver={onDragOver} onDragLeave={onDragLeave} onDrop={onDrop} className={`relative rounded-[1.35rem] border-2 border-dashed p-8 text-center transition-all duration-300 ${isDragging ? 'scale-[1.015] border-cyan-300 bg-cyan-300/10' : 'border-white/15 bg-white/[0.04] hover:border-fuchsia-300/60 hover:bg-white/[0.07]'} ${isProcessing ? 'pointer-events-none opacity-70' : ''}`}>
                  {isProcessing ? (
                    <div className="flex flex-col items-center gap-4 py-6"><div className="h-14 w-14 animate-spin rounded-full border-4 border-cyan-300 border-t-transparent" /><div><p className="text-lg font-bold">Interpretando {fileName || 'PDF'}...</p><p className="mt-1 text-sm text-slate-300">Lendo cabeçalho, trechos, jornadas, folgas e totais.</p></div></div>
                  ) : (
                    <div className="flex flex-col items-center gap-5 py-4">
                      <div className="flex h-20 w-20 items-center justify-center rounded-[1.7rem] bg-gradient-to-br from-cyan-300 to-fuchsia-400 text-[#07111F] shadow-xl shadow-cyan-500/25"><Upload className="h-9 w-9" /></div>
                      <div><p className="text-xl font-black">Arraste o CrewRosterReport aqui</p><p className="mt-2 text-sm text-slate-300">ou selecione o PDF original emitido pelo sistema de escala</p></div>
                      <label className="relative inline-flex cursor-pointer items-center justify-center rounded-2xl bg-white px-7 py-3 text-sm font-black text-[#07111F] shadow-lg transition hover:bg-cyan-100 active:scale-[0.99]"><input ref={fileInputRef} type="file" accept="application/pdf,.pdf,application/octet-stream" onChange={onFileInput} className="absolute inset-0 h-full w-full cursor-pointer opacity-0" />Escolher PDF no dispositivo</label>
                      <p className="max-w-sm text-xs leading-5 text-slate-400">No iPhone/iPad, prefira Arquivos → No iPhone/iCloud Drive. Se o PDF veio do WhatsApp, salve em Arquivos antes de importar.</p>
                    </div>
                  )}
                </div>

                {error && <div className="mt-4 flex gap-3 rounded-2xl border border-red-300/20 bg-red-500/10 p-4 text-left text-red-100"><AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" /><p className="text-sm leading-6">{error}</p></div>}

                <div className="mt-5 grid gap-3 text-sm text-slate-200/85">
                  <TrustLine icon={CheckCircle2} text="Processamento com parser do servidor e fallback local no app." />
                  <TrustLine icon={CheckCircle2} text="Gera painel, alertas, rotina, PDF, ICS e Google Calendar." />
                  <TrustLine icon={CheckCircle2} text="Salvamento automático sem duplicar histórico." />
                </div>
              </div>
            </Card>
          </section>
        </main>
      </div>
    </div>
  );
}

function HistoryScreen({ rosters, loading, dbStatus, openingId, onBack, onOpen, onRefresh }: {
  rosters: SavedRosterSummary[];
  loading: boolean;
  dbStatus: DatabaseStatus | null;
  openingId: string | null;
  onBack: () => void;
  onOpen: (id: string) => void;
  onRefresh: () => void;
}) {
  const dbOnline = Boolean(dbStatus?.connected || dbStatus?.ok);
  return (
    <div className="min-h-screen bg-[#08111f] px-5 py-8 text-white">
      <div className="mx-auto max-w-4xl">
        <HeaderBack title="Histórico de escalas" subtitle={dbOnline ? 'Banco online' : 'Histórico local/offline'} onBack={onBack} action={<button onClick={onRefresh} className="rounded-2xl border border-white/10 bg-white/10 px-4 py-2 text-xs font-black text-cyan-100"><RefreshCw className="mr-2 inline h-4 w-4" />Atualizar</button>} />
        {loading ? <StateCard icon={Loader2} title="Buscando escalas" text="Carregando histórico salvo..." spin /> : rosters.length ? (
          <div className="mt-6 grid gap-3">
            {rosters.map((item) => (
              <button key={item.id} onClick={() => onOpen(item.id)} disabled={openingId === item.id} className="flex w-full items-center justify-between gap-4 rounded-3xl border border-white/10 bg-white/[0.05] p-5 text-left transition hover:bg-white/[0.09] disabled:opacity-60">
                <div><p className="text-xs font-black uppercase tracking-[0.2em] text-cyan-100/70">{monthLabel(item.month, item.year)} · {item.base || 'Base'}</p><h3 className="mt-1 text-lg font-black">{item.crewName || 'Tripulante'}</h3><p className="mt-1 text-sm text-slate-400">{item.sourceFileName || 'Escala salva'} · score {item.score ?? '-'}</p></div>
                <div className="rounded-2xl bg-white px-4 py-2 text-sm font-black text-[#07111f]">{openingId === item.id ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Abrir'}</div>
              </button>
            ))}
          </div>
        ) : <StateCard icon={FolderOpen} title="Nenhuma escala salva" text="Importe uma escala uma vez; ela ficará disponível aqui após o login." />}
      </div>
    </div>
  );
}

function NotesPanel({ onBack }: { onBack: () => void }) {
  const [note, setNote] = useState(() => localStorage.getItem('crewcheck_personal_notes') || '');
  return (
    <div className="min-h-screen bg-[#08111f] px-5 py-8 text-white">
      <div className="mx-auto max-w-3xl">
        <HeaderBack title="Notas" subtitle="Anotações locais do tripulante" onBack={onBack} />
        <div className="mt-6 rounded-3xl border border-white/10 bg-white/[0.05] p-5">
          <textarea value={note} onChange={(event) => setNote(event.target.value)} placeholder="Ex.: observar pernoite, descanso, voo extra, treinamento, pendência pessoal..." className="min-h-[18rem] w-full rounded-2xl border border-white/10 bg-[#07111f] p-4 text-sm leading-6 text-white outline-none focus:border-cyan-300" />
          <div className="mt-4 flex justify-end"><Button onClick={() => { localStorage.setItem('crewcheck_personal_notes', note); toast.success('Notas salvas neste dispositivo.'); }} className="rounded-2xl bg-cyan-300 text-[#07111f] hover:bg-cyan-200"><StickyNote className="h-4 w-4" /> Salvar notas</Button></div>
        </div>
      </div>
    </div>
  );
}

function SettingsHomePanel({ userLabel, avatar, onAvatarChange, onBack, onOpenIFlight, onLogout }: {
  userLabel: string;
  avatar: string;
  onAvatarChange: (value: string) => void;
  onBack: () => void;
  onOpenIFlight: () => void;
  onLogout: () => void;
}) {
  const [preview, setPreview] = useState(avatar);
  const [isSaving, setIsSaving] = useState(false);

  async function handleAvatarInput(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      toast.error('Escolha uma imagem JPG, PNG ou WebP.');
      return;
    }
    if (file.size > 3 * 1024 * 1024) {
      toast.error('A foto deve ter até 3 MB para ficar rápida no app.');
      return;
    }
    setIsSaving(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => typeof reader.result === 'string' ? resolve(reader.result) : reject(new Error('Imagem inválida.'));
        reader.onerror = () => reject(reader.error || new Error('Falha ao ler imagem.'));
        reader.readAsDataURL(file);
      });
      setPreview(dataUrl);
      onAvatarChange(dataUrl);
      toast.success('Foto de perfil atualizada.');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Não foi possível salvar a foto.');
    } finally {
      setIsSaving(false);
    }
  }

  function removeAvatar() {
    setPreview('');
    onAvatarChange('');
    toast.success('Foto removida.');
  }

  return (
    <div className="min-h-screen overflow-hidden bg-[#030914] px-5 py-8 text-white">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_15%_0%,rgba(14,165,233,0.28),transparent_34%),linear-gradient(180deg,#030914_0%,#07111f_55%,#020817_100%)]" />
      <div className="relative z-10 mx-auto max-w-5xl">
        <HeaderBack title="Configurações" subtitle="Perfil, conta e integrações" onBack={onBack} />

        <div className="mt-6 grid gap-5 lg:grid-cols-[minmax(0,1fr)_22rem]">
          <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 shadow-2xl shadow-black/25 backdrop-blur-2xl sm:p-6">
            <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-4">
                <div className="relative h-24 w-24 overflow-hidden rounded-[2rem] border-2 border-cyan-300/25 bg-white/10 p-1 shadow-2xl shadow-cyan-950/30">
                  {preview ? <img src={preview} alt="Foto de perfil" className="h-full w-full rounded-[1.7rem] object-cover" /> : <div className="flex h-full w-full items-center justify-center rounded-[1.7rem] bg-gradient-to-br from-cyan-300/25 to-blue-700/40 text-2xl font-black text-cyan-50">{userLabel.slice(0, 2).toUpperCase()}</div>}
                </div>
                <div>
                  <p className="text-xs font-black uppercase tracking-[0.2em] text-cyan-100/60">perfil premium</p>
                  <h2 className="mt-1 text-2xl font-black">{userLabel}</h2>
                  <p className="mt-1 max-w-md text-sm leading-6 text-slate-400">A foto fica salva localmente no dispositivo para preservar privacidade e aparece no painel inicial.</p>
                </div>
              </div>
              <img src="/icons/crewcheck-icon.svg" alt="Logo antiga CrewCheck" className="hidden h-20 w-20 rounded-[1.6rem] shadow-2xl shadow-cyan-950/40 sm:block" />
            </div>

            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <label className="flex cursor-pointer items-center justify-center gap-3 rounded-2xl bg-cyan-300 px-5 py-4 text-sm font-black text-[#07111f] shadow-lg shadow-cyan-950/25 transition hover:bg-cyan-200 active:scale-[0.99]">
                <Camera className="h-5 w-5" /> {isSaving ? 'Salvando...' : 'Alterar foto'}
                <input type="file" accept="image/png,image/jpeg,image/webp" onChange={handleAvatarInput} disabled={isSaving} className="sr-only" />
              </label>
              <button onClick={removeAvatar} disabled={!preview} className="flex items-center justify-center gap-3 rounded-2xl border border-white/10 bg-white/10 px-5 py-4 text-sm font-black text-white transition hover:bg-white/15 disabled:cursor-not-allowed disabled:opacity-40">
                <Trash2 className="h-5 w-5" /> Remover foto
              </button>
            </div>
          </section>

          <aside className="space-y-4">
            <button onClick={onOpenIFlight} className="w-full rounded-[1.7rem] border border-orange-300/20 bg-orange-400/10 p-5 text-left shadow-xl shadow-black/20 transition hover:bg-orange-400/15">
              <Plane className="mb-4 h-9 w-9 text-orange-200" />
              <h3 className="text-lg font-black">iFlight LATAM</h3>
              <p className="mt-2 text-sm leading-6 text-orange-100/70">Abra o portal corporativo, use importação assistida e mantenha o PDF como caminho confiável.</p>
            </button>
            <div className="rounded-[1.7rem] border border-emerald-300/20 bg-emerald-400/10 p-5 text-sm leading-6 text-emerald-50/80">
              <Shield className="mb-3 h-8 w-8 text-emerald-200" />
              <strong>Privacidade:</strong> a foto não é enviada para terceiros e pode ser apagada a qualquer momento.
            </div>
            <button onClick={onLogout} className="w-full rounded-[1.4rem] border border-white/10 bg-white/10 px-5 py-4 text-sm font-black text-white hover:bg-white/15"><LogOut className="mr-2 inline h-4 w-4" /> Sair da conta</button>
          </aside>
        </div>
      </div>
    </div>
  );
}

function MorePanel({ onBack, onNavigate, onLogout, pendingOffline }: { onBack: () => void; onNavigate: (view: string) => void; onLogout: () => void; pendingOffline: number }) {
  return (
    <div className="min-h-screen bg-[#08111f] px-5 py-8 text-white">
      <div className="mx-auto max-w-4xl">
        <HeaderBack title="Mais funções" subtitle="Menu completo do CrewCheck" onBack={onBack} />
        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          <MenuAction icon={CloudUpload} title="Importar nova escala" text="PDF CrewRosterReport/AIMS" onClick={() => onNavigate('import')} />
          <MenuAction icon={History} title="Histórico" text="Abrir escalas salvas" onClick={() => onNavigate('history')} />
          <MenuAction icon={Bell} title="Alertas" text="Irregularidades e avisos" onClick={() => onNavigate('alerts')} />
          <MenuAction icon={BarChart3} title="Relatórios" text="Métricas e PDF" onClick={() => onNavigate('reports')} />
          <MenuAction icon={CalendarDays} title="Calendário" text="Visual, ICS e Google" onClick={() => onNavigate('calendar')} />
          <MenuAction icon={Settings} title="Configurações" text="Conta, rotina e Google" onClick={() => onNavigate('settings')} />
          <MenuAction icon={Database} title="Sincronizar offline" text={`${pendingOffline} pendência(s)`} onClick={() => onNavigate('sync')} />
          <MenuAction icon={LogOut} title="Sair" text="Encerrar sessão" onClick={onLogout} />
        </div>
      </div>
    </div>
  );
}

function SimplePanel({ title, description, icon: Icon, actions, onBack }: { title: string; description: string; icon: LucideIcon; actions: { label: string; onClick: () => void }[]; onBack: () => void }) {
  return (
    <div className="min-h-screen bg-[#08111f] px-5 py-8 text-white">
      <div className="mx-auto max-w-3xl">
        <HeaderBack title={title} subtitle="CrewCheck Premium" onBack={onBack} />
        <div className="mt-8 rounded-[2rem] border border-white/10 bg-white/[0.05] p-6 text-center">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-[1.6rem] bg-cyan-300/15 text-cyan-200"><Icon className="h-10 w-10" /></div>
          <h2 className="mt-5 text-2xl font-black">{title}</h2>
          <p className="mx-auto mt-3 max-w-xl text-sm leading-6 text-slate-300">{description}</p>
          <div className="mt-6 grid gap-3 sm:grid-cols-2">{actions.map((action) => <Button key={action.label} onClick={action.onClick} className="rounded-2xl bg-cyan-300 text-[#07111f] hover:bg-cyan-200">{action.label}</Button>)}</div>
        </div>
      </div>
    </div>
  );
}

function HeaderBack({ title, subtitle, onBack, action }: { title: string; subtitle: string; onBack: () => void; action?: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <button onClick={onBack} className="flex items-center gap-3 text-left"><div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10 text-cyan-100"><ArrowLeft className="h-5 w-5" /></div><div><h1 className="text-xl font-black">{title}</h1><p className="text-xs uppercase tracking-[0.22em] text-cyan-100/60">{subtitle}</p></div></button>
      {action}
    </div>
  );
}

function StateCard({ icon: Icon, title, text, spin }: { icon: LucideIcon; title: string; text: string; spin?: boolean }) {
  return <div className="mt-6 rounded-3xl border border-white/10 bg-white/[0.05] p-6 text-center text-slate-300"><Icon className={`mx-auto mb-4 h-8 w-8 text-cyan-200 ${spin ? 'animate-spin' : ''}`} /><h3 className="text-lg font-black text-white">{title}</h3><p className="mt-2 text-sm">{text}</p></div>;
}

function MenuAction({ icon: Icon, title, text, onClick }: { icon: LucideIcon; title: string; text: string; onClick: () => void }) {
  return <button onClick={onClick} className="flex items-center gap-4 rounded-3xl border border-white/10 bg-white/[0.05] p-5 text-left transition hover:bg-white/[0.09]"><div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-300/15 text-cyan-200"><Icon className="h-6 w-6" /></div><div><h3 className="font-black">{title}</h3><p className="text-sm text-slate-400">{text}</p></div><ChevronRight className="ml-auto h-5 w-5 text-slate-500" /></button>;
}

function monthLabel(month: number | null, year: number | null): string {
  const names = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
  if (!month || !year) return 'Período salvo';
  return `${names[month - 1] || String(month).padStart(2, '0')}/${year}`;
}

function Kpi({ icon: Icon, value, label }: { icon: LucideIcon; value: string; label: string }) {
  return <div className="rounded-2xl border border-white/10 bg-white/[0.06] p-4 backdrop-blur-xl"><Icon className="mb-3 h-5 w-5 text-cyan-200" /><p className="text-xl font-black">{value}</p><p className="mt-1 text-xs leading-4 text-slate-300">{label}</p></div>;
}

function TrustLine({ icon: Icon, text }: { icon: LucideIcon; text: string }) {
  return <div className="flex items-start gap-3"><Icon className="mt-0.5 h-4 w-4 shrink-0 text-cyan-300" /><span>{text}</span></div>;
}
