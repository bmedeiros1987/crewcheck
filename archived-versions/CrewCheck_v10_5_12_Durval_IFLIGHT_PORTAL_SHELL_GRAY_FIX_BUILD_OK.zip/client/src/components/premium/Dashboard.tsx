import React from 'react';
import {
  AlertCircle,
  BarChart3,
  Bell,
  Calendar,
  ChevronRight,
  Clock,
  FileText,
  FolderSync,
  Lock,
  Menu,
  Plane,
  RefreshCw,
  Settings,
  ShieldCheck,
  Sparkles,
  UserRound,
  Wifi,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

interface DashboardProps {
  user: {
    name: string;
    company: string;
    avatar?: string;
    base?: string;
  };
  nextEvent?: {
    title: string;
    time: string;
    endTime: string;
    date: string;
  };
  onNavigate: (view: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, nextEvent, onNavigate }) => {
  const displayName = user.name || 'Tripulante';
  const initials = displayName
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('') || 'CC';

  const menuItems = [
    { icon: FileText, label: 'Nova Escala', caption: 'PDF ou iFlight', color: 'from-cyan-300 to-blue-500', onClick: () => onNavigate('import') },
    { icon: Calendar, label: 'Minha Escala', caption: 'voos e folgas', color: 'from-blue-400 to-indigo-600', onClick: () => onNavigate('roster') },
    { icon: FolderSync, label: 'Minha Rotina', caption: 'dentro da escala', color: 'from-emerald-300 to-teal-600', onClick: () => onNavigate('routine') },
    { icon: AlertCircle, label: 'Irregularidades', caption: 'ACT e descanso', color: 'from-rose-400 to-red-600', onClick: () => onNavigate('irregularities') },
    { icon: Clock, label: 'Histórico', caption: 'sem duplicar', color: 'from-amber-300 to-orange-600', onClick: () => onNavigate('history') },
    { icon: BarChart3, label: 'Relatórios', caption: 'métricas e PDF', color: 'from-sky-300 to-cyan-600', onClick: () => onNavigate('reports') },
    { icon: Plane, label: 'iFlight LATAM', caption: 'portal/PDF', color: 'from-orange-300 to-amber-600', onClick: () => onNavigate('iflight') },
    { icon: FileText, label: 'Notas', caption: 'local e privado', color: 'from-yellow-300 to-amber-500', onClick: () => onNavigate('notes') },
    { icon: Settings, label: 'Configurações', caption: 'foto e conta', color: 'from-slate-300 to-slate-600', onClick: () => onNavigate('settings') },
  ];

  return (
    <div className="min-h-screen overflow-hidden bg-[#030914] text-white">
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_12%_6%,rgba(14,165,233,0.30),transparent_30%),radial-gradient(circle_at_88%_8%,rgba(37,99,235,0.22),transparent_28%),linear-gradient(180deg,#030914_0%,#07111f_42%,#020817_100%)]" />
        <div className="absolute inset-x-0 top-0 h-72 bg-[radial-gradient(circle_at_50%_0%,rgba(255,255,255,0.15),transparent_42%)]" />
        <div className="absolute -bottom-24 left-1/2 h-72 w-[42rem] -translate-x-1/2 rounded-full bg-cyan-500/10 blur-3xl" />
      </div>

      <div className="relative z-10 mx-auto flex min-h-screen w-full max-w-7xl flex-col px-4 pb-28 pt-5 sm:px-6 lg:grid lg:grid-cols-[20rem_minmax(0,1fr)_16rem] lg:gap-5 lg:pb-8 lg:pt-6">
        <aside className="hidden rounded-[2rem] border border-white/10 bg-white/[0.045] p-5 shadow-2xl shadow-black/30 backdrop-blur-2xl lg:block">
          <div className="flex items-center gap-4">
            <img src="/icons/crewcheck-icon.svg" alt="CrewCheck" className="h-16 w-16 rounded-3xl shadow-2xl shadow-cyan-950/40" />
            <div>
              <h1 className="text-2xl font-black tracking-tight">CrewCheck</h1>
              <p className="mt-1 text-[0.64rem] font-black uppercase tracking-[0.22em] text-cyan-100/60">Roster Intelligence</p>
            </div>
          </div>

          <div className="mt-6 rounded-3xl border border-cyan-300/15 bg-cyan-300/10 px-4 py-3 text-sm font-bold text-cyan-50">
            <Sparkles className="mr-2 inline h-4 w-4 text-cyan-200" /> Premium · Offline · Durval
          </div>

          <div className="mt-6 space-y-3">
            <FeatureLine icon={Wifi} title="100% Offline" text="Funciona sem internet" />
            <FeatureLine icon={RefreshCw} title="Sincronização inteligente" text="Atualiza quando online" />
            <FeatureLine icon={ShieldCheck} title="Dados protegidos" text="Privacidade no dispositivo" />
            <FeatureLine icon={Lock} title="Conta protegida" text="Login e sessão segura" />
          </div>

          <button onClick={() => onNavigate('iflight')} className="mt-6 flex w-full items-center justify-between rounded-3xl border border-orange-300/20 bg-orange-400/10 p-4 text-left transition hover:bg-orange-400/15 active:scale-[0.99]">
            <div>
              <p className="text-sm font-black text-orange-100">Botão iFlight</p>
              <p className="mt-1 text-xs leading-5 text-orange-100/65">Portal corporativo e importação assistida</p>
            </div>
            <ChevronRight className="h-5 w-5 text-orange-200" />
          </button>
        </aside>

        <main className="min-w-0 lg:overflow-hidden">
          <header className="flex items-center justify-between gap-3 rounded-[1.7rem] border border-white/10 bg-white/[0.055] px-4 py-3 shadow-2xl shadow-black/20 backdrop-blur-2xl lg:hidden">
            <button onClick={() => onNavigate('more')} className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/8 active:scale-95" aria-label="Abrir menu completo">
              <Menu className="h-6 w-6 text-slate-300" />
            </button>
            <div className="flex items-center gap-3">
              <img src="/icons/crewcheck-icon.svg" alt="CrewCheck" className="h-10 w-10 rounded-2xl" />
              <div className="text-center">
                <p className="text-base font-black leading-none tracking-tight">CrewCheck</p>
                <p className="mt-1 text-[0.58rem] font-black uppercase tracking-[0.18em] text-emerald-300">Offline</p>
              </div>
            </div>
            <button onClick={() => onNavigate('alerts')} className="relative flex h-11 w-11 items-center justify-center rounded-2xl bg-white/8 active:scale-95" aria-label="Abrir alertas">
              <Bell className="h-6 w-6 text-slate-300" />
              <span className="absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full border-2 border-[#07111f] bg-rose-500 px-1 text-[10px] font-black">3</span>
            </button>
          </header>

          <section className="mt-5 overflow-hidden rounded-[2.1rem] border border-white/10 bg-white/[0.055] shadow-2xl shadow-black/25 backdrop-blur-2xl lg:mt-0">
            <div className="relative min-h-[13rem] p-5 sm:p-6">
              <div className="absolute inset-0 bg-[linear-gradient(135deg,rgba(56,189,248,0.28)_0%,rgba(30,41,59,0.08)_45%,rgba(2,6,23,0.18)_100%)]" />
              <div className="absolute -right-20 -top-28 h-64 w-64 rounded-full bg-cyan-400/15 blur-3xl" />
              <Plane className="absolute right-7 top-8 h-28 w-28 rotate-12 text-white/[0.07]" />

              <div className="relative z-10 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
                <div className="flex items-center gap-4">
                  <button onClick={() => onNavigate('settings')} className="group relative h-[4.5rem] w-[4.5rem] overflow-hidden rounded-[1.65rem] border-2 border-cyan-300/25 bg-white/10 p-0.5 shadow-2xl shadow-cyan-950/30" aria-label="Alterar foto de perfil">
                    {user.avatar ? (
                      <img src={user.avatar} alt="Foto de perfil" className="h-full w-full rounded-[1.45rem] object-cover" />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center rounded-[1.45rem] bg-gradient-to-br from-cyan-300/20 to-blue-700/40 text-xl font-black text-cyan-50">{initials}</div>
                    )}
                    <span className="absolute inset-x-0 bottom-0 bg-black/55 py-1 text-[9px] font-black uppercase tracking-[0.12em] text-white opacity-0 transition group-hover:opacity-100">Editar</span>
                  </button>
                  <div>
                    <p className="text-xs font-black uppercase tracking-[0.20em] text-cyan-100/70">Bem-vindo a bordo</p>
                    <h2 className="mt-1 text-2xl font-black tracking-tight sm:text-3xl">{displayName}</h2>
                    <p className="mt-1 text-sm font-semibold text-slate-300">{user.company || 'CrewCheck Premium'}{user.base ? ` · ${user.base}` : ''}</p>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 sm:min-w-[21rem]">
                  <MiniStatus icon={Wifi} value="100%" label="offline" />
                  <MiniStatus icon={ShieldCheck} value="LGPD" label="privado" />
                  <MiniStatus icon={RefreshCw} value="Sync" label="online" />
                </div>
              </div>
            </div>
          </section>

          <section className="mt-5 grid grid-cols-3 gap-3 sm:gap-4">
            {menuItems.map((item) => <MenuCard key={item.label} {...item} />)}
          </section>

          <section className="mt-5 rounded-[1.7rem] border border-white/10 bg-white/[0.055] p-4 shadow-2xl shadow-black/20 backdrop-blur-2xl sm:p-5">
            <div className="mb-3 flex items-center justify-between gap-3">
              <div>
                <p className="text-[0.65rem] font-black uppercase tracking-[0.20em] text-slate-400">Próximo evento</p>
                <h3 className="mt-1 text-lg font-black">Escala inteligente</h3>
              </div>
              <button className="flex items-center gap-1 text-xs font-black text-cyan-300" onClick={() => onNavigate('roster')}>Ver todos <ChevronRight className="h-3.5 w-3.5" /></button>
            </div>

            <button onClick={() => onNavigate('roster')} className="flex w-full items-center justify-between gap-4 rounded-3xl border border-white/10 bg-[#081a30]/80 p-4 text-left transition hover:bg-[#0b2039] active:scale-[0.99]">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-orange-400/15 text-orange-200">
                  <Clock className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-black">{nextEvent?.title || 'Importe sua escala'}</h4>
                  <p className="mt-1 text-xs font-semibold text-slate-400">{nextEvent?.date || 'CrewRosterReport / AIMS'}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xl font-black text-white">{nextEvent?.time || 'PDF'}</p>
                <p className="mt-1 text-[10px] font-black uppercase tracking-[0.12em] text-slate-500">{nextEvent?.endTime || 'novo'}</p>
              </div>
            </button>
          </section>
        </main>

        <aside className="mt-5 grid gap-4 sm:grid-cols-3 lg:mt-0 lg:block lg:space-y-4">
          <SideCard icon={ShieldCheck} title="100% Offline" text="Funciona sem internet" />
          <SideCard icon={RefreshCw} title="Sincroniza" text="quando voltar online" />
          <SideCard icon={Lock} title="Dados protegidos" text="apenas no seu dispositivo" />
          <button onClick={() => onNavigate('settings')} className="hidden w-full rounded-[1.65rem] border border-white/10 bg-white/[0.055] p-5 text-left shadow-xl shadow-black/20 backdrop-blur-xl transition hover:bg-white/[0.08] lg:block">
            <Settings className="mb-4 h-8 w-8 text-cyan-200" />
            <p className="font-black">Perfil premium</p>
            <p className="mt-1 text-sm leading-6 text-slate-400">Altere sua foto e preferências.</p>
          </button>
        </aside>
      </div>

      <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-white/10 bg-[#08111f]/85 px-5 pb-[calc(0.75rem+env(safe-area-inset-bottom,0px))] pt-3 shadow-2xl shadow-black backdrop-blur-2xl lg:hidden">
        <div className="mx-auto flex max-w-md items-center justify-between">
          <NavItem icon={Calendar} label="Início" active onClick={() => onNavigate('home')} />
          <NavItem icon={Calendar} label="Escala" onClick={() => onNavigate('roster')} />
          <NavItem icon={Clock} label="Rotina" onClick={() => onNavigate('routine')} />
          <NavItem icon={Bell} label="Alertas" badge={3} onClick={() => onNavigate('alerts')} />
          <NavItem icon={Menu} label="Mais" onClick={() => onNavigate('more')} />
        </div>
      </nav>
    </div>
  );
};

function FeatureLine({ icon: Icon, title, text }: { icon: LucideIcon; title: string; text: string }) {
  return (
    <div className="flex items-start gap-3 rounded-3xl border border-white/8 bg-white/[0.035] p-3">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-cyan-300/10 text-cyan-200"><Icon className="h-5 w-5" /></div>
      <div><p className="text-sm font-black">{title}</p><p className="mt-0.5 text-xs leading-5 text-slate-400">{text}</p></div>
    </div>
  );
}

function MiniStatus({ icon: Icon, value, label }: { icon: LucideIcon; value: string; label: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.07] p-3 text-center backdrop-blur-xl">
      <Icon className="mx-auto mb-1 h-4 w-4 text-cyan-200" />
      <p className="text-sm font-black">{value}</p>
      <p className="text-[9px] font-black uppercase tracking-[0.13em] text-slate-400">{label}</p>
    </div>
  );
}

function MenuCard({ icon: Icon, label, caption, color, onClick }: { icon: LucideIcon; label: string; caption: string; color: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="group min-h-[7rem] rounded-[1.45rem] border border-white/10 bg-white/[0.045] p-3 text-left shadow-xl shadow-black/15 transition hover:-translate-y-0.5 hover:bg-white/[0.075] active:scale-95 sm:p-4">
      <div className={`mb-3 flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br ${color} text-[#06101d] shadow-lg shadow-black/20 transition group-hover:scale-105`}>
        <Icon className="h-5 w-5" />
      </div>
      <p className="text-[0.72rem] font-black leading-tight text-white sm:text-sm">{label}</p>
      <p className="mt-1 hidden text-[10px] font-bold leading-4 text-slate-500 sm:block">{caption}</p>
    </button>
  );
}

function SideCard({ icon: Icon, title, text }: { icon: LucideIcon; title: string; text: string }) {
  return (
    <div className="rounded-[1.65rem] border border-white/10 bg-white/[0.055] p-5 shadow-xl shadow-black/20 backdrop-blur-xl">
      <Icon className="mb-4 h-9 w-9 text-cyan-200" />
      <p className="font-black">{title}</p>
      <p className="mt-1 text-sm leading-6 text-slate-400">{text}</p>
    </div>
  );
}

function NavItem({ icon: Icon, label, active, badge, onClick }: { icon: LucideIcon; label: string; active?: boolean; badge?: number; onClick: () => void }) {
  return (
    <button onClick={onClick} className={`flex min-w-12 flex-col items-center gap-1 rounded-2xl px-2 py-1 transition ${active ? 'text-cyan-300' : 'text-slate-500'}`}>
      <span className={`relative flex h-9 w-9 items-center justify-center rounded-2xl ${active ? 'bg-cyan-300/15' : ''}`}>
        <Icon className="h-5 w-5" />
        {badge ? <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[8px] font-black text-white">{badge}</span> : null}
      </span>
      <span className="text-[10px] font-black">{label}</span>
    </button>
  );
}

export default Dashboard;
