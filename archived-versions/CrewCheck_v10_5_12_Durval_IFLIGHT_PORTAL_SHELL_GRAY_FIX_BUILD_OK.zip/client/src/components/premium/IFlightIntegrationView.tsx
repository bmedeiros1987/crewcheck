import React, { useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  CalendarDays,
  CheckCircle2,
  ChevronLeft,
  DownloadCloud,
  ExternalLink,
  FileText,
  Globe,
  Loader2,
  Lock,
  MonitorSmartphone,
  RefreshCw,
  ShieldCheck,
  Upload,
  Workflow,
} from 'lucide-react';
import { toast } from 'sonner';
import type { CrewRoster } from '@/lib/pdfParser';

interface IFlightIntegrationViewProps {
  onBack: () => void;
  onSuccess: () => void;
  onFileUpload?: (file: File) => Promise<void>;
  onRosterImport?: (roster: CrewRoster, sourceFileName?: string) => Promise<void>;
}

type IFlightStatus = 'idle' | 'portal' | 'fetching' | 'success' | 'error';

type IFlightPortalOptions = {
  autoClicks: boolean;
  fromDate: string;
  toDate: string;
  periodMonth: string;
  periodYear: string;
  format: 'pdf';
  includeLegend: boolean;
  clickSend: false;
  privacyMode: 'lgpd_no_credentials';
  actions: string[];
};

type NativeIFlightPayload = {
  ok?: boolean;
  roster?: CrewRoster;
  dataBase64?: string;
  filename?: string;
  sourceFileName?: string;
  message?: string;
  error?: string;
};

declare global {
  interface Window {
    CrewCheckIFlight?: {
      openPortalAndImport?: (
        url: string,
        options?: IFlightPortalOptions,
      ) => Promise<NativeIFlightPayload | string> | NativeIFlightPayload | string;
    };
  }
}

const IFLIGHT_URL = 'https://iflightla.ibsplc.aero/iflight-cwp/web/getMainPage';
const MONTH_NAMES: Record<string, string> = {
  '01': 'Jan',
  '02': 'Feb',
  '03': 'Mar',
  '04': 'Apr',
  '05': 'May',
  '06': 'Jun',
  '07': 'Jul',
  '08': 'Aug',
  '09': 'Sep',
  '10': 'Oct',
  '11': 'Nov',
  '12': 'Dec',
};

function lastDayOfMonth(year: string, month: string) {
  const yearNumber = Number(year) || new Date().getFullYear();
  const monthNumber = Number(month) || new Date().getMonth() + 1;
  return String(new Date(yearNumber, monthNumber, 0).getDate()).padStart(2, '0');
}

function formatIFlightDate(day: string, month: string, year: string) {
  return `${day}-${MONTH_NAMES[month] || 'Jan'}-${year || new Date().getFullYear()}`;
}

async function parseBase64Pdf(filename: string, dataBase64: string): Promise<CrewRoster> {
  const response = await fetch('/api/parse-pdf', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ filename, dataBase64 }),
  });
  const payload = await response.json().catch(() => null);
  if (!response.ok || !payload?.ok || !payload?.roster) {
    throw new Error(payload?.message || payload?.detail || 'Não consegui interpretar o PDF baixado pelo iFlight.');
  }
  return payload.roster as CrewRoster;
}

const IFlightIntegrationView: React.FC<IFlightIntegrationViewProps> = ({ onBack, onSuccess, onFileUpload, onRosterImport }) => {
  const now = new Date();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [status, setStatus] = useState<IFlightStatus>('idle');
  const [message, setMessage] = useState('Abra o iFlight dentro do CrewCheck. Use seu e-mail corporativo LATAM apenas no portal oficial, faça login/MFA normalmente e o app capturará somente o PDF gerado.');
  const [periodMonth, setPeriodMonth] = useState(String(now.getMonth() + 1).padStart(2, '0'));
  const [periodYear, setPeriodYear] = useState(String(now.getFullYear()));
  const [includeLegend, setIncludeLegend] = useState(false);
  const [autoClicks, setAutoClicks] = useState(true);

  const isBusy = status === 'fetching' || status === 'portal';
  const hasNativeBridge = typeof window !== 'undefined' && Boolean(window.CrewCheckIFlight?.openPortalAndImport);
  const months = useMemo(() => ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'], []);
  const fromDate = formatIFlightDate('01', periodMonth, periodYear);
  const toDate = formatIFlightDate(lastDayOfMonth(periodYear, periodMonth), periodMonth, periodYear);

  const portalOptions: IFlightPortalOptions = {
    autoClicks,
    fromDate,
    toDate,
    periodMonth,
    periodYear,
    format: 'pdf',
    includeLegend,
    clickSend: false,
    privacyMode: 'lgpd_no_credentials',
    actions: ['wait_user_login_mfa', 'open_roster', 'open_roster_report', 'fill_period', 'select_pdf', 'run_report', 'capture_pdf_download'],
  };

  const finishRosterImport = async (roster: CrewRoster, sourceFileName: string) => {
    if (!onRosterImport) {
      setStatus('success');
      setMessage('Escala recebida. Abra a tela de escala para conferir.');
      onSuccess();
      return;
    }
    setStatus('fetching');
    setMessage('PDF recebido. Interpretando escala e montando painel premium...');
    await onRosterImport(roster, sourceFileName);
    setStatus('success');
    setMessage('Escala iFlight importada com sucesso.');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setStatus('fetching');
    setMessage(`Processando ${file.name}...`);

    try {
      if (onFileUpload) {
        await onFileUpload(file);
        setStatus('success');
        setMessage('Escala iFlight importada com sucesso.');
        onSuccess();
        return;
      }

      setStatus('success');
      setMessage('PDF selecionado. Conclua a análise na tela de escala.');
      onSuccess();
    } catch (error) {
      setStatus('error');
      setMessage(error instanceof Error ? error.message : 'Não foi possível importar o PDF do iFlight.');
    } finally {
      e.target.value = '';
    }
  };

  async function handleOpenPortalFlow() {
    if (hasNativeBridge && window.CrewCheckIFlight?.openPortalAndImport) {
      setStatus('portal');
      setMessage('Abrindo o portal oficial iFlight dentro do CrewCheck. Use seu e-mail corporativo LATAM no Google/SSO, conclua o MFA manualmente e aguarde: o CrewCheck fará somente os cliques do relatório e importará o PDF.');
      try {
        const nativeResult = await window.CrewCheckIFlight.openPortalAndImport(IFLIGHT_URL, portalOptions);
        const payload: NativeIFlightPayload = typeof nativeResult === 'string' ? JSON.parse(nativeResult) : nativeResult;
        if (!payload?.ok) throw new Error(payload?.error || payload?.message || 'O portal foi fechado sem retornar o PDF da escala.');
        if (payload.roster) {
          await finishRosterImport(payload.roster, payload.sourceFileName || payload.filename || `iFlight_${periodYear}_${periodMonth}.pdf`);
          return;
        }
        if (payload.dataBase64) {
          const filename = payload.filename || `iFlight_${periodYear}_${periodMonth}.pdf`;
          const roster = await parseBase64Pdf(filename, payload.dataBase64);
          await finishRosterImport(roster, filename);
          return;
        }
        throw new Error('O portal retornou sem PDF e sem escala interpretada.');
      } catch (error) {
        const rawMessage = error instanceof Error ? error.message : 'Não foi possível concluir a importação pelo portal.';
        const isSso403 = /app_not_configured_for_user|service is not configured|403/i.test(rawMessage);
        const errorMessage = isSso403
          ? 'O iFlight/Google retornou 403 app_not_configured_for_user. Isso normalmente significa conta corporativa sem permissão, conta Google errada aberta no dispositivo ou bloqueio da WebView. Use o botão Chrome, faça login com a conta corporativa, baixe o PDF e abra/compartilhe com o CrewCheck.'
          : rawMessage;
        setStatus('error');
        setMessage(errorMessage);
        toast.error(errorMessage);
      }
      return;
    }

    setStatus('portal');
    setMessage('Portal iFlight aberto em nova aba. No navegador comum, por segurança, o CrewCheck não consegue clicar nem ler o PDF baixado por outro domínio. Para automação completa, use o APK Android com WebView nativa.');
    window.open(IFLIGHT_URL, '_blank', 'noopener,noreferrer');
    toast.info('No navegador comum, baixe o PDF no iFlight e importe manualmente pelo botão do CrewCheck.');
  }

  return (
    <div className="min-h-screen overflow-hidden bg-[#030914] pb-32 text-white">
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_12%_0%,rgba(249,115,22,0.22),transparent_32%),radial-gradient(circle_at_86%_4%,rgba(14,165,233,0.18),transparent_30%),linear-gradient(180deg,#030914_0%,#07111f_58%,#020817_100%)]" />
        <div className="absolute inset-0 opacity-[0.06]" style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,0.95) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.95) 1px, transparent 1px)', backgroundSize: '58px 58px' }} />
      </div>

      <div className="relative z-10 mx-auto max-w-6xl px-5 py-8">
        <header className="flex items-center justify-between gap-4 rounded-[1.8rem] border border-white/10 bg-white/[0.055] px-4 py-3 shadow-2xl shadow-black/25 backdrop-blur-2xl">
          <button onClick={onBack} className="flex items-center gap-3 text-left">
            <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10 text-orange-100"><ChevronLeft className="h-5 w-5" /></span>
            <span>
              <h2 className="text-xl font-black">Portal iFlight dentro do CrewCheck</h2>
              <p className="mt-1 text-xs font-black uppercase tracking-[0.2em] text-orange-100/60">e-mail corporativo no SSO · MFA manual · PDF automático</p>
            </span>
          </button>
          <div className="flex items-center gap-3">
            <span className="hidden rounded-full border border-emerald-300/20 bg-emerald-300/10 px-3 py-1 text-[10px] font-black uppercase tracking-[0.16em] text-emerald-100 sm:inline-flex">LGPD integral</span>
            <img src="/icons/crewcheck-icon.svg" alt="CrewCheck" className="h-12 w-12 rounded-2xl shadow-xl shadow-orange-950/30" />
          </div>
        </header>

        <section className="mt-6 grid gap-5 lg:grid-cols-[minmax(0,1fr)_22rem]">
          <div className="space-y-5">
            <div className="overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.055] shadow-2xl shadow-black/25 backdrop-blur-2xl">
              <div className="relative p-6 sm:p-8">
                <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-orange-300 via-cyan-300 to-blue-500" />
                <div className="flex flex-col gap-5 sm:flex-row sm:items-center">
                  <div className={`flex h-20 w-20 shrink-0 items-center justify-center rounded-[1.8rem] ${
                    status === 'success' ? 'bg-emerald-500/15 text-emerald-300' :
                    status === 'error' ? 'bg-rose-500/15 text-rose-300' :
                    status === 'portal' ? 'bg-blue-500/15 text-blue-200' :
                    'bg-orange-500/15 text-orange-300'
                  }`}>
                    {status === 'fetching' ? <Loader2 className="h-12 w-12 animate-spin" /> : status === 'success' ? <CheckCircle2 className="h-12 w-12" /> : <Globe className="h-12 w-12" />}
                  </div>
                  <div>
                    <p className="text-xs font-black uppercase tracking-[0.22em] text-orange-100/60">o usuário continua no controle</p>
                    <h3 className="mt-1 text-3xl font-black tracking-tight">Importação iFlight assistida</h3>
                    <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-300">{message}</p>
                    <div className="mt-4 rounded-2xl border border-cyan-300/15 bg-cyan-300/10 px-4 py-3 text-xs font-bold leading-5 text-cyan-50">
                      Na tela do Google/iFlight, use o <strong>e-mail corporativo LATAM</strong>. No cadastro do CrewCheck, use e-mail pessoal; contas <strong>@latam.com</strong> são bloqueadas para evitar mistura de dados corporativos.
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <FlowCard number="1" icon={MonitorSmartphone} title="Login corporativo" text="E-mail LATAM e MFA são digitados somente no Google/portal oficial, dentro da tela do CrewCheck." />
              <FlowCard number="2" icon={Workflow} title="Cliques assistidos" text="Após login, o app abre Roster, relatório, muda UTC para LT, PDF e Run." />
              <FlowCard number="3" icon={DownloadCloud} title="PDF importado" text="O download é capturado e interpretado pelo CrewCheck." />
            </div>

            <div className="rounded-[2rem] border border-cyan-300/15 bg-cyan-300/10 p-5 shadow-2xl shadow-black/20 backdrop-blur-2xl sm:p-6">
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-cyan-300/15 text-cyan-200"><Globe className="h-6 w-6" /></div>
                <div>
                  <h4 className="text-xl font-black">Abrir navegador seguro dentro do app</h4>
                  <p className="mt-1 text-sm leading-6 text-cyan-50/75">No APK Android, o CrewCheck abre o portal oficial iFlight em uma tela interna identificada como CrewCheck. O login corporativo e o MFA continuam manuais; após o acesso, o app só preenche o relatório em LT/PDF e captura o PDF baixado.</p>
                </div>
              </div>

              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                <label className="block">
                  <span className="text-xs font-black uppercase tracking-[0.16em] text-cyan-100/70">Mês da escala</span>
                  <select value={periodMonth} onChange={(event) => setPeriodMonth(event.target.value)} className="mt-2 h-12 w-full rounded-2xl border border-white/10 bg-[#07111f] px-4 text-sm font-bold text-white outline-none focus:border-cyan-300">
                    {months.map((month) => <option key={month} value={month}>{month}</option>)}
                  </select>
                </label>
                <label className="block">
                  <span className="text-xs font-black uppercase tracking-[0.16em] text-cyan-100/70">Ano</span>
                  <input value={periodYear} onChange={(event) => setPeriodYear(event.target.value.replace(/\D/g, '').slice(0, 4))} inputMode="numeric" className="mt-2 h-12 w-full rounded-2xl border border-white/10 bg-[#07111f] px-4 text-sm font-bold text-white outline-none focus:border-cyan-300" />
                </label>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <label className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/10 px-4 py-3 text-sm font-bold text-white">
                  <input checked={autoClicks} onChange={(event) => setAutoClicks(event.target.checked)} type="checkbox" className="h-4 w-4 accent-cyan-300" />
                  Fazer cliques automáticos após login/MFA
                </label>
                <label className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/10 px-4 py-3 text-sm font-bold text-white">
                  <input checked={includeLegend} onChange={(event) => setIncludeLegend(event.target.checked)} type="checkbox" className="h-4 w-4 accent-cyan-300" />
                  Marcar Include Legend no relatório
                </label>
              </div>

              <div className="mt-4 rounded-3xl border border-white/10 bg-[#07111f]/75 p-4">
                <div className="flex items-start gap-3">
                  <CalendarDays className="mt-0.5 h-5 w-5 shrink-0 text-cyan-200" />
                  <div>
                    <p className="text-sm font-black">Período que será preenchido no iFlight</p>
                    <p className="mt-1 text-xs leading-5 text-slate-400">From Date: <strong className="text-white">{fromDate}</strong> · To Date: <strong className="text-white">{toDate}</strong> · fuso: <strong className="text-white">LT</strong> · formato: <strong className="text-white">PDF</strong></p>
                  </div>
                </div>
              </div>

              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                <button onClick={handleOpenPortalFlow} disabled={status === 'fetching'} className="flex items-center justify-center gap-3 rounded-2xl bg-cyan-300 px-5 py-4 text-sm font-black text-[#07111f] shadow-lg shadow-cyan-950/30 transition hover:bg-cyan-200 disabled:cursor-wait disabled:opacity-70">
                  <ExternalLink className="h-5 w-5" /> {hasNativeBridge ? 'Abrir iFlight e automatizar' : 'Abrir iFlight'}
                </button>
                <button onClick={() => fileInputRef.current?.click()} disabled={status === 'fetching'} className="flex items-center justify-center gap-3 rounded-2xl border border-white/10 bg-white/10 px-5 py-4 text-sm font-black text-white transition hover:bg-white/15 disabled:cursor-wait disabled:opacity-70">
                  <Upload className="h-5 w-5" /> Importar PDF manualmente
                </button>
                <input ref={fileInputRef} type="file" accept=".pdf,application/pdf" onChange={handleFileUpload} disabled={status === 'fetching'} className="sr-only" />
              </div>
            </div>

            <div className="rounded-[2rem] border border-emerald-300/15 bg-emerald-400/10 p-5 shadow-2xl shadow-black/20 backdrop-blur-2xl sm:p-6">
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-emerald-300/15 text-emerald-200"><ShieldCheck className="h-6 w-6" /></div>
                <div>
                  <h4 className="text-xl font-black">LGPD e privacidade por desenho</h4>
                  <p className="mt-1 text-sm leading-6 text-emerald-50/75">O CrewCheck não cria cadastro com e-mail @latam.com, não recebe senha corporativa, não salva MFA, não grava cookies do iFlight no banco e apaga a WebView do portal ao terminar. O único dado importado é o PDF que o próprio usuário gerou no iFlight.</p>
                </div>
              </div>
            </div>
          </div>

          <aside className="space-y-4">
            <div className="rounded-[1.7rem] border border-white/10 bg-white/[0.055] p-5 shadow-xl shadow-black/20 backdrop-blur-xl">
              <Lock className="mb-4 h-9 w-9 text-emerald-300" />
              <h4 className="font-black">O que será automatizado</h4>
              <div className="mt-4 space-y-3">
                <Step number="1" text="Aguardar o usuário concluir login e MFA." />
                <Step number="2" text="Clicar em Roster quando o portal estiver aberto." />
                <Step number="3" text="Abrir Roster Report/Calendar conforme disponível." />
                <Step number="4" text="Preencher From Date e To Date." />
                <Step number="5" text="Mudar UTC para LT, selecionar PDF e clicar em Run." />
                <Step number="6" text="Capturar o PDF baixado e importar." />
              </div>
            </div>

            <div className="rounded-[1.7rem] border border-blue-300/20 bg-blue-400/10 p-5 text-sm leading-6 text-blue-50/80">
              <AlertCircle className="mb-3 h-6 w-6 text-blue-200" />
              O botão <strong>Send</strong> não é clicado automaticamente, para evitar qualquer envio indevido. O fluxo automático usa o <strong>Run</strong> para gerar/baixar o PDF.
            </div>

            <a href={IFLIGHT_URL} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/10 px-5 py-4 text-sm font-black text-white hover:bg-white/15">
              Abrir Portal iFlight no navegador <ExternalLink className="h-4 w-4" />
            </a>

            <div className="rounded-[1.7rem] border border-white/10 bg-white/[0.045] p-5">
              <p className="text-xs font-black uppercase tracking-[0.18em] text-slate-500">fallback seguro</p>
              <div className="mt-4 space-y-3">
                <Step number="1" text="Se o portal mudar o layout, baixe o PDF manualmente." />
                <Step number="2" text="Toque em Importar PDF manualmente." />
                <Step number="3" text="O parser continua funcionando do mesmo jeito." />
              </div>
            </div>
          </aside>
        </section>
      </div>
    </div>
  );
};

function FlowCard({ number, icon: Icon, title, text }: { number: string; icon: React.ComponentType<{ className?: string }>; title: string; text: string }) {
  return (
    <div className="rounded-[1.7rem] border border-white/10 bg-white/[0.052] p-5 shadow-xl shadow-black/15 backdrop-blur-xl">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10 text-cyan-200"><Icon className="h-5 w-5" /></div>
        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-cyan-300 text-xs font-black text-[#07111f]">{number}</span>
      </div>
      <h5 className="font-black">{title}</h5>
      <p className="mt-2 text-xs leading-5 text-slate-400">{text}</p>
    </div>
  );
}

const Step = ({ number, text }: { number: string, text: string }) => (
  <div className="flex items-start gap-3">
    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500/20 text-[10px] font-black text-orange-300">{number}</div>
    <p className="text-xs leading-5 text-slate-300">{text}</p>
  </div>
);

export default IFlightIntegrationView;
