# CrewCheck v10.5.12 Durval — iFlight Portal Shell + Gray Fix

- Portal iFlight recebe moldura visual persistente do CrewCheck dentro da própria WebView.
- Usuário continua vendo que está dentro do CrewCheck durante login, MFA e navegação no iFlight.
- Automação melhorada para a tela cinza/default dashboard: tenta abrir o menu hambúrguer por seletor e coordenadas seguras.
- Botões internos Menu e Auto dentro do overlay do iFlight.
- Permissões de push/notificação do iFlight são negadas dentro da WebView para evitar banners/travamentos.
- Mantém LGPD: não salva usuário, senha, MFA, cookies ou sessão corporativa.
- Antes de Run: PDF + LT.
