# HOTFIX v10.5.4 Durval — Premium visual, perfil e iFlight

Este pacote evolui a versão Durval com foco em visual premium, botões funcionais e configurações de perfil.

## Incluído

- Dashboard redesenhado para ficar mais próximo do mockup enviado: fundo escuro premium, cards em vidro, badges offline e painéis laterais.
- Logo clássica do CrewCheck restaurada no topo, no painel e nas configurações.
- Configurações próprias na tela inicial, sem exigir escala carregada.
- Alteração e remoção da foto de perfil em Configurações, com salvamento local no dispositivo.
- Botão iFlight LATAM redesenhado com modo PDF assistido e formulário de tentativa de importação corporativa.
- Endpoint `/api/iflight/import` no servidor, com suporte futuro a conector/API oficial via `IFLIGHT_CONNECTOR_URL` e `IFLIGHT_CONNECTOR_TOKEN`.
- Tratamento seguro quando o portal iFlight exige Google/SAML/MFA: o sistema não armazena senha nem tenta burlar autenticação corporativa.

## Observação técnica sobre iFlight

O portal informado redireciona para autenticação corporativa Google/SAML. Para importação 100% automática sem PDF, a companhia precisa liberar API/conector autorizado. Sem isso, o modo confiável continua sendo gerar o Roster Report em PDF e importar pelo CrewCheck.

## Validação

- `npm run check`
- `npm run build`
