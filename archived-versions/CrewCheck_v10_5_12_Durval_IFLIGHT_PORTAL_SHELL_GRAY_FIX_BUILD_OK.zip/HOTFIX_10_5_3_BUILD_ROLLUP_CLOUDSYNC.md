# HOTFIX 10.5.3 Durval — Correção de build Rollup/Vite

## Problema corrigido

O deploy no Render falhava durante `vite build` com erro do Rollup:

```txt
client/src/components/premium/Dashboard.tsx (8:2): "CloudSync" is not exported by "lucide-react"
```

## Causa

A versão instalada de `lucide-react` não exporta o ícone `CloudSync`. Por isso, o Rollup interrompia o build ao resolver os imports do Dashboard.

## Correção aplicada

No arquivo:

```txt
client/src/components/premium/Dashboard.tsx
```

o ícone `CloudSync` foi substituído por `FolderSync`, que existe na versão atual do pacote e mantém a mesma ideia visual de sincronização/rotina.

## Validação

Executado com sucesso:

```bash
npm run check
npm run build
```

Resultado: build aprovado.
