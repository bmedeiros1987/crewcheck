# CrewCheck v10.5.3 Durval — Identificação da versão

Ajuste solicitado para exibir o nome **Durval** depois da versão v10.5.3 no sistema.

## Alterações realizadas

- Rodapé do sistema atualizado para: `CrewCheck v10.5.3 Durval · Premium Clean`.
- Manifest/PWA atualizado para: `CrewCheck v10.5.3 Durval`.
- Android wrapper atualizado para `versionCode 10503` e `versionName 10.5.3 Durval`.
- Descrição do pacote atualizada para identificar a versão Durval.

## Validação

Executado com sucesso:

```bash
npm run check
npm run build
```
