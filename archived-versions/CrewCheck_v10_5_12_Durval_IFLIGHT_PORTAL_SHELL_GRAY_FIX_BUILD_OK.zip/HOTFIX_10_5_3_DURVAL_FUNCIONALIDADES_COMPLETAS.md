# HOTFIX v10.5.3 Durval — Funcionalidades completas integradas

Este pacote mantém o rótulo **CrewCheck v10.5.3 Durval** e recompõe as funcionalidades reais do sistema dentro da nova experiência premium.

## Ajustes principais

- Tela de login protegida preservada.
- Dashboard Durval mantido, agora com botões funcionais.
- Botão **Nova Escala** incluído no menu principal.
- Upload real de PDF restaurado na Home:
  - CrewRosterReport;
  - AIMS/iFlight;
  - fallback local quando o parser do servidor falhar.
- Abertura de escala salva pelo histórico.
- Menu **Mais** funcional com atalhos para importação, histórico, alertas, relatórios, calendário, configurações, sincronização e sair.
- Botão de alertas do topo funcional.
- iFlight LATAM deixou de ser apenas simulação e agora usa o fluxo real de importação/análise de PDF.
- Resultados podem abrir diretamente na aba solicitada pelo menu:
  - escala;
  - irregularidades;
  - alertas;
  - rotina;
  - métricas;
  - configurações.
- Notas locais funcionais com persistência em `localStorage`.
- Sincronização offline reaproveitada no dashboard e no menu completo.

## Validação

Executado com sucesso:

```bash
npm run check
npm run build
npm start
```

O aviso de chunk grande do Vite permanece apenas como alerta de otimização e não impede o deploy.
