# CrewCheck 10.5.2 — Rotina, Escala, Configurações e Google Calendar

## Rotina
- Recomendações agora consideram folgas, DOP/DOPR/VC, inativos/pernoites e programações curtas onde a atividade caiba.
- Ao abrir um card da escala no celular, o usuário vê uma recomendação objetiva para rotina/descanso.
- Adicionar atividade continua com limite e bloqueio de duplicidade por tipo.

## Escala
- Tela de Escala foi simplificada: exportações e ações administrativas saíram do menu Escala e foram centralizadas em Configurações.
- Cards mobile continuam clicáveis, com menos informação na primeira vista e detalhes ao abrir.
- HSB/ASB recebeu deduplicação final por fragmentos de ticket.
- Treinamentos/checks continuam separados dos voos.
- C32F/check com horários repetidos no PDF passa a usar a primeira e a última hora válida do bloco, evitando jornada irreal de 20h+.

## Configurações
- Exportar PDF, ICS, copiar e e-mail ficam centralizados em Configurações.
- Suporte por WhatsApp/e-mail foi adicionado como botão, sem expor o contato diretamente na tela.
- Manual agora possui uma página pública `/manual.html` e botão dentro do menu Manual.

## Google Calendar
- Sincronização separa treinamento/check de voo, evitando evento concatenado no Google Calendar.
- Mantido o mecanismo de update/patch por chave privada para não duplicar eventos.

## Validação
- npm run check
- npm run build
- node --check server.mjs
