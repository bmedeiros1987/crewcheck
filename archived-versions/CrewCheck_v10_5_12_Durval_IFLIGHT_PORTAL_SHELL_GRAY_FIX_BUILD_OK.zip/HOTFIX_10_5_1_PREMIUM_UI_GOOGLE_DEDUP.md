# CrewCheck 10.5.1 — Premium UI, deduplicação e métricas

## Ajustes principais

- Resumo consolidado apenas no menu **Resumo**; as demais telas deixaram de repetir resumo/KPIs.
- Escala no celular em cards claros, objetivos e clicáveis; detalhes ficam recolhidos.
- Tema do sistema: modo **Automático**, **Claro** ou **Escuro** em Configurações.
- Deduplicação final de HSB/HSBE/ASB/RES/CBF/EMER quando o PDF ticket fragmenta o mesmo bloco.
- Check/treinamento separado do voo extra PS; voo não é mais concatenado com C32F/treinamento.
- Recalibragem da “escala puxada”: madrugada isolada com até 2 pernas é rotina normal; maior peso para sequência, mais de 3 pernas, tempo em solo elevado e repouso curto.
- Histórico de escalas passa a deduplicar por mês/ano/tripulante, não por arquivo enviado.
- Google Calendar recebeu mensagens de fluxo mais claras e mantém sincronização por chave privada para evitar duplicidade.
- Rodapé, manifest e Android wrapper atualizados para 10.5.1.

## Observações

- Reenviar/reprocessar a escala após o deploy para recalcular deduplicação, puxada e histórico mensal.
- Para Google Calendar funcionar, manter `VITE_GOOGLE_CLIENT_ID` no Render e domínio autorizado no Google Cloud.
