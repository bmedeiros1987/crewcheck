package com.crewcheck.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.PermissionRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST_CODE = 4242;
    private static final int MAX_PDF_BYTES = 35 * 1024 * 1024;

    private FrameLayout rootLayout;
    private WebView webView;
    private WebView portalWebView;
    private View portalContainer;
    private ValueCallback<Uri[]> filePathCallback;
    private String activeIFlightRequestId;
    private String activeIFlightConfigJson = "{}";
    private boolean closingPortalWithResult = false;
    private boolean portalSsoErrorDetected = false;
    private String lastIFlightUrl = "https://iflightla.ibsplc.aero/iflight-cwp/web/getMainPage";
    private String pendingSharedPdfBase64;
    private String pendingSharedPdfName;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.parseColor("#071D33"));
        getWindow().setNavigationBarColor(Color.parseColor("#071D33"));

        rootLayout = new FrameLayout(this);
        rootLayout.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(rootLayout);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        rootLayout.addView(webView);

        configureWebView(webView, false);
        webView.addJavascriptInterface(new CrewCheckIFlightBridge(), "AndroidCrewCheckIFlight");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectCrewCheckBridge();
                dispatchPendingSharedPdf();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request != null && request.isForMainFrame()) {
                    try {
                        view.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
                        view.loadUrl("https://crewcheck.online?app=1");
                    } catch (Exception ignored) {}
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/pdf");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf", "application/octet-stream"});
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);

                Intent chooser = Intent.createChooser(intent, "Escolher PDF da escala");
                try {
                    startActivityForResult(chooser, FILE_CHOOSER_REQUEST_CODE);
                } catch (Exception ex) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        handleIncomingPdfIntent(getIntent());
        webView.loadUrl("https://crewcheck.online?app=1");
    }

    private void configureWebView(WebView target, boolean portalMode) {
        WebSettings settings = target.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(!portalMode);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(portalMode);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setSaveFormData(false);
        if (portalMode) {
            try {
                // O iFlight antigo costuma renderizar corretamente apenas no layout desktop.
                // Usamos User-Agent desktop e viewport amplo, sem salvar credenciais.
                settings.setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36");
                settings.setTextZoom(100);
                target.setInitialScale(80);
                target.setHorizontalScrollBarEnabled(true);
                target.setVerticalScrollBarEnabled(true);
                target.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
            } catch (Exception ignored) {}
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.setAcceptThirdPartyCookies(target, true);
        }
    }

    private void injectCrewCheckBridge() {
        if (webView == null) return;
        String js = "(function(){" +
                "if(window.__crewcheckNativeBridgeInstalled)return;" +
                "window.__crewcheckNativeBridgeInstalled=true;" +
                "window.__crewcheckIflightCallbacks=window.__crewcheckIflightCallbacks||{};" +
                "window.CrewCheckIFlight={openPortalAndImport:function(url,options){" +
                "return new Promise(function(resolve){" +
                "var id='iflight_'+Date.now()+'_'+Math.random().toString(36).slice(2);" +
                "window.__crewcheckIflightCallbacks[id]=function(payload){try{if(typeof payload==='string')payload=JSON.parse(payload);}catch(e){};delete window.__crewcheckIflightCallbacks[id];resolve(payload);};" +
                "try{AndroidCrewCheckIFlight.openPortalAndImport(String(url),JSON.stringify(options||{}),id);}catch(e){resolve({ok:false,error:String(e&&e.message||e)});}" +
                "});" +
                "}};" +
                "})();";
        try {
            webView.evaluateJavascript(js, null);
        } catch (Exception ignored) {}
    }

    public class CrewCheckIFlightBridge {
        @JavascriptInterface
        public void openPortalAndImport(final String url, final String configJson, final String requestId) {
            runOnUiThread(() -> openIFlightPortal(url, configJson, requestId));
        }
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    private void openIFlightPortal(String url, String configJson, String requestId) {
        closePortalOnly();
        closingPortalWithResult = false;
        activeIFlightRequestId = requestId;
        activeIFlightConfigJson = sanitizeJsonConfig(configJson);
        lastIFlightUrl = url;
        portalSsoErrorDetected = false;

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setBackgroundColor(Color.parseColor("#030914"));
        container.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(12), dp(10), dp(12), dp(10));
        toolbar.setBackgroundColor(Color.parseColor("#071D33"));

        TextView title = new TextView(this);
        title.setText("CrewCheck · Portal iFlight\nUse o e-mail corporativo LATAM somente no SSO oficial");
        title.setTextColor(Color.WHITE);
        title.setTextSize(13f);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setSingleLine(false);
        toolbar.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Button automate = new Button(this);
        automate.setText("Auto");
        automate.setAllCaps(false);
        automate.setOnClickListener(v -> {
            if (portalWebView != null) {
                injectIFlightAutomation(portalWebView);
                Toast.makeText(this, "Automação iFlight reativada. Login/MFA continuam manuais.", Toast.LENGTH_SHORT).show();
            }
        });
        toolbar.addView(automate, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        Button reload = new Button(this);
        reload.setText("Recarregar");
        reload.setAllCaps(false);
        reload.setOnClickListener(v -> {
            if (portalWebView != null) portalWebView.reload();
        });
        toolbar.addView(reload, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        Button browser = new Button(this);
        browser.setText("Chrome");
        browser.setAllCaps(false);
        browser.setOnClickListener(v -> openIFlightInExternalBrowser(lastIFlightUrl));
        toolbar.addView(browser, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        Button close = new Button(this);
        close.setText("Fechar");
        close.setAllCaps(false);
        close.setOnClickListener(v -> finishIFlightWithError("Portal iFlight fechado pelo usuário antes do download do PDF."));
        toolbar.addView(close, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        portalWebView = new WebView(this);
        portalWebView.setBackgroundColor(Color.WHITE);
        configureWebView(portalWebView, true);

        portalWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (request != null && request.getUrl() != null && isLikelyPdfUrl(request.getUrl().toString(), "", "")) {
                    fetchPdfAndReturn(request.getUrl().toString(), view.getSettings().getUserAgentString(), "", "application/pdf");
                    return true;
                }
                return false;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                try {
                    if (request != null && request.getUrl() != null) {
                        String requested = request.getUrl().toString();
                        if (isLikelyPdfUrl(requested, "", "")) {
                            fetchPdfAndReturn(requested, view.getSettings().getUserAgentString(), "", "application/pdf");
                            return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                        }
                    }
                } catch (Exception ignored) {}
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onPageFinished(WebView view, String pageUrl) {
                super.onPageFinished(view, pageUrl);
                injectIFlightAutomation(view);
                checkForIFlightSsoError(view, pageUrl);
            }
        });
        portalWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                // O iFlight pode pedir permissão de push/notificação.
                // Por LGPD e para evitar travamento visual, o CrewCheck nega
                // a permissão na WebView interna sem afetar o login/MFA.
                try {
                    request.deny();
                } catch (Exception ignored) {}
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                try {
                    WebView popup = new WebView(MainActivity.this);
                    configureWebView(popup, true);
                    popup.setWebViewClient(new WebViewClient() {
                        @Override
                        public boolean shouldOverrideUrlLoading(WebView popupView, WebResourceRequest request) {
                            if (request != null && request.getUrl() != null && portalWebView != null) {
                                String targetUrl = request.getUrl().toString();
                                if (isLikelyPdfUrl(targetUrl, "", "")) {
                                    fetchPdfAndReturn(targetUrl, popupView.getSettings().getUserAgentString(), "", "application/pdf");
                                } else {
                                    portalWebView.loadUrl(targetUrl);
                                }
                            }
                            return true;
                        }
                    });
                    popup.setDownloadListener((downloadUrl, userAgent, contentDisposition, mimeType, contentLength) -> fetchPdfAndReturn(downloadUrl, userAgent, contentDisposition, mimeType));
                    WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                    transport.setWebView(popup);
                    resultMsg.sendToTarget();
                    return true;
                } catch (Exception ignored) {
                    return false;
                }
            }
        });
        portalWebView.setDownloadListener((downloadUrl, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (isLikelyPdfUrl(downloadUrl, contentDisposition, mimeType)) {
                fetchPdfAndReturn(downloadUrl, userAgent, contentDisposition, mimeType);
            } else if (downloadUrl != null && downloadUrl.startsWith("blob:")) {
                finishIFlightWithError("O iFlight gerou um download interno do tipo blob. Tente tocar em Roster Report > PDF > Run novamente ou use Importar PDF manualmente.");
            } else {
                fetchPdfAndReturn(downloadUrl, userAgent, contentDisposition, mimeType);
            }
        });

        container.addView(toolbar, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView guidance = new TextView(this);
        guidance.setText("Você está no CrewCheck. Login e MFA acontecem no portal oficial iFlight. Use seu e-mail corporativo LATAM aqui; o CrewCheck não lê nem salva credenciais.");
        guidance.setTextColor(Color.parseColor("#D8F3FF"));
        guidance.setTextSize(12f);
        guidance.setGravity(Gravity.CENTER_VERTICAL);
        guidance.setPadding(dp(14), dp(9), dp(14), dp(9));
        guidance.setBackgroundColor(Color.parseColor("#0B2A45"));
        container.addView(guidance, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        container.addView(portalWebView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        portalContainer = container;
        rootLayout.addView(container);
        portalWebView.loadUrl(url);
    }

    private String sanitizeJsonConfig(String configJson) {
        if (configJson == null || configJson.trim().isEmpty()) return "{}";
        try {
            return new JSONObject(configJson).toString();
        } catch (Exception ignored) {
            return "{}";
        }
    }


    private void checkForIFlightSsoError(WebView view, String pageUrl) {
        if (portalSsoErrorDetected || view == null) return;
        try {
            view.evaluateJavascript("(function(){return (document.body&&document.body.innerText)||'';})()", value -> {
                try {
                    Object parsed = new JSONTokener(value == null ? "\"\"" : value).nextValue();
                    String text = String.valueOf(parsed == null ? "" : parsed);
                    String merged = ((pageUrl == null ? "" : pageUrl) + " " + text).toLowerCase(Locale.US);
                    if (merged.contains("app_not_configured_for_user") || merged.contains("service is not configured for this user") || merged.contains("that’s an error") || merged.contains("that's an error")) {
                        portalSsoErrorDetected = true;
                        showIFlightSsoCompatibilityDialog();
                    }
                } catch (Exception ignored) {}
            });
        } catch (Exception ignored) {}
    }

    private void showIFlightSsoCompatibilityDialog() {
        runOnUiThread(() -> {
            try {
                new AlertDialog.Builder(this)
                        .setTitle("iFlight bloqueou esta sessão")
                        .setMessage("O erro 403 app_not_configured_for_user vem da autenticação Google/SAML do iFlight. Pode ser conta Google incorreta, usuário sem permissão no app corporativo ou bloqueio da WebView. Primeiro tente com a conta corporativa no Chrome. Depois baixe o PDF e abra/compartilhe com o CrewCheck para importar sem salvar credenciais.")
                        .setPositiveButton("Abrir no Chrome", (dialog, which) -> openIFlightInExternalBrowser(lastIFlightUrl))
                        .setNegativeButton("Continuar aqui", null)
                        .show();
            } catch (Exception ignored) {}
        });
    }

    private void openIFlightInExternalBrowser(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url == null || url.trim().isEmpty() ? lastIFlightUrl : url));
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(intent);
            Toast.makeText(this, "Use o e-mail corporativo LATAM no Chrome. Ao baixar o PDF, use Compartilhar/Abrir com CrewCheck para importar.", Toast.LENGTH_LONG).show();
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "Não encontrei navegador instalado para abrir o iFlight.", Toast.LENGTH_LONG).show();
        } catch (Exception ignored) {}
    }

    private void handleIncomingPdfIntent(Intent intent) {
        if (intent == null) return;
        try {
            String action = intent.getAction();
            Uri uri = null;
            if (Intent.ACTION_SEND.equals(action)) {
                Object stream = intent.getParcelableExtra(Intent.EXTRA_STREAM);
                if (stream instanceof Uri) uri = (Uri) stream;
            } else if (Intent.ACTION_VIEW.equals(action)) {
                uri = intent.getData();
            }
            if (uri == null) return;
            readIncomingPdfUri(uri);
        } catch (Exception error) {
            Toast.makeText(this, "Não consegui receber o PDF compartilhado.", Toast.LENGTH_LONG).show();
        }
    }

    private void readIncomingPdfUri(Uri uri) throws Exception {
        String filename = "iFlight_RosterReport.pdf";
        String last = uri.getLastPathSegment();
        if (last != null && last.toLowerCase(Locale.US).contains("pdf")) filename = last.substring(Math.max(0, last.lastIndexOf('/') + 1));
        InputStream input = getContentResolver().openInputStream(uri);
        if (input == null) throw new Exception("PDF sem conteúdo.");
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int total = 0;
        int read;
        while ((read = input.read(buffer)) != -1) {
            total += read;
            if (total > MAX_PDF_BYTES) throw new Exception("PDF maior que 35 MB.");
            output.write(buffer, 0, read);
        }
        input.close();
        byte[] bytes = output.toByteArray();
        if (bytes.length < 4 || bytes[0] != '%' || bytes[1] != 'P' || bytes[2] != 'D' || bytes[3] != 'F') {
            throw new Exception("Arquivo recebido não parece ser PDF.");
        }
        pendingSharedPdfName = filename;
        pendingSharedPdfBase64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
        dispatchPendingSharedPdf();
    }

    private void dispatchPendingSharedPdf() {
        if (webView == null || pendingSharedPdfBase64 == null) return;
        try {
            JSONObject payload = new JSONObject();
            payload.put("ok", true);
            payload.put("filename", pendingSharedPdfName == null ? "iFlight_RosterReport.pdf" : pendingSharedPdfName);
            payload.put("sourceFileName", pendingSharedPdfName == null ? "iFlight_RosterReport.pdf" : pendingSharedPdfName);
            payload.put("dataBase64", pendingSharedPdfBase64);
            String js = "(function(){var payload=" + payload.toString() + ";window.__crewcheckPendingNativePdf=payload;window.dispatchEvent(new CustomEvent('crewcheck:native-pdf',{detail:payload}));})();";
            webView.evaluateJavascript(js, null);
            pendingSharedPdfBase64 = null;
            pendingSharedPdfName = null;
            Toast.makeText(this, "PDF recebido pelo CrewCheck. Importando escala...", Toast.LENGTH_LONG).show();
        } catch (Exception ignored) {}
    }

    private void injectIFlightAutomation(WebView view) {
        if (view == null || activeIFlightConfigJson == null) return;
        String js = """
(function(config){
try{
  var topBar=document.getElementById('__crewcheck_iflight_topbar');
  var banner=document.getElementById('__crewcheck_iflight_banner');
  function css(el, value){ try{ el.style.cssText=value; }catch(e){} }
  function ensureShell(){
    if(!topBar){
      topBar=document.createElement('div');
      topBar.id='__crewcheck_iflight_topbar';
      css(topBar,'position:fixed;left:0;right:0;top:0;z-index:2147483647;height:54px;display:flex;align-items:center;gap:10px;padding:7px 12px;box-sizing:border-box;background:linear-gradient(135deg,#03101f,#073154 58%,#0a5b78);color:#fff;font:700 12px Arial,Helvetica,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.35);border-bottom:1px solid rgba(125,211,252,.35)');
      topBar.innerHTML='<div style="width:34px;height:34px;border-radius:12px;background:linear-gradient(135deg,#22d3ee,#2563eb);display:flex;align-items:center;justify-content:center;font-size:18px">✈</div><div style="line-height:1.15;min-width:0;flex:1"><div style="font-size:14px;font-weight:900;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">CrewCheck · Portal iFlight</div><div id="__crewcheck_iflight_status" style="font-size:10px;color:#bae6fd;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">Login e MFA são manuais. O CrewCheck só auxilia no relatório PDF em LT.</div></div><button id="__crewcheck_menu_btn" style="border:1px solid rgba(255,255,255,.25);background:rgba(255,255,255,.12);color:#fff;border-radius:11px;padding:7px 9px;font-weight:900">Menu</button><button id="__crewcheck_auto_btn" style="border:1px solid rgba(125,211,252,.5);background:rgba(14,165,233,.22);color:#fff;border-radius:11px;padding:7px 9px;font-weight:900">Auto</button>';
      (document.body||document.documentElement).appendChild(topBar);
      var mb=document.getElementById('__crewcheck_menu_btn'); if(mb) mb.onclick=function(){openHamburger(true);};
      var ab=document.getElementById('__crewcheck_auto_btn'); if(ab) ab.onclick=function(){ state.attempts=0; state.run=false; state.menuAttempts=0; show('automação reativada. Abra/aguarde o Roster; login e MFA continuam manuais.'); step(); };
    }
    if(!banner){
      banner=document.createElement('div');
      banner.id='__crewcheck_iflight_banner';
      css(banner,'position:fixed;left:10px;right:10px;bottom:10px;z-index:2147483647;background:linear-gradient(135deg,#06101d,#0b2a45);color:white;border:1px solid rgba(14,165,233,.65);border-radius:16px;padding:11px 13px;font:700 12px Arial,Helvetica,sans-serif;box-shadow:0 14px 32px rgba(0,0,0,.42)');
      (document.body||document.documentElement).appendChild(banner);
    }
    if(document.body){
      document.body.style.paddingTop='56px';
      document.body.style.overflowX='auto';
      document.body.style.minWidth='1000px';
      document.body.style.backgroundColor=document.body.style.backgroundColor||'#f8fafc';
    }
  }
  function show(msg){
    ensureShell();
    var status=document.getElementById('__crewcheck_iflight_status');
    if(status) status.textContent=msg;
    if(banner) banner.textContent='CrewCheck · '+msg;
  }
  var meta=document.querySelector('meta[name=viewport]');
  if(!meta){ meta=document.createElement('meta'); meta.name='viewport'; (document.head||document.documentElement).appendChild(meta); }
  if(meta) meta.content='width=1180, initial-scale=0.72, minimum-scale=0.35, maximum-scale=2.5, user-scalable=yes';
  window.Notification=window.Notification||{};
  try{ Object.defineProperty(window.Notification,'permission',{get:function(){return 'denied';}}); window.Notification.requestPermission=function(cb){ if(cb) cb('denied'); return Promise.resolve('denied'); }; }catch(e){}
  ensureShell();
  show('você está dentro do CrewCheck. Use e-mail corporativo apenas no SSO oficial do iFlight.');
  if(!config||!config.autoClicks)return;

  window.__crewcheckAutoRosterState=window.__crewcheckAutoRosterState||{attempts:0,roster:false,report:false,run:false,menuAttempts:0,lt:false,lastText:''};
  var state=window.__crewcheckAutoRosterState;
  if(window.__crewcheckAutoRosterInterval) clearInterval(window.__crewcheckAutoRosterInterval);

  function visible(el){ if(!el) return false; var r=el.getBoundingClientRect(); var s=getComputedStyle(el); return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'&&s.opacity!=='0'; }
  function txt(el){ return String((el&& (el.innerText||el.textContent||el.value||el.title||el.getAttribute('aria-label')||el.getAttribute('alt'))) || '').replace(/\s+/g,' ').trim(); }
  function all(){ return Array.prototype.slice.call(document.querySelectorAll('a,button,input[type=button],input[type=submit],input[type=radio],label,span,div,td,li,[role=button],[onclick],svg,i')); }
  function safeClick(el){ if(!el) return false; try{el.scrollIntoView({block:'center',inline:'center'});}catch(e){} try{el.focus&&el.focus();}catch(e){} try{el.click();return true;}catch(e){} try{el.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:window}));el.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:window}));el.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}));return true;}catch(e){} return false; }
  function tapAt(x,y){ try{ var el=document.elementFromPoint(x,y); if(!el) return false; ['mousedown','mouseup','click'].forEach(function(n){el.dispatchEvent(new MouseEvent(n,{bubbles:true,cancelable:true,clientX:x,clientY:y,view:window}));}); return true; }catch(e){ return false; } }
  function clickText(patterns, exact){ var list=all(); for(var p=0;p<patterns.length;p++){ var pat=String(patterns[p]).toLowerCase(); for(var i=0;i<list.length;i++){ var el=list[i]; if(!visible(el)) continue; var t=txt(el).toLowerCase(); if(!t) continue; var ok=exact ? t===pat : t.indexOf(pat)>=0; if(ok&&!/send|logout|sign out|sair|create account/i.test(t)){ return safeClick(el); } } } return false; }
  function clickSelector(selectors){ for(var i=0;i<selectors.length;i++){ var list=[]; try{ list=Array.prototype.slice.call(document.querySelectorAll(selectors[i])); }catch(e){ list=[]; } for(var j=0;j<list.length;j++){ if(visible(list[j])) return safeClick(list[j]); } } return false; }
  function openHamburger(force){
    state.menuAttempts++;
    var clicked=clickSelector(['.navbar-toggle','.menu-toggle','.hamburger','[class*="hamburger"]','[class*="menu-toggle"]','[class*="navbar-toggle"]','button[aria-label*="menu" i]','button[title*="menu" i]','a[title*="menu" i]','.fa-bars','.glyphicon-menu-hamburger','[class*="fa-bars"]','[class*="bars"]']);
    if(!clicked){
      // iFlight mobile costuma deixar o hambúrguer no topo esquerdo. Tentamos coordenadas seguras.
      var points=[[128,28],[145,38],[112,42],[86,34],[160,54]];
      for(var i=0;i<points.length&&!clicked;i++) clicked=tapAt(points[i][0],points[i][1]);
    }
    if(clicked) show(force?'menu solicitado manualmente.':'abrindo menu do iFlight para localizar Roster...');
    return clicked;
  }
  function hasLoginOrMfa(){
    var body=((document.body&&document.body.innerText)||'').toLowerCase();
    var inputs=Array.prototype.slice.call(document.querySelectorAll('input'));
    var pwd=inputs.some(function(input){ var v=String((input.type||'')+' '+(input.name||'')+' '+(input.id||'')+' '+(input.placeholder||'')).toLowerCase(); return v.indexOf('password')>=0||v.indexOf('senha')>=0||v.indexOf('passcode')>=0||v.indexOf('otp')>=0||v.indexOf('code')>=0; });
    return pwd || /sign in|use your google account|senha|verifica|verification|2-step|two-step|mfa|authenticator|digite o código/.test(body);
  }
  function setVal(el,val){ if(!el||!val)return false; try{el.scrollIntoView({block:'center'});}catch(e){} el.focus&&el.focus(); var desc=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el),'value'); if(desc&&desc.set)desc.set.call(el,val); else el.value=val; ['input','change','keyup','blur'].forEach(function(n){el.dispatchEvent(new Event(n,{bubbles:true}));}); return true; }
  function labelInput(label){ var nodes=Array.prototype.slice.call(document.querySelectorAll('label,span,td,div')); for(var i=0;i<nodes.length;i++){ var n=nodes[i]; if(!visible(n))continue; var t=txt(n).toLowerCase(); if(t.indexOf(label.toLowerCase())<0)continue; var p=n.parentElement; for(var d=0;p&&d<6;d++,p=p.parentElement){ var input=p.querySelector('input:not([type=hidden])'); if(input&&visible(input))return input; } var next=n.nextElementSibling; while(next){ if(next.matches&&next.matches('input'))return next; var q=next.querySelector&&next.querySelector('input:not([type=hidden])'); if(q&&visible(q))return q; next=next.nextElementSibling; } } return null; }
  function fillDates(){ var changed=false; var inputs=Array.prototype.slice.call(document.querySelectorAll('input:not([type=hidden]):not([type=password])')).filter(visible); function attrHas(input,word){ var v=String((input.name||'')+' '+(input.id||'')+' '+(input.placeholder||'')+' '+(input.title||'')).toLowerCase(); return v.indexOf(word)>=0; } var from=labelInput('From Date')||inputs.find(function(i){return attrHas(i,'from');}); var to=labelInput('To Date')||inputs.find(function(i){return attrHas(i,'to');}); if(!from&&inputs.length>=1)from=inputs[0]; if(!to&&inputs.length>=2)to=inputs[1]; if(from&&from.value!==config.fromDate)changed=setVal(from,config.fromDate)||changed; if(to&&to.value!==config.toDate)changed=setVal(to,config.toDate)||changed; return changed; }
  function selectPdf(){ var changed=false; Array.prototype.slice.call(document.querySelectorAll('select')).forEach(function(sel){ if(!visible(sel))return; for(var i=0;i<sel.options.length;i++){ var o=sel.options[i]; var v=String(o.text+' '+o.value).toLowerCase(); if(v.indexOf('pdf')>=0){ if(sel.selectedIndex!==i){ sel.selectedIndex=i; sel.dispatchEvent(new Event('change',{bubbles:true})); changed=true; } break; } } }); if(!changed) changed=clickText(['pdf'], true); return changed; }
  function ensureLT(){ var changed=false; Array.prototype.slice.call(document.querySelectorAll('select')).forEach(function(sel){ if(!visible(sel))return; for(var i=0;i<sel.options.length;i++){ var o=sel.options[i]; var raw=String(o.text+' '+o.value).trim(); if(/^(lt|local time)$/i.test(raw)||/\bLT\b/.test(raw)){ if(sel.selectedIndex!==i){ sel.selectedIndex=i; sel.dispatchEvent(new Event('change',{bubbles:true})); changed=true; } state.lt=true; break; } } }); var list=all(); for(var i=0;i<list.length;i++){ var el=list[i]; if(!visible(el))continue; var t=txt(el); var attrs=String((el.id||'')+' '+(el.name||'')+' '+(el.value||'')+' '+(el.title||'')+' '+(el.getAttribute('aria-label')||'')).trim(); var isLt=/^(LT|Local Time)$/i.test(t)||/^(LT|Local Time)$/i.test(attrs)||(/\bLT\b/i.test(attrs)&&/(radio|button|toggle|time|zone|local)/i.test(attrs)); if(!isLt)continue; var active=/active|selected|checked|on/i.test(String(el.className||''))||el.getAttribute('aria-pressed')==='true'||el.checked===true; if(!active){ safeClick(el); changed=true; } state.lt=true; break; } return changed; }
  function setLegend(){ var box=document.querySelector('input[type=checkbox]'); if(box&&visible(box)&&!!config.includeLegend!==box.checked){ safeClick(box); return true; } return false; }
  function bodyText(){ return ((document.body&&document.body.innerText)||''); }
  function formReady(){ var body=bodyText().toLowerCase(); return body.indexOf('run')>=0 && (body.indexOf('pdf')>=0||document.querySelector('select')); }
  function visibleRoster(){ return /Roster Report|Roster Calendar|From Date|To Date|Select Format|Include Legend|Run/i.test(bodyText()); }
  function menuVisible(){ return /Home\s+Profile\s+Swap\s+Roster|Alert History|Airport|Roster Calendar|Roster Report/i.test(bodyText()); }

  function step(){
    ensureShell();
    state.attempts++;
    if(hasLoginOrMfa()){ show('aguardando login/MFA manual no portal oficial. Use o e-mail corporativo LATAM aqui.'); return; }
    if(state.run){ show('PDF solicitado. Aguardando download, nova janela ou compartilhamento com o CrewCheck...'); return; }
    var text=bodyText();
    if(!visibleRoster() && !menuVisible()){
      if(state.menuAttempts<12){ openHamburger(false); return; }
      show('tela do iFlight carregou sem conteúdo. Toque em Menu/Auto ou Recarregar; se abrir o Roster manualmente eu capturo o PDF.');
      return;
    }
    if(!state.roster && clickText(['Roster'], true)){ state.roster=true; show('Roster aberto. Procurando Roster Report...'); return; }
    if(!state.report && clickText(['Roster Report','Roster Calendar'], false)){ state.report=true; show('abrindo relatório/calendário da escala...'); return; }
    var did=!!(fillDates()|selectPdf()|ensureLT()|setLegend());
    if(did){ show('período, formato PDF e LT ajustados.'); return; }
    ensureLT();
    if(formReady() && clickText(['Run'], true)){ state.run=true; show('LT confirmado. Run acionado. Aguardando o PDF...'); return; }
    if(state.attempts<80){ show('aguardando Roster Report. Também posso capturar se você tocar manualmente em PDF > Run.'); }
    else { show('não encontrei o botão Run. Abra Roster > Roster Report, selecione PDF/LT e toque Run; eu capturo o PDF.'); }
  }
  window.__crewcheckAutoRosterInterval=setInterval(step,1600);
  setTimeout(step,450);
}catch(e){ console.log('CrewCheck iFlight automation',e); }
})(
""" + activeIFlightConfigJson + """
);
""";
        try {
            view.evaluateJavascript(js, null);
        } catch (Exception ignored) {}
    }

    private boolean isLikelyPdfUrl(String url, String contentDisposition, String mimeType) {
        String value = String.format(Locale.US, "%s %s %s", url == null ? "" : url, contentDisposition == null ? "" : contentDisposition, mimeType == null ? "" : mimeType).toLowerCase(Locale.US);
        return value.contains("application/pdf") || value.contains(".pdf") || value.contains("format=pdf") || value.contains("pdf") || value.contains("rosterreport");
    }

    private void fetchPdfAndReturn(final String downloadUrl, final String userAgent, final String contentDisposition, final String mimeType) {
        if (downloadUrl == null || downloadUrl.trim().isEmpty()) {
            finishIFlightWithError("URL de download vazia no iFlight.");
            return;
        }
        if (downloadUrl.startsWith("blob:")) {
            finishIFlightWithError("O iFlight gerou um PDF em blob interno. Salve o PDF manualmente e use Importar PDF manualmente.");
            return;
        }
        runOnUiThread(() -> {
            if (portalWebView != null) {
                try {
                    portalWebView.evaluateJavascript("(function(){var b=document.getElementById('__crewcheck_iflight_banner');if(b)b.textContent='CrewCheck: PDF detectado. Baixando e importando...';})();", null);
                } catch (Exception ignored) {}
            }
        });
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(downloadUrl);
                connection = (HttpURLConnection) url.openConnection();
                connection.setInstanceFollowRedirects(true);
                connection.setConnectTimeout(25000);
                connection.setReadTimeout(45000);
                if (userAgent != null && !userAgent.trim().isEmpty()) connection.setRequestProperty("User-Agent", userAgent);
                connection.setRequestProperty("Accept", "application/pdf,application/octet-stream,*/*");
                String cookies = CookieManager.getInstance().getCookie(downloadUrl);
                if (cookies != null && !cookies.trim().isEmpty()) connection.setRequestProperty("Cookie", cookies);

                int code = connection.getResponseCode();
                InputStream input = code >= 400 ? connection.getErrorStream() : connection.getInputStream();
                if (input == null) throw new Exception("Resposta sem conteúdo do iFlight (HTTP " + code + ").");
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                int total = 0;
                int read;
                while ((read = input.read(buffer)) != -1) {
                    total += read;
                    if (total > MAX_PDF_BYTES) throw new Exception("PDF maior que 35 MB. Baixe manualmente e importe pelo seletor.");
                    output.write(buffer, 0, read);
                }
                input.close();
                byte[] bytes = output.toByteArray();
                if (bytes.length < 4 || bytes[0] != '%' || bytes[1] != 'P' || bytes[2] != 'D' || bytes[3] != 'F') {
                    String responseType = connection.getContentType();
                    throw new Exception("O download capturado não parece ser PDF" + (responseType != null ? " (" + responseType + ")" : "") + ". Gere novamente em formato PDF no iFlight.");
                }
                String filename = URLUtil.guessFileName(downloadUrl, contentDisposition, mimeType);
                if (filename == null || !filename.toLowerCase(Locale.US).endsWith(".pdf")) filename = "iFlight_RosterReport.pdf";
                JSONObject payload = new JSONObject();
                payload.put("ok", true);
                payload.put("filename", filename);
                payload.put("sourceFileName", filename);
                payload.put("dataBase64", Base64.encodeToString(bytes, Base64.NO_WRAP));
                finishIFlightWithPayload(payload);
            } catch (Exception error) {
                finishIFlightWithError(error.getMessage() == null ? "Falha ao baixar PDF do iFlight." : error.getMessage());
            } finally {
                if (connection != null) connection.disconnect();
            }
        }).start();
    }

    private void finishIFlightWithError(String message) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("ok", false);
            payload.put("error", message == null ? "Importação iFlight interrompida." : message);
            finishIFlightWithPayload(payload);
        } catch (Exception ignored) {}
    }

    private void finishIFlightWithPayload(final JSONObject payload) {
        runOnUiThread(() -> {
            closingPortalWithResult = true;
            String requestId = activeIFlightRequestId;
            closePortalOnly();
            if (webView != null && requestId != null) {
                String js = "(function(){var cb=window.__crewcheckIflightCallbacks&&window.__crewcheckIflightCallbacks['" + escapeJs(requestId) + "'];if(cb)cb(" + payload.toString() + ");})();";
                try { webView.evaluateJavascript(js, null); } catch (Exception ignored) {}
            }
            activeIFlightRequestId = null;
            activeIFlightConfigJson = "{}";
            closingPortalWithResult = false;
        });
    }

    private String escapeJs(String value) {
        return value == null ? "" : value.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "");
    }

    private void closePortalOnly() {
        if (portalWebView != null) {
            try { portalWebView.stopLoading(); } catch (Exception ignored) {}
            try { portalWebView.loadUrl("about:blank"); } catch (Exception ignored) {}
            try { portalWebView.clearHistory(); } catch (Exception ignored) {}
            try { portalWebView.clearCache(true); } catch (Exception ignored) {}
            try { portalWebView.clearFormData(); } catch (Exception ignored) {}
            try { portalWebView.destroy(); } catch (Exception ignored) {}
            portalWebView = null;
        }
        if (portalContainer != null && rootLayout != null) {
            try { rootLayout.removeView(portalContainer); } catch (Exception ignored) {}
            portalContainer = null;
        }
        try {
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
        } catch (Exception ignored) {}
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingPdfIntent(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) return;
            Uri[] result = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) {
                    try {
                        final int takeFlags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        getContentResolver().takePersistableUriPermission(uri, takeFlags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception ignored) {}
                    result = new Uri[]{uri};
                }
            }
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (portalWebView != null) {
            if (portalWebView.canGoBack()) portalWebView.goBack();
            else finishIFlightWithError("Portal iFlight fechado pelo usuário antes do download do PDF.");
            return;
        }
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        closePortalOnly();
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
