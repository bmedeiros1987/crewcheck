# Hotfix 10.5.10 Durval — iFlight LT antes do Run

## Ajuste aplicado

- A automação do iFlight agora muda o seletor de fuso/horário de **UTC** para **LT** antes de acionar o botão **Run**.
- O fluxo continua respeitando LGPD: login, senha e MFA seguem manuais no portal original e não são salvos no banco, localStorage ou histórico.
- O botão **Send** continua bloqueado fora da automação para evitar envio indevido.
- O PDF gerado em LT é capturado/importado automaticamente quando a WebView ou o compartilhamento Android permite.

## Ordem da automação

1. Abrir iFlight em WebView desktop.
2. Aguardar login/MFA manual.
3. Abrir Roster.
4. Abrir Roster Report/Calendar.
5. Preencher From Date e To Date.
6. Selecionar **PDF**.
7. Mudar **UTC → LT**.
8. Clicar **Run**.
9. Capturar e importar o PDF.
