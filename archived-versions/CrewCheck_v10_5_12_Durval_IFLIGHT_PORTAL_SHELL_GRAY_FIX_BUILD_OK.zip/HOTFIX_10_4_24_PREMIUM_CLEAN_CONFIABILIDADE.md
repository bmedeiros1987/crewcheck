# CrewCheck 10.4.24 — Premium Clean, Perfil, Rotina e Confiabilidade

## Incluído

- Menu lateral funcional: o botão de três barras abre o menu lateral no celular/Android.
- Perfil clicável: tocar no nome do usuário abre Configurações, Perfil e Conta.
- Configurações centralizadas: perfil, conta, privacidade, exclusão de conta, rotina, Google Calendar e confiabilidade ficam no mesmo lugar.
- Rotina premium: mantém bloqueio de duplicidade por tipo, limite de rotinas e confirmação de sucesso.
- Central de Confiabilidade: administrador pode acompanhar regras de falsos positivos aprendidas e limpar o aprendizado local.
- Visual mobile/tablet mais limpo: menos poluição, cards mais compactos, melhor encaixe em celular/tablet e paisagem.
- Android wrapper atualizado para 10.4.24, mantendo app=1, NoActionBar e orientação vertical/horizontal.

## Regras de segurança mantidas

- Alertas técnicos de siglas não identificadas não aparecem para tripulante comum.
- Descanso de 13h para escala publicada normal; 12h para acionamento/extra/alteração.
- Removido falso positivo de pernoite maior que 20h.
- Aprendizado de falso positivo por administrador permanece ativo.
