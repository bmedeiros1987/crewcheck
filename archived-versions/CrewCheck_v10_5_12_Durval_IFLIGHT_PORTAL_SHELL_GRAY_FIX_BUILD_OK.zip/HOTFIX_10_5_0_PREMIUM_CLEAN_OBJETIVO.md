# CrewCheck 10.5.0 — Premium Clean Objetivo

- Nova tela inicial pós-upload: Resumo.
- Escala com cards mais limpos e detalhes clicáveis no mobile.
- Menu Alertas centralizando contadores e botões clicáveis.
- Menu Métricas com critérios de conformidade, repouso e carga.
- Glossário de siglas e conceitos.
- Configurações mais limpas com idioma seguindo o sistema.
- Rotina permanece centralizada em Configurações/Perfil.
- Removida redundância entre Nova escala e Import Roster.
- Privacidade movida para o final da página.
- Deduplicação reforçada para HSB/HSBE/ASB em acionamento/sobreaviso.
- Google Calendar mantém fluxo de reconexão e opção mais objetiva em Configurações.
