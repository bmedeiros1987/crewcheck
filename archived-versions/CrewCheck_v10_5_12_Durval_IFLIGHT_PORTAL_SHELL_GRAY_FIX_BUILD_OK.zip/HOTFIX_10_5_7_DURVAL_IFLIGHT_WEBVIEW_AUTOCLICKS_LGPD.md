# HOTFIX v10.5.7 Durval — iFlight WebView, cliques automáticos e LGPD integral

## Objetivo

Padronizar o layout premium e evoluir a integração iFlight para abrir o portal dentro do app Android, mantendo login e MFA manuais pelo usuário, com cliques automáticos somente após autenticação e captura do PDF da escala.

## Implementado

- Versão exibida como **CrewCheck v10.5.7 Durval**.
- Tela iFlight redesenhada com o mesmo padrão visual premium escuro.
- Remoção do fluxo visual que pedia usuário/senha corporativos no CrewCheck.
- Novo fluxo LGPD: o CrewCheck não coleta, não salva e não envia usuário, senha, MFA ou cookies corporativos ao banco.
- WebView Android nativa com bridge `window.CrewCheckIFlight.openPortalAndImport(url, options)`.
- Usuário faz login e MFA diretamente no portal iFlight original.
- Automação pós-login para clicar em **Roster**, **Roster Report/Calendar**, preencher **From Date/To Date**, selecionar **PDF** e clicar em **Run**.
- O botão **Send** não é clicado automaticamente para evitar envio indevido.
- Captura do download PDF via WebView/DownloadListener.
- Download do PDF com cookies da sessão temporária do portal apenas em memória.
- Importação automática do PDF para o parser CrewCheck.
- Limpeza da WebView do iFlight ao finalizar: cache, histórico, formulário e cookies.
- Fallback seguro: se o portal mudar layout ou gerar blob interno, o usuário pode baixar e importar o PDF manualmente.

## Limites conhecidos

- No navegador web comum, por segurança do browser, o CrewCheck não consegue clicar dentro de outro domínio nem ler automaticamente um arquivo baixado por ele. A automação completa depende do APK Android com WebView nativa.
- Se o iFlight alterar nomes de botões ou fluxo do relatório, o fallback manual permanece funcional.

## Validação

- `npm run check`
- `npm run build`
- `node --check server.mjs`
