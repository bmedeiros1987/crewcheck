CrewCheck v11.1.78 - Radar SSA Salvador HST oficial com portão, Infobip v3 + ElevenLabs MP3, moedas e regulamentação.
