# CrewCheck v10.8.138 — Promoção 6 meses transparente

## Objetivo

Deixar a página de assinatura clara antes do lançamento: o valor promocional mensal não é vitalício.

## Implementado

- Mensal promocional informado como válido por 6 meses para assinaturas feitas até 19/07.
- Após os 6 meses, o plano mensal passa ao valor regular de R$ 19,90/mês.
- Anual promocional informado como desconto no primeiro ano; renovação regular de R$ 179,90/ano, salvo nova promoção.
- Card de assinatura atualizado com aviso dentro do próprio card.
- Política de preço retornada pelo backend com `monthlyPromoMonths`, valor regular pós-promoção e regras em texto.
- Checkout registra metadados da promoção no log de auditoria e descrição da assinatura Asaas.

## Android

- versionName: `10.8.138`
- versionCode: `10933`

## Validação

- `node --check server.mjs`
- `npm run check`
- `npm run build`
