# CrewCheck v10.8.32 — Menu Premium + Diárias Reliable

Correções principais:

- Remove a sensação de menu duplicado em Configurações: os atalhos internos viram abas premium no topo da tela, enquanto o rodapé fica apenas como navegação global.
- Escala mobile com data horizontal e mais estável: número do mês/dia da semana não deve mais cortar ou ficar escondido.
- Diárias agora são exibidas por atividade, não mais repetidas por dia inteiro em todos os cards.
- Sobreaviso puro não mostra diária.
- Café, almoço e jantar aparecem somente se a atividade elegível cruzar a janela real trabalhada.
- Ceia aparece somente para voo ou reserva ativos entre 00:00 e 01:00; reserva/voo encerrando antes de 00:00 não conta.
- Blocos de diárias ficam mais limpos e explicam a regra quando exibidos.
