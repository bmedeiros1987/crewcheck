# CrewCheck v10.8.38 — Radar Push Hub Privado

## Objetivo
Transformar o Radar de Voos em um hub privado do backend: o app não mostra Kayak, Google Flights, FlightStats ou qualquer site externo para o usuário. O backend consulta fontes configuradas, normaliza os dados e entrega somente o resultado confiável no padrão “Radar CrewCheck”.

## O que mudou
- Criado endpoint `POST /api/radar/private-batch-status` para consulta em lote de voos da escala.
- O endpoint `GET /api/radar/private-status` agora aceita `flight`, `flightNumber`, `number` e `designator`.
- Adicionados provedores privados opcionais:
  - Cirium/FlightStats: `FLIGHTSTATS_APP_ID` e `FLIGHTSTATS_APP_KEY`.
  - AeroDataBox: `AERODATABOX_API_KEY` ou `AERODATABOX_RAPIDAPI_KEY`.
  - FlightAware AeroAPI: `FLIGHTAWARE_AEROAPI_KEY`.
  - Amadeus On-Demand: `AMADEUS_CLIENT_ID` e `AMADEUS_CLIENT_SECRET`.
  - Proxy próprio: `FLIGHT_STATUS_ENDPOINT`.
- O Dashboard passa a buscar status/portão/terminal do próximo voo a cada 4 minutos.
- Quando o portão, terminal, horário previsto ou status muda, o app gera alerta local.
- O app agenda notificação de próximo voo aproximadamente 90 minutos antes da apresentação.
- As fontes externas continuam privadas: o front recebe `sourceLabel: "Radar CrewCheck"` e não recebe links externos.

## Variáveis recomendadas no Render
```env
FLIGHTSTATS_APP_ID=
FLIGHTSTATS_APP_KEY=
AERODATABOX_API_KEY=
FLIGHTAWARE_AEROAPI_KEY=
AVIATIONSTACK_ACCESS_KEY=
AMADEUS_CLIENT_ID=
AMADEUS_CLIENT_SECRET=
```

## Validação
Rode:

```bash
npm run validate:10838
node --check server.mjs
```
