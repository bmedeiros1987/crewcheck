# CrewCheck v10.8.40 — Android Radar, Saída Inteligente, Diárias, Chefia e Tripulação

Hotfix focada em confiança operacional no Android e nas métricas financeiras.

## Android
- Corrige a ponte nativa `CrewCheckNative`/`CrewCheckPremium` para que o web app consiga solicitar permissões reais do Android.
- Botão de localização agora chama o bridge nativo antes do `navigator.geolocation`.
- Agendamento de notificações usa fallback nativo unificado para escala, radar e saída inteligente.
- Atualiza Android `versionCode 10840` e `versionName 10.8.40`.

## Radar e Saída Inteligente
- O Radar da escala passa a consultar o endpoint privado `/api/radar/private-status` também nos detalhes do voo.
- Saída Inteligente aciona permissão runtime de localização no Android antes de calcular a rota.
- Notificações de próximo voo, alteração de status/portão/terminal e hora de sair passam pelo bridge nativo.

## Diárias
- Reserva ASB/RES não soma mais uma diária para cada janela principal cruzada.
- Regra aplicada: reserva normalmente conta 1 refeição principal; conta 2 apenas quando cruza café da manhã + uma principal.
- Sobreaviso HSB/HSBE continua sem diária.
- Detalhe do card de escala mostra a mesma regra do financeiro.

## Gratificação de chefe CCM
- Salário passa a contar gratificação de chefe quando o usuário é identificado como primeiro CCM da tripulação.
- Mantém regra: se houver outro CCM antes do usuário, não soma a gratificação.
- Usa tripulação detectada, `ccmLead` e comparação robusta de nomes.

## Tripulação na escala
- Parser do CrewRosterReport passa a ler seção `Tripulações`, `Tripulacao`, `Crew List`, `Crew Complement` ou `Crew Members`.
- Cada voo recebe lista de tripulantes, chefe efetivo e status de gratificação CCM.
- A tela de escala já possui bloco `Tripulação detectada`; agora passa a receber dados também nesse formato de PDF.

## Validação
- Novo comando: `npm run validate:10840`.
- Valida versão, Android wrapper, bridge nativo, Radar privado, Saída Inteligente, regra de diárias, gratificação CCM e parser de tripulação.
