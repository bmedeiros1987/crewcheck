import fs from 'node:fs';

const read = (file) => fs.readFileSync(file, 'utf8');
const checks = [];
function check(condition, message) {
  checks.push({ ok: Boolean(condition), message });
  if (!condition) process.exitCode = 1;
}

const pkg = JSON.parse(read('package.json'));
const server = read('server.mjs');
const home = read('client/src/pages/Home.tsx');
const runtime = read('client/src/lib/crewcheckPremiumRuntime.ts');
const dash = read('client/src/components/premium/Dashboard.tsx');
const manifest = read('android-wrapper/app/src/main/AndroidManifest.xml');

check(pkg.version === '10.8.38', 'package.json atualizado para 10.8.38');
check(server.includes('Radar Push Hub privado'), 'server.mjs contém Radar Push Hub privado');
check(server.includes('/api/radar/private-batch-status'), 'endpoint batch privado do radar criado');
check(server.includes('fetchAeroDataBoxFlightStatus'), 'provedor AeroDataBox no backend');
check(server.includes('fetchFlightAwareAeroApiStatus'), 'provedor FlightAware AeroAPI no backend');
check(server.includes('fetchFlightStatsSingleStatus'), 'status individual Cirium/FlightStats no backend');
check(server.includes('radarProviderStatus'), 'diagnóstico privado de provedores disponível');
check(home.includes('RadarPrivateStatus'), 'Home consulta status do próximo voo');
check(home.includes('/api/radar/private-status'), 'Home usa endpoint privado para próximo voo');
check(home.includes('crewcheck_radar_scheduled_'), 'Home agenda notificação de próximo voo');
check(dash.includes('flightNumber?: string'), 'Dashboard exibe número do voo no cartão premium');
check(runtime.includes("version: '10.8.38'"), 'runtime premium atualizado para 10.8.38');
check(runtime.includes('flightNumber: flight'), 'runtime envia flightNumber ao backend');
check(manifest.includes('android.permission.POST_NOTIFICATIONS'), 'Android tem permissão POST_NOTIFICATIONS');
check(manifest.includes('android.permission.ACCESS_FINE_LOCATION'), 'Android tem permissão de localização');

for (const item of checks) console.log(`${item.ok ? '✓' : '✗'} ${item.message}`);
if (process.exitCode) process.exit(process.exitCode);
