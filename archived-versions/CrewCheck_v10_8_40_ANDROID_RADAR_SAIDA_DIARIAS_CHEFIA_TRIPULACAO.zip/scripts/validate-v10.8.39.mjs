import fs from 'node:fs';

const read = (file) => fs.readFileSync(file, 'utf8');
const check = (condition, message) => {
  if (!condition) {
    console.error(`✗ ${message}`);
    process.exitCode = 1;
  } else {
    console.log(`✓ ${message}`);
  }
};

const pkg = JSON.parse(read('package.json'));
const lock = JSON.parse(read('package-lock.json'));
const home = read('client/src/pages/Home.tsx');
const results = read('client/src/pages/Results.tsx');
const aims = read('client/src/lib/aimsParser.ts');
const normalizer = read('client/src/lib/rosterNormalizer.ts');
const runtime = read('client/src/lib/crewcheckPremiumRuntime.ts');
const gradle = read('android-wrapper/app/build.gradle');

check(pkg.version === '10.8.39', 'package.json atualizado para 10.8.39');
check(lock.version === '10.8.39' && lock.packages?.['']?.version === '10.8.39', 'package-lock atualizado para 10.8.39');
check(pkg.scripts?.['validate:10839'] === 'node scripts/validate-v10.8.39.mjs', 'script validate:10839 registrado');
check(home.includes("const APP_VERSION = '10.8.39'"), 'Home.tsx mostra versão 10.8.39');
check(runtime.includes("version: '10.8.39'"), 'runtime premium atualizado para 10.8.39');
check(gradle.includes('versionCode 10839') && gradle.includes("versionName '10.8.39'"), 'Android versionCode/versionName atualizados');
check(aims.includes('sliceOwnActivityLines(lines, \'ASB\')') && aims.includes('addClockMinutes(startTime, 6 * 60)'), 'parser ASB isola bloco próprio e estima 6h quando fim não vem');
check(normalizer.includes('sem misturar HSB com ASB') && normalizer.includes('Reserva sem fim legível usa 6h padrão'), 'normalizador evita ASB herdar HSB e não encerra reserva pelo próximo card');
check(home.includes('inferDashboardFlightPresentationTime') && home.includes('addMinutesToDisplayTime(departure, -60)'), 'Dashboard calcula apresentação 1h antes da decolagem quando report não é confiável');
check(results.includes('presentationTimeForFlightDay') && results.includes('Decolagem ${first.departureTime}'), 'Tela de escala mostra apresentação e decolagem do voo');
check(home.includes('normalmente 1 diária; 2 quando também cruza café da manhã'), 'diárias explicam regra de reserva uma/duas janelas');
check(!results.includes('\x08'), 'Results sem caracteres backspace em regex');

if (process.exitCode) process.exit(1);
