import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
let failures = 0;
function read(file){ return fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : ''; }
function walk(dir){ if(!fs.existsSync(dir)) return []; return fs.readdirSync(dir).flatMap((name)=>{ if(['.git','node_modules','dist','build','.gradle'].includes(name)) return []; const p=path.join(dir,name); const st=fs.statSync(p); return st.isDirectory()?walk(p):[p]; }); }
function check(ok,msg){ if(ok) console.log('✓',msg); else { console.error('✗',msg); failures += 1; } }
const pkg = JSON.parse(read(path.join(root,'package.json')) || '{}');
check(pkg.version === '10.8.37', 'package.json atualizado para 10.8.37');
const home = read(path.join(root,'client/src/pages/Home.tsx'));
check(home.includes('const key = `${segment.date}-${window.type}`;'), 'diárias deduplicadas por data + janela, não por card');
check(home.includes("if (code.includes('ASB')) return addMinutesToDisplayTime(start, 360);"), 'ASB/reserva sem fim usa 6h a partir do início');
check(home.includes('Ativar notificações'), 'botão de notificação visível no app');
const server = read(path.join(root,'server.mjs'));
check(server.includes("/api/radar/private-status"), 'endpoint privado de status de voo instalado');
check(/function buildRadarExternalLinks[\s\S]*return \[\];/.test(server), 'radar não entrega links externos ao usuário');
const clientText = walk(path.join(root,'client/src')).filter(f=>/\.(ts|tsx|js|jsx|css|html)$/.test(f)).map(read).join('\n');
check(!/kayak\.com\.br\/tracker/i.test(clientText), 'client sem link Kayak visível');
check(!/flightstats\.com\/v2\/flight-tracker/i.test(clientText), 'client sem link FlightStats visível');
check(!/google\.[^\s"']*\/travel\/flights/i.test(clientText), 'client sem Google Flights visível');
const manifest = read(path.join(root,'android-wrapper/app/src/main/AndroidManifest.xml'));
check(manifest.includes('POST_NOTIFICATIONS'), 'Android POST_NOTIFICATIONS declarado');
check(manifest.includes('ACCESS_FINE_LOCATION') && manifest.includes('ACCESS_COARSE_LOCATION'), 'Android localização declarada');
check(manifest.includes('CrewCheckNotificationReceiver'), 'receiver de notificação declarado');
const main = read(path.join(root,'android-wrapper/app/src/main/java/com/crewcheck/app/MainActivity.java'));
check(main.includes('requestLocation()'), 'ponte nativa requestLocation disponível');
check(main.includes('scheduleNotification'), 'ponte nativa scheduleNotification disponível');
if (failures) process.exit(1);
