import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const pkg = JSON.parse(read('package.json'));
const lock = JSON.parse(read('package-lock.json'));
const home = read('client/src/pages/Home.tsx');
const results = read('client/src/pages/Results.tsx');
const parser = read('client/src/lib/pdfParser.ts');
const runtime = read('client/src/lib/crewcheckPremiumRuntime.ts');
const auth = read('client/src/pages/AuthPage.tsx');
const app = read('client/src/App.tsx');
const manifest = read('client/public/manifest.json');
const gradle = read('android-wrapper/app/build.gradle');
const mainActivity = read('android-wrapper/app/src/main/java/com/crewcheck/app/MainActivity.java');
const server = read('server.mjs');

const checks = [];
function check(condition, message) {
  checks.push({ ok: Boolean(condition), message });
}

check(pkg.version === '10.8.40', 'package.json atualizado para 10.8.40');
check(lock.version === '10.8.40' && lock.packages?.['']?.version === '10.8.40', 'package-lock atualizado para 10.8.40');
check(pkg.scripts?.['validate:10840'] === 'node scripts/validate-v10.8.40.mjs', 'script validate:10840 registrado');
check(home.includes("const APP_VERSION = '10.8.40'"), 'Home.tsx mostra versão 10.8.40');
check(auth.includes("const APP_VERSION = '10.8.40'"), 'AuthPage mostra versão 10.8.40');
check(runtime.includes("version: '10.8.40'"), 'runtime premium atualizado para 10.8.40');
check(app.includes("crewcheck_last_loaded_version', '10.8.40'"), 'App.tsx força cache/versão 10.8.40');
check(manifest.includes('"version": "10.8.40"'), 'manifest PWA atualizado para 10.8.40');
check(gradle.includes('versionCode 10840') && gradle.includes("versionName '10.8.40'"), 'Android versionCode/versionName atualizados');

check(mainActivity.includes('window.CrewCheckPremium=window.CrewCheckNative'), 'Android bridge expõe CrewCheckPremium como alias nativo');
check(mainActivity.includes('requestLocation:function()') && mainActivity.includes('requestNotifications:function()') && mainActivity.includes('scheduleNotification:function'), 'Android bridge tem localização, notificações e agendamento');
check(home.includes('function requestCrewCheckLocationPermission') && home.includes('requestCrewCheckLocationPermission();'), 'Saída Inteligente solicita permissão nativa de localização');
check(home.includes('function scheduleCrewCheckNotification') && home.includes('scheduleCrewCheckNotification('), 'Agendamento usa bridge unificado');

check(server.includes("/api/radar/private-status"), 'Backend possui endpoint privado de status de voo');
check(server.includes("/api/airport-board"), 'Backend possui endpoint de painel/radar de aeroporto');
check(server.includes("/api/smart-departure"), 'Backend possui endpoint de saída inteligente');
check(results.includes('/api/radar/private-status'), 'Detalhes do voo usam Radar privado, não endpoint antigo');

check(home.includes('function computeReservePerDiemEntries') && home.includes('máximo 1 refeição principal por reserva'), 'Diárias de ASB/RES travadas em 1 principal + café quando houver');
check(results.includes('if (kind === \'reserve\')') && results.includes('mainMeal'), 'Card da escala exibe regra de diária de reserva consistente');
check(home.includes('function shouldCountCcmChiefBonusForFinance') && home.includes('firstCcm') && home.includes('leg.ccmLead'), 'Salário conta gratificação de chefe pelo primeiro CCM detectado');
check(parser.includes('parseGenericTripulationRecords') && parser.includes('applyGenericTripulationRecordsToDays'), 'Parser lê e aplica tripulação genérica do CrewRosterReport');
check(parser.includes('Tripula(?:ç|c)[oõ]es') && parser.includes('Crew\\s+List'), 'Parser procura seção de tripulação em PT/EN');
check(parser.includes("ccmBonusStatus: FlightLeg['ccmBonusStatus']"), 'Parser define status de gratificação CCM no voo');

const failed = checks.filter((item) => !item.ok);
for (const item of checks) console.log(`${item.ok ? '✅' : '❌'} ${item.message}`);
if (failed.length) {
  console.error(`\nFalha na validação v10.8.40: ${failed.length} item(ns).`);
  process.exit(1);
}
console.log('\nCrewCheck v10.8.40 validado com sucesso.');
