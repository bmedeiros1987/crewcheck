# CrewCheck v10.8.39 — Apresentação, ASB e Diárias Confiáveis

## Correções aplicadas

### 1. Horário de apresentação antes da decolagem
- O card de voo agora exibe a apresentação como início da programação.
- Quando o PDF/iFlight não traz `dutyReport` confiável, o CrewCheck calcula apresentação **1h antes da decolagem**.
- A tela de escala mostra também a decolagem no subtítulo do card: `Apres. HH:MM · Decolagem HH:MM`.
- O Dashboard usa esse horário para próxima programação, contagem regressiva, hora de sair e notificações.

### 2. ASB não herda mais horário de HSB
- O parser AIMS agora isola o bloco do código ASB/RES.
- Horários de HSB/HSBE anteriores no mesmo dia deixam de contaminar a reserva.
- O normalizador corrige também escalas já salvas: se o início da ASB veio do HSB, ele tenta recuperar o primeiro horário do bloco ASB.

### 3. Reserva sem fim legível = 6h
- Quando a reserva ASB/RES vem com horário repetido ou sem fim confiável, o CrewCheck considera 6h a partir do início.
- Exemplo: ASB 13:55 sem fim confiável vira 13:55–19:55.
- O fim da reserva não é mais inferido pelo início de DO/folga ou outro card seguinte.

### 4. Diárias de reserva mais confiáveis
- Sobreaviso puro continua sem diária.
- Reserva ASB/RES passa a contar somente as janelas cruzadas pela própria reserva.
- Regra operacional no app: normalmente 1 diária; 2 quando a janela também cruza café da manhã.
- Mantida deduplicação por data + tipo de refeição para evitar contagem duplicada no mesmo dia.

### 5. Validação
- Novo comando: `npm run validate:10839`.
- Valida versão, Android versionCode, isolamento ASB/HSB, apresentação 1h antes e textos de confiança das diárias.

## Comandos validados

```bash
npm run validate:10839
node --check server.mjs
```
