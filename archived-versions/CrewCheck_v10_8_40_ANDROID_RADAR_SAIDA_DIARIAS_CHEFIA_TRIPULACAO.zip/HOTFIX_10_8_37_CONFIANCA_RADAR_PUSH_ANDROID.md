# CrewCheck v10.8.37 — Confiança, Radar privado e Push Android

## Correções aplicadas

- Diárias com base principal de **R$ 109,44** e café de **R$ 27,36**.
- Teste de referência: **5 refeições principais = R$ 547,20**.
- Deduplicação por **data + janela de refeição** para não contar C32F + voo duas vezes no mesmo jantar.
- ASB/reserva sem horário de fim lido passa a usar **6h a partir do início**.
- Descanso de **13h** somente para escala originalmente publicada.
- Acionamento, voo extra, PS, alteração ou reprogramação usam **12h**.
- Radar de voos sem links de Kayak, Google Flights ou FlightStats para usuário final.
- Endpoint interno `/api/radar/private-status` para status, portão e terminal quando houver provedor configurado.
- Android com ponte nativa de localização e notificações locais.
- Botões para ativar notificações e agendar hora de sair.

## Variáveis opcionais no Render

- `AVIATIONSTACK_ACCESS_KEY`
- `FLIGHTSTATS_APP_ID` e `FLIGHTSTATS_APP_KEY` ou `CIRIUM_APP_ID` e `CIRIUM_APP_KEY`
- `AMADEUS_CLIENT_ID` e `AMADEUS_CLIENT_SECRET`
- `GOOGLE_MAPS_API_KEY` para saída inteligente

## Validação

```bash
npm run validate:10837
npm run build
```
