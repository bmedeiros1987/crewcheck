# CrewCheck v10.8.100 — Radar MultiFonte integrado

## Integração
- Incorpora o Radar MultiFonte corrigido no build atual do CrewCheck.
- Mantém os ajustes mais recentes da v10.8.99.
- Expande fontes oficiais públicas do radar para:
  - BSB Aero
  - GRU Airport
  - Aena Congonhas
  - Aena Recife
  - Aena Maceió
  - Aena João Pessoa
  - Aena Aracaju
  - Aena Campina Grande
  - Aena Juazeiro do Norte
  - Salvador Bahia Airport
  - Zurich VIX
  - Zurich FLN
- Mantém fallback premium sem API:
  - dados da escala importada;
  - status previsto;
  - Radar CrewCheck;
  - painel de aeroporto quando fonte pública responder.
- Adiciona diagnóstico `/api/radar-health`.

## Versão
- App: 10.8.100
- Android: versionCode 10900 / versionName 10.8.100
