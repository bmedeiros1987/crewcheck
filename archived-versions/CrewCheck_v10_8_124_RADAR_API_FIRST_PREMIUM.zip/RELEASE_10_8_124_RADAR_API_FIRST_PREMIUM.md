# CrewCheck v10.8.124 — Radar API-first Premium

Correção focada no Radar de Voos:

- Radar agora consulta API real prioritariamente por padrão.
- Cache compartilhado continua ativo, mas cache vazio não bloqueia nova consulta.
- Monitor oficial passa a ser fallback, não a fonte principal.
- `Atualizar agora` força nova consulta API e salva para todos.
- Vivo de Extra passa a chamar o radar com `apiFirst=1` para puxar portão, terminal e status.
- Resultado vazio não é persistido por padrão, evitando “radar morto” por cache sem voos.
- Provider order configurável via `AIRPORT_BOARD_API_PROVIDER_ORDER`.

Android: `versionName 10.8.124`, `versionCode 10921`.
