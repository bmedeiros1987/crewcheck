# CrewCheck v10.8.123 — Apple Watch + Planos Premium

## Implementado

- Nova rota `/apple-watch` para uso compacto no Apple Watch, mantendo a experiência `/watch` para Samsung Galaxy Watch / Wear OS.
- Rota alternativa `/watch/apple` para abrir a versão Apple Watch.
- Tela do relógio sem menu inferior, com foco total na escala compacta.
- Ajustes visuais específicos para telas muito pequenas do Apple Watch.
- Tabela comparativa de assinatura em Configurações > Assinatura.
- Comparação clara entre Básico gratuito, Premium mensal e Premium anual.
- Explicação mais intuitiva do teste grátis, cancelamento, custos operacionais e diferença entre mensal e anual.
- Plano especial mantém nome público Premium Unlimited, sem termos como vitalício/vitalícia.

## Mantido das versões anteriores

- Galaxy Watch / Wear OS em `/watch`.
- Radar com cache compartilhado no banco.
- Vivo de Extra usando radar/cache para portão, terminal e status.
- SerpAPI + SearchAPI fallback.
- Plano por diária de referência.
- Asaas com CPF no checkout.
- Teste grátis sem cartão.
- Validação de e-mail e Turnstile.
- Base virtual no cadastro e perfil.
- Menu Android premium.

## Validação

- `node --check server.mjs`
- `npm run check`
- `npm run build`

Android: `versionName 10.8.123`, `versionCode 10920`.
