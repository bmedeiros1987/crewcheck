# CrewCheck v10.8.101 — Extra High Radar + Destino Original

## Correção Extra High
- Mantém todas as correções da v10.8.100.
- Reforça a Próxima Programação para nunca exibir rota circular incorreta como BSB → BSB quando houver destino original recuperável.
- O Dashboard agora corrige defensivamente a rota exibida usando origem/destino normalizados.
- O Radar MultiFonte ganhou fallback extra:
  - se provedor/API/painel público não retornar linha confiável, exibe dado previsto pela escala;
  - endpoint /api/airport-board retorna fallback de escala quando possível;
  - endpoint /api/radar-health reforçado para diagnóstico.
- Sem token embutido no ZIP.

## Validação
- npm run build
- npm run check
- node --check server.mjs

## Android
- versionCode 108101
- versionName 10.8.101
