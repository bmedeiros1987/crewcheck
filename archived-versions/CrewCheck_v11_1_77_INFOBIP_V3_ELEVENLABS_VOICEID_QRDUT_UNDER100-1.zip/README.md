CrewCheck v11.1.77 - Infobip v3 com áudio MP3 ElevenLabs

Hotfix do Despertador Premium: Infobip continua como provedor da ligação, mas o áudio em português é gerado por ElevenLabs usando voice id padrão Qrdut83w0Cr152Yb4Xn3 e entregue como MP3 público para a Infobip v3. Endpoint legado v1 permanece bloqueado. Mantém hotfix do radar/cockpit, moedas e regulamentação.
