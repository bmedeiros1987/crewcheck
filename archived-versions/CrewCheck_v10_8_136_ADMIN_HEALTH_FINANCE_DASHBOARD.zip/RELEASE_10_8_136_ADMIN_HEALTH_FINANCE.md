# CrewCheck v10.8.136 — Admin Health & Finance Dashboard

## Destaques

- Novo dashboard administrativo consolidando saúde do sistema, APIs, e-mail, Radar, cobrança e gestão operacional.
- Novo endpoint admin: `/api/admin/system-dashboard`.
- Dashboard financeiro Asaas ampliado com previsão de MRR, ARR, custos configurados, taxas e lucro mensal estimado.
- Logos das companhias aéreas aumentadas nos cards de Radar e Vivo de Extra para ficar mais próximo do impacto visual da GOL.
- Menu admin agora expõe o Dashboard Admin com saúde, financeiro, usuários e gerenciamento.
- Diagnóstico continua restrito ao admin e não expõe segredos, tokens ou chaves.

## Endpoints admin

- `GET /api/admin/system-dashboard`
- `GET /api/admin/billing/dashboard`
- `GET /api/admin/usage-summary`
- `GET /api/admin/email-health`
- `GET /api/radar-health?airport=BSB&type=departure`

## Variáveis para lucro real estimado

Configure no Render para o painel calcular margem com mais precisão:

```bash
CREWCHECK_COST_RENDER_MONTHLY=0
CREWCHECK_COST_FLIGHT_DATA_MONTHLY=0
CREWCHECK_COST_EMAIL_MONTHLY=0
CREWCHECK_COST_MAPS_MONTHLY=0
CREWCHECK_COST_DOMAIN_MONTHLY=0
CREWCHECK_COST_OTHER_MONTHLY=0
CREWCHECK_ASAAS_FEE_PERCENT=0
CREWCHECK_ASAAS_FIXED_FEE=0
```

O cálculo usa assinaturas ativas do banco e os custos informados acima.

## Android

- versionName: `10.8.136`
- versionCode: `10931`
