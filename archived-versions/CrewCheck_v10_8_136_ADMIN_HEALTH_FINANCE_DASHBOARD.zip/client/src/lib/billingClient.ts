import { authFetch } from './authClient';

export type BillingPlanId = 'free' | 'premium_monthly' | 'premium_annual' | 'premium_lifetime' | 'admin';

export interface BillingPlan {
 id: BillingPlanId | string;
 name: string;
 cycle: string;
 value: number;
 currency: string;
 description: string;
 reference?: string;
 diariaReferenceValue?: number;
 annualDiscountPercent?: number;
 notice?: string;
 originalValue?: number;
 promoValue?: number;
 promoActive?: boolean;
 promoEndsAt?: string;
}

export interface BillingPricePolicy {
 diariaReferenceValue?: number;
 monthlyValue?: number;
 annualValue?: number;
 monthlyOriginalValue?: number;
 annualOriginalValue?: number;
 monthlyPromoValue?: number;
 annualPromoValue?: number;
 promoActive?: boolean;
 promoEndsAt?: string;
 annualDiscountPercent?: number;
 notice?: string;
 monthlyRule?: string;
 annualRule?: string;
}

export interface BillingStatus {
 ok: boolean;
 plan: BillingPlan;
 status: string;
 premiumAccess: boolean;
 trialEligible: boolean;
 trialDays?: number;
 trialExpiresAt?: string | null;
 premiumExpiresAt?: string | null;
 billingCycle?: string | null;
 cancelAtPeriodEnd?: boolean;
 asaasConfigured?: boolean;
 asaasSubscriptionId?: string | null;
 plans?: BillingPlan[];
 pricePolicy?: BillingPricePolicy;
 misusePolicy?: string;
 message?: string;
}

export interface BillingCheckoutResponse {
 ok: boolean;
 plan: BillingPlan;
 subscriptionId?: string;
 checkoutUrl?: string | null;
 billing?: BillingStatus;
 message?: string;
}

export function formatBillingValue(value?: number | null, currency = 'BRL'): string {
 const number = Number(value || 0);
 if (!Number.isFinite(number) || number <= 0) return 'Grátis';
 return new Intl.NumberFormat('pt-BR', { style: 'currency', currency }).format(number);
}

export function billingStatusLabel(status?: string): string {
 const normalized = String(status || 'free').toLowerCase();
 if (normalized === 'lifetime') return 'Premium Unlimited';
 if (normalized === 'trialing') return 'Teste grátis ativo';
 if (normalized === 'active' || normalized === 'paid' || normalized === 'received') return 'Premium ativo';
 if (normalized === 'pending') return 'Pagamento pendente';
 if (normalized === 'past_due') return 'Pagamento em atraso';
 if (normalized === 'canceled') return 'Cancelado';
 if (normalized === 'trial_expired') return 'Teste encerrado';
 return 'Básico gratuito';
}

export async function getBillingStatus(): Promise<BillingStatus> {
 return authFetch<BillingStatus>('/api/billing/status');
}

export async function startPremiumTrial(): Promise<BillingStatus> {
 return authFetch<BillingStatus>('/api/billing/start-trial', { method: 'POST', body: '{}' });
}

export async function createBillingCheckout(
 planId: 'premium_monthly' | 'premium_annual',
 billingType: 'UNDEFINED' | 'PIX' | 'BOLETO' | 'CREDIT_CARD' = 'UNDEFINED',
 customer?: { cpfCnpj?: string },
): Promise<BillingCheckoutResponse> {
 return authFetch<BillingCheckoutResponse>('/api/billing/checkout', {
  method: 'POST',
  body: JSON.stringify({ planId, billingType, ...(customer || {}) }),
 });
}

export async function cancelBillingSubscription(): Promise<BillingStatus> {
 return authFetch<BillingStatus>('/api/billing/cancel', { method: 'POST', body: '{}' });
}
