import React, { useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  CalendarDays,
  CheckCircle2,
  ChevronLeft,
  DownloadCloud,
  ExternalLink,
  FileText,
  Globe,
  Loader2,
  Lock,
  RefreshCw,
  ShieldCheck,
  Upload,
} from 'lucide-react';
import { toast } from 'sonner';
import type { CrewRoster } from '@/lib/pdfParser';

interface IFlightIntegrationViewProps {
  onBack: () => void;
  onSuccess: () => void;
  onFileUpload?: (file: File) => Promise<void>;
  onRosterImport?: (roster: CrewRoster, sourceFileName?: string) => Promise<void>;
}

type IFlightStatus = 'idle' | 'portal' | 'fetching' | 'success' | 'error';

type IFlightPortalOptions = {
  autoClicks: boolean;
  keepAuthorizedSession: boolean;
  silentPremiumPull: boolean;
  autoResumeAfterLogin: boolean;
  universalPdfCapture: boolean;
  maskPortalUntilUserAction: boolean;
  noExternalApps: boolean;
  credentialEntry: 'official_iflight_page_only';
  mfaEntry: 'official_iflight_page_only';
  calendarStrategy: 'calendar_month_first';
  collectCrew: boolean;
  collectPairing: boolean;
  collectRosterDetails: boolean;
  collectDutyTimes: boolean;
  collectCrewList: boolean;
  collectAircraftAndTraining: boolean;
  maxAutomationMinutes: number;
  fromDate: string;
  toDate: string;
  periodMonth: string;
  periodYear: string;
  format: 'pdf' | 'calendar_first';
  includeLegend: boolean;
  clickSend: false;
  privacyMode: 'lgpd_no_credentials';
  actions: string[];
};

type NativeIFlightPayload = {
  ok?: boolean;
  roster?: CrewRoster;
  dataBase64?: string;
  calendarText?: string;
  sourceFormat?: string;
  filename?: string;
  sourceFileName?: string;
  message?: string;
  error?: string;
};

declare global {
  interface Window {
    CrewCheckIFlight?: {
      openPortalAndImport?: (
        url: string,
        options?: IFlightPortalOptions,
      ) => Promise<NativeIFlightPayload | string> | NativeIFlightPayload | string;
    };
  }
}

const IFLIGHT_URL = 'https://iflightla.ibsplc.aero/iflight-cwp/web/getMainPage';
const MONTH_NAMES: Record<string, string> = {
  '01': 'Jan',
  '02': 'Feb',
  '03': 'Mar',
  '04': 'Apr',
  '05': 'May',
  '06': 'Jun',
  '07': 'Jul',
  '08': 'Aug',
  '09': 'Sep',
  '10': 'Oct',
  '11': 'Nov',
  '12': 'Dec',
};

function lastDayOfMonth(year: string, month: string) {
  const yearNumber = Number(year) || new Date().getFullYear();
  const monthNumber = Number(month) || new Date().getMonth() + 1;
  return String(new Date(yearNumber, monthNumber, 0).getDate()).padStart(2, '0');
}

function formatIFlightDate(day: string, month: string, year: string) {
  return `${day}-${MONTH_NAMES[month] || 'Jan'}-${year || new Date().getFullYear()}`;
}

async function parseBase64Pdf(filename: string, dataBase64: string): Promise<CrewRoster> {
  const response = await fetch('/api/parse-pdf', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ filename, dataBase64 }),
  });
  const payload = await response.json().catch(() => null);
  if (!response.ok || !payload?.ok || !payload?.roster) {
    throw new Error(payload?.message || payload?.detail || 'Não consegui interpretar o PDF baixado pelo iFlight.');
  }
  return payload.roster as CrewRoster;
}


async function parseIFlightCalendarText(filename: string, text: string, periodMonth: string, periodYear: string): Promise<CrewRoster> {
  const response = await fetch('/api/parse-iflight-calendar', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ filename, text, periodMonth, periodYear }),
  });
  const payload = await response.json().catch(() => null);
  if (!response.ok || !payload?.ok || !payload?.roster) {
    throw new Error(payload?.message || payload?.detail || 'Capturei o calendário do iFlight, mas ainda não consegui transformar em escala confiável.');
  }
  return payload.roster as CrewRoster;
}

const IFlightIntegrationView: React.FC<IFlightIntegrationViewProps> = ({ onBack, onSuccess, onFileUpload, onRosterImport }) => {
  const now = new Date();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [status, setStatus] = useState<IFlightStatus>('idle');
  const [message, setMessage] = useState('iFlight AutoPull pronto: o usuário entra com login, senha e MFA somente na página oficial do iFlight. Depois disso o CrewCheck mascara a navegação, tenta ler o calendário mensal, tripulação, programação, detalhes e PDF/LT autorizado, sem depender de outro app.');
  const [periodMonth, setPeriodMonth] = useState(String(now.getMonth() + 1).padStart(2, '0'));
  const [periodYear, setPeriodYear] = useState(String(now.getFullYear()));
  const [includeLegend, setIncludeLegend] = useState(false);
  const [autoClicks, setAutoClicks] = useState(true);
  const [keepAuthorizedSession, setKeepAuthorizedSession] = useState(true);
  const [silentPremiumPull, setSilentPremiumPull] = useState(true);

  const isBusy = status === 'fetching' || status === 'portal';
  const hasNativeBridge = typeof window !== 'undefined' && Boolean(window.CrewCheckIFlight?.openPortalAndImport);
  const months = useMemo(() => ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'], []);
  const fromDate = formatIFlightDate('01', periodMonth, periodYear);
  const toDate = formatIFlightDate(lastDayOfMonth(periodYear, periodMonth), periodMonth, periodYear);

  const portalOptions: IFlightPortalOptions = {
    autoClicks,
    keepAuthorizedSession,
    silentPremiumPull,
    autoResumeAfterLogin: true,
    universalPdfCapture: true,
    maskPortalUntilUserAction: true,
    noExternalApps: true,
    credentialEntry: 'official_iflight_page_only',
    mfaEntry: 'official_iflight_page_only',
    calendarStrategy: 'calendar_month_first',
    collectCrew: true,
    collectPairing: true,
    collectRosterDetails: true,
    collectDutyTimes: true,
    collectCrewList: true,
    collectAircraftAndTraining: true,
    maxAutomationMinutes: 10,
    fromDate,
    toDate,
    periodMonth,
    periodYear,
    format: 'calendar_first',
    includeLegend,
    clickSend: false,
    privacyMode: 'lgpd_no_credentials',
    actions: ['open_official_iflight_webview', 'wait_user_login_password_mfa_on_official_portal', 'mask_portal_after_auth', 'reuse_authorized_session', 'auto_resume_after_login', 'open_menu', 'open_roster_calendar', 'capture_roster_calendar_dom', 'capture_pairing_details', 'capture_crew_list', 'capture_duty_times', 'capture_training_meetings_reserve_standby', 'parse_calendar_inside_app', 'open_roster_report_fallback', 'fill_period', 'select_pdf', 'set_lt', 'run_report', 'monitor_pdf_download', 'capture_blob_pdf', 'intercept_fetch_xhr', 'return_to_crewcheck', 'broadcast_roster_to_all_modules'],
  };

  const finishRosterImport = async (roster: CrewRoster, sourceFileName: string) => {
    if (!onRosterImport) {
      setStatus('success');
      setMessage('Escala recebida automaticamente. Abra a tela de escala para conferir.');
      onSuccess();
      return;
    }
    setStatus('fetching');
    setMessage('PDF recebido. Interpretando escala e montando painel...');
    await onRosterImport(roster, sourceFileName);
    setStatus('success');
    setMessage('Escala iFlight sincronizada com sucesso.');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setStatus('fetching');
    setMessage(`Processando ${file.name}...`);
    try {
      if (onFileUpload) {
        await onFileUpload(file);
        setStatus('success');
        setMessage('Escala iFlight sincronizada com sucesso.');
        onSuccess();
        return;
      }
      setStatus('success');
      setMessage('PDF selecionado. Conclua a análise na tela de escala.');
      onSuccess();
    } catch (error) {
      setStatus('error');
      setMessage(error instanceof Error ? error.message : 'Não foi possível importar o PDF do iFlight.');
    } finally {
      e.target.value = '';
    }
  };

  async function handleOpenPortalFlow() {
    if (hasNativeBridge && window.CrewCheckIFlight?.openPortalAndImport) {
      setStatus('portal');
      setMessage('Modo Automático iniciado. Vou tentar ler primeiro o Calendário iFlight dentro do próprio iFlight. Se o iFlight pedir login/MFA, conclua somente essa etapa no portal oficial; depois eu continuo. Se o calendário não estiver completo, uso PDF/LT como fallback.');
      try {
        const nativeResult = await window.CrewCheckIFlight.openPortalAndImport(IFLIGHT_URL, portalOptions);
        const payload: NativeIFlightPayload = typeof nativeResult === 'string' ? JSON.parse(nativeResult) : nativeResult;
        if (!payload?.ok) throw new Error(payload?.error || payload?.message || 'O portal foi fechado sem retornar o PDF da escala.');
        if (payload.roster) {
          await finishRosterImport(payload.roster, payload.sourceFileName || payload.filename || `iFlight_${periodYear}_${periodMonth}.pdf`);
          return;
        }
        if (payload.calendarText) {
          const filename = payload.filename || `iFlight_RosterCalendar_${periodYear}_${periodMonth}.txt`;
          setMessage('Calendário iFlight capturado. Interpretando programação, tripulação, reservas, sobreavisos, treinamentos, pernoites e voos...');
          const roster = await parseIFlightCalendarText(filename, payload.calendarText, periodMonth, periodYear);
          await finishRosterImport(roster, filename);
          return;
        }
        if (payload.dataBase64) {
          const filename = payload.filename || `iFlight_${periodYear}_${periodMonth}.pdf`;
          const roster = await parseBase64Pdf(filename, payload.dataBase64);
          await finishRosterImport(roster, filename);
          return;
        }
        throw new Error('O portal retornou sem calendário legível, PDF ou escala interpretada.');
      } catch (error) {
        const rawMessage = error instanceof Error ? error.message : 'Não foi possível concluir a importação pelo portal.';
        const isSso403 = /app_not_configured_for_user|service is not configured|403/i.test(rawMessage);
        const errorMessage = isSso403
          ? 'O iFlight/Google retornou 403. Verifique se a conta corporativa correta tem permissão. Como fallback, baixe o PDF no portal e importe manualmente.'
          : rawMessage;
        setStatus('error');
        setMessage(errorMessage);
        toast.error(errorMessage);
      }
      return;
    }

    setStatus('portal');
    setMessage('Na versão Web comum, o navegador não permite controlar/capturar outro domínio automaticamente. No Android, o Calendar Pull roda dentro do CrewCheck e tenta ler o Calendário iFlight inteiro antes do PDF. Aqui, use o portal externo e importe o PDF manualmente.');
    window.open(IFLIGHT_URL, '_blank', 'noopener,noreferrer');
    toast.info('No web comum, o portal oficial abre fora do app. No Android, use AutoPull para não depender de outro app.');
  }

  const statusTone = status === 'success'
    ? 'border-emerald-300/30 bg-emerald-400/10 text-emerald-50'
    : status === 'error'
      ? 'border-rose-300/30 bg-rose-400/10 text-rose-50'
      : 'border-cyan-300/25 bg-cyan-300/10 text-cyan-50';

  return (
    <div className="min-h-screen overflow-hidden bg-[#030914] pb-24 text-white crewcheck-iflight-screen">
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_12%_0%,rgba(249,115,22,0.18),transparent_30rem),radial-gradient(circle_at_86%_4%,rgba(14,165,233,0.16),transparent_28rem),linear-gradient(180deg,#030914_0%,#07111f_58%,#020817_100%)]" />
      </div>

      <div className="relative z-10 mx-auto max-w-5xl px-5 py-6">
        <header className="flex items-center justify-between gap-4 rounded-[1.6rem] border border-white/10 bg-white/[0.065] px-4 py-3 shadow-2xl shadow-black/25 backdrop-blur-2xl">
          <button onClick={onBack} className="flex min-w-0 items-center gap-3 text-left">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-white/10 text-orange-100"><ChevronLeft className="h-5 w-5" /></span>
            <span className="min-w-0">
              <h2 className="truncate text-lg font-black">iFlight AutoPull</h2>
              <p className="mt-1 truncate text-xs font-black uppercase tracking-[0.18em] text-orange-100/60">sem outros apps · login/MFA só no portal oficial</p>
            </span>
          </button>
          <img src="/icons/crewcheck-icon.svg" alt="CrewCheck" className="h-11 w-11 rounded-2xl" />
        </header>

        <section className="mt-5 rounded-[2rem] border border-white/10 bg-white/[0.065] p-5 shadow-2xl shadow-black/25 backdrop-blur-2xl sm:p-6">
          <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_20rem]">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.2em] text-orange-100/65">calendar pull mascarado</p>
              <h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">iFlight AutoPull Seguro</h1>
              <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-300">Fluxo parecido com CrewTopia, porém com LGPD: o login, a senha e o MFA são digitados somente na página oficial do iFlight. Após a autenticação, o CrewCheck mascara a tela, percorre o calendário do iFlight e tenta puxar programação, tripulação, reservas, treinamentos, pernoites, detalhes do voo e PDF/LT autorizado.</p>
              <div className={`mt-4 rounded-2xl border px-4 py-3 text-sm leading-6 ${statusTone}`}>{isBusy && <Loader2 className="mr-2 inline h-4 w-4 animate-spin" />}{message}</div>

              <div className="mt-4 grid gap-2 rounded-[1.4rem] border border-white/10 bg-white/[0.045] p-3 text-xs font-bold leading-5 text-slate-300 sm:grid-cols-4">
                <span className="rounded-2xl bg-white/10 px-3 py-2"><Lock className="mr-1 inline h-3.5 w-3.5 text-cyan-200" /> Login/MFA oficial</span>
                <span className="rounded-2xl bg-white/10 px-3 py-2"><Globe className="mr-1 inline h-3.5 w-3.5 text-cyan-200" /> Calendário iFlight</span>
                <span className="rounded-2xl bg-white/10 px-3 py-2"><FileText className="mr-1 inline h-3.5 w-3.5 text-cyan-200" /> PDF/LT autorizado</span>
                <span className="rounded-2xl bg-white/10 px-3 py-2"><CheckCircle2 className="mr-1 inline h-3.5 w-3.5 text-emerald-200" /> Sync do app</span>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-3">
                <div className="rounded-[1.35rem] border border-cyan-200/15 bg-cyan-300/10 p-4"><b className="text-cyan-50">Automático</b><p className="mt-1 text-xs leading-5 text-slate-300">Reaproveita sessão autorizada e tenta sincronizar calendário, tripulação e PDF sem outro app.</p></div>
                <div className="rounded-[1.35rem] border border-emerald-200/15 bg-emerald-300/10 p-4"><b className="text-emerald-50">Login/MFA e puxar</b><p className="mt-1 text-xs leading-5 text-slate-300">Você informa login/senha/MFA no portal oficial; o CrewCheck continua após autenticar.</p></div>
                <div className="rounded-[1.35rem] border border-amber-200/15 bg-amber-300/10 p-4"><b className="text-amber-50">Caixa de Entrada</b><p className="mt-1 text-xs leading-5 text-slate-300">Plano B apenas se o portal bloquear captura: importar PDF selecionado em um toque.</p></div>
              </div>

              <div className="mt-4 rounded-[1.4rem] border border-white/10 bg-[#07111f]/75 p-4">
                <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-100/60">informações que o AutoPull tenta trazer</p>
                <div className="mt-3 grid gap-2 text-xs font-bold leading-5 text-slate-300 sm:grid-cols-2">
                  <span className="rounded-2xl bg-white/[0.07] px-3 py-2">Programação mensal e mudanças por dia</span>
                  <span className="rounded-2xl bg-white/[0.07] px-3 py-2">Voos, reservas, sobreavisos e treinamentos</span>
                  <span className="rounded-2xl bg-white/[0.07] px-3 py-2">Tripulação e detalhes de duty/pairing</span>
                  <span className="rounded-2xl bg-white/[0.07] px-3 py-2">Pernoites, horários, relatório PDF e calendário</span>
                </div>
              </div>

              <div className="mt-5 grid gap-3 sm:grid-cols-3">
                <button onClick={handleOpenPortalFlow} disabled={status === 'fetching'} className="flex min-h-[4rem] items-center justify-center gap-3 rounded-2xl bg-cyan-300 px-5 py-4 text-base font-black text-[#07111f] shadow-lg shadow-cyan-950/30 transition hover:bg-cyan-200 disabled:cursor-wait disabled:opacity-70">
                  <DownloadCloud className="h-5 w-5" /> {hasNativeBridge ? 'Puxar escala agora' : 'Abrir iFlight seguro'}
                </button>
                <button type="button" onClick={handleOpenPortalFlow} disabled={status === 'fetching'} className="flex min-h-[4rem] items-center justify-center gap-3 rounded-2xl border border-emerald-300/25 bg-emerald-300/12 px-5 py-4 text-base font-black text-emerald-50 shadow-lg shadow-emerald-950/20 transition hover:bg-emerald-300/18 disabled:cursor-wait disabled:opacity-70">
                  <ShieldCheck className="h-5 w-5" /> Login/MFA e puxar
                </button>
                <button onClick={() => fileInputRef.current?.click()} disabled={status === 'fetching'} className="flex min-h-[4rem] items-center justify-center gap-3 rounded-2xl border border-white/10 bg-white/10 px-5 py-4 text-base font-black text-white transition hover:bg-white/15 disabled:cursor-wait disabled:opacity-70">
                  <Upload className="h-5 w-5" /> Importar PDF manual
                </button>
                <input ref={fileInputRef} type="file" accept=".pdf,application/pdf" onChange={handleFileUpload} disabled={status === 'fetching'} className="sr-only" />
              </div>
            </div>

            <div className="rounded-[1.5rem] border border-cyan-300/15 bg-[#07111f]/70 p-4">
              <div className="mb-3 flex items-center gap-2 text-sm font-black text-cyan-100"><CalendarDays className="h-4 w-4" /> Período</div>
              <div className="grid gap-3">
                <label className="block">
                  <span className="text-xs font-black uppercase tracking-[0.16em] text-cyan-100/70">Mês</span>
                  <select value={periodMonth} onChange={(event) => setPeriodMonth(event.target.value)} className="mt-2 h-12 w-full rounded-2xl border border-white/10 bg-[#07111f] px-4 text-sm font-bold text-white outline-none focus:border-cyan-300">
                    {months.map((month) => <option key={month} value={month}>{month}</option>)}
                  </select>
                </label>
                <label className="block">
                  <span className="text-xs font-black uppercase tracking-[0.16em] text-cyan-100/70">Ano</span>
                  <input value={periodYear} onChange={(event) => setPeriodYear(event.target.value.replace(/\D/g, '').slice(0, 4))} inputMode="numeric" className="mt-2 h-12 w-full rounded-2xl border border-white/10 bg-[#07111f] px-4 text-sm font-bold text-white outline-none focus:border-cyan-300" />
                </label>
                <div className="rounded-2xl border border-white/10 bg-white/[0.055] p-3 text-xs leading-5 text-slate-300">
                  <strong className="text-white">{fromDate}</strong> até <strong className="text-white">{toDate}</strong><br />Formato: <strong className="text-white">PDF</strong> · Fuso: <strong className="text-white">LT</strong>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="mt-4 grid gap-4 md:grid-cols-3">
          <ToggleCard checked={autoClicks} onChange={setAutoClicks} title="Piloto automático" text="Após login/MFA, navega sozinho até Roster Report, seleciona PDF/LT e captura o download." />
          <ToggleCard checked={keepAuthorizedSession} onChange={setKeepAuthorizedSession} title="Manter sessão autorizada" text="Não salva senha; preserva apenas a sessão oficial do iFlight no dispositivo para tentar nova sincronização enquanto válida." />
          <ToggleCard checked={silentPremiumPull} onChange={setSilentPremiumPull} title="Tela mascarada premium" text="Depois do login/MFA, esconde a navegação técnica e mostra progresso amigável." />
          <ToggleCard checked={includeLegend} onChange={setIncludeLegend} title="Legenda" text="Inclui legenda/observações quando o portal disponibilizar essa opção." />
          <div className="rounded-[1.5rem] border border-emerald-300/20 bg-emerald-400/10 p-4 text-sm leading-6 text-emerald-50/80 md:col-span-2"><ShieldCheck className="mb-2 h-5 w-5" /><strong>LGPD:</strong> o CrewCheck não recebe senha nem MFA no backend. Essas informações ficam na tela oficial do iFlight. A sessão autorizada pode ser preservada localmente pelo WebView e encerrada pelo usuário no portal.</div>
        </section>

        <section className="mt-4 grid gap-4 md:grid-cols-3">
          <div className="rounded-[1.5rem] border border-cyan-300/20 bg-cyan-300/10 p-4 text-sm leading-6 text-cyan-50/85"><DownloadCloud className="mb-2 h-5 w-5" /><strong>Sem outro app:</strong> no Android/ambiente com ponte nativa, o portal abre dentro do CrewCheck e o retorno da escala volta direto para o app.</div>
          <div className="rounded-[1.5rem] border border-orange-300/20 bg-orange-300/10 p-4 text-sm leading-6 text-orange-50/85"><RefreshCw className="mb-2 h-5 w-5" /><strong>Anti-loop:</strong> cliques repetidos são bloqueados por etapa para evitar ficar preso nas mesmas abas.</div>
          <div className="rounded-[1.5rem] border border-white/10 bg-white/[0.055] p-4 text-sm leading-6 text-slate-200"><Upload className="mb-2 h-5 w-5" /><strong>Fallback:</strong> se o portal bloquear WebView, o app orienta importar o PDF, mas esse deixa de ser o fluxo principal.</div>
        </section>

        <section className="mt-4 rounded-[1.7rem] border border-white/10 bg-white/[0.055] p-4 text-sm leading-6 text-slate-300 shadow-xl shadow-black/20 backdrop-blur-2xl">
          <AlertCircle className="mr-2 inline h-4 w-4 text-orange-200" />
          Fluxo Premium Pull no Android: reutiliza sessão autorizada quando disponível → Calendário iFlight → Roster Report → PDF → LT → Run → captura do PDF. Se o iFlight exigir login/MFA, você faz essa etapa sem interferência do app; depois toque em Auto/PDF para continuar. Não usa Send e não salva senha.
        </section>

        <a href={IFLIGHT_URL} target="_blank" rel="noopener noreferrer" className="mt-4 inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/10 px-5 py-3 text-sm font-black text-white hover:bg-white/15">
          Abrir portal externo apenas se necessário <ExternalLink className="h-4 w-4" />
        </a>
      </div>
    </div>
  );
};

function ToggleCard({ checked, onChange, title, text }: { checked: boolean; onChange: (value: boolean) => void; title: string; text: string }) {
  return (
    <label className="flex cursor-pointer items-start gap-3 rounded-[1.5rem] border border-white/10 bg-white/[0.055] p-4 text-sm text-slate-200 shadow-xl shadow-black/15 backdrop-blur-xl">
      <input checked={checked} onChange={(event) => onChange(event.target.checked)} type="checkbox" className="mt-1 h-4 w-4 accent-cyan-300" />
      <span><strong className="text-white">{title}</strong><br /><span className="text-slate-400">{text}</span></span>
    </label>
  );
}

export default IFlightIntegrationView;
