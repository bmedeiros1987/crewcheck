# CrewCheck v11.1.52 — CallMeBot automático e payload enxuto

Correções principais:

- Corrige o erro de **Payload muito grande** ao salvar CallMeBot.
- O front-end agora envia apenas `preferencesPatch`, e não o objeto inteiro de preferências.
- O backend filtra/compacta as preferências aceitas antes de salvar em `preferences_json`.
- Novo endpoint `/api/telegram/callmebot/autoconfig` para configurar automaticamente pelo Telegram já conectado.
- A tela de CallMeBot ficou mais simples: botão **Configurar automático** e configuração manual recolhida em **avançado**.
- Mantém chamada de teste, Telegram Voice, telefone/apikey e fallback por variáveis de ambiente no Render.
- A apikey não fica hardcoded no ZIP.

Variáveis úteis no Render:

```env
CREWCHECK_WAKEUP_CALL_PROVIDER=callmebot
CALLMEBOT_MODE=telegram
CALLMEBOT_LANG=pt-BR-Standard-A
CALLMEBOT_REPEAT=2
# opcional para fallback Telefone/apikey global:
# CALLMEBOT_PHONE=5561999999999
# CALLMEBOT_API_KEY=coloque_no_Render
```
