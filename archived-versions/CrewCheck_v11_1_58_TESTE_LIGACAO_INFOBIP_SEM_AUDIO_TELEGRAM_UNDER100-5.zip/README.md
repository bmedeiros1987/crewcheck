# CrewCheck v11.1.58 — Teste de ligação Infobip separado do Telegram

Correção principal: o botão de teste da chamada premium agora força Infobip/VoIP e não dispara áudio no Telegram.

## Ajustes incluídos

- Botão de teste alterado para **Testar ligação Infobip**.
- Endpoint `/api/telegram/wakeup/test` agora chama `sendWakeupCallIfConfigured` com `callOnly=true`, `forceProvider=infobip`, `disableFallback=true` e `allowTelegramVoice=false`.
- O envio de voz ElevenLabs no Telegram deixou de ser padrão. Só ocorre se `CREWCHECK_WAKEUP_ELEVENLABS_SEND_TELEGRAM_VOICE=true` for configurado de propósito.
- Se Infobip/VoIP falhar no teste, o app mostra erro de ligação em vez de parecer sucesso por áudio no Telegram.
- Plano gratuito continua apenas com Telegram.
- Premium/Admin continuam com ligação premium.
- Mantidos: abertura Full HD, CallMeBot fallback para uso normal, payload pequeno e white label do Despertador CrewCheck.

## Variáveis recomendadas

```env
CREWCHECK_WAKEUP_CALL_PROVIDER=infobip
CREWCHECK_WAKEUP_CALL_PREMIUM_ONLY=true
CREWCHECK_WAKEUP_FREE_CHANNEL=telegram
CREWCHECK_WAKEUP_FALLBACK_PROVIDER=callmebot
CREWCHECK_WAKEUP_ELEVENLABS_SEND_TELEGRAM_VOICE=false

INFOBIP_ENABLED=true
INFOBIP_BASE_URL=https://y4x2z9.api.infobip.com
INFOBIP_API_KEY=COLE_AQUI_SUA_API_KEY_INFOBIP
INFOBIP_FROM_NUMBER=COLE_AQUI_NUMERO_ORIGEM_HABILITADO
INFOBIP_TO_PHONE=5561XXXXXXXXX
INFOBIP_DEFAULT_COUNTRY=BR
INFOBIP_CALL_TIMEOUT_SECONDS=45
INFOBIP_LANGUAGE=pt-BR
INFOBIP_VOICE_NAME=br-pt
```

`INFOBIP_FROM_NUMBER` precisa ser o número/caller ID habilitado na Infobip. `INFOBIP_TO_PHONE` é opcional, mas ajuda no teste quando o app ainda não salvou telefone do usuário.
