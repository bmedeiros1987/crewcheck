# CrewCheck v11.1.105 — Saída Inteligente Minimal / Auditoria Visual

Base: v11.1.104.

## Foco
Auditoria visual da tela **Saída Inteligente**, reduzindo poluição de texto, corrigindo mistura de tema claro/escuro e mantendo o padrão Premium com menu lateral e motor da escala preservados.

## Correções principais
- Reestruturação da tela de Saída Inteligente em layout minimalista.
- Hero com recomendação principal e poucos indicadores.
- KPIs reduzidos para Aeroporto, Tempo e Distância.
- Configurações movidas para painel lateral compacto.
- Textos longos de LGPD/confiança/dicas ocultados do fluxo principal.
- Extra, ônibus/metrô e corrida deixam de poluir a tela principal; aparecem apenas como opções rápidas quando houver dados.
- Tema claro/escuro unificado via tokens do Design System Premium.
- Campos, botões, cards, chips e alertas com contraste reforçado.
- Painel avançado recolhido em “Mais opções”.

## Preservado
- Motor canônico da escala.
- Escala Ouro / anti-teletransporte.
- BIDS/PBS.
- Radar multi-API.
- Alertas operacionais.
- Regulamentação automática por função/ACT.
- Meteorologia.
- WhatsApp Premium/import.
- Infobip.
- FreeCurrencyAPI.
- Fuso BSB.
- Calendário limpo.

## Validação
- `node --check server.mjs`: OK.
- `unzip -tq`: OK.
- `bash -n`: OK.
- Pacote: 99 arquivos.
- `npm run build`: não executado localmente porque o ambiente não possui `vite`; deve rodar no Render/GitHub.
