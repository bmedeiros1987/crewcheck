# CrewCheck v11.0.86 — Concierge completo e escala antiga sem alterar o cockpit

Esta versão evolui o Concierge Telegram e adiciona uma visualização premium de escalas antigas: o usuário pode abrir um mês salvo para consultar escala, diárias e salário sem trocar a escala ativa usada pelo Cockpit, Saída Inteligente, Radar e Concierge.

## Principais melhorias

- Histórico agora tem modo **Visualizar**: abre escala antiga sem alterar o cockpit.
- Botão separado **Usar no cockpit** para quando o usuário realmente quiser tornar a escala antiga ativa.
- Tela **Escala antiga** com abas/atalhos para Escala, Diárias e Salário do mês selecionado.
- Diárias e Salário, ao selecionar mês salvo, abrem a visualização histórica segura.
- Concierge Telegram mais completo com comandos de histórico, mês antigo e resumo financeiro.
- Novos comandos Premium: `/historico`, `/mes julho 2026`, `/salario`.
- Gratuito mantém histórico limitado e comandos básicos; Premium libera consulta completa.

## Validação

- `node --check server.mjs`
- `npm run check`
- `npm run build`

Avisos conhecidos: PDF.js/chunk grande do Vite, sem quebrar o build.
