# CrewCheck v11.1.68 — Infobip principal restaurado

- Provedor premium principal voltou para Infobip.
- Twilio ficou como fallback técnico opcional, sem bloquear o fluxo por conta Trial.
- Usuário gratuito continua apenas no Telegram.
- Premium/Admin continuam com ligação telefônica premium.
- Teste principal volta a forçar Infobip e não envia áudio no Telegram.
- Mantém abertura Full HD, payload pequeno e bloqueio de fallback automático em inglês.
