# CrewCheck v10.8.96 — correção GitHub Actions Android

## Correção principal
- Corrigido erro do GitHub Actions:
  - `Unrecognized named-value: 'secrets'`
  - causado por uso de `secrets.*` diretamente em `if:` no workflow `android-build.yml`.

## Novo comportamento
- O workflow não usa mais `secrets` em `if:`.
- A keystore é detectada dentro do shell.
- Sempre tenta gerar APK debug.
- Tenta gerar APK/AAB release quando possível.
- Se assinatura não estiver configurada, mantém APK debug como fallback.
- Artifacts são publicados como `CrewCheck_v10_8_96_APK_AAB`.

## Versão
- App: 10.8.96
- Android: versionCode 10896 / versionName 10.8.96
