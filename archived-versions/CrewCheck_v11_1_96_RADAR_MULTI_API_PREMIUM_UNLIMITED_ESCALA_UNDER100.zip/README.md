# CrewCheck v11.1.96 — Radar Multi-API Premium sem limite artificial

Base: v11.1.95.

## Ajustes principais
- Radar de voo passa a consultar e agregar múltiplos provedores configurados: FlightAware/AeroAPI, FlightStats/Cirium, AeroDataBox, AirLabs, Aviationstack, Amadeus, fontes oficiais BSB/GRU/SSA e proxy próprio.
- Premium e Premium Unlimited não ficam mais presos ao limite curto de consulta em lote; o limite operacional passa a ser configurável por ambiente.
- Deduplicação reforçada para evitar redundância entre provedores/codeshare e preencher portão, terminal, status e horários com a melhor fonte disponível.
- Radar de aeroporto agrega linhas de todas as APIs configuradas, em vez de parar no primeiro retorno útil.
- Status individual do voo usa agregação Multi-API e preserva diagnóstico de fontes.
- Mantidas: regulamentação automática por função/ACT, alertas de portão/status/meteo, parser anti-teletransporte, Infobip, WhatsApp Premium/import, FreeCurrencyAPI, fuso BSB e calendário limpo.

## Variáveis úteis
```env
AIRPORT_BOARD_API_PROVIDER_ORDER=FLIGHTAWARE,FLIGHTSTATS,CIRIUM,AERODATABOX,AIRLABS,AVIATIONSTACK,OFFICIAL
CREWCHECK_RADAR_STATUS_PROVIDER_ORDER=FLIGHTAWARE,FLIGHTSTATS,CIRIUM,AERODATABOX,AIRLABS,AVIATIONSTACK,AMADEUS,OFFICIAL,CUSTOM
CREWCHECK_RADAR_AGGREGATE_PROVIDERS=true
CREWCHECK_RADAR_FREE_BATCH_MAX_FLIGHTS=12
CREWCHECK_RADAR_PREMIUM_BATCH_MAX_FLIGHTS=120
CREWCHECK_RADAR_PREMIUM_AIRPORT_REFRESH_MAX=80
FLIGHTAWARE_AEROAPI_KEY=...
FLIGHTSTATS_APP_ID=...
FLIGHTSTATS_APP_KEY=...
AERODATABOX_API_KEY=...
AIRLABS_API_KEY=...
AVIATIONSTACK_ACCESS_KEY=...
AMADEUS_CLIENT_ID=...
AMADEUS_CLIENT_SECRET=...
FLIGHT_STATUS_ENDPOINT=...
```
