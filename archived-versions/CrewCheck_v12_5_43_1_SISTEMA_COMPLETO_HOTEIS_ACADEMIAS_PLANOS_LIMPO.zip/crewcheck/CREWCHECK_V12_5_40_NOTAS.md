# CrewCheck v12.5.43.1 — Sistema completo: Hotéis + Academias por plano

## Base

Gerado a partir de `crewcheck_v12.5.40_gympass_compat_gyms_concierge_20260705.zip`.

## Incluído

- Base com 153 hotéis da empresa.
- Busca de hotel por aeroporto, cidade, país, estado/província ou nome.
- Alias operacional `DXB` para o hotel de Dubai que veio na lista como `DBX`.
- Configuração de academias por plano:
  - Wellhub
  - Smart Fit
  - Wellhub + Smart Fit
- Preferência salva no dispositivo em `crewcheck:gym-provider-plan:v1`.
- Busca de academias próximas respeitando o plano escolhido.
- Painel premium automático em telas de resultados/configurações/rotina/hotéis.
- Rotas backend:
  - `/api/company-hotels`
  - `/api/company-hotels/:airportCode`
  - `/api/gym-provider-plans`

## Preservado

- Motor canônico da escala.
- Parser PDF/AIMS.
- Diárias, salário, regulamentação e Concierge.
- Build no Render/GitHub Actions.
- Sem `npm install` ou `npm run build` dentro do Termux.

## Observação

O ZIP foi gerado como sistema completo, não apenas patch.
