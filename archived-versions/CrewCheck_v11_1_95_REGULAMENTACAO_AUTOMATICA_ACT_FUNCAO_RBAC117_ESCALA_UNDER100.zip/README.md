# CrewCheck v11.1.95 — Regulamentação automática por função/ACT

Versão baseada na v11.1.94.

## Principais ajustes

- Regulamentação agora é definida automaticamente pela função do usuário no Perfil.
- Aceita variações de siglas/funções: CCM, CC, CCF, comissário(a), chefe de cabine, purser, comandante, CMTE, CP, FO, copiloto, piloto etc.
- ACT aplicada automaticamente:
  - ACT Aeronautas Comissários 2025/2027 para comissário/chefe de cabine.
  - ACT Aeronautas Pilotos 2025/2027 para comandante/copiloto/piloto.
- Em caso de conflito, o sistema aplica a regra mais restritiva entre RBAC 117 e ACT.
- Limite de jornada usa RBAC 117 Apêndice B, Tabela B.1 conforme horário de apresentação/início e número de etapas.
- Reserva acionada conta desde o início da reserva/apresentação, não pelo acionamento/decolagem.
- Menus específicos passam a respeitar a função definida no Perfil.
- Cadastro passa a solicitar função para reduzir erro de ACT no primeiro cálculo.
- Mantém v11.1.94: alertas de portão/status, meteorologia, parser anti-teletransporte, fuso, calendário limpo, Infobip, WhatsApp e FreeCurrency.

## Validação

- `node --check server.mjs`
- `npm run build`
- pacote abaixo de 100 arquivos
