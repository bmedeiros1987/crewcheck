# CrewCheck v11.1.53 — Despertador CrewCheck White Label

Versão focada em deixar o fluxo de chamadas mais premium e automatizado.

## Principais ajustes

- A tela principal agora mostra **Despertador CrewCheck**, não CallMeBot.
- O provedor técnico fica escondido na área **Configuração técnica/avançada**.
- Fluxo guiado em 3 passos: conectar Telegram, autorizar chamadas e configurar/testar.
- Novos endpoints white label:
  - `/api/telegram/wakeup/autoconfig`
  - `/api/telegram/wakeup/test`
- Endpoints antigos mantidos para compatibilidade:
  - `/api/telegram/callmebot/autoconfig`
  - `/api/telegram/callmebot/test`
- Botão **Abrir autorização** para levar o usuário ao provedor técnico no Telegram sem expor isso como item principal da UI.
- Mantém o patch pequeno para evitar **Payload muito grande**.
- API key não fica hardcoded no ZIP.

## Variáveis sugeridas no Render

```env
CREWCHECK_WAKEUP_CALL_PROVIDER=callmebot
CREWCHECK_WAKEUP_BRAND=CrewCheck Voice
CREWCHECK_WAKEUP_AUTHORIZE_URL=https://t.me/CallMeBot_API
CALLMEBOT_MODE=telegram
CALLMEBOT_LANG=pt-BR-Standard-A
CALLMEBOT_REPEAT=2
CREWCHECK_ROSTER_PAYLOAD_LIMIT_MB=48
CREWCHECK_DEFAULT_JSON_BODY_LIMIT_MB=32
```

Para fallback por telefone/apikey no Render:

```env
CALLMEBOT_MODE=auto
CALLMEBOT_PHONE=55DDDNUMERO
CALLMEBOT_API_KEY=sua_apikey_no_Render
```

## Observação transparente

A experiência dentro do app fica como **Despertador CrewCheck**. No momento da autorização ou da chamada dentro do Telegram, o provedor técnico pode aparecer com a identidade real dele, porque isso é controlado pelo Telegram/provedor externo.
