# CrewCheck v11.1.03 · Admin real + Gerenciador multiescala iOS

Esta versão corrige regressões da v11.0.99 e muda o foco da aba Meteorologia para operação aeronáutica.

## Principais ajustes

- Remove a seção Alertas+ Socioambiental da Meteorologia.
- Meteorologia passa a consultar METAR/TAF via backend e destacar risco de tempestade, CB/TCU, vento/rajada, teto baixo e visibilidade reduzida.
- Os aeroportos são sugeridos automaticamente a partir da escala ativa: origem, destino e base dos próximos dias.
- Corrige fallback persistente da escala no iOS: ao reabrir o app, a tela inicial tenta recuperar a última escala salva localmente antes de mostrar “sem escala”.
- Corrige nome do tripulante na tela inicial usando o nome extraído da escala quando o perfil local estiver vazio.
- Corrige abertura em vídeo com cache-bust, tentativa explícita de autoplay e tela de carregamento centralizada no Android/WebView.

## Endpoints novos

- `/api/meteorologia/aviacao/alertas`
- `/api/weather/aviation-alerts`

Fonte padrão: `https://aviationweather.gov/api/data`.

## Android

- versionName: 11.1.03
- versionCode: 11103
