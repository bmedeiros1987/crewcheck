# CrewCheck v10.8.101 — Salário por KM + Radar MultiFonte

## Ganho estimado por voo
- Adicionado painel em **Salário** com o ganho estimado por trecho.
- Métrica: `KM aproximado entre aeroportos × valor do KM em R$`.
- Considera:
  - KM diurno;
  - KM noturno;
  - KM em fim de semana/DSR quando aplicável;
  - valor estimado por trecho;
  - total estimado por voos.
- Em **Escala > detalhes do voo**, passa a aparecer o ganho estimado do trecho.
- O sistema sempre indica que é estimativa, sujeita a arredondamentos, regras de folha e contracheque oficial.

## Radar
- Mantém e incorpora Radar MultiFonte com fontes oficiais públicas quando disponíveis.
- Inclui diagnóstico `/api/radar-health`.
- Mantém fallback sem API com dados da escala.

## Versão
- App: 10.8.101
- Android: versionCode 10901 / versionName 10.8.101
