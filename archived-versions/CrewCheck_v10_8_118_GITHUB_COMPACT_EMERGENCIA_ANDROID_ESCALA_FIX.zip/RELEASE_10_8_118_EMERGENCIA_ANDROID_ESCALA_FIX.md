# CrewCheck v10.8.118 — Emergência Android: Escala Fix

## Correção emergencial
- Corrigido layout da escala no Android/mobile.
- Removido o card mobile quebrado que deixava horários e chips gigantes/sobrepostos.
- Criado card mobile específico e estável para Android:
  - título limpo;
  - rota/atividade legível;
  - apresentação;
  - decolagem/pouso;
  - portão;
  - status;
  - tripulação quando disponível.
- Mantido clique para abrir detalhes completos.
- Mantidas as regras anteriores de:
  - Chefe de Cabine;
  - diárias;
  - toque em folga;
  - Voo de Extra real only;
  - Nova Escala light font fix.

## Versão
- App: 10.8.118
- Android: versionCode 108118 / versionName 10.8.118
