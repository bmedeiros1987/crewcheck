#!/bin/bash
set -euo pipefail
APP_VERSION="10.8.85"
BUNDLE_ID="com.crewcheck.app"
echo "CrewCheck ${APP_VERSION} — preparação iOS"
if [[ "$(uname -s)" != "Darwin" ]]; then echo "Este script precisa rodar no macOS."; exit 1; fi
command -v node >/dev/null 2>&1 || { echo "Instale Node.js 22+."; exit 1; }
command -v xcodebuild >/dev/null 2>&1 || { echo "Instale/abra o Xcode."; exit 1; }
npm install
npm run build
if [[ ! -d "ios" ]]; then npx cap add ios; fi
npx cap sync ios
if [[ -f "ios/App/App/Info.plist" ]]; then
  /usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString ${APP_VERSION}" "ios/App/App/Info.plist" 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Set :CFBundleVersion 10885" "ios/App/App/Info.plist" 2>/dev/null || true
fi
npx cap open ios
echo "No Xcode: App > Signing & Capabilities > Team > Product > Archive. Bundle ID: ${BUNDLE_ID}"
