import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
if (pkg.version !== '10.8.76') throw new Error(`Versão inválida: ${pkg.version}`);

const requiredFiles = [
  'client/src/lib/calendarExport.ts',
  'client/src/lib/googleCalendarSync.ts',
  'client/src/pages/Home.tsx',
  'client/src/pages/Results.tsx',
  'server.mjs',
  'capacitor.config.ts',
  'scripts/ios_gerar_no_mac_v10_8_76.sh',
];
for (const file of requiredFiles) {
  if (!fs.existsSync(path.join(root, file))) throw new Error(`Arquivo obrigatório ausente: ${file}`);
}

const calendar = fs.readFileSync(path.join(root, 'client/src/lib/calendarExport.ts'), 'utf8');
const google = fs.readFileSync(path.join(root, 'client/src/lib/googleCalendarSync.ts'), 'utf8');
for (const needle of ['buildPairingDescription', 'CREWCONNECT_COLORS', '#CREWCHECK', 'calendarColorForFlightLeg']) {
  if (!calendar.includes(needle)) throw new Error(`Exportação premium: marcador ausente ${needle}`);
}
for (const needle of ['googleColorIdFromCrewCheck', 'colorId: googleColorIdFromCrewCheck']) {
  if (!google.includes(needle)) throw new Error(`Google Calendar premium: marcador ausente ${needle}`);
}

console.log('CrewCheck v10.8.76 validado: exportação de calendário premium, cores estilo Crew Lounge e iOS-ready preservado.');
