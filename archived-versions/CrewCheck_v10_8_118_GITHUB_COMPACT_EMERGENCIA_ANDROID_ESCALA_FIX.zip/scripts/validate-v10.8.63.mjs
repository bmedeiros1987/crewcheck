import fs from 'node:fs';

const pkg = JSON.parse(fs.readFileSync('package.json','utf8'));
if (pkg.version !== '10.8.63') throw new Error(`Versão inválida: ${pkg.version}`);
const home = fs.readFileSync('client/src/pages/Home.tsx','utf8');
const results = fs.readFileSync('client/src/pages/Results.tsx','utf8');
const parser = fs.readFileSync('client/src/lib/pdfParser.ts','utf8');
for (const token of [
  'Regra de confiança: a Escala/Cockpit só exibe apresentação quando ela veio publicada.',
  'dashboardSmartDepartureTarget',
  'smartDepartureTargetIso',
  'voo fora da base sem apresentação publicada; considera 1h antes da decolagem'
]) {
  if (!home.includes(token)) throw new Error(`Home sem ${token}`);
}
if (!results.includes('Escala: não sintetizar apresentação')) throw new Error('Results ainda pode sintetizar apresentação.');
if (parser.includes('subtractMinutes(firstLeg.departureTime, 45)')) throw new Error('Parser local ainda usa apresentação sintética -45min.');
const server = fs.readFileSync('server.mjs','utf8');
if (!server.includes('/api/smart-departure')) throw new Error('Servidor sem Saída Inteligente.');
console.log('CrewCheck v10.8.63 validado: escala usa horários publicados e Saída Inteligente aplica 1h fora de base apenas no cálculo operacional.');
