import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
if (pkg.version !== '10.8.67') throw new Error(`Versão inválida: ${pkg.version}`);

const requiredFiles = [
  'client/src/lib/aimsParser.ts',
  'client/src/lib/pdfParser.ts',
  'client/src/lib/calendarExport.ts',
  'client/src/pages/Home.tsx',
  'client/src/pages/Results.tsx',
  'server.mjs',
];
for (const file of requiredFiles) {
  const full = path.join(root, file);
  if (!fs.existsSync(full)) throw new Error(`Arquivo obrigatório ausente: ${file}`);
}

const aims = fs.readFileSync(path.join(root, 'client/src/lib/aimsParser.ts'), 'utf8');
const home = fs.readFileSync(path.join(root, 'client/src/pages/Home.tsx'), 'utf8');
const results = fs.readFileSync(path.join(root, 'client/src/pages/Results.tsx'), 'utf8');
const calendar = fs.readFileSync(path.join(root, 'client/src/lib/calendarExport.ts'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.mjs'), 'utf8');

for (const [label, text, needles] of [
  ['AIMS', aims, ['isExtraAimsMarker', 'parseFlightDay', 'pendingWorkType', 'firstReportTime']],
  ['Saída Inteligente', home, ['dashboardRequiresHomeDeparture', 'Saída Inteligente: programação exige deslocamento']],
  ['Resultados', results, ['Extra · Passageiro (PS)', '🧍']],
  ['Exportação', calendar, ['EXTRA ·', 'Positioning']],
  ['Servidor', server, ['isExtraMarkerRC10867', 'function parseAimsBlockRC7', 'forcedWorkType']],
]) {
  for (const needle of needles) if (!text.includes(needle)) throw new Error(`${label}: marcador ausente ${needle}`);
}

console.log('CrewCheck v10.8.67 validado: base v10.8.63 preservada, escala nova/última escala mantidas e parser premium PS/apresentação ativo.');
