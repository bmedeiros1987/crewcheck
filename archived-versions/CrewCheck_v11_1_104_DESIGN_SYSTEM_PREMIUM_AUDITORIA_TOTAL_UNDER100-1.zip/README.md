# CrewCheck v11.1.104 — Design System Premium / Auditoria Total

Versão focada em auditoria visual completa do sistema, tela por tela, mantendo o menu lateral e preservando o motor canônico da escala.

## Objetivo

- Unificar todo o sistema em um Design System Premium único.
- Evitar mistura de modo claro com modo escuro.
- Melhorar legibilidade de fontes, cards, botões, inputs e menus.
- Deixar o visual mais minimalista, com menos ruído e mais contraste.
- Manter o coração da escala e as correções anti-teletransporte intactas.

## Telas auditadas por CSS global

- App Shell / estrutura principal.
- Menu lateral Premium fixo.
- Escala / Results.
- Cockpit / Home.
- Calendário.
- Conformidade / Regulamentação.
- Radar de voos.
- Meteorologia.
- Despertador Premium.
- Perfil / Configurações.
- BIDS/PBS.
- Admin / suporte / ferramentas.

## Correções visuais principais

- Novo conjunto de tokens premium para claro/escuro.
- Sidebar estabilizada e mantida como padrão principal.
- Cards, painéis, KPIs, chips e botões padronizados.
- Overrides contra classes hard-coded claras no tema escuro e escuras no tema claro.
- Fail-safes para imagens, logo, overflow horizontal e textos sem contraste.
- Escala com visual mais limpo e minimalista, sem alterar o parser.
- Service Worker/cache atualizado para 11.1.104.

## Mantido da base anterior

- Motor canônico da escala.
- Bloqueio de cache antigo/reimportação da escala ouro.
- Anti-teletransporte.
- BIDS/PBS.
- Radar multi-API e alertas.
- Regulamentação automática por função/ACT.
- Meteorologia.
- Infobip/WhatsApp Premium.
- FreeCurrencyAPI.

## Validação recomendada

1. Fazer deploy e limpar cache PWA.
2. Abrir em desktop web e Android.
3. Testar modo claro, escuro e automático.
4. Abrir Escala, Cockpit, Radar, Meteorologia, Despertador Premium, Configurações e BIDS.
5. Conferir se nenhuma tela mistura card claro em tema escuro ou card escuro em tema claro.
6. Reimportar a escala original se houver dados antigos no cache.
