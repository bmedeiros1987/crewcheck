# CrewCheck v10.8.91 — Perfil Instrutor + BIDS/PBS

## Ajustes
- Adicionada opção no Perfil: “Sou instrutor”.
- Quando marcada, a tela BIDS/PBS abre por padrão na janela de Instrutores.
- A preferência fica salva localmente no aparelho/navegador.
- O BIDS mostra badge “Perfil marcado como instrutor”.
- Mantida a opção manual para alternar entre Geral e Instrutores.
- Android atualizado para versionCode 10891 e versionName 10.8.91.
