# CrewCheck v10.8.90 — BIDS/PBS Reminder Premium

## Novo módulo
- Novo menu no Cockpit: BIDS.
- Tabela da janela de solicitação BIDS/PBS conforme informativo enviado pelo usuário.
- Seleção de ano, mês alvo e tipo: Geral ou Instrutores.
- Status visual: aguardando abertura, janela aberta, encerrada ou já solicitado.
- Botão “Já solicitado” para parar lembrete interno.
- Exportação `.ics` para calendário com:
  - evento de abertura;
  - evento de último dia;
  - alarmes antes da abertura/fechamento;
  - observação “confirme sempre no sistema oficial”.

## Janela cadastrada
- Fevereiro: geral 7–11, instrutores 7–10.
- Março: geral 11–15, instrutores 11–15.
- Abril: geral 11–15, instrutores 11–14.
- Maio: geral 10–14, instrutores 10–12.
- Junho: geral 11–15, instrutores 11–14.
- Julho: geral 11–15, instrutores 11–13.
- Agosto: geral 11–15, instrutores 11–13.
- Setembro: geral 11–15, instrutores 11–13.
- Outubro: geral 11–15, instrutores 11–12.
- Novembro: geral 10–14, instrutores 10–12.
- Dezembro: geral 11–15, instrutores 11–13.

## Versão
- App: 10.8.90
- Android: versionCode 10890 / versionName 10.8.90
