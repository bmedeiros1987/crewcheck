# CrewCheck v10.8.89 — Calendário com apresentação visível

## Ajustes
- Eventos principais de jornada/pairing agora mostram o horário de apresentação no título.
- A primeira perna do voo também mostra `Apres. HH:MM` no título do evento.
- Eventos de duty/reserva/reunião passam a trazer o horário inicial no título.
- A descrição dos eventos ganhou linha explícita `Apresentação: HH:MM LOCAL`.
- Mantém o padrão premium de cores e organização do calendário.
- Android atualizado para versionCode 10889 e versionName 10.8.89.
