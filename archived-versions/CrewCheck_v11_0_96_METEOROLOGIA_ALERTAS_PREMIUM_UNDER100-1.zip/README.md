# CrewCheck v11.0.96

Meteorologia Premium para pilotos/admin, com METAR/TAF, favoritos, glossário, Concierge Telegram em texto/áudio estilo ATIS e alertas de piora meteorológica.

## Destaques

- Menu Meteorologia liberado para piloto e administrador nesta fase.
- Consulta METAR/TAF via proxy backend do Aviation Weather Center.
- Favoritos de aeródromos e busca por ICAO/IATA.
- Exibição normal, traduzida ou ambas.
- Glossário METAR/TAF para download.
- Detecção de piora/sensibilidade: chuva forte, trovoada, cumulonimbus, teto baixo, visibilidade ruim, nevoeiro e rajada de vento.
- Concierge Telegram responde meteorologia por texto ou por áudio estilo ATIS quando a entrada for áudio.
- Para cabine, mantém aviso simplificado de piora meteorológica, sem excesso técnico.
- Produção Android mantém R8/ProGuard, shrinkResources e mapping.txt.

## Android

- versionName: 11.0.96
- versionCode: 11096
