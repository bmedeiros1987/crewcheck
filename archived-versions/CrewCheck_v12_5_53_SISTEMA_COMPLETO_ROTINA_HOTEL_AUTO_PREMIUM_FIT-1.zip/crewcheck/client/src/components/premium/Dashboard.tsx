import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Bell,
  CalendarDays,
  Bus,
  Car,
  ChevronDown,
  ChevronRight,
  Clock,
  CreditCard,
  FileText,
  Home as HomeIcon,
  Map,
  Menu,
  Moon,
  Plane,
  Radar,
  Settings2,
  ShieldCheck,
  Sparkles,
  SunMedium,
  TrendingUp,
  Users,
  Wifi,
} from 'lucide-react';

interface DashboardProps {
  user: {
    name: string;
    company: string;
    avatar?: string;
    base?: string;
    requiresDeparture?: boolean;
  };
  nextEvent?: {
    title: string;
    time: string;
    endTime: string;
    date: string;
    presentationTime?: string;
    departureTime?: string;
    route?: string;
    status?: string;
    gate?: string;
    gateSource?: string;
    terminal?: string;
    registration?: string;
    aircraftIcao?: string;
    estimatedArrival?: string;
    landingCountdown?: string;
    countdown?: string;
    source?: string;
    flightNumber?: string;
    isFlight?: boolean;
    targetIso?: string;
    smartDepartureTargetIso?: string;
    origin?: string;
    destination?: string;
    base?: string;
    requiresDeparture?: boolean;
    relation?: 'current' | 'today' | 'tomorrow' | 'future' | 'rest_followup' | 'fallback';
    relationLabel?: string;
    dayContext?: string;
    isToday?: boolean;
    isTomorrow?: boolean;
    isInProgress?: boolean;
    isAfterRest?: boolean;
    actualDateIso?: string;
  };
  onNavigate: (view: string) => void;
  onOpenMenu?: () => void;
  onToggleTheme?: () => void;
  currentMonthLabel?: string;
  perDiemForecastLabel?: string;
  perDiemForecastDetail?: string;
  todayDutyLabel?: string;
  todayDutyDetail?: string;
  weeklyDutyLabel?: string;
  weeklyDutyDetail?: string;
  weeklyDutyProgress?: number;
  canAccessC32FAcademy?: boolean;
  pendingOffline?: number;
  hasRoster?: boolean;
  alertsCount?: number;
  daysLoaded?: number;
  complianceScore?: number;
  seatForecast?: {
    symbol?: string;
    title?: string;
    route?: string;
    flight?: string;
    score?: string;
    riskLabel?: string;
    source?: string;
    updatedAt?: string;
    empty?: boolean;
  };
}


type SmartDepartureApiPlan = {
  ok?: boolean;
  leaveAtIso?: string;
  leaveAtLabel?: string;
  leaveAtFullLabel?: string;
  durationMinutes?: number;
  marginMinutes?: number;
  safetyMarginMinutes?: number;
  trafficLabel?: string | null;
  dataQualityLabel?: string | null;
  estimateDisclosure?: string | null;
  originSourceLabel?: string | null;
  originSource?: string | null;
  routeQuality?: string | null;
  warning?: string | null;
  source?: string | null;
  recommendedMode?: string | null;
  fastestMode?: string | null;
  mode?: string | null;
  firstTransitDeparture?: string | null;
  mapsUrl?: string | null;
  destination?: { lat?: number | null; lng?: number | null } | null;
  transitBoard?: Array<{ departureLabel?: string | null }>;
  transitSteps?: Array<{ departureLabel?: string | null }>;
  routeOptions?: Array<{ mode?: string | null; firstTransitDeparture?: string | null; mapsUrl?: string | null; rideApps?: Array<{ id?: string; name?: string; etaMinutes?: number | null; webUrl?: string | null; deepLink?: string | null; mapsUrl?: string | null }> }>;
  rideApps?: Array<{ id?: string; name?: string; etaMinutes?: number | null; webUrl?: string | null; deepLink?: string | null; mapsUrl?: string | null }>;
  diagnostics?: { mapsKeyConfigured?: boolean; provider?: string; errors?: string[] };
  error?: string;
  message?: string;
};

function airportForCommute(nextEvent?: DashboardProps['nextEvent'], base = 'BSB') {
  const route = splitRoute(nextEvent);
  return String(nextEvent?.origin || route.origin || base || 'BSB').toUpperCase();
}

function addMinutesToIso(iso?: string, minutes = 0) {
  if (!iso) return '';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '';
  return new Date(date.getTime() + minutes * 60000).toISOString();
}

function fallbackSmartDepartureIso(targetIso?: string, commuteMinutes = 65, marginMinutes = 25) {
  if (!targetIso) return '';
  return addMinutesToIso(targetIso, -(Math.max(30, commuteMinutes) + Math.max(15, marginMinutes)));
}

function getStoredCrewLocation() {
  try {
    const lat = Number(localStorage.getItem('crewcheck_last_lat') || localStorage.getItem('crewcheck_home_lat') || '');
    const lng = Number(localStorage.getItem('crewcheck_last_lng') || localStorage.getItem('crewcheck_home_lng') || '');
    if (Number.isFinite(lat) && Number.isFinite(lng)) return { ok: true, lat, lng, accuracy: Number(localStorage.getItem('crewcheck_last_accuracy') || 999), provider: 'local-storage' };
  } catch {}
  return null;
}

function requestDashboardLocation(timeoutMs = 12000): Promise<{ ok?: boolean; lat?: number; lng?: number; accuracy?: number; provider?: string; time?: number; error?: string }> {
  return new Promise((resolve) => {
    try {
      if (!('geolocation' in navigator)) {
        resolve({ ok: false, error: 'GPS indisponível neste navegador/app.' });
        return;
      }
      navigator.geolocation.getCurrentPosition((position) => {
        try {
          localStorage.setItem('crewcheck_last_lat', String(position.coords.latitude));
          localStorage.setItem('crewcheck_last_lng', String(position.coords.longitude));
          localStorage.setItem('crewcheck_last_accuracy', String(position.coords.accuracy || ''));
          localStorage.setItem('crewcheck_last_location_time', String(position.timestamp || Date.now()));
        } catch {}
        resolve({
          ok: true,
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          accuracy: position.coords.accuracy,
          provider: 'gps-alta-precisao',
          time: position.timestamp,
        });
      }, (error) => {
        const stored = getStoredCrewLocation();
        if (stored?.ok) resolve(stored);
        else resolve({ ok: false, error: error?.code === 1 ? 'Permita localização para calcular saída real.' : 'Não consegui obter GPS em alta precisão.' });
      }, { enableHighAccuracy: true, timeout: timeoutMs, maximumAge: 0 });
    } catch {
      const stored = getStoredCrewLocation();
      resolve(stored?.ok ? stored : { ok: false, error: 'Falha ao solicitar localização.' });
    }
  });
}

async function fetchDashboardSmartDeparturePlan(nextEvent: DashboardProps['nextEvent'], base: string): Promise<SmartDepartureApiPlan | null> {
  if (!nextEvent?.smartDepartureTargetIso) return null;
  const loc = await requestDashboardLocation();
  if (!loc?.ok || typeof loc.lat !== 'number' || typeof loc.lng !== 'number') {
    return { ok: false, error: loc?.error || 'Localização real não autorizada.' };
  }
  const airport = airportForCommute(nextEvent, base);
  const params = new URLSearchParams({
    lat: String(loc.lat),
    lng: String(loc.lng),
    accuracy: String(loc.accuracy || ''),
    provider: loc.provider || 'gps',
    locationTime: String(loc.time || Date.now()),
    airport,
    targetIso: nextEvent.smartDepartureTargetIso,
    marginMinutes: '25',
    mode: 'AUTO',
    telegramNotify: '0',
  });
  try {
    const response = await fetch(`/api/smart-departure?${params.toString()}`, { cache: 'no-store' });
    const payload = await response.json().catch(() => null) as SmartDepartureApiPlan | null;
    if (!response.ok || !payload?.ok) return { ok: false, error: payload?.message || payload?.error || `API de rota indisponível (${response.status}).` };
    return payload;
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : 'API de rota indisponível.' };
  }
}


const Dashboard: React.FC<DashboardProps> = ({
  user,
  nextEvent,
  onNavigate,
  onOpenMenu,
  onToggleTheme,
  currentMonthLabel = 'Escala atual',
  perDiemForecastLabel = '—',
  perDiemForecastDetail = 'Próximos pagamentos',
  todayDutyLabel = '—',
  todayDutyDetail = 'Sem jornada hoje',
  weeklyDutyLabel = '—',
  weeklyDutyDetail = 'Horas de trabalho da semana',
  weeklyDutyProgress,
  alertsCount = 0,
  hasRoster = false,
}) => {
  const firstName = (user.name || 'Bruno Saraiva').split(/\s+/).filter(Boolean)[0] || 'Bruno';
  const route = splitRoute(nextEvent);
  const rawFlightNumber = sanitizeFlight(nextEvent?.flightNumber || nextEvent?.title);
  const isFlight = Boolean(nextEvent?.isFlight && rawFlightNumber);
  const placeholderText = `${nextEvent?.title || ''} ${nextEvent?.time || ''} ${nextEvent?.date || ''} ${nextEvent?.source || ''}`.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const emptySchedule = !hasRoster || !nextEvent || /importe sua escala|pdf exportado|escala antiga|historico/.test(placeholderText) || nextEvent?.time === 'PDF';
  const hasRealProgram = Boolean(hasRoster && nextEvent && !emptySchedule);
  const shouldShowFlight = Boolean(hasRealProgram && isFlight);
  const flightNumber = shouldShowFlight ? rawFlightNumber : hasRealProgram ? (nextEvent?.title || nextEvent?.flightNumber || 'Programação') : 'Importe sua escala';
  const presentation = shouldShowFlight ? safeTime(nextEvent?.presentationTime || nextEvent?.time, '—') : hasRealProgram ? safeTime(nextEvent?.time, '—') : '—';
  const departure = safeTime(nextEvent?.departureTime || nextEvent?.time, shouldShowFlight ? '—' : '—');
  const arrival = safeTime(nextEvent?.endTime, shouldShowFlight ? '—' : '—');
  const base = user.base || nextEvent?.base || 'BSB';
  const requiresDeparture = Boolean(hasRealProgram && shouldShowFlight && nextEvent?.requiresDeparture !== false);
  const smartTitle = requiresDeparture ? 'Saída Inteligente' : 'Próxima programação';
  const smartSubtitle = requiresDeparture ? 'Análise otimizada para seu deslocamento.' : 'Folgas e descansos não exigem saída para apresentação.';
  const routeDetail = shouldShowFlight ? `${route.origin} → ${route.destination}` : hasRealProgram ? `${nextEvent?.date || 'Data da escala'} · ${nextEvent?.time || 'dia inteiro'}` : 'Sem escala ativa';
  const nextLabel = shouldShowFlight ? 'Próximo voo' : hasRealProgram ? 'Próxima programação' : 'Escala';
  const eventDateLabel = formatDashboardEventDate(nextEvent);
  const eventDateShort = formatDashboardEventDate(nextEvent, true);
  const liveStatusLabel = normalizeDashboardStatus(nextEvent?.status);
  const liveGateLabel = cleanRadarDisplayValue(nextEvent?.gate);
  const liveTerminalLabel = cleanRadarDisplayValue(nextEvent?.terminal);
  const liveRegistrationLabel = cleanRadarDisplayValue(nextEvent?.registration);
  const hasLiveRadarInfo = Boolean(shouldShowFlight && (liveStatusLabel || liveGateLabel || liveTerminalLabel || liveRegistrationLabel));
  const nextProgramGateLabel = shouldShowFlight ? (liveGateLabel || 'A confirmar') : '';
  const nextProgramGateSource = liveGateLabel ? (cleanRadarDisplayValue(nextEvent?.gateSource) || 'Radar/OAG') : 'Aguardando radar';
  const [smartPlan, setSmartPlan] = useState<SmartDepartureApiPlan | null>(null);
  const [smartPlanLoading, setSmartPlanLoading] = useState(false);

  useEffect(() => {
    let alive = true;
    setSmartPlan(null);
    if (!requiresDeparture || !nextEvent?.smartDepartureTargetIso) return () => { alive = false; };
    setSmartPlanLoading(true);
    fetchDashboardSmartDeparturePlan(nextEvent, base)
      .then((plan) => { if (alive) setSmartPlan(plan); })
      .catch((error) => { if (alive) setSmartPlan({ ok: false, error: error instanceof Error ? error.message : 'Falha ao calcular rota real.' }); })
      .finally(() => { if (alive) setSmartPlanLoading(false); });
    return () => { alive = false; };
  }, [requiresDeparture, nextEvent?.smartDepartureTargetIso, nextEvent?.origin, nextEvent?.destination, base]);

  const conservativeFallbackIso = fallbackSmartDepartureIso(nextEvent?.smartDepartureTargetIso, 65, 25);
  const smartDeparture = formatSmartDepartureMoment(smartPlan?.ok && smartPlan.leaveAtIso ? smartPlan.leaveAtIso : conservativeFallbackIso, nextEvent?.actualDateIso, nextEvent?.date);
  const smartDepartureTime = smartDeparture.time || '—';
  const commuteAirport = airportForCommute(nextEvent, base);
  const commuteQuality = smartPlanLoading ? 'Atualizando rota…' : smartPlan?.ok ? 'Rota calculada' : 'Calcular rota';
  const commuteDuration = smartPlan?.ok && smartPlan.durationMinutes
    ? formatCrewDurationLabel(smartPlan.durationMinutes)
    : 'calcular';
  const commuteTraffic = smartPlan?.ok ? (smartPlan.trafficLabel || 'Normal') : 'calcular';
  const commuteMargin = `${smartPlan?.marginMinutes || smartPlan?.safetyMarginMinutes || 25} min`;
  const kpiRouteDetail = shouldShowFlight ? `${eventDateLabel} · apres. ${presentation} · decolagem ${departure}${liveGateLabel ? ` · portão ${liveGateLabel}` : ''}${liveStatusLabel ? ` · ${liveStatusLabel}` : ''}` : routeDetail;
  const preferredDashboardMode = (() => { try { return String(localStorage.getItem('crewcheck_departure_mode') || 'AUTO').toUpperCase(); } catch { return 'AUTO'; } })();
  const recommendedMode = String(smartPlan?.recommendedMode || smartPlan?.fastestMode || smartPlan?.mode || preferredDashboardMode || 'DRIVE').toUpperCase();
  const transitFirstDeparture = smartPlan?.firstTransitDeparture || smartPlan?.transitBoard?.[0]?.departureLabel || smartPlan?.transitSteps?.[0]?.departureLabel || smartPlan?.routeOptions?.find((item) => String(item.mode || '').toUpperCase() === 'TRANSIT')?.firstTransitDeparture || null;
  const rideApp = smartPlan?.rideApps?.find((item) => /uber/i.test(item.name || item.id || '')) || smartPlan?.routeOptions?.flatMap((item) => item.rideApps || []).find((item) => /uber/i.test(item.name || item.id || '')) || null;
  const showUberButton = Boolean(rideApp?.webUrl || rideApp?.deepLink) && (preferredDashboardMode.includes('RIDE') || recommendedMode === 'RIDE_APP');
  const departureModeIcon = recommendedMode.includes('FLIGHT') ? <Plane /> : recommendedMode === 'TRANSIT' ? <Bus /> : recommendedMode === 'RIDE_APP' ? <span aria-hidden="true" className="cc12521-smart-emoji">🚕</span> : <Car />;
  const departureModeLabel = recommendedMode.includes('FLIGHT') ? 'Avião' : recommendedMode === 'TRANSIT' ? 'Ônibus/metrô' : recommendedMode === 'RIDE_APP' ? 'Uber/99' : 'Carro';
  const departureModeDetail = recommendedMode === 'TRANSIT' && transitFirstDeparture ? `1º embarque ${transitFirstDeparture}` : recommendedMode === 'RIDE_APP' && rideApp?.etaMinutes ? `chamada/app ${rideApp.etaMinutes} min` : commuteDuration;
  const openDashboardRoute = () => {
    const targetUrl = smartPlan?.mapsUrl || (smartPlan?.destination?.lat && smartPlan?.destination?.lng ? `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${smartPlan.destination.lat},${smartPlan.destination.lng}`)}&travelmode=${recommendedMode === 'TRANSIT' ? 'transit' : 'driving'}` : `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${commuteAirport} Aeroporto`)}`);
    window.open(targetUrl, '_blank', 'noopener,noreferrer');
  };
  const openDashboardUber = () => {
    const targetUrl = rideApp?.webUrl || rideApp?.deepLink || rideApp?.mapsUrl;
    if (targetUrl) window.open(targetUrl, '_blank', 'noopener,noreferrer');
  };

  const smartDisplayTitle = emptySchedule ? 'Importar escala' : requiresDeparture ? smartDepartureTime : 'Descanso';
  const smartDisplayBadge = emptySchedule ? 'PDF' : requiresDeparture ? departureModeLabel : 'Sem saída';
  const smartDisplayRoute = emptySchedule ? 'Envie sua escala oficial' : requiresDeparture ? `Casa → ${commuteAirport}` : routeDetail;
  const smartDisplayDetail = emptySchedule ? 'Sem cartões fictícios' : requiresDeparture ? eventDateLabel : 'Sem deslocamento';

  return (
    <div className="cc1251-dashboard-shell">
      <header className="cc1251-topbar">
        <div>
          <p className="cc1251-kicker">Página Principal</p>
          <h1>Cockpit</h1>
        </div>
        <div className="cc1251-topbar-actions" aria-label="Controles do cockpit">
          <button className="cc1251-month" type="button" onClick={() => onNavigate('history')}><CalendarDays size={18} /> {currentMonthLabel} <ChevronDown size={16} /></button>
          <button className="cc1251-icon-btn" type="button" onClick={() => (onOpenMenu ? onOpenMenu() : onNavigate('more'))} aria-label="Menu"><Menu size={20} /></button>
          <button className="cc1251-icon-btn" type="button" onClick={() => onNavigate('settings')} aria-label="Ajustar layout"><Settings2 size={20} /></button>
          <button className="cc1251-icon-btn cc1251-bell" type="button" onClick={() => onNavigate('alerts')} aria-label="Notificações"><Bell size={20} />{alertsCount > 0 && <span>{alertsCount}</span>}</button>
          <button className="cc1251-icon-btn" type="button" onClick={() => (onToggleTheme ? onToggleTheme() : toggleCrewThemeFromDashboard())} aria-label="Alternar tema"><Moon size={19} /><SunMedium size={15} /></button>
          <button className="cc1251-avatar-btn" type="button" onClick={() => onNavigate('settings')} aria-label="Perfil">
            {user.avatar ? <img src={user.avatar} alt="Perfil" /> : <span>{firstName[0]}</span>}
          </button>
        </div>
      </header>

      <section className="cc1251-kpi-row" aria-label="Resumo operacional">
        <MetricCard icon={<Plane />} tone="blue" label={nextLabel} value={flightNumber} detail={kpiRouteDetail} badge={isFlight ? `${eventDateShort} · ${departure}` : eventDateShort} onClick={() => onNavigate('roster')} />
        <MetricCard icon={<Clock />} tone="blue" label="Horas semana" value={weeklyDutyLabel || todayDutyLabel} detail={weeklyDutyDetail || todayDutyDetail} progress={typeof weeklyDutyProgress === 'number' ? weeklyDutyProgress : undefined} onClick={() => onNavigate('roster')} />
        <MetricCard icon={<ShieldCheck />} tone="green" label="Status RBAC" value="Ativo" detail="Conformidade da escala" onClick={() => onNavigate('regulation')} />
        <MetricCard icon={<CreditCard />} tone="purple" label="Diárias" value={perDiemForecastLabel} detail={perDiemForecastDetail} chevron onClick={() => onNavigate('perdiem')} />
        <MetricCard icon={<AlertTriangle />} tone="amber" label="Alertas" value={String(alertsCount || 0)} detail={alertsCount ? 'Toque para revisar' : 'Tudo certo'} chevron onClick={() => onNavigate('alerts')} />
      </section>

      <div className="cc1251-main-grid">
        <div className="cc1251-main-column">
          <section className="cc1251-panel cc1251-next-card cc12518-next-card-real">
            <div className="cc1251-section-head">
              <div><CalendarDays size={19} /><h2>Próxima Programação</h2></div>
              <button type="button" onClick={() => onNavigate('roster')}>Ver todas</button>
            </div>
            {!hasRealProgram ? (
              <div className="cc127-empty-next-card">
                <span><CalendarDays size={28} /></span>
                <div>
                  <small>Escala oficial</small>
                  <strong>Importe sua escala</strong>
                  <p>Use PDF oficial do CrewTopia, AIMS ou arquivo salvo. A tela inicial não mostra dados fictícios.</p>
                </div>
                <button type="button" onClick={() => onNavigate('import')}>Importar PDF</button>
              </div>
            ) : (
            <div className="cc1251-flight-mini">
              <div className="cc1251-airline-line">
                <b>{shouldShowFlight ? 'LATAM' : 'Escala'}</b>
                <strong>{flightNumber}</strong>
                <span>{eventDateShort}</span>
              </div>
              <div className="cc12518-program-date"><CalendarDays size={16} /><b>{eventDateLabel}</b><small>{isFlight ? 'Próximo voo programado' : 'Próxima atividade da escala'}</small></div>
              {shouldShowFlight ? <div className="cc1251-route-line"><b>{route.origin}<small>{cityName(route.origin)}</small></b><i><Plane size={24} /></i><b>{route.destination}<small>{cityName(route.destination)}</small></b></div> : <div className="cc1251-rest-line"><HomeIcon size={24} /><b>{routeDetail}</b></div>}
              <div className="cc1251-flight-details">
                <span><small>{shouldShowFlight ? 'Apresentação' : 'Início'}</small><b>{presentation}</b></span>
                <span><small>{shouldShowFlight ? 'Decolagem' : 'Fim'}</small><b>{departure}</b></span>
                <span><small>{shouldShowFlight ? 'Chegada' : 'Tipo'}</small><b>{shouldShowFlight ? arrival : 'Atividade'}</b></span>
              </div>
              {shouldShowFlight && (
                <div className="cc12522-radar-strip cc12523-radar-strip-clean cc12548-next-gate-strip" aria-label="Portão e status do próximo voo">
                  <span className={liveGateLabel ? 'cc12548-gate-confirmed' : 'cc12548-gate-pending'}><small>Portão</small><b>{nextProgramGateLabel}</b><em>{nextProgramGateSource}</em></span>
                  {liveStatusLabel && <span><small>Status</small><b>{liveStatusLabel}</b></span>}
                  {liveTerminalLabel && <span><small>Terminal</small><b>{liveTerminalLabel}</b></span>}
                  {liveRegistrationLabel && <span><small>Matrícula</small><b>{liveRegistrationLabel}</b></span>}
                </div>
              )}
              <div className="cc1251-flight-foot"><span><Plane size={17} />{shouldShowFlight ? 'Operacional' : 'Escala'}</span>{hasLiveRadarInfo && <span><Users size={17} />Radar ativo</span>}</div>
            </div>

            )}
          </section>

          <section className={`cc12524-home-smart-card ${requiresDeparture ? 'is-active' : 'is-rest'}`}>
            <div className="cc12524-home-smart-top">
              <span className="cc12524-home-smart-icon">{requiresDeparture ? departureModeIcon : <ShieldCheck size={26} />}</span>
              <div>
                <small>Saída Inteligente</small>
                <strong>{smartDisplayTitle}</strong>
              </div>
              <em>{smartDisplayBadge}</em>
            </div>
            <div className="cc12524-home-smart-route">
              <b>{smartDisplayRoute}</b>
              <span>{smartDisplayDetail}</span>
            </div>
            {requiresDeparture && !emptySchedule && (
              <div className="cc12524-home-smart-pills">
                <span><small>Chegar</small><b>{presentation}</b></span>
                <span><small>Tempo</small><b>{commuteDuration}</b></span>
                <span><small>Status</small><b>{smartPlan?.ok ? 'Pronto' : 'Calcular'}</b></span>
              </div>
            )}
            <div className="cc12524-home-smart-actions">
              {emptySchedule ? <button type="button" onClick={() => onNavigate('import')}><FileText size={17} /> Importar</button> : requiresDeparture && <button type="button" onClick={openDashboardRoute}><Map size={17} /> Mapa</button>}
              {!emptySchedule && showUberButton && <button type="button" onClick={openDashboardUber} className="cc12521-uber-action"><span aria-hidden="true">🚕</span> Uber</button>}
              {!emptySchedule && <button type="button" onClick={() => onNavigate('departure')} className="secondary">{requiresDeparture ? 'Detalhes' : 'Abrir'} <ChevronRight size={17} /></button>}
            </div>
          </section>
        </div>

        <aside className="cc1251-side-column">


          <section className="cc1251-modules-grid" aria-label="Módulos rápidos">
            <QuickModule icon={<Radar />} label="Radar" onClick={() => onNavigate('flightboard')} />
            <QuickModule icon={<Wifi />} label="Meteorologia" onClick={() => onNavigate('weather')} />
            <QuickModule icon={<CreditCard />} label="Diárias" onClick={() => onNavigate('perdiem')} />
            <QuickModule icon={<TrendingUp />} label="Salário" onClick={() => onNavigate('salary')} />
            <QuickModule icon={<FileText />} label="Relatórios" onClick={() => onNavigate('reports')} wide />
          </section>
        </aside>
      </div>
    </div>
  );
};

function MetricCard({ icon, tone, label, value, detail, badge, progress, chevron, onClick }: { icon: React.ReactNode; tone: string; label: string; value: string; detail: string; badge?: string; progress?: number; chevron?: boolean; onClick?: () => void }) {
  return <button type="button" onClick={onClick} className={`cc1251-metric tone-${tone}`}>
    <span className="cc1251-metric-icon">{icon}</span>
    <span><small>{label}</small><b>{value}</b><em>{detail}</em>{typeof progress === 'number' && <i style={{ ['--pct' as string]: `${Math.max(0, Math.min(100, progress))}%` }} />}</span>
    {badge && <strong>{badge}</strong>}
    {chevron && <ChevronRight className="cc1251-card-chevron" size={18} />}
  </button>;
}

function SmartTile({ icon, title, value, success }: { icon: React.ReactNode; title: string; value: string; success?: boolean }) {
  return <div className="cc1251-smart-tile"><span>{icon}</span><small>{title}</small><b className={success ? 'is-success' : ''}>{value}</b></div>;
}

function AlertRow({ title, text, right, tone }: { title: string; text: string; right: string; tone: 'amber' | 'red' }) {
  return <button type="button" className={`cc1251-alert-row tone-${tone}`}><AlertTriangle size={18} /><span><b>{title}</b><small>{text}</small></span><em>{right}</em><ChevronRight size={17} /></button>;
}

function QuickModule({ icon, label, wide, onClick }: { icon: React.ReactNode; label: string; wide?: boolean; onClick: () => void }) {
  return <button type="button" onClick={onClick} className={`cc1251-module ${wide ? 'is-wide' : ''}`}><span>{icon}</span><b>{label}</b><ChevronRight size={18} /></button>;
}

function splitRoute(nextEvent?: DashboardProps['nextEvent']) {
  const raw = `${nextEvent?.route || nextEvent?.title || ''}`;
  const parts = raw.split(/\s*(?:→|->|–|-)\s*/).map((part) => part.trim().replace(/^(LA|JJ|G3|AD|TP)\s*\d+\s*/i, '')).filter((part) => /^[A-Z]{3}$/.test(part));
  const origin = nextEvent?.origin || parts[0] || 'FOR';
  const destination = nextEvent?.destination || parts[1] || 'GRU';
  return { origin, destination };
}

function sanitizeFlight(value?: string) {
  const match = String(value || '').match(/\b[A-Z]{2}\s?\d{3,4}\b/i);
  return match ? match[0].replace(/\s+/, ' ').toUpperCase() : '';
}

function safeTime(value?: string, fallback = '—') {
  const match = String(value || '').match(/\b\d{1,2}:\d{2}\b/);
  return match ? match[0].padStart(5, '0') : fallback;
}

function formatCrewDurationLabel(minutes?: number | null) {
  const total = Math.max(0, Math.round(Number(minutes) || 0));
  if (!total) return '—';
  const hours = Math.floor(total / 60);
  const mins = total % 60;
  if (!hours) return `${mins}min`;
  if (!mins) return `${hours}h`;
  return `${hours}h${String(mins).padStart(2, '0')}`;
}

function cleanRadarDisplayValue(value?: string | null) {
  const text = String(value || '').trim();
  if (!text || /^[-—]+$/.test(text)) return '';
  return text;
}

function normalizeDashboardStatus(value?: string | null) {
  const text = cleanRadarDisplayValue(value);
  if (!text) return '';
  const normalized = text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  if (/cancel/.test(normalized)) return 'Cancelado';
  if (/embarque|boarding/.test(normalized)) return 'Embarque';
  if (/ultima chamada|last call/.test(normalized)) return 'Última chamada';
  if (/finalizado|pousou|landed|arrived|encerrado/.test(normalized)) return 'Finalizado';
  if (/decolou|departed/.test(normalized)) return 'Decolou';
  if (/atras/.test(normalized)) return 'Atrasado';
  if (/confirm|scheduled|program/.test(normalized)) return 'Confirmado';
  return text;
}

function formatDashboardEventDate(nextEvent?: DashboardProps['nextEvent'], short = false) {
  const rawIso = String(nextEvent?.actualDateIso || '').trim();
  const raw = String(nextEvent?.date || '').trim();
  let date: Date | null = null;

  if (/^\d{4}-\d{2}-\d{2}$/.test(rawIso)) {
    const [y, m, d] = rawIso.split('-').map(Number);
    date = new Date(y, m - 1, d);
  } else {
    const m = raw.match(/(\d{1,2})\/(\d{1,2})\/?(\d{2,4})?/);
    if (m) {
      const day = Number(m[1]);
      const month = Number(m[2]);
      const year = Number(m[3] || new Date().getFullYear());
      date = new Date(year < 100 ? 2000 + year : year, month - 1, day);
    }
  }

  if (!date || Number.isNaN(date.getTime())) return raw || 'Data da escala';
  const today = new Date();
  const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
  const dateStart = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  const diff = Math.round((dateStart - todayStart) / 86400000);
  const weekday = date.toLocaleDateString('pt-BR', { weekday: short ? 'short' : 'long' }).replace('.', '');
  const dayMonth = date.toLocaleDateString('pt-BR', { day: '2-digit', month: short ? 'short' : 'long' }).replace('.', '');
  if (short) return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}`;
  if (diff === 0) return `Hoje, ${weekday} · ${dayMonth}`;
  if (diff === 1) return `Amanhã, ${weekday} · ${dayMonth}`;
  return `${weekday.charAt(0).toUpperCase()}${weekday.slice(1)} · ${dayMonth}`;
}

function formatSmartDepartureMoment(iso?: string, actualDateIso?: string, rawDate?: string) {
  let date: Date | null = null;
  if (iso) {
    const parsed = new Date(iso);
    if (!Number.isNaN(parsed.getTime())) date = parsed;
  }
  if (!date) return { prefix: 'Saída inteligente', time: '—' };

  const today = new Date();
  const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
  const dateStart = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  const diff = Math.round((dateStart - todayStart) / 86400000);
  const time = date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  if (diff === 0) return { prefix: 'Saia hoje às', time };
  if (diff === 1) return { prefix: 'Saia amanhã às', time };
  const day = date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
  return { prefix: `Saia no dia ${day} às`, time };
}


function inferPresentation(time: string) {
  const [h, m] = time.split(':').map(Number);
  if (!Number.isFinite(h) || !Number.isFinite(m)) return '04:15';
  const total = (h * 60 + m - 30 + 1440) % 1440;
  return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
}

function cityName(code: string) {
  const map: Record<string, string> = { FOR: 'Fortaleza', GRU: 'São Paulo', PMW: 'Palmas', CGH: 'São Paulo', BSB: 'Brasília', CXJ: 'Caxias do Sul' };
  return map[code] || code;
}


function toggleCrewThemeFromDashboard() {
  try {
    const current = document.documentElement.dataset.crewTheme === 'dark' ? 'dark' : 'light';
    const next = current === 'dark' ? 'light' : 'dark';
    localStorage.setItem('crewcheck_theme_mode', next);
    document.documentElement.dataset.crewThemeMode = next;
    document.documentElement.dataset.crewTheme = next;
    document.documentElement.classList.toggle('dark', next === 'dark');
    document.documentElement.style.colorScheme = next;
    window.dispatchEvent(new CustomEvent('crewcheck:theme-change', { detail: { mode: next, effective: next } }));
  } catch {}
}

export default Dashboard;
