# CrewCheck v11.0.5 — iFlight Admin em sessão anônima

## Objetivo
Evitar que o navegador interno do iFlight puxe automaticamente a conta Google/pessoal já usada no WebView.

## Ajustes
- iFlight continua restrito ao administrador.
- Usuários comuns permanecem com importação manual de PDF oficial.
- Android/WebView abre o portal iFlight em modo de sessão anônima por padrão.
- Antes de abrir o iFlight, o app limpa cookies conhecidos de iFlight, Google e Microsoft/SSO.
- Desativa autofill no WebView do portal para reduzir sugestão automática de conta pessoal.
- Desativa cache no portal iFlight.
- Adiciona botão nativo **Anônimo** na toolbar do portal para reiniciar a sessão e escolher outra conta.
- Mantém opção administrativa de preservar sessão local, mas agora vem desligada por padrão.
- Mensagens atualizadas para orientar o admin a escolher a conta LATAM/corporativa.

## Validação
- npm run check
- npm run build

## Android
- versionName: 11.0.5
- versionCode: 11005
