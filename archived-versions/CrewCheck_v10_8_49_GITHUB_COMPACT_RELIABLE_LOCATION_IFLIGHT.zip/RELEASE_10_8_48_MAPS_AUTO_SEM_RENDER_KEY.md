# CrewCheck v10.8.48 — Maps Auto Config sem Render API Key

Esta versão mantém o pacote GitHub Compact abaixo de 100 arquivos e adiciona configuração automática da Saída Inteligente com Google Routes sem exigir Render API Key no Termux.

## Incluído

- Fallback temporário de `GOOGLE_ROUTES_API_KEY`/`GOOGLE_MAPS_API_KEY` no backend para facilitar teste imediato.
- Saída Inteligente com carro e transporte público usando Google Routes quando disponível.
- Cache de rotas e timezone configurados automaticamente.
- Mantidas as correções de tripulação, chefia CCM, web compacta, Android safe area e permissões.

## Produção

Após validar, recomenda-se criar uma nova chave restrita no Google Cloud e configurar no Render como variável de ambiente, removendo o fallback embutido do código.
