# CrewCheck v10.8.49 — Reliable Location + iFlight Compact

Correções principais:

- Saída Inteligente: pedido de permissão de localização mais confiável no Android.
- Android: `requestCurrentLocation` agora aguarda a resposta da permissão e depois puxa GPS real.
- Web: cálculo usa geolocation do navegador no clique do usuário e informa erro mais claro quando o navegador bloqueia.
- Backend: Google Routes tenta autenticação por header e por `key=`, com `referer/origin` do CrewCheck.
- Backend: fallback para Google Directions API quando Routes falhar, incluindo transporte público por região quando disponível.
- iFlight WebView: visual mais compacto para o Roster Calendar caber melhor no Android.
- Mantido pacote GitHub Compact abaixo de 100 arquivos.
