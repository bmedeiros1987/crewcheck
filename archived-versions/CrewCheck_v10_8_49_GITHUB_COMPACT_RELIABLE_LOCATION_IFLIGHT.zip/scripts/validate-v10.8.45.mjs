import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const assert = (condition, message) => {
  if (!condition) {
    console.error(`✗ ${message}`);
    process.exit(1);
  }
  console.log(`✓ ${message}`);
};

const pkg = JSON.parse(read('package.json'));
assert(pkg.version === '10.8.45', 'package.json version 10.8.45');

const gradle = read('android-wrapper/app/build.gradle');
assert(/versionCode\s+10845/.test(gradle), 'Android versionCode 10845');
assert(/versionName\s+['"]10\.8\.45['"]/.test(gradle), 'Android versionName 10.8.45');

const server = read('server.mjs');
assert(server.includes('parseTripulationRecordsV10845'), 'Servidor inclui parser de Tripulações v10.8.45');
assert(server.includes('applyTripulationsToRosterV10845'), 'Servidor aplica tripulação ao voo por data/número');
assert(server.includes('/api/parse-iflight-calendar'), 'Endpoint interno /api/parse-iflight-calendar existe');
assert(server.includes('first CCM') || server.includes('ccmBonusStatus'), 'Servidor marca primeiro CCM para chefia');
assert(/Tripula(?:ç|c)/i.test(server), 'Servidor reconhece seção Tripulações/Tripulacao');

const mainActivity = read('android-wrapper/app/src/main/java/com/crewcheck/app/MainActivity.java');
assert(mainActivity.includes('receiveCalendarText'), 'Android bridge recebe texto do calendário iFlight');
assert(mainActivity.includes('__crewcheckCaptureCalendarText'), 'Android injeta captura do Roster Calendar');
assert(mainActivity.includes('calendar_first'), 'Android tenta calendário antes do PDF');

const iflightView = read('client/src/components/premium/IFlightIntegrationView.tsx');
assert(iflightView.includes('calendar_first'), 'Front envia modo calendar_first ao iFlight');
assert(iflightView.includes('/api/parse-iflight-calendar'), 'Front consome parser de calendário iFlight');
assert(iflightView.includes('calendarText'), 'Front aceita payload calendarText do Android');

const css = read('client/src/index.css');
assert(css.includes('CrewCheck v10.8.45 — WEB compacto'), 'CSS web compacto v10.8.45 presente');
assert(css.includes('.cc-roster-desktop-list .cc-roster-date-desktop p:nth-child(2)'), 'Data desktop reduzida por CSS');
assert(css.includes('.cc-roster-desktop-list .cc-flight-live-grid'), 'Grid de status do voo compactado no web');

const aimsParser = read('client/src/lib/aimsParser.ts');
const pdfParser = read('client/src/lib/pdfParser.ts');
assert(aimsParser.includes("['CP','FO'].includes(role)"), 'AIMS aceita CP/FO com nome simples');
assert(pdfParser.includes("['CP','FO'].includes(role)"), 'PDF parser aceita CP/FO com nome simples');

console.log('\nCrewCheck v10.8.45 validado com sucesso.');
