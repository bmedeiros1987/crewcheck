import fs from 'node:fs';

const mustContain = [
  ['package.json', '"version": "10.8.48"'],
  ['server.mjs', 'CREWCHECK_MAPS_AUTO_CONFIG_START'],
  ['server.mjs', 'GOOGLE_ROUTES_API_KEY'],
  ['server.mjs', 'CREWCHECK_COMMUTE_TRANSIT_ENABLED'],
  ['server.mjs', 'Google Routes'],
  ['android-wrapper/app/build.gradle', 'versionCode 10848'],
  ['android-wrapper/app/build.gradle', "versionName '10.8.48'"],
];

let ok = true;
for (const [file, token] of mustContain) {
  if (!fs.existsSync(file)) {
    console.error(`Arquivo ausente: ${file}`);
    ok = false;
    continue;
  }
  const text = fs.readFileSync(file, 'utf8');
  if (!text.includes(token)) {
    console.error(`Token ausente em ${file}: ${token}`);
    ok = false;
  }
}

if (!ok) process.exit(1);
console.log('CrewCheck v10.8.48 validado: Maps Auto Config, Google Routes, Android version e fallback reliable OK.');
