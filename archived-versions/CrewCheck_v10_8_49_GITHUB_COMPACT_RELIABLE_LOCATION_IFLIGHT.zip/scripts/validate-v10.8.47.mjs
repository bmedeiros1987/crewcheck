import fs from 'node:fs';

const read = (p) => fs.readFileSync(p, 'utf8');
function ok(label, cond){
  if(!cond){ console.error(`✗ ${label}`); process.exitCode = 1; }
  else { console.log(`✓ ${label}`); }
}
const pkg = JSON.parse(read('package.json'));
const gradle = read('android-wrapper/app/build.gradle');
const server = read('server.mjs');
const main = read('android-wrapper/app/src/main/java/com/crewcheck/app/MainActivity.java');
const dashboard = read('client/src/components/premium/Dashboard.tsx');
const env = read('.env.example');

ok('package.json version 10.8.47', pkg.version === '10.8.47');
ok('Android versionCode 10847', /versionCode\s+10847/.test(gradle));
ok('Android versionName 10.8.47', /versionName\s+["']10\.8\.47["']/.test(gradle));
ok('Backend usa Google Routes com TRANSIT', /travelMode\s*=\s*mode === 'TRANSIT'/.test(server) || /travelMode:\s*travelMode/.test(server));
ok('Backend retorna routeOptions carro + transporte público', /routeOptions/.test(server) && /TRANSIT/.test(server) && /DRIVE/.test(server));
ok('Backend gera fallback para Google Maps', /buildGoogleMapsDirectionsUrl/.test(server));
ok('Android expõe localização nativa assíncrona', /requestCurrentLocation/.test(main) && /crewcheck:native-location-result/.test(main));
ok('Android usa LocationManager com GPS/Network', /LocationManager\.GPS_PROVIDER/.test(main) && /LocationManager\.NETWORK_PROVIDER/.test(main));
ok('Dashboard tenta localização nativa antes do navegador', /requestCrewCheckNativeCurrentLocation/.test(dashboard) && /requestBrowserLocation/.test(dashboard));
ok('Dashboard exibe modo Auto, carro e transporte público', /AUTO/.test(dashboard) && /TRANSIT/.test(dashboard) && /Transp\./.test(dashboard));
ok('Env documenta GOOGLE_MAPS_API_KEY', /GOOGLE_MAPS_API_KEY/.test(env) && /GOOGLE_ROUTES_API_KEY/.test(env));
ok('Script npm validate:10847 configurado', /validate:10847/.test(JSON.stringify(pkg.scripts || {})));

if(process.exitCode){ process.exit(process.exitCode); }
console.log('\nCrewCheck v10.8.47 validado com sucesso.');
