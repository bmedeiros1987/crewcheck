import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const assert = (cond, msg) => { if (!cond) { console.error(`❌ ${msg}`); process.exit(1); } };
const pkg = JSON.parse(read('package.json'));
assert(pkg.version === '10.8.44', 'package.json precisa estar em 10.8.44');
assert(read('client/src/pages/Home.tsx').includes("const APP_VERSION = '10.8.44'"), 'Home.tsx precisa exibir APP_VERSION 10.8.44');
assert(read('client/src/pages/Home.tsx').includes('loadFinanceCrewNameCandidates'), 'Salário precisa usar candidatos de nome para gratificação CCM');
assert(read('client/src/pages/Home.tsx').includes('shouldCountCcmChiefBonusForFinance(leg, crewNameCandidates)'), 'Gratificação CCM precisa usar candidatos robustos');
assert(read('client/src/lib/pdfParser.ts').includes('normalizeTripulationRoleForDisplay'), 'Parser genérico precisa normalizar papel CM/CCM');
assert(read('client/src/lib/aimsParser.ts').includes('parseAimsCrewMembersFromTripulationText'), 'Parser AIMS precisa ler tripulação robusta');
assert(read('client/src/pages/Results.tsx').includes('crewSummaryForRosterEvent'), 'Escala precisa mostrar resumo de tripulação nos cards');
assert(read('client/src/index.css').includes('CrewCheck v10.8.44'), 'CSS v10.8.44 precisa estar aplicado');
if (fs.existsSync(path.join(root, 'android-wrapper/app/build.gradle'))) {
  const gradle = read('android-wrapper/app/build.gradle');
  assert(/versionCode\s+10844/.test(gradle), 'Android versionCode precisa ser 10844');
  assert(/versionName\s+'10\.8\.44'/.test(gradle), 'Android versionName precisa ser 10.8.44');
}
console.log('✅ CrewCheck v10.8.44 validado: tripulação, chefia CCM, web compacta e menu premium.');
