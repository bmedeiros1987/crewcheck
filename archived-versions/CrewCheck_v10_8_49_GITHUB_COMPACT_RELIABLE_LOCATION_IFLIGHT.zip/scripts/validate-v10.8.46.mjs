import fs from 'node:fs';

const read = (p) => fs.readFileSync(p, 'utf8');
const checks = [];
function ok(label, cond){
  if(!cond){ console.error(`✗ ${label}`); process.exitCode = 1; }
  else { console.log(`✓ ${label}`); }
}
const pkg = JSON.parse(read('package.json'));
const gradle = read('android-wrapper/app/build.gradle');
const server = read('server.mjs');
const main = read('android-wrapper/app/src/main/java/com/crewcheck/app/MainActivity.java');
const css = read('client/src/index.css');
const results = read('client/src/pages/Results.tsx');
const aims = read('client/src/lib/aimsParser.ts');

ok('package.json version 10.8.46', pkg.version === '10.8.46');
ok('Android versionCode 10846', /versionCode\s+10846/.test(gradle));
ok('Android versionName 10.8.46', /versionName\s+["']10\.8\.46["']/.test(gradle));
ok('Servidor aceita tripulação com data e voo em linhas separadas', /pode colocar data, voo e tripulação em linhas separadas/.test(server));
ok('Parser client normaliza tripulações quebradas em linhas separadas', /Tripulações do AIMS podem vir quebradas em linhas separadas/.test(aims));
ok('Servidor inclui parser estruturado do calendário iFlight Web DOM', /parseIFlightStructuredCalendarV10846/.test(server));
ok('Android captura JSON estruturado do Roster Calendar DOM', /iflight-web-calendar-dom-v10846/.test(main));
ok('Android cria marcador __CREWCHECK_IFLIGHT_CALENDAR_JSON__', /__CREWCHECK_IFLIGHT_CALENDAR_JSON__/.test(main));
ok('Web usa classes específicas para data e período', /cc-roster-day-number-desktop/.test(results) && /cc-roster-period-time-desktop/.test(results));
ok('CSS ultra compacto reduz período/data no desktop', /WEB ultra compacto/.test(css) && /cc-roster-period-time-desktop/.test(css));
ok('Script npm validate:10846 configurado', /validate:10846/.test(JSON.stringify(pkg.scripts || {})));

if(process.exitCode){ process.exit(process.exitCode); }
console.log('\nCrewCheck v10.8.46 validado com sucesso.');
