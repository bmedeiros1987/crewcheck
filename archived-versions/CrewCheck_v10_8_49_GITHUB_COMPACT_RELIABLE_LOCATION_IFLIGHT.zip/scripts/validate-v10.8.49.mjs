import fs from 'node:fs';

const mustContain = [
  ['package.json', '"version": "10.8.49"'],
  ['server.mjs', 'fetchGoogleRoutesWithFallbackAuth'],
  ['server.mjs', 'computeLegacyDirectionsPlan'],
  ['server.mjs', 'GOOGLE_ROUTES_API_KEY'],
  ['client/src/components/premium/Dashboard.tsx', 'requestCrewCheckNativeCurrentLocation'],
  ['client/src/pages/Home.tsx', 'requestCrewCheckCurrentLocation'],
  ['android-wrapper/app/src/main/java/com/crewcheck/app/MainActivity.java', 'pendingNativeLocationCallbackId'],
  ['android-wrapper/app/src/main/java/com/crewcheck/app/MainActivity.java', 'return true;'],
  ['android-wrapper/app/build.gradle', 'versionCode 10849'],
  ['android-wrapper/app/build.gradle', "versionName '10.8.49'"],
];

let ok = true;
for (const [file, token] of mustContain) {
  if (!fs.existsSync(file)) {
    console.error(`Arquivo ausente: ${file}`);
    ok = false;
    continue;
  }
  const text = fs.readFileSync(file, 'utf8');
  if (!text.includes(token)) {
    console.error(`Token ausente em ${file}: ${token}`);
    ok = false;
  }
}

if (!ok) process.exit(1);
console.log('CrewCheck v10.8.49 validado: localização Android/Web, permissões reliable, Google Routes/Directions fallback e iFlight compacto OK.');
