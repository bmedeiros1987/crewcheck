# CrewCheck v10.8.47 — Premium Trust Edition

## Objetivo

Deixar o CrewCheck mais premium e mais confiável, com foco em Saída Inteligente real, Google Routes/Maps, transporte público, auditoria de cálculos e estabilidade no Android.

## Saída Inteligente Reliable

- Botão de localização prioriza a ponte nativa Android.
- O Android busca GPS/Network/Passive Location pelo LocationManager.
- O front usa fallback para `navigator.geolocation` quando a ponte nativa não retorna.
- O backend calcula rota por `Google Routes API` quando `GOOGLE_MAPS_API_KEY` ou `GOOGLE_ROUTES_API_KEY` estiver configurada.
- Modo Auto calcula carro e transporte público e retorna `routeOptions`.
- Modo Transporte usa `TRANSIT` com chegada antes da apresentação/margem.
- Fallback local conservador quando a API não estiver configurada.
- Link seguro para abrir no Google Maps se o app precisar de confirmação externa.

## Transporte público

- Usa `travelMode: TRANSIT` no backend.
- Solicita preferência por menos transferências.
- Retorna passos de transporte público quando o Google disponibiliza linhas/estações/horários.
- A qualidade depende da cobertura regional do Google Maps e dados de transporte disponíveis para a região.

## Permissões

- Localização: `ACCESS_FINE_LOCATION` e `ACCESS_COARSE_LOCATION`.
- Notificação: `POST_NOTIFICATIONS` para Android 13+.
- O app mostra status de permissão no Cockpit.

## Configuração Render

Adicionar no Render, se quiser trânsito e transporte público reais:

```env
GOOGLE_MAPS_API_KEY=
GOOGLE_ROUTES_API_KEY=
CREWCHECK_COMMUTE_CACHE_TTL_MS=120000
CREWCHECK_LOCAL_TIMEZONE=America/Sao_Paulo
```

## Validação

```bash
node --check server.mjs
node scripts/validate-v10.8.47.mjs
```
