# CrewCheck v10.8.45 — GitHub Compact Calendar + Tripulação + Web

Versão compacta para GitHub com menos de 100 arquivos, baseada na v10.8.44.

## Correções principais

- Escala web mais compacta em desktop: data lateral menor, cards mais densos e grade de status escondida em telas menores.
- Parser de Tripulações reforçado:
  - lê seções `Tripulações`, `Tripulação`, `Tripulacao`, `Crew List`, `Crew Complement` e `Crew Members`;
  - cruza por data e número do voo;
  - aceita nomes quebrados em várias linhas;
  - aceita CP/FO com nome simples;
  - marca primeiro CCM como chefe efetivo.
- Salário/chefia: marca `ccmBonusStatus` quando o tripulante salvo no perfil é o primeiro CCM listado.
- iFlight Calendar Pull privado:
  - Android tenta capturar o calendário completo dentro do WebView antes do PDF;
  - envia `calendarText` ao app via bridge nativa;
  - backend interpreta o texto pelo endpoint `/api/parse-iflight-calendar`;
  - PDF/Roster Report continua como fallback quando o calendário do iFlight não expõe texto suficiente.

## Android

- Package mantido: `com.crewcheck.app`.
- `versionCode`: 10845.
- `versionName`: 10.8.45.

## Validação

```bash
node --check server.mjs
node scripts/validate-v10.8.45.mjs
```
