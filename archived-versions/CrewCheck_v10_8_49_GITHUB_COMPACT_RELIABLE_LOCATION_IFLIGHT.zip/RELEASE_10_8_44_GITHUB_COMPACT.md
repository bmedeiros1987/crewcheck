# CrewCheck v10.8.44 — GitHub Compact

Pacote compacto com menos de 100 arquivos para facilitar upload no GitHub.

Mantido:
- Código web/client.
- Backend `server.mjs`.
- Wrapper Android `android-wrapper`.
- Workflow GitHub Actions para gerar APK/AAB.
- Correções v10.8.44: tripulação, adicional de chefe CCM, UI premium, safe area, permissões, escala web compacta.

Removido do pacote compacto:
- Históricos antigos de hotfix/release em Markdown.
- Pasta `private/` e apostila interna, para reduzir tamanho e evitar envio de material privado ao GitHub.

Versão:
- Package: `com.crewcheck.app`
- VersionName: `10.8.44`
- VersionCode: `10844`
