#!/data/data/com.termux/files/usr/bin/bash
set -e

ZIP_NAME="CrewCheck_v10_8_92_GITHUB_COMPACT_CHIEF_OTP_PREMIUM.zip"
GITHUB_TOKEN="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"
GITHUB_USER="bmedeiros1987"
REPO_NAME="crewcheck"
BRANCH="main"
WORK_UPLOAD="$HOME/crewcheck_upload"
WORK_REPO="$HOME/crewcheck_repo"

pkg update -y || true
pkg install -y unzip rsync git

rm -rf "$WORK_UPLOAD" "$WORK_REPO"
mkdir -p "$WORK_UPLOAD" "$WORK_REPO"

cp "/sdcard/Download/$ZIP_NAME" "$WORK_UPLOAD/"
cd "$WORK_UPLOAD"
unzip -o "$ZIP_NAME"

PROJECT_DIR="$(find . -maxdepth 2 -name package.json -printf '%h\n' | head -n 1)"
if [ -z "$PROJECT_DIR" ]; then
  echo "Não encontrei package.json dentro do ZIP."
  exit 1
fi

cd "$WORK_REPO"
git init
git checkout -b "$BRANCH"
git config user.name "Bruno Saraiva"
git config user.email "bmedeiros1987@gmail.com"
rsync -av --delete --exclude '.git' "$WORK_UPLOAD/$PROJECT_DIR/" "$WORK_REPO/"

git add .
git commit -m "CrewCheck v10.8.92 - chefe de cabine premium OTP + gerais do voo" || true
git remote add origin "https://${GITHUB_USER}:${GITHUB_TOKEN}@github.com/${GITHUB_USER}/${REPO_NAME}.git"
git push -u origin "$BRANCH" --force

echo "Upload concluído para https://github.com/${GITHUB_USER}/${REPO_NAME}"
