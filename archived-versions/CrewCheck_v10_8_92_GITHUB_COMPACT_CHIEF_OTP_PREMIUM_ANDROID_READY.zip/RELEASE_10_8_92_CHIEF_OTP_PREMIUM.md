# CrewCheck v10.8.92 — Chefe de Cabine Premium / OTP + Gerais do Voo

## Destaques
- Formulário do Chefe de Cabine reorganizado em **Relatório OTP** e **Gerais do Voo**.
- Horários com **digitação manual**, botão **Agora**, preenchimento **Auto/Escala/API** e botão **Limpar**.
- Removidos do fluxo principal os horários desnecessários de pushback; foco em apresentação, embarque da tripulação, limpeza, primeiros/últimos passageiros, acomodação, porta, decolagem, pouso e desembarques.
- **QTA** em porcentagem por padrão, com opção de leitura por **fração** (1/2, 5/8, 3/4, 7/8, F).
- **QTU desabilitado por padrão**, podendo ser habilitado nas configurações.
- Configurações premium para **quantidade de tanques**, nomes dos tanques e modo de leitura.
- Novo bloco de **assistências e desembarque**: menores, MAAS, cadeirantes, tipo de cadeira e número de cadeiras no desembarque.
- Alertas locais no pouso para passageiros especiais.
- Ocorrências com opção de **apagar** quando preenchidas por engano.
- Exportação premium em **PDF pesquisável**, cópia do relatório e compartilhamento preparado para **e-mail** e **WhatsApp**.
- Ajustes visuais para melhor legibilidade do formulário em diferentes temas.

## Android / versão
- `versionCode 10892`
- `versionName 10.8.92`
