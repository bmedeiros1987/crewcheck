# CrewCheck v10.8.93 — Token Safe GitHub

## Correção
- Removidos scripts com token do pacote enviado ao GitHub.
- Novo fluxo Termux solicita o token em tempo de execução, sem gravar o token no repositório.
- Evita bloqueio do GitHub por push protection / repository rule violations.

## Base mantida
- Chefe de Cabine Premium com Relatório OTP e Gerais do Voo.
- QTA em porcentagem por padrão e frações opcionais.
- QTU desabilitado por padrão, habilitável nas configurações.
- Exportação PDF pesquisável e compartilhamento.
- Workflow Android para gerar APK/AAB no GitHub Actions.

## Versão
- App: 10.8.93
- Android: versionCode 10893 / versionName 10.8.93
