# CrewCheck v11.1.103 — UI Hardening / Design Audit Total

Versão focada exclusivamente em estabilização visual e padronização do design, preservando o motor canônico de escala da v11.1.101/102.

## Correções principais

- Corrige regressão do logo gigante na web: classes do menu lateral Premium agora têm CSS travado, com dimensões máximas para imagem/logo.
- Implementa App Shell robusto para Home/Results: sidebar, conteúdo, drawer mobile, fundo, espaçamento e responsividade.
- Padroniza menu lateral Premium em modo claro, escuro e automático.
- Padroniza botões, cards, inputs, speed dial e navegação inferior.
- Aplica fail-safe para impedir estouro horizontal e imagens fora de proporção.
- Mantém BIDS/PBS, motor canônico da escala, cache/reimportação anti-teletransporte, radar, alertas, regulamentação automática por ACT/função, meteorologia, WhatsApp/Infobip e FreeCurrency.

## Validação recomendada

1. Abrir `/` no desktop e mobile.
2. Confirmar que o logo fica apenas no menu, sem ocupar a tela.
3. Testar menu expandido/retraído e drawer mobile.
4. Abrir Escala, Radar, Meteorologia, Despertador Premium, Configurações e BIDS.
5. Testar claro/escuro/automático.
6. Reimportar a escala ouro de julho se houver cache antigo.
