# CrewCheck v11.0.21 — iPad, PDF oficial e nomenclatura Extra

## Ajustes principais

- Reforço no fluxo de importação por PDF oficial para iPad/Web, mantendo o iFlight automático restrito ao ambiente autorizado/admin.
- Correção de nomenclatura: voos PS/passagem deixam de aparecer como "Vivo de Extra" e passam a aparecer como "Extra" ou "Extra / passageiro".
- Ajustes de texto no sistema para evitar confusão com modo automático em iPad.
- Mantidas as regras de CPF inteligente, modo demonstração, tela dedicada de assinatura e manual web da v11.0.20.
- Versão Android atualizada para 11.0.21 / versionCode 11021.

## Observações

No iPad/Web comum, o portal iFlight pode bloquear automação direta por sessão corporativa, navegador, download ou restrição do próprio portal. O fluxo está mantido como importação de PDF oficial, com o iFlight automático apenas em validação restrita/admin.
