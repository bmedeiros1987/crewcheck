import { bootCrewCheckHotelsGymsPanel } from './lib/crewcheckHotelsGyms';
import './lib/crewcheckPremiumRuntime';
import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

createRoot(document.getElementById("root")!).render(<App />);
bootCrewCheckHotelsGymsPanel();
