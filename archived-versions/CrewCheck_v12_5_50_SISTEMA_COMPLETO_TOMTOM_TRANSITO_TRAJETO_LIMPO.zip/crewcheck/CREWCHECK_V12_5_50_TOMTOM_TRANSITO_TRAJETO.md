# CrewCheck v12.5.50 — TomTom API para trânsito e trajeto

## Incluído

- TomTom Routing passa a ser provedor principal para carro/moto/a pé quando `TOMTOM_API_KEY` estiver configurada.
- Cálculo de rota com `traffic=true` e `computeTravelTimeFor=all`.
- TomTom Traffic Flow para leitura de velocidade atual/free-flow e atraso do trecho.
- Saída Inteligente mostra fonte/estado do trânsito nos cards de rota.
- Endpoints internos:
  - `/api/tomtom/status`
  - `/api/tomtom/route`
  - `/api/tomtom/traffic`
- Fallback preservado: Google Routes/Directions, OSRM/OpenStreetMap e estimativa CrewCheck.

## Variáveis Render

```env
TOMTOM_API_KEY=
TOMTOM_ROUTING_ENABLED=true
TOMTOM_TRAFFIC_ENABLED=true
TOMTOM_TRAFFIC_FLOW_ENABLED=true
TOMTOM_PREFER_FOR_DRIVE=true
CREWCHECK_MAPS_PROVIDER=tomtom-traffic
CREWCHECK_TRAFFIC_PROVIDER=tomtom
CREWCHECK_MAPS_OPEN_PROVIDER=tomtom
```

## Segurança

A chave TomTom deve ficar somente no Render. O ZIP não contém chave.
