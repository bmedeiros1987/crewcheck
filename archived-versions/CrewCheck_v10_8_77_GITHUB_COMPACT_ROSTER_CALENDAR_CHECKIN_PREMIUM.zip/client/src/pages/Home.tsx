import { useCallback, useEffect, useRef, useState, type ChangeEvent, type DragEvent, type ReactNode, type RefObject } from 'react';
import { jsPDF } from 'jspdf';
import { useLocation } from 'wouter';
import {
  AlertTriangle,
  ArrowLeft,
  BarChart3,
  Bell,
  Building2,
  CalendarDays,
  Camera,
  Car,
  CheckCircle2,
  ChevronRight,
  CloudUpload,
  Database,
  Download as DownloadIcon,
  Dumbbell,
  FileText,
  FolderOpen,
  ExternalLink,
  GraduationCap,
  History,
  Home as HomeIcon,
  Loader2,
  Lock,
  Mail,
  Languages,
  Menu,
  Monitor,
  Moon,
  Search,
  SlidersHorizontal,
  MapPin,
  Navigation,
  Clock,
  Bus,
  LogOut,
  Plane,
  Radar,
  RefreshCw,
  Settings,
  Shield,
  Sparkles,
  StickyNote,
  Sun,
  TrendingUp,
  Trash2,
  Upload,
  UserRound,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { analyzeCompliance, getGymRecommendations, type ComplianceResult, type GymRecommendation } from '@/lib/complianceEngine';
import { detectAndMarkLayovers } from '@/lib/layoverDetection';
import { normalizeRosterSchedule } from '@/lib/rosterNormalizer';
import type { CrewRoleSelection } from '@/lib/actRules';
import { parsePDF, type CrewRoster } from '@/lib/pdfParser';
import { getStoredUser, getToken, logout } from '@/lib/authClient';
import { syncPendingRosters, getPendingOfflineCount } from '@/lib/offlineSync';
import { getDatabaseStatus, listSavedRosters, openSavedRoster, type DatabaseStatus, type SavedRosterSummary } from '@/lib/databaseClient';
import { exportReport } from '@/lib/pdfExport';
import { applyDocumentLanguage, getSavedLanguage, saveCrewLanguage, type CrewLanguage } from '@/lib/i18n';
import { downloadCalendarFile, generateICalendar } from '@/lib/calendarExport';
import {
  connectGoogleCalendar,
  hasGoogleCalendarToken,
  hasGoogleClientIdFromEnv,
  getGoogleClientIdOverride,
  isGoogleCalendarConfigured,
  listGoogleCalendars,
  loadGoogleCalendarSettings,
  saveGoogleCalendarSettings,
  saveGoogleClientIdOverride,
  type GoogleCalendarOption,
  type GoogleCalendarSettings,
  type GoogleCalendarSyncMode,
} from '@/lib/googleCalendarSync';
import Dashboard from '../components/premium/Dashboard';
import CalendarView from '../components/premium/CalendarView';
import IFlightIntegrationView from '../components/premium/IFlightIntegrationView';

type HomeView = 'home' | 'import' | 'history' | 'calendar' | 'iflight' | 'flightboard' | 'departure' | 'routine' | 'perdiem' | 'salary' | 'c32f' | 'settings' | 'support' | 'notes' | 'more';
type CrewThemeMode = 'light' | 'dark' | 'system';
type ResultsView = 'summary' | 'roster' | 'alerts' | 'irregularities' | 'gym' | 'fatigue' | 'metrics' | 'glossary' | 'statistics' | 'settings' | 'manual';

type NativePdfPayload = {
  ok?: boolean;
  filename?: string;
  sourceFileName?: string;
  dataBase64?: string;
};

const RESULT_VIEWS = new Set<ResultsView>(['summary', 'roster', 'alerts', 'irregularities', 'gym', 'fatigue', 'metrics', 'glossary', 'statistics', 'settings', 'manual']);

const C32F_ADMIN_EMAIL = 'bmedeiros1987@gmail.com';
const APP_VERSION = '10.8.77';

function normalizeEmail(value?: string | null): string {
  return String(value || '').trim().toLowerCase();
}

function isC32FAcademyAdmin(user: ReturnType<typeof getStoredUser>): boolean {
  return normalizeEmail(user?.email) === C32F_ADMIN_EMAIL;
}

async function fileToBase64Payload(file: File): Promise<string> {
  const buffer = await new Promise<ArrayBuffer>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => reader.result instanceof ArrayBuffer ? resolve(reader.result) : reject(new Error('Arquivo inválido.'));
    reader.onerror = () => reject(reader.error || new Error('Falha ao ler arquivo.'));
    reader.readAsArrayBuffer(file);
  });
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

function base64ToPdfFile(filename: string, dataBase64: string): File {
  const binary = atob(dataBase64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return new File([bytes], filename || 'iFlight_RosterReport.pdf', { type: 'application/pdf' });
}

async function parsePdfViaServer(file: File): Promise<CrewRoster> {
  const dataBase64 = await fileToBase64Payload(file);
  const response = await fetch('/api/parse-pdf', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ filename: file.name, dataBase64 }),
  });
  const payload = await response.json().catch(() => null);
  if (!response.ok || !payload?.ok || !payload?.roster) {
    throw new Error(payload?.message || payload?.detail || 'Parser servidor indisponível.');
  }
  return payload.roster as CrewRoster;
}

function hasCurrentRosterSession() {
  return Boolean(sessionStorage.getItem('crewcheck_roster') && sessionStorage.getItem('crewcheck_compliance'));
}

function setInitialResultsView(view?: ResultsView) {
  if (view && RESULT_VIEWS.has(view)) sessionStorage.setItem('crewcheck_initial_view', view);
}


type SessionRosterBundle = {
  roster: CrewRoster;
  compliance: ComplianceResult;
  gym: GymRecommendation[];
};

type LocalProfileSettings = {
  displayName: string;
  company: string;
  base: string;
  rank: string;
};

function loadLocalProfileSettings(): LocalProfileSettings {
  try {
    return {
      displayName: localStorage.getItem('crewcheck_profile_display_name') || '',
      company: localStorage.getItem('crewcheck_profile_company') || '',
      base: localStorage.getItem('crewcheck_profile_base') || '',
      rank: localStorage.getItem('crewcheck_profile_rank') || '',
    };
  } catch {
    return { displayName: '', company: '', base: '', rank: '' };
  }
}

function saveLocalProfileSettings(settings: LocalProfileSettings): LocalProfileSettings {
  const cleaned = {
    displayName: settings.displayName.trim(),
    company: settings.company.trim(),
    base: settings.base.trim().toUpperCase(),
    rank: settings.rank.trim(),
  };
  try {
    localStorage.setItem('crewcheck_profile_display_name', cleaned.displayName);
    localStorage.setItem('crewcheck_profile_company', cleaned.company);
    localStorage.setItem('crewcheck_profile_base', cleaned.base);
    localStorage.setItem('crewcheck_profile_rank', cleaned.rank);
  } catch {
    // mantém estado em memória quando storage não está disponível
  }
  return cleaned;
}

function loadCrewThemeMode(): CrewThemeMode {
  try {
    const saved = localStorage.getItem('crewcheck_theme_mode');
    return saved === 'light' || saved === 'dark' || saved === 'system' ? saved : 'system';
  } catch {
    return 'system';
  }
}

function getEffectiveCrewTheme(mode: CrewThemeMode): 'light' | 'dark' {
  if (mode === 'light') return 'light';
  if (mode === 'dark') return 'dark';
  try {
    return window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  } catch {
    return 'light';
  }
}

function saveAndApplyCrewThemeMode(mode: CrewThemeMode): CrewThemeMode {
  try {
    localStorage.setItem('crewcheck_theme_mode', mode);
    const effective = getEffectiveCrewTheme(mode);
    document.documentElement.dataset.crewThemeMode = mode;
    document.documentElement.dataset.crewTheme = effective;
    document.documentElement.classList.toggle('dark', effective === 'dark');
    document.documentElement.style.colorScheme = effective;
    window.dispatchEvent(new CustomEvent('crewcheck:theme-change', { detail: { mode, effective } }));
  } catch {
    // mantém estado visual padrão quando storage não estiver disponível
  }
  return mode;
}

function readCurrentRosterBundle(): SessionRosterBundle | null {
  try {
    const rosterRaw = sessionStorage.getItem('crewcheck_roster');
    const complianceRaw = sessionStorage.getItem('crewcheck_compliance');
    if (!rosterRaw || !complianceRaw) return null;
    return {
      roster: JSON.parse(rosterRaw) as CrewRoster,
      compliance: JSON.parse(complianceRaw) as ComplianceResult,
      gym: JSON.parse(sessionStorage.getItem('crewcheck_gym') || '[]') as GymRecommendation[],
    };
  } catch {
    return null;
  }
}

type RosterChangeSummaryV10867 = {
  samePeriod: boolean;
  added: number;
  removed: number;
  changed: number;
  duplicatesIgnored: number;
  message: string;
};

function rosterComparableKeyV10867(day: CrewRoster['days'][number]): string {
  const code = String(day.pairingCode || day.type || '').toUpperCase();
  const legs = (day.legs || []).map((leg) => [leg.flightNumber, leg.origin, leg.destination].join('-')).join('+');
  return `${day.date}|${code}|${legs || day.type}`;
}

function rosterComparableValueV10867(day: CrewRoster['days'][number]): string {
  const legs = (day.legs || []).map((leg) => [leg.flightNumber, leg.origin, leg.destination, leg.departureTime, leg.arrivalTime, leg.workType].join('-')).join('+');
  return [day.date, day.type, day.pairingCode, day.dutyReport || '', day.dutyDebrief || '', legs].join('|');
}

function buildRosterChangeSummaryV10867(previous: CrewRoster | null | undefined, next: CrewRoster): RosterChangeSummaryV10867 | null {
  if (!previous?.days?.length || !next?.days?.length) return null;
  const samePeriod = Number(previous.month) === Number(next.month) && Number(previous.year) === Number(next.year);
  if (!samePeriod) return null;
  const oldMap = new Map<string, string>();
  previous.days.forEach((day) => oldMap.set(rosterComparableKeyV10867(day), rosterComparableValueV10867(day)));
  const newMap = new Map<string, string>();
  let duplicatesIgnored = 0;
  next.days.forEach((day) => {
    const key = rosterComparableKeyV10867(day);
    const value = rosterComparableValueV10867(day);
    if (newMap.get(key) === value) duplicatesIgnored += 1;
    newMap.set(key, value);
  });
  let added = 0;
  let removed = 0;
  let changed = 0;
  for (const [key, value] of newMap) {
    if (!oldMap.has(key)) added += 1;
    else if (oldMap.get(key) !== value) changed += 1;
  }
  for (const key of oldMap.keys()) if (!newMap.has(key)) removed += 1;
  const message = added || removed || changed
    ? `Alterações da escala: ${added} nova(s), ${changed} alterada(s), ${removed} removida(s); duplicidades ignoradas: ${duplicatesIgnored}.`
    : `Nenhuma alteração operacional detectada; duplicidades ignoradas: ${duplicatesIgnored}.`;
  return { samePeriod, added, removed, changed, duplicatesIgnored, message };
}




type CrewCheckPermissionStatus = { location?: boolean; notifications?: boolean };
type CrewCheckNativeLocationPayload = { ok?: boolean; lat?: number; lng?: number; accuracy?: number; provider?: string; time?: number; error?: string; permission?: boolean; callbackId?: string };

type CrewCheckNativeLike = {
  openExternal?: (url: string) => boolean | void;
  requestLocation?: () => boolean | void;
  requestCurrentLocation?: (callbackId: string) => boolean | void;
  requestNotifications?: () => boolean | void | Promise<boolean | void>;
  permissionStatus?: () => CrewCheckPermissionStatus | string | null;
  notify?: (title: string, body: string) => boolean | void;
  scheduleNotification?: (title: string, body: string, epochMillis: number) => boolean | void;
};

function getCrewCheckNative(): CrewCheckNativeLike | undefined {
  const win = window as unknown as { CrewCheckNative?: CrewCheckNativeLike; CrewCheckPremium?: CrewCheckNativeLike; AndroidCrewCheckNative?: CrewCheckNativeLike };
  return win.CrewCheckPremium || win.CrewCheckNative || win.AndroidCrewCheckNative;
}

function readCrewCheckPermissionStatus(): CrewCheckPermissionStatus {
  try {
    const win = window as unknown as { __crewcheckNativePermissionStatus?: CrewCheckPermissionStatus };
    const native = getCrewCheckNative();
    const raw = native?.permissionStatus?.();
    const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (parsed && typeof parsed === 'object') return { ...(win.__crewcheckNativePermissionStatus || {}), ...parsed };
    if (win.__crewcheckNativePermissionStatus) return win.__crewcheckNativePermissionStatus;
  } catch {
    // segue para fallback web
  }
  return {
    location: undefined,
    notifications: 'Notification' in window ? Notification.permission === 'granted' : undefined,
  };
}

function requestCrewCheckLocationPermission(): boolean {
  try {
    const native = getCrewCheckNative();
    if (native?.requestLocation) return Boolean(native.requestLocation());
  } catch {
    // Localização é opcional; se o usuário negar, a saída inteligente mostra aviso.
  }
  return false;
}

function requestCrewCheckCurrentLocation(timeoutMs = 16000): Promise<CrewCheckNativeLocationPayload | null> {
  return new Promise((resolve) => {
    try {
      const native = getCrewCheckNative();
      if (!native?.requestCurrentLocation) {
        resolve(null);
        return;
      }
      const callbackId = `loc_${Date.now()}_${Math.random().toString(36).slice(2)}`;
      let done = false;
      const cleanup = () => window.removeEventListener('crewcheck:native-location-result', listener as EventListener);
      const finish = (payload: CrewCheckNativeLocationPayload | null) => {
        if (done) return;
        done = true;
        cleanup();
        resolve(payload);
      };
      const listener = (event: Event) => {
        const detail = (event as CustomEvent<CrewCheckNativeLocationPayload>).detail || {};
        if (detail.callbackId && detail.callbackId !== callbackId) return;
        finish(detail);
      };
      window.addEventListener('crewcheck:native-location-result', listener as EventListener);
      native.requestCurrentLocation(callbackId);
      window.setTimeout(() => finish(null), timeoutMs);
    } catch {
      resolve(null);
    }
  });
}

function requestCrewCheckBrowserLocation(timeoutMs = 17000): Promise<CrewCheckNativeLocationPayload> {
  return new Promise((resolve) => {
    if (!('geolocation' in navigator)) {
      resolve({ ok: false, error: 'Localização indisponível neste navegador. Use HTTPS ou libere localização para o app.' });
      return;
    }
    navigator.geolocation.getCurrentPosition((position) => {
      resolve({
        ok: true,
        lat: position.coords.latitude,
        lng: position.coords.longitude,
        accuracy: position.coords.accuracy,
        provider: 'browser-geolocation',
        time: position.timestamp,
      });
    }, (geoError) => {
      resolve({ ok: false, permission: geoError?.code === 1, error: geoError?.code === 1 ? 'Permita a localização no aviso do navegador/Android.' : 'Não consegui obter sua localização atual. Ative GPS/alta precisão e tente novamente.' });
    }, { enableHighAccuracy: true, timeout: timeoutMs, maximumAge: 30_000 });
  });
}

function requestCrewCheckNotificationPermission(): boolean {
  try {
    const native = getCrewCheckNative();
    if (native?.requestNotifications) return Boolean(native.requestNotifications());
    if ('Notification' in window && Notification.permission === 'default') {
      void Notification.requestPermission();
      return false;
    }
    return 'Notification' in window && Notification.permission === 'granted';
  } catch {
    return false;
  }
}

function scheduleCrewCheckNotification(title: string, body: string, epochMillis: number): boolean {
  try {
    const native = getCrewCheckNative();
    if (native?.scheduleNotification) {
      native.scheduleNotification(title, body, epochMillis);
      return true;
    }
  } catch {
    return false;
  }
  return false;
}

function notifyCrewCheck(title: string, body: string, key?: string): void {
  try {
    if (key) {
      const todayKey = new Date().toISOString().slice(0, 10);
      const storageKey = `crewcheck_notification_${key}_${todayKey}`;
      if (localStorage.getItem(storageKey) === '1') return;
      localStorage.setItem(storageKey, '1');
    }
    const native = getCrewCheckNative();
    if (native?.notify) {
      native.notify(title, body);
      return;
    }
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(title, { body, tag: key || title });
    }
  } catch {
    // Silencioso por privacidade e compatibilidade.
  }
}

type DashboardNextEvent = {
  title: string;
  time: string;
  endTime: string;
  date: string;
  route?: string;
  status?: string;
  gate?: string;
  terminal?: string;
  countdown?: string;
  source?: string;
  flightNumber?: string;
  isFlight?: boolean;
  targetIso?: string;
  smartDepartureTargetIso?: string;
  smartDepartureRule?: string;
  origin?: string;
  destination?: string;
  base?: string;
  requiresDeparture?: boolean;
};


type RadarPrivateStatus = {
  ok?: boolean;
  flightNumber?: string | null;
  status?: string | null;
  gate?: string | null;
  terminal?: string | null;
  scheduledDeparture?: string | null;
  estimatedDeparture?: string | null;
  scheduledArrival?: string | null;
  estimatedArrival?: string | null;
  confidence?: string | null;
  updatedAt?: string | null;
  message?: string | null;
};

function radarDateFromNextEvent(event?: DashboardNextEvent): string {
  if (event?.targetIso && /^\d{4}-\d{2}-\d{2}/.test(event.targetIso)) return event.targetIso.slice(0, 10);
  const text = String(event?.date || '');
  const match = text.match(/(\d{1,2})[\/.-](\d{1,2})[\/.-]?(\d{2,4})?/);
  if (!match) return new Date().toISOString().slice(0, 10);
  const day = match[1].padStart(2, '0');
  const month = match[2].padStart(2, '0');
  const year = match[3] ? (match[3].length === 2 ? `20${match[3]}` : match[3]) : String(new Date().getFullYear());
  return `${year}-${month}-${day}`;
}

function radarStatusLine(status?: RadarPrivateStatus | null): string {
  const parts = [
    status?.status ? `Status: ${status.status}` : '',
    status?.gate ? `Portão: ${status.gate}` : '',
    status?.terminal ? `Terminal: ${status.terminal}` : '',
    status?.estimatedDeparture ? `Previsto: ${status.estimatedDeparture}` : '',
  ].filter(Boolean);
  return parts.length ? parts.join(' · ') : 'Sem portão confirmado ainda.';
}

function hasUsefulRadarStatus(status?: RadarPrivateStatus | null): boolean {
  return Boolean(status?.status || status?.gate || status?.terminal || status?.estimatedDeparture || status?.scheduledDeparture);
}

function buildDashboardNextEvent(bundle: SessionRosterBundle | null, saved?: SavedRosterSummary): DashboardNextEvent {
  const fallback: DashboardNextEvent = saved
    ? {
        title: saved.sourceFileName || 'Escala salva',
        time: 'Abrir',
        endTime: 'histórico',
        date: `${monthLabel(saved.month, saved.year)} · ${saved.base || 'Base'}`,
        status: 'Salva',
        base: saved.base || undefined,
        countdown: '—',
        source: 'Histórico CrewCheck',
        isFlight: false,
      }
    : {
        title: 'Importe sua escala',
        time: 'PDF',
        endTime: 'novo',
        date: 'PDF exportado pelo CrewTopia, iFlight ou AIMS',
        status: 'PDF',
        countdown: '—',
        source: 'Importação segura',
        isFlight: false,
      };

  const roster = bundle?.roster;
  if (!roster?.days?.length) return fallback;

  const now = Date.now();
  const candidates = [...roster.days]
    .map((day, index) => {
      const firstLeg = day.legs?.[0];
      const lastLeg = day.legs?.[day.legs.length - 1];
      const range = dashboardDutyRange(day, firstLeg, lastLeg);
      const base = String(day.base || roster.base || '').toUpperCase();
      const activation = dashboardDepartureActivation(day, firstLeg);
      const start = activation?.startTime || range.start || firstLeg?.departureTime || day.dutyReport || '00:00';
      const target = dashboardTargetDate(day.date, start);
      const route = firstLeg && lastLeg ? `${firstLeg.origin} → ${lastLeg.destination}` : (activation?.title || day.pairingCode || day.type || 'Programação');
      const title = firstLeg ? route : (activation?.title || readableDutyTitle(day.type, day.pairingCode));
      const requiresDeparture = activation?.requiresDeparture ?? dashboardRequiresHomeDeparture(day, firstLeg, base);
      const smart = dashboardSmartDepartureTarget(day, firstLeg, start, base);
      return { day, firstLeg, lastLeg, range: { ...range, start }, route, title, target, smartTarget: smart.target, smartRule: smart.rule, index, base, requiresDeparture, activation };
    })
    .sort((a, b) => a.target.getTime() - b.target.getTime() || a.index - b.index);

  const next = candidates.find((item) => item.target.getTime() >= now) || candidates[0];
  if (!next) return fallback;
  const operationalText = `${next.day.type || ''} ${next.day.pairingCode || ''} ${next.day.rawText || ''} ${next.title || ''} ${next.route || ''}`.toUpperCase();
  const effectiveRequiresDeparture = Boolean(next.requiresDeparture || ['ASB', 'RES', 'RESERVA', 'AIRPORT STAND', 'LA', 'VOO ACIONADO', 'REUNIÃO', 'MEETING', 'CRM', 'CBF', 'EMER', 'CHECK', 'SIMULADOR'].some((token) => operationalText.includes(token)));

  return {
    title: next.title,
    route: next.route,
    time: next.range.start || '—',
    endTime: next.range.end || (isDashboardReserveOrStandby(next.day) ? 'fim não lido' : '—'),
    date: `${next.day.dayOfWeek || ''} ${next.day.date}`.trim(),
    status: next.firstLeg ? 'Programado' : (next.activation?.status || readableDutyTitle(next.day.type, next.day.pairingCode)),
    gate: next.firstLeg ? '—' : undefined,
    terminal: next.firstLeg ? '—' : undefined,
    countdown: effectiveRequiresDeparture ? countdownToRosterTime(next.day.date, next.range.start) : 'Sem deslocamento',
    targetIso: next.target.toISOString(),
    smartDepartureTargetIso: next.smartTarget?.toISOString?.() || next.target.toISOString(),
    smartDepartureRule: next.smartRule,
    source: next.firstLeg ? 'Escala atual · Radar CrewCheck quando disponível' : 'Escala atual',
    flightNumber: next.firstLeg?.flightNumber || undefined,
    isFlight: Boolean(next.firstLeg),
    origin: next.firstLeg?.origin || next.base,
    destination: next.lastLeg?.destination || undefined,
    base: next.base,
    requiresDeparture: effectiveRequiresDeparture,
  };
}

function dashboardDutyRange(day: CrewRoster['days'][number], firstLeg?: CrewRoster['days'][number]['legs'][number], lastLeg?: CrewRoster['days'][number]['legs'][number]): { start: string; end: string } {
  const times = extractTimesFromText(day.rawText || '');
  const flightPresentation = firstLeg ? inferDashboardFlightPresentationTime(day, firstLeg) : '';
  const start = firstLeg ? (flightPresentation || day.dutyReport || firstLeg.departureTime || times[0] || '') : (day.dutyReport || times[0] || '');
  let end = firstLeg ? (day.dutyDebrief || lastLeg?.arrivalTime || '') : (day.dutyDebrief || '');

  if (!firstLeg && !end && times.length > 1 && !isDashboardReserveOrStandby(day)) end = times[times.length - 1];
  if (isDashboardReserveOrStandby(day) && start && end === start) end = '';
  if (!end && start && isDashboardReserveOrStandby(day)) end = inferDashboardReserveEndTime(day, start);
  if (!end && start && !isDashboardReserveOrStandby(day) && typeof day.dutyHours === 'number' && day.dutyHours > 0) end = addMinutesToDisplayTime(start, Math.round(day.dutyHours * 60));
  return { start, end };
}

function inferDashboardFlightPresentationTime(day: CrewRoster['days'][number], firstLeg?: CrewRoster['days'][number]['legs'][number]): string {
  const departure = firstLeg?.departureTime || '';
  if (!departure) return day.dutyReport || '';
  const report = day.dutyReport || '';
  const depMinutes = parseTimeToMinutes(departure);
  const reportMinutes = parseTimeToMinutes(report);
  if (report && depMinutes !== null && reportMinutes !== null) {
    const diff = depMinutes >= reportMinutes ? depMinutes - reportMinutes : depMinutes + 1440 - reportMinutes;
    if (diff >= 15 && diff <= 240) return report;
  }
  // Regra de confiança: a Escala/Cockpit só exibe apresentação quando ela veio publicada.
  // A estimativa de 1h antes fora de base fica exclusiva da Saída Inteligente.
  return '';
}

function dashboardSmartDepartureTarget(day: CrewRoster['days'][number], firstLeg: CrewRoster['days'][number]['legs'][number] | undefined, scaleStart: string, base: string): { target: Date; rule: string } {
  const scaleTarget = dashboardTargetDate(day.date, scaleStart || firstLeg?.departureTime || day.dutyReport || '');
  if (!dashboardRequiresHomeDeparture(day, firstLeg, base)) return { target: scaleTarget, rule: 'Sem saída inteligente: programação não exige deslocamento de casa' };
  if (!firstLeg?.departureTime) return { target: scaleTarget, rule: 'Saída Inteligente: programação exige deslocamento; usando horário publicado na escala' };
  const publishedReport = inferDashboardFlightPresentationTime(day, firstLeg);
  if (publishedReport) return { target: dashboardTargetDate(day.date, publishedReport), rule: 'Apresentação publicada na escala' };
  const origin = String(firstLeg.origin || '').toUpperCase();
  const homeBase = String(base || day.base || '').toUpperCase();
  if (origin && homeBase && origin !== homeBase) {
    const operational = dashboardTargetDate(day.date, addMinutesToDisplayTime(firstLeg.departureTime, -60));
    return { target: operational, rule: 'Saída Inteligente: voo fora da base sem apresentação publicada; considera 1h antes da decolagem' };
  }
  return { target: scaleTarget, rule: 'Horário publicado/visível na escala' };
}

function dashboardDepartureActivation(day: CrewRoster['days'][number], firstLeg: CrewRoster['days'][number]['legs'][number] | undefined): { requiresDeparture: boolean; startTime?: string; title?: string; status?: string } | null {
  if (firstLeg) return { requiresDeparture: true, startTime: firstLeg.departureTime, title: 'Voo', status: 'Programado' };
  const text = `${day.type || ''} ${day.pairingCode || ''} ${day.rawText || ''}`.toUpperCase();
  const hasStandby = /(HSB|HSBE|SOBREAVISO|HOME\s*STAND)/.test(text);
  const findTimeNear = (token: string) => {
    const idx = text.indexOf(token);
    if (idx < 0) return '';
    const raw = String(day.rawText || '').slice(idx, idx + 140);
    return extractTimesFromText(raw)[0] || '';
  };
  if (/(ASB|RES|RESERVA|AIRPORT\s*STAND)/.test(text)) {
    const token = text.match(/(ASB|RES|RESERVA|AIRPORT\s*STAND)/)?.[0] || 'ASB';
    return { requiresDeparture: true, startTime: findTimeNear(token) || day.dutyReport || '', title: 'Reserva', status: 'Reserva' };
  }
  if (/LA\s?\d{3,4}/.test(text)) {
    const token = text.match(/LA\s?\d{3,4}/)?.[0] || 'LA';
    return { requiresDeparture: true, startTime: findTimeNear(token) || day.dutyReport || '', title: 'Voo acionado', status: hasStandby ? 'Sobreaviso acionado' : 'Voo' };
  }
  if (/(MT|REUNI[AÃ]O|MEETING)/.test(text)) {
    const token = text.match(/(MT|REUNI[AÃ]O|MEETING)/)?.[0] || 'MT';
    return { requiresDeparture: true, startTime: findTimeNear(token) || day.dutyReport || '', title: 'Reunião', status: 'Reunião' };
  }
  if (/(C\d{2,3}F|TREINAMENTO\s+PRESENCIAL|SIMULADOR|CHECK|CRM|CBF|EMER)/.test(text) && !/(EAD|ONLINE|REMOTO|REMOTE|VIRTUAL)/.test(text)) {
    const token = text.match(/(C\d{2,3}F|TREINAMENTO\s+PRESENCIAL|SIMULADOR|CHECK|CRM|CBF|EMER)/)?.[0] || 'CRM';
    return { requiresDeparture: true, startTime: findTimeNear(token) || day.dutyReport || '', title: 'Treinamento', status: 'Treinamento' };
  }
  if (hasStandby) return { requiresDeparture: false, startTime: day.dutyReport || '', title: 'Sobreaviso', status: 'Sobreaviso' };
  return null;
}

function dashboardRequiresHomeDeparture(day: CrewRoster['days'][number], firstLeg: CrewRoster['days'][number]['legs'][number] | undefined, base: string): boolean {
  const activation = dashboardDepartureActivation(day, firstLeg);
  if (activation) return activation.requiresDeparture;
  const text = `${day.type || ''} ${day.pairingCode || ''} ${day.rawText || ''}`.toUpperCase();
  if (/(DO|DOF|DOP|DOPR|DR|OFF|VC|FERIAS|FÉRIAS|FOLGA|DESCANSO)/.test(text)) return false;
  if (/(EAD|ONLINE|REMOTO|REMOTE|VIRTUAL)/.test(text)) return false;
  if (/(ASB|RES|RESERVA|AIRPORT\s*STAND|MT|REUNI[AÃ]O|MEETING|C\d{2,3}F|TREINAMENTO\s+PRESENCIAL|SIMULADOR|CHECK|CRM|CBF|EMER)/.test(text)) return true;
  return false;
}

function inferDashboardReserveEndTime(day: CrewRoster['days'][number], start: string): string {
  const code = String(day.pairingCode || day.type || '').toUpperCase();
  const explicit = extractDashboardActivityTimes(day, code).filter((time) => time !== start);
  if (explicit.length) return explicit[explicit.length - 1];
  if (code.includes('ASB') || code.includes('RES')) return addMinutesToDisplayTime(start, 360);
  if (code.includes('HSBE')) return addMinutesToDisplayTime(start, 180);
  if (code.includes('HSB')) return addMinutesToDisplayTime(start, 180);
  return '';
}

function extractDashboardActivityTimes(day: CrewRoster['days'][number], code: string): string[] {
  const normalizedCode = String(code || '').toUpperCase();
  const raw = String(day.rawText || '');
  if (!normalizedCode || !raw) return [];
  const upper = raw.toUpperCase();
  const idx = upper.search(new RegExp(`\\b${normalizedCode}\\b`));
  if (idx < 0) return [];
  const nextIdx = findDashboardNextActivityIndex(upper, idx + normalizedCode.length);
  const segment = raw.slice(idx, nextIdx > idx ? nextIdx : Math.min(raw.length, idx + 220));
  return extractTimesFromText(segment);
}

function findDashboardNextActivityIndex(text: string, fromIndex: number): number {
  const re = /\b(HSBE|HSB|ASB|RES|CBF|EMER|CRM|CRMB|MT|C\d{2,3}F|DOF?|DOPR?|DR|OFF|VC|LA\s?\d{3,4})\b/g;
  re.lastIndex = fromIndex;
  const match = re.exec(text);
  return match ? match.index : -1;
}

function isDashboardReserveOrStandby(day: CrewRoster['days'][number]): boolean {
  const code = String(day.pairingCode || day.type || '').toUpperCase();
  return /^(HSB|HSBE|ASB|RES)$/.test(code);
}

function extractTimesFromText(text: string): string[] {
  const seen = new Set<string>();
  const times: string[] = [];
  for (const match of String(text || '').matchAll(/\b([01]?\d|2[0-3]):[0-5]\d(?:\(\+1\))?\b/g)) {
    const clean = match[0].replace('(+1)', '');
    if (!seen.has(clean)) { seen.add(clean); times.push(clean); }
  }
  return times;
}

function addMinutesToDisplayTime(time: string, minutesToAdd: number): string {
  const [hours, minutes] = String(time || '').split(':').map((part) => Number(part));
  if (!Number.isFinite(hours)) return '';
  const total = (((hours * 60 + (Number.isFinite(minutes) ? minutes : 0) + minutesToAdd) % 1440) + 1440) % 1440;
  return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
}

function dashboardTargetDate(date: string, time: string): Date {
  const target = rosterDateFromString(date);
  const [hours, minutes] = String(time || '').split(':').map((part) => Number(part));
  if (Number.isFinite(hours)) target.setHours(hours, Number.isFinite(minutes) ? minutes : 0, 0, 0);
  return target;
}

function rosterDateFromString(value: string): Date {
  const [day, month, year] = String(value || '').split(/[\/.-]/).map((part) => Number(part));
  return new Date(year || new Date().getFullYear(), (month || 1) - 1, day || 1);
}

function countdownToRosterTime(date: string, time: string): string {
  const target = rosterDateFromString(date);
  const [hours, minutes] = String(time || '').split(':').map((part) => Number(part));
  if (Number.isFinite(hours)) target.setHours(hours, Number.isFinite(minutes) ? minutes : 0, 0, 0);
  const diff = target.getTime() - Date.now();
  if (diff <= 0) return 'agora';
  const totalMinutes = Math.floor(diff / 60000);
  const days = Math.floor(totalMinutes / 1440);
  const hoursLeft = Math.floor((totalMinutes % 1440) / 60);
  const minutesLeft = totalMinutes % 60;
  if (days > 0) return `${days}d ${hoursLeft}h`;
  return `${hoursLeft}h ${String(minutesLeft).padStart(2, '0')}m`;
}

function readableDutyTitle(type: string, code?: string | null): string {
  const normalized = String(code || type || '').toUpperCase();
  if (['DO', 'DOF', 'DR', 'DOP', 'DOPR'].includes(normalized)) return 'Folga';
  if (['HSB', 'HSBE'].includes(normalized)) return 'Sobreaviso';
  if (['ASB', 'RES'].includes(normalized)) return 'Reserva';
  if (['CRM', 'C32F'].includes(normalized)) return 'Treinamento';
  return normalized || 'Programação';
}

export default function Home() {
  const [, setLocation] = useLocation();
  const [currentView, setCurrentView] = useState<HomeView>('home');
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [roleSelection, setRoleSelection] = useState<CrewRoleSelection>('auto');
  const [savedRosters, setSavedRosters] = useState<SavedRosterSummary[]>([]);
  const [savedLoading, setSavedLoading] = useState(true);
  const [autoLatestLoaded, setAutoLatestLoaded] = useState(false);
  const [dbStatus, setDbStatus] = useState<DatabaseStatus | null>(null);
  const [openingSavedId, setOpeningSavedId] = useState<string | null>(null);
  const [pendingOffline, setPendingOffline] = useState(getPendingOfflineCount());
  const [profileAvatar, setProfileAvatar] = useState(() => localStorage.getItem('crewcheck_profile_avatar') || '');
  const [profileSettings, setProfileSettings] = useState<LocalProfileSettings>(() => loadLocalProfileSettings());
  const [themeMode, setThemeMode] = useState<CrewThemeMode>(() => loadCrewThemeMode());
  const [dashboardClockTick, setDashboardClockTick] = useState(() => Date.now());
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const nativePdfImportingRef = useRef(false);

  const user = getStoredUser();
  // Reavalia a próxima programação a cada minuto para manter o cockpit vivo após o login.
  void dashboardClockTick;
  const currentRosterBundle = readCurrentRosterBundle();
  const canAccessC32FAcademy = isC32FAcademyAdmin(user);
  const dashboardNextEvent = buildDashboardNextEvent(currentRosterBundle, savedRosters[0]);
  const [nextFlightStatus, setNextFlightStatus] = useState<RadarPrivateStatus | null>(null);
  const dashboardNextEventLive: DashboardNextEvent = dashboardNextEvent?.isFlight && hasUsefulRadarStatus(nextFlightStatus)
    ? {
        ...dashboardNextEvent,
        status: nextFlightStatus?.status || dashboardNextEvent.status,
        gate: nextFlightStatus?.gate || dashboardNextEvent.gate,
        terminal: nextFlightStatus?.terminal || dashboardNextEvent.terminal,
        source: nextFlightStatus?.updatedAt ? `Radar CrewCheck · ${new Date(nextFlightStatus.updatedAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}` : 'Radar CrewCheck',
      }
    : dashboardNextEvent;
  const dashboardAlerts = currentRosterBundle?.compliance?.alerts?.length || 0;
  const dashboardDaysLoaded = currentRosterBundle?.roster?.days?.length || 0;
  const dashboardComplianceScore = currentRosterBundle?.compliance?.score;

  useEffect(() => {
    const timer = window.setInterval(() => {
      setDashboardClockTick(Date.now());
      window.dispatchEvent(new CustomEvent('crewcheck:refresh-smart-departure'));
    }, 60_000);
    window.dispatchEvent(new CustomEvent('crewcheck:refresh-smart-departure'));
    return () => window.clearInterval(timer);
  }, []);


  useEffect(() => {
    try {
      if (!localStorage.getItem('crewcheck_notifications_intro_v1')) {
        localStorage.setItem('crewcheck_notifications_intro_v1', '1');
        requestCrewCheckNotificationPermission();
      }
      if (dashboardNextEvent?.title && dashboardNextEvent.time && dashboardNextEvent.time !== 'PDF') {
        notifyCrewCheck(
          'CrewCheck · próxima programação',
          `${dashboardNextEvent.title} às ${dashboardNextEvent.time}. ${dashboardNextEvent.countdown && dashboardNextEvent.countdown !== '—' ? `Faltam ${dashboardNextEvent.countdown}.` : ''}`,
          `next_${dashboardNextEvent.date}_${dashboardNextEvent.time}`
        );
      }
    } catch {
      // Não bloqueia o cockpit se o navegador/app negar notificações.
    }
  }, [dashboardNextEvent?.title, dashboardNextEvent?.time, dashboardNextEvent?.date, dashboardNextEvent?.countdown]);


  useEffect(() => {
    try {
      const roster = currentRosterBundle?.roster;
      if (!roster?.days?.length) return;
      const base = String(roster.base || '').toUpperCase();
      const now = Date.now();
      for (const day of roster.days.slice(0, 45)) {
        const text = `${day.type || ''} ${day.pairingCode || ''} ${day.rawText || ''}`.toUpperCase();
        const firstLeg = day.legs?.[0];
        const startsAtBase = Boolean(firstLeg?.origin && base && String(firstLeg.origin).toUpperCase() === base);
        const extraFlightAtBase = Boolean(startsAtBase && day.legs?.some((leg) => String(leg.workType || '').toUpperCase() === 'PS') && !/\b(CBF|EMER|CRM|C\d{2,3}F|TREIN|TRAIN|CHECK|SIMULADOR|EAD)\b/.test(text));
        const reserve = /\b(ASB|RES|RESERVA|AIRPORT\s*STAND)\b/.test(text);
        if (!reserve && !extraFlightAtBase) continue;
        const start = day.dutyReport || firstLeg?.departureTime || '';
        if (!start) continue;
        const target = dashboardTargetDate(day.date, start).getTime();
        const reminder = target - 30 * 60_000;
        if (reminder <= now + 60_000) continue;
        const key = `checkin_${day.date}_${start}_${day.pairingCode || day.type}`;
        if (localStorage.getItem(`crewcheck_checkin_reminder_${key}`) === '1') continue;
        const ok = scheduleCrewCheckNotification('CrewCheck · Check-in da escala', `Lembrete premium: preencher o formulário de Check-in da escala para ${reserve ? 'reserva/ASB' : 'voo extra/PS'} às ${start}.`, reminder);
        if (ok) localStorage.setItem(`crewcheck_checkin_reminder_${key}`, '1');
      }
    } catch {
      // check-in é auxiliar; nunca bloqueia o cockpit.
    }
  }, [currentRosterBundle?.roster?.days?.length]);


  useEffect(() => {
    if (!dashboardNextEvent?.isFlight || !dashboardNextEvent.flightNumber) {
      setNextFlightStatus(null);
      return;
    }
    let active = true;
    const controller = new AbortController();
    const loadRadarStatus = async () => {
      try {
        const params = new URLSearchParams({
          flightNumber: dashboardNextEvent.flightNumber || '',
          flight: dashboardNextEvent.flightNumber || '',
          date: radarDateFromNextEvent(dashboardNextEvent),
        });
        if (dashboardNextEvent.origin) params.set('origin', dashboardNextEvent.origin);
        if (dashboardNextEvent.destination) params.set('destination', dashboardNextEvent.destination);
        if (dashboardNextEvent.route) params.set('route', dashboardNextEvent.route);
        const response = await fetch(`/api/radar/private-status?${params.toString()}`, { cache: 'no-store', signal: controller.signal });
        const payload = await response.json().catch(() => null) as RadarPrivateStatus | null;
        if (!active || !payload?.ok) return;
        setNextFlightStatus(payload);
        if (hasUsefulRadarStatus(payload)) {
          const statusKey = `crewcheck_radar_last_${dashboardNextEvent.flightNumber}_${radarDateFromNextEvent(dashboardNextEvent)}`;
          const compact = JSON.stringify({ status: payload.status || '', gate: payload.gate || '', terminal: payload.terminal || '', estimatedDeparture: payload.estimatedDeparture || '' });
          const previous = localStorage.getItem(statusKey);
          if (previous && previous !== compact) {
            notifyCrewCheck(
              `CrewCheck · ${dashboardNextEvent.flightNumber}`,
              radarStatusLine(payload),
              `radar_${dashboardNextEvent.flightNumber}_${payload.status || 'status'}_${payload.gate || 'sem-portao'}_${payload.terminal || 'sem-terminal'}`
            );
          }
          localStorage.setItem(statusKey, compact);

          if (dashboardNextEvent.targetIso) {
            const target = new Date(dashboardNextEvent.targetIso).getTime();
            const when = target - 90 * 60_000;
            const scheduleKey = `crewcheck_radar_scheduled_${dashboardNextEvent.flightNumber}_${radarDateFromNextEvent(dashboardNextEvent)}`;
            if (when > Date.now() + 60_000 && localStorage.getItem(scheduleKey) !== '1') {
              const scheduled = scheduleCrewCheckNotification(
                `CrewCheck · próximo voo ${dashboardNextEvent.flightNumber}`,
                radarStatusLine(payload),
                when
              );
              if (scheduled) localStorage.setItem(scheduleKey, '1');
            }
          }
        }
      } catch {
        // Radar é auxiliar; não deve bloquear a tela inicial.
      }
    };
    void loadRadarStatus();
    const timer = window.setInterval(() => void loadRadarStatus(), 4 * 60_000);
    return () => { active = false; controller.abort(); window.clearInterval(timer); };
  }, [dashboardNextEvent?.isFlight, dashboardNextEvent?.flightNumber, dashboardNextEvent?.origin, dashboardNextEvent?.destination, dashboardNextEvent?.route, dashboardNextEvent?.targetIso]);

  const refreshSavedRosters = useCallback(async () => {
    setSavedLoading(true);
    try {
      const [statusResult, historyResult] = await Promise.allSettled([
        getDatabaseStatus(),
        listSavedRosters(8),
      ]);
      if (statusResult.status === 'fulfilled') setDbStatus(statusResult.value);
      else setDbStatus({ ok: false, connected: false, databaseConfigured: false, message: 'Banco indisponível. Histórico local ativo.' });
      if (historyResult.status === 'fulfilled') setSavedRosters(historyResult.value);
      else setSavedRosters([]);
      setPendingOffline(getPendingOfflineCount());
    } finally {
      setSavedLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshSavedRosters();
  }, [refreshSavedRosters]);


  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const storedTarget = window.localStorage.getItem('crewcheck_next_home_view');
      if (storedTarget) window.localStorage.removeItem('crewcheck_next_home_view');
      const target = storedTarget || params.get('view') || params.get('screen');
      if (target && ['home','import','history','calendar','iflight','flightboard','departure','routine','perdiem','salary','c32f','settings','support','notes','more'].includes(target)) {
        setCurrentView(target as HomeView);
        window.history.replaceState(null, '', window.location.pathname || '/');
      } else if (params.has('import') || params.has('newRoster')) {
        setCurrentView('import');
        window.history.replaceState(null, '', window.location.pathname || '/');
      }
    } catch {
      // Mantém a tela inicial quando o navegador bloqueia leitura da URL.
    }
  }, []);


  useEffect(() => {
    if (autoLatestLoaded || savedLoading || hasCurrentRosterSession() || !savedRosters[0]) return;
    setAutoLatestLoaded(true);
    const latest = savedRosters[0];
    openSavedRoster(latest.id)
      .then((data) => {
        const normalized = normalizeRosterSchedule(detectAndMarkLayovers(data.roster));
        sessionStorage.setItem('crewcheck_roster', JSON.stringify(normalized));
        sessionStorage.setItem('crewcheck_compliance', JSON.stringify(data.compliance));
        sessionStorage.setItem('crewcheck_gym', JSON.stringify(data.gym || []));
        sessionStorage.setItem('crewcheck_role_selection', roleSelection);
        sessionStorage.setItem('crewcheck_source_file', latest.sourceFileName || 'Última escala sincronizada');
        toast.success('Última escala sincronizada neste dispositivo.');
        setDashboardClockTick(Date.now());
        window.setTimeout(() => window.dispatchEvent(new CustomEvent('crewcheck:refresh-smart-departure')), 450);
      })
      .catch(() => {
        // Mantém silencioso; o histórico continua disponível pelo menu.
      });
  }, [autoLatestLoaded, savedLoading, savedRosters, roleSelection]);

  useEffect(() => {
    saveAndApplyCrewThemeMode(themeMode);
    if (themeMode !== 'system') return;
    const media = window.matchMedia?.('(prefers-color-scheme: dark)');
    const onChange = () => saveAndApplyCrewThemeMode('system');
    media?.addEventListener?.('change', onChange);
    return () => media?.removeEventListener?.('change', onChange);
  }, [themeMode]);

  const handleOpenSavedRoster = useCallback(async (id: string, targetView: ResultsView = 'summary') => {
    setOpeningSavedId(id);
    try {
      const data = await openSavedRoster(id);
      sessionStorage.setItem('crewcheck_roster', JSON.stringify(normalizeRosterSchedule(detectAndMarkLayovers(data.roster))));
      sessionStorage.setItem('crewcheck_compliance', JSON.stringify(data.compliance));
      sessionStorage.setItem('crewcheck_gym', JSON.stringify(data.gym || []));
      sessionStorage.setItem('crewcheck_role_selection', roleSelection);
      const summary = savedRosters.find((item) => item.id === id);
      sessionStorage.setItem('crewcheck_source_file', summary?.sourceFileName || 'Escala salva');
      setInitialResultsView(targetView);
      toast.success('Escala salva carregada.');
      setLocation('/results');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Não foi possível abrir a escala salva.');
    } finally {
      setOpeningSavedId(null);
    }
  }, [roleSelection, savedRosters, setLocation]);

  async function handleLogout() {
    try {
      await logout();
    } finally {
      sessionStorage.clear();
      setLocation('/login');
    }
  }

  async function handleSyncPending() {
    try {
      const result = await syncPendingRosters();
      await refreshSavedRosters();
      setPendingOffline(result.remaining);
      if (result.synced > 0) toast.success(`${result.synced} escala(s) sincronizada(s).`);
      if (result.remaining > 0) toast.warning(`${result.remaining} pendência(s) ainda offline.`);
      if (!result.synced && !result.remaining) toast.info('Nenhuma pendência offline para sincronizar.');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Falha ao sincronizar pendências offline.');
    }
  }


  function handleExportCurrentPdf() {
    const bundle = readCurrentRosterBundle();
    if (!bundle) {
      toast.info('Importe ou abra uma escala antes de exportar o PDF completo.');
      setCurrentView('import');
      return;
    }
    exportReport(bundle.roster, bundle.compliance, bundle.gym);
    toast.success('PDF completo da escala gerado.');
  }

  function handleExportCurrentIcs() {
    const bundle = readCurrentRosterBundle();
    if (!bundle) {
      toast.info('Importe ou abra uma escala antes de exportar o calendário completo.');
      setCurrentView('import');
      return;
    }
    const ical = generateICalendar(bundle.roster, bundle.gym, {
      mode: 'all',
      titleFormat: 'route-flight',
      includeReminders: true,
      flightReminderMinutes: [120, 30],
      dutyReminderMinutes: [120, 30],
      gymReminderMinutes: [60],
      routineReminderMinutes: [60],
    });
    downloadCalendarFile(ical, `crewcheck-completo-${bundle.roster.year}-${String(bundle.roster.month).padStart(2, '0')}.ics`);
    toast.success('Calendário completo exportado.');
  }

  function handleProfileSettingsChange(next: LocalProfileSettings) {
    setProfileSettings(saveLocalProfileSettings(next));
    toast.success('Perfil atualizado neste dispositivo.');
  }

  const goToResults = useCallback((view: ResultsView = 'summary') => {
    if (hasCurrentRosterSession()) {
      setInitialResultsView(view);
      setLocation('/results');
      return;
    }
    if (savedRosters[0]) {
      void handleOpenSavedRoster(savedRosters[0].id, view);
      return;
    }
    toast.info('Carregue uma escala primeiro para abrir esta função.');
    setCurrentView('import');
  }, [handleOpenSavedRoster, savedRosters, setLocation]);

  const handleDashboardNavigate = useCallback((view: string) => {
    const map: Record<string, () => void> = {
      home: () => setCurrentView('home'),
      import: () => setCurrentView('import'),
      roster: () => goToResults('roster'),
      calendar: () => setCurrentView('calendar'),
      irregularities: () => goToResults('irregularities'),
      routine: () => goToResults('gym'),
      c32f: () => canAccessC32FAcademy ? setCurrentView('c32f') : toast.info('Academia C32F restrita ao administrador.'),
      iflight: () => canAccessC32FAcademy ? setCurrentView('iflight') : setCurrentView('support'),
      flightboard: () => setCurrentView('flightboard'),
      departure: () => setCurrentView('departure'),
      smartDeparture: () => setCurrentView('departure'),
      perdiem: () => setCurrentView('perdiem'),
      salary: () => setCurrentView('salary'),
      history: () => setCurrentView('history'),
      reports: () => goToResults('metrics'),
      pdf: () => handleExportCurrentPdf(),
      ics: () => handleExportCurrentIcs(),
      google: () => goToResults('settings'),
      alerts: () => goToResults('alerts'),
      notes: () => setCurrentView('notes'),
      support: () => setCurrentView('support'),
      settings: () => setCurrentView('settings'),
      sync: () => void handleSyncPending(),
      more: () => setCurrentView('more'),
    };
    (map[view] || (() => setCurrentView('more')))();
  }, [canAccessC32FAcademy, goToResults]);

  const commitRoster = useCallback(async (inputRoster: CrewRoster, sourceFileName: string, targetView: ResultsView = 'summary') => {
    const previousBundle = readCurrentRosterBundle();
    const roster = normalizeRosterSchedule(detectAndMarkLayovers(inputRoster));
    const changeSummary = buildRosterChangeSummaryV10867(previousBundle?.roster, roster);
    const compliance = analyzeCompliance(roster, roleSelection);
    const gym = getGymRecommendations(roster, roleSelection);

    if (changeSummary) sessionStorage.setItem('crewcheck_last_roster_changes', JSON.stringify(changeSummary));
    else sessionStorage.removeItem('crewcheck_last_roster_changes');
    sessionStorage.setItem('crewcheck_roster', JSON.stringify(roster));
    sessionStorage.setItem('crewcheck_compliance', JSON.stringify(compliance));
    sessionStorage.setItem('crewcheck_gym', JSON.stringify(gym));
    sessionStorage.setItem('crewcheck_role_selection', roleSelection);
    sessionStorage.setItem('crewcheck_source_file', sourceFileName);
    sessionStorage.setItem('crewcheck_auto_sync_pending', '1');
    sessionStorage.setItem('crewcheck_auto_db_save_pending', '1');
    setInitialResultsView(targetView);

    toast.success('Escala interpretada com sucesso.');
    if (changeSummary) toast.info(changeSummary.message);
    notifyCrewCheck('CrewCheck · escala atualizada', changeSummary?.message || 'Sua escala foi importada e recalculada com rotina, diárias, salário e calendário.', 'roster_imported');
    setLocation('/results');
  }, [roleSelection, setLocation]);

  const handleRosterImport = useCallback(async (roster: CrewRoster, sourceFileName = 'iFlight LATAM') => {
    await commitRoster(roster, sourceFileName, 'roster');
  }, [commitRoster]);

  const handleFile = useCallback(async (file: File) => {
    const fileNameLower = (file.name || '').toLowerCase();
    const looksLikePdf = fileNameLower.endsWith('.pdf') || file.type === 'application/pdf' || file.type === 'application/octet-stream' || fileNameLower.includes('pdf');
    if (!looksLikePdf) {
      setError('Por favor, envie um PDF exportado pelo CrewTopia, iFlight, CrewRosterReport ou AIMS. No iPhone, use Arquivos > iCloud/No iPhone e selecione o PDF original.');
      return;
    }
    if (!file.size || file.size < 50) {
      setError('O PDF selecionado parece vazio ou não foi liberado pelo iOS. Tente salvar o arquivo em Arquivos > No iPhone e selecionar novamente.');
      return;
    }

    setFileName(file.name);
    setIsProcessing(true);
    setError(null);

    try {
      let roster: CrewRoster;
      try {
        roster = await parsePdfViaServer(file);
      } catch (serverError) {
        console.warn('Server PDF parser failed; trying local parser fallback', serverError);
        try {
          roster = await parsePDF(file);
          toast.info('PDF interpretado pelo modo local do app.');
        } catch (localError) {
          console.error('Local PDF parser fallback failed', localError);
          const serverMessage = serverError instanceof Error ? serverError.message : 'Parser servidor indisponível.';
          const localMessage = localError instanceof Error ? localError.message : 'Parser local indisponível.';
          throw new Error(`${serverMessage} Fallback local: ${localMessage}`);
        }
      }
      await commitRoster(roster, file.name, 'summary');
    } catch (err) {
      console.error('Error parsing PDF:', err);
      const message = err instanceof Error ? err.message : '';
      setError(`Não consegui interpretar este PDF. ${message ? `Detalhe: ${message}. ` : ''}Tente salvar o arquivo localmente e selecionar novamente pelo botão Escolher PDF. Se for escala em formato ticket, confira se o PDF tem texto selecionável.`);
    } finally {
      setIsProcessing(false);
    }
  }, [commitRoster]);

  useEffect(() => {
    async function importNativePdf(payload?: NativePdfPayload) {
      if (!payload?.dataBase64 || nativePdfImportingRef.current) return;
      nativePdfImportingRef.current = true;
      const filename = payload.filename || payload.sourceFileName || 'iFlight_RosterReport.pdf';
      setCurrentView('import');
      setFileName(filename);
      setIsProcessing(true);
      setError(null);
      toast.info('PDF recebido do iFlight. Importando escala...');
      try {
        const file = base64ToPdfFile(filename, payload.dataBase64);
        let roster: CrewRoster;
        try {
          roster = await parsePdfViaServer(file);
        } catch (serverError) {
          console.warn('Server PDF parser failed for native PDF; trying local parser fallback', serverError);
          roster = await parsePDF(file);
        }
        await commitRoster(roster, filename, 'roster');
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Erro desconhecido.';
        setError(`Recebi o PDF do iFlight, mas não consegui interpretar. Detalhe: ${message}`);
        toast.error('Não consegui interpretar o PDF recebido do iFlight.');
      } finally {
        setIsProcessing(false);
        const win = window as Window & { __crewcheckPendingNativePdf?: NativePdfPayload };
        delete win.__crewcheckPendingNativePdf;
        nativePdfImportingRef.current = false;
      }
    }

    const handler = (event: Event) => {
      void importNativePdf((event as CustomEvent<NativePdfPayload>).detail);
    };

    window.addEventListener('crewcheck:native-pdf', handler as EventListener);
    const win = window as Window & { __crewcheckPendingNativePdf?: NativePdfPayload };
    if (win.__crewcheckPendingNativePdf) void importNativePdf(win.__crewcheckPendingNativePdf);
    return () => window.removeEventListener('crewcheck:native-pdf', handler as EventListener);
  }, [commitRoster]);

  const handleDrop = useCallback((event: DragEvent) => {
    event.preventDefault();
    setIsDragging(false);
    const file = event.dataTransfer.files?.[0];
    if (file) void handleFile(file);
  }, [handleFile]);

  const handleFileInput = useCallback((event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) void handleFile(file);
    event.target.value = '';
  }, [handleFile]);

  const renderWithMobileMenu = (content: ReactNode, active: 'home' | 'roster' | 'iflight' | 'settings' | 'more' = 'home') => (
    <>
      <div className="crewcheck-mobile-menu-safe">{content}</div>
      <CrewCheckMobileMenu active={active} onNavigate={handleDashboardNavigate} />
    </>
  );

  if (currentView === 'calendar') return renderWithMobileMenu(<CalendarView onBack={() => setCurrentView('home')} />, 'roster');
  if (currentView === 'iflight') return renderWithMobileMenu(canAccessC32FAcademy ? <IFlightIntegrationView onBack={() => setCurrentView('home')} onSuccess={() => goToResults('roster')} onFileUpload={handleFile} onRosterImport={handleRosterImport} /> : <IFlightBetaUserPanel onBack={() => setCurrentView('home')} onOpenImport={() => setCurrentView('import')} />, 'iflight');
  if (currentView === 'flightboard') return renderWithMobileMenu(<FlightBoardScreen onBack={() => setCurrentView('home')} />, 'more');
  if (currentView === 'departure') return renderWithMobileMenu(<SmartDepartureScreen nextEvent={dashboardNextEventLive} userBase={profileSettings.base || user?.base || ''} hasRoster={hasCurrentRosterSession()} onBack={() => setCurrentView('home')} onOpenRoster={() => goToResults('roster')} />, 'more');

  if (currentView === 'perdiem') return renderWithMobileMenu(<PerDiemForecastScreen bundle={currentRosterBundle} onBack={() => setCurrentView('home')} onOpenImport={() => setCurrentView('import')} />, 'more');

  if (currentView === 'salary') return renderWithMobileMenu(<SalaryForecastScreen bundle={currentRosterBundle} isAdmin={canAccessC32FAcademy} onBack={() => setCurrentView('home')} onOpenImport={() => setCurrentView('import')} />, 'more');

  if (currentView === 'import') {
    return renderWithMobileMenu(
      <ImportScreen
        userLabel={user?.name || user?.email || 'Usuário'}
        roleSelection={roleSelection}
        onRoleSelectionChange={setRoleSelection}
        isDragging={isDragging}
        isProcessing={isProcessing}
        error={error}
        fileName={fileName}
        fileInputRef={fileInputRef}
        isAdmin={canAccessC32FAcademy}
        onBack={() => setCurrentView('home')}
        onDrop={handleDrop}
        onDragOver={(event) => { event.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onFileInput={handleFileInput}
        onLogout={handleLogout}
      />,
      'roster'
    );
  }

  if (currentView === 'history') {
    return renderWithMobileMenu(<HistoryScreen rosters={savedRosters} loading={savedLoading} dbStatus={dbStatus} openingId={openingSavedId} onBack={() => setCurrentView('home')} onOpen={(id) => void handleOpenSavedRoster(id, 'summary')} onRefresh={refreshSavedRosters} />, 'more');
  }

  if (currentView === 'routine') {
    return renderWithMobileMenu(<SimplePanel title="Rotina Reliable" icon={Dumbbell} onBack={() => setCurrentView('home')} description="Treino, estudo e recuperação agora são sugeridos de forma conservadora dentro da escala, respeitando descanso, alimentação, reserva, sobreaviso, pernoite, madrugadas e margem real de deslocamento." actions={[{ label: 'Abrir painel premium de rotina', onClick: () => goToResults('gym') }, { label: 'Importar nova escala', onClick: () => setCurrentView('import') }]} />, 'more');
  }

  if (currentView === 'notes') {
    return renderWithMobileMenu(<NotesPanel onBack={() => setCurrentView('home')} />, 'more');
  }

  if (currentView === 'c32f') {
    if (!canAccessC32FAcademy) {
      return renderWithMobileMenu(<SimplePanel title="Acesso restrito" icon={Lock} onBack={() => setCurrentView('home')} description="A academia C32F é um módulo administrativo privado." actions={[{ label: 'Voltar ao início', onClick: () => setCurrentView('home') }]} />, 'home');
    }
    return renderWithMobileMenu(<C32FStudyPanel onBack={() => setCurrentView('home')} onOpenRoster={() => goToResults('roster')} />, 'more');
  }

  if (currentView === 'settings') {
    return renderWithMobileMenu(<SettingsHomePanel
      userLabel={profileSettings.displayName || user?.name || user?.email || 'Tripulante'}
      userEmail={user?.email || ''}
      profileSettings={profileSettings}
      avatar={profileAvatar}
      pendingOffline={pendingOffline}
      hasRoster={hasCurrentRosterSession()}
      onProfileSettingsChange={handleProfileSettingsChange}
      onAvatarChange={(value) => { setProfileAvatar(value); if (value) localStorage.setItem('crewcheck_profile_avatar', value); else localStorage.removeItem('crewcheck_profile_avatar'); }}
      themeMode={themeMode}
      onThemeModeChange={setThemeMode}
      onBack={() => setCurrentView('home')}
      onOpenIFlight={() => setCurrentView('iflight')}
      onOpenImport={() => setCurrentView('import')}
      onOpenResultsSettings={() => goToResults('settings')}
      onOpenPerDiem={() => setCurrentView('perdiem')}
      onOpenSalary={() => setCurrentView('salary')}
      onExportPdf={handleExportCurrentPdf}
      onExportIcs={handleExportCurrentIcs}
      onSyncPending={() => void handleSyncPending()}
      onLogout={handleLogout}
    />, 'settings');
  }

  if (currentView === 'support') {
    return renderWithMobileMenu(<SupportPanel onBack={() => setCurrentView('home')} onOpenSettings={() => setCurrentView('settings')} onOpenImport={() => setCurrentView('import')} />, 'more');
  }

  if (currentView === 'more') {
    return renderWithMobileMenu(<MorePanel onBack={() => setCurrentView('home')} onNavigate={handleDashboardNavigate} onLogout={handleLogout} pendingOffline={pendingOffline} hasRoster={hasCurrentRosterSession()} canAccessC32FAcademy={canAccessC32FAcademy} />, 'more');
  }

  return renderWithMobileMenu(
    <div className="relative min-h-screen bg-[#08111f] crewcheck-has-global-menu">
      <Dashboard
        user={{ name: profileSettings.displayName || user?.name || user?.email || 'Tripulante', company: profileSettings.company || 'CrewCheck Premium', base: profileSettings.base || user?.base || undefined, avatar: profileAvatar || undefined }}
        nextEvent={dashboardNextEventLive}
        canAccessC32FAcademy={canAccessC32FAcademy}
        pendingOffline={pendingOffline}
        hasRoster={hasCurrentRosterSession()}
        alertsCount={dashboardAlerts}
        daysLoaded={dashboardDaysLoaded}
        complianceScore={dashboardComplianceScore}
        onNavigate={handleDashboardNavigate}
      />

    </div>,
    'home'
  );
}

function CrewCheckMobileMenu({ active, onNavigate }: { active: 'home' | 'roster' | 'iflight' | 'departure' | 'settings' | 'more'; onNavigate: (view: string) => void }) {
  const items: { id: 'home' | 'roster' | 'iflight' | 'departure' | 'settings'; label: string; icon: LucideIcon; view: string }[] = [
    { id: 'home', label: 'Cockpit', icon: HomeIcon, view: 'home' },
    { id: 'roster', label: 'Escala', icon: CalendarDays, view: 'roster' },
    { id: 'iflight', label: 'iFlight', icon: Plane, view: 'iflight' },
    { id: 'departure', label: 'Saída', icon: Navigation, view: 'departure' },
    { id: 'settings', label: 'Conta', icon: Settings, view: 'settings' },
  ];
  return (
    <nav className="crewcheck-global-bottom-menu fixed bottom-0 left-0 right-0 z-[95] border-t border-white/10 bg-[#08111f]/92 px-4 pb-[calc(0.9rem+env(safe-area-inset-bottom,0px))] pt-2.5 shadow-2xl shadow-black/45 backdrop-blur-2xl lg:hidden">
      <div className="mx-auto flex max-w-md items-center justify-between gap-1">
        {items.map(({ id, label, icon: Icon, view }) => {
          const isActive = active === id;
          return (
            <button key={id} onClick={() => onNavigate(view)} className={`flex min-w-12 flex-1 flex-col items-center gap-1 rounded-2xl px-1.5 py-1.5 transition active:scale-95 ${isActive ? 'bg-cyan-300/15 text-cyan-200' : 'text-slate-400 hover:bg-white/8 hover:text-white'}`}>
              <Icon className="h-5 w-5" />
              <span className="text-[10px] font-black leading-none">{label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}



type SmartDepartureScreenPlan = {
  ok?: boolean;
  airport?: string;
  airportName?: string;
  leaveAtLabel?: string;
  leaveAtFullLabel?: string;
  leaveAtDayLabel?: string;
  originSource?: string | null;
  originAddress?: string | null;
  originName?: string | null;
  arrivalDeadlineLabel?: string;
  durationMinutes?: number;
  delayMinutes?: number | null;
  distanceKm?: number | null;
  source?: string;
  humanSourceLabel?: string;
  pickupBufferMinutes?: number | null;
  inVehicleMinutes?: number | null;
  warning?: string | null;
  message?: string;
  marginMinutes?: number;
  isLate?: boolean;
  updatedAt?: string;
  recommendedMode?: string;
  fastestMode?: string;
  recommendedReason?: string;
  routeOptions?: Array<{ mode?: string; label?: string; leaveAtLabel?: string; leaveAtFullLabel?: string; durationMinutes?: number; distanceKm?: number | null; source?: string; humanSourceLabel?: string; firstTransitDeparture?: string | null; routeQuality?: string; pickupBufferMinutes?: number | null; inVehicleMinutes?: number | null; fareLabel?: string | null; fareConfidence?: string | null; rideApps?: Array<{ id?: string; name?: string; status?: string; fareLabel?: string; fareConfidence?: string; etaMinutes?: number; webUrl?: string; deepLink?: string; mapsUrl?: string; source?: string; products?: Array<{ product?: string; estimate?: string; low?: number | null; high?: number | null; currency?: string }> }>; transitSteps?: Array<{ line?: string; mode?: string; from?: string; to?: string; departureLabel?: string; arrivalLabel?: string; headsign?: string; agency?: string; realtime?: boolean }> }>;
  rideApps?: Array<{ id?: string; name?: string; status?: string; fareLabel?: string; fareConfidence?: string; etaMinutes?: number; webUrl?: string; deepLink?: string; mapsUrl?: string; source?: string }>;
  fareLabel?: string | null;
  fareConfidence?: string | null;
  permissionConfidence?: string;
  metadata?: { permissionConfidence?: string; [key: string]: unknown };
  transitBoard?: Array<{ line?: string; mode?: string; from?: string; to?: string; departureLabel?: string; arrivalLabel?: string; headsign?: string; agency?: string; realtime?: boolean; routeLabel?: string; source?: string }>;
};

const SMART_DEPARTURE_AIRPORTS = [
  ['BSB','Brasília'], ['REC','Recife'], ['GRU','Guarulhos'], ['CGH','Congonhas'], ['GIG','Galeão'], ['SDU','Santos Dumont'], ['CNF','Confins'], ['VCP','Viracopos'], ['SSA','Salvador'], ['FOR','Fortaleza'], ['NAT','Natal'], ['POA','Porto Alegre'], ['CWB','Curitiba'], ['MAO','Manaus'], ['BEL','Belém'], ['FLN','Florianópolis'], ['VIX','Vitória'], ['GYN','Goiânia'], ['MCZ','Maceió'], ['JPA','João Pessoa'], ['AJU','Aracaju'], ['CGB','Cuiabá'], ['CGR','Campo Grande'], ['SLZ','São Luís'], ['THE','Teresina'], ['PVH','Porto Velho'], ['RBR','Rio Branco'], ['BVB','Boa Vista'], ['PMW','Palmas'], ['MCP','Macapá'], ['NVT','Navegantes'], ['JOI','Joinville'], ['LDB','Londrina'], ['MGF','Maringá'], ['RAO','Ribeirão Preto'], ['UDI','Uberlândia'], ['IOS','Ilhéus'], ['BPS','Porto Seguro']
] as const;

function inferSmartDepartureAirport(nextEvent?: DashboardNextEvent, userBase?: string) {
  const supported = SMART_DEPARTURE_AIRPORTS.map(([code]) => code).join('|');
  const pattern = new RegExp(`\\b(${supported})\\b`, 'i');
  const candidates = [nextEvent?.origin, nextEvent?.base, nextEvent?.route, userBase, localStorage.getItem('crewcheck_preferred_airport') || ''];
  for (const candidate of candidates) {
    const match = String(candidate || '').toUpperCase().match(pattern);
    if (match?.[1]) return match[1].toUpperCase();
  }
  return 'BSB';
}

function SmartDepartureScreen({ nextEvent, userBase, hasRoster, onBack, onOpenRoster }: { nextEvent?: DashboardNextEvent; userBase?: string; hasRoster: boolean; onBack: () => void; onOpenRoster: () => void }) {
  const [airport, setAirport] = useState(() => inferSmartDepartureAirport(nextEvent, userBase));
  const [margin, setMargin] = useState(() => Number(localStorage.getItem('crewcheck_departure_margin_minutes') || 15) || 15);
  const [mode, setMode] = useState<'AUTO' | 'DRIVE' | 'TRANSIT' | 'RIDE_APP'>((localStorage.getItem('crewcheck_departure_mode') as 'AUTO' | 'DRIVE' | 'TRANSIT' | 'RIDE_APP') || 'AUTO');
  const [permission, setPermission] = useState<'idle' | 'requesting' | 'granted' | 'denied' | 'unsupported'>('idle');
  const [nativeStatus, setNativeStatus] = useState<CrewCheckPermissionStatus>(() => readCrewCheckPermissionStatus());
  const [plan, setPlan] = useState<SmartDepartureScreenPlan | null>(() => {
    try { return JSON.parse(localStorage.getItem('crewcheck_departure_last_plan') || 'null'); } catch { return null; }
  });
  const [error, setError] = useState<string | null>(null);
  const [originMode, setOriginMode] = useState<'gps' | 'home' | 'base2'>((localStorage.getItem('crewcheck_departure_origin_mode') as 'gps' | 'home' | 'base2') || 'gps');
  const [homeCep, setHomeCep] = useState(() => localStorage.getItem('crewcheck_home_cep') || '');
  const [homeAddress, setHomeAddress] = useState(() => localStorage.getItem('crewcheck_home_address') || '');
  const [base2Label, setBase2Label] = useState(() => localStorage.getItem('crewcheck_base2_label') || 'Outra base');
  const [base2Cep, setBase2Cep] = useState(() => localStorage.getItem('crewcheck_base2_cep') || '');
  const [base2Address, setBase2Address] = useState(() => localStorage.getItem('crewcheck_base2_address') || '');
  const [addressStatus, setAddressStatus] = useState<string>(() => localStorage.getItem('crewcheck_departure_address_status') || '');
  const [addressLoading, setAddressLoading] = useState(false);
  const canCalculate = Boolean(hasRoster && nextEvent?.targetIso && nextEvent?.requiresDeparture !== false);
  const locationAllowed = nativeStatus.location === true || permission === 'granted';
  const notificationsAllowed = nativeStatus.notifications === true;
  const routeOptions = Array.isArray(plan?.routeOptions) ? plan.routeOptions : [];
  const transitBoard = Array.isArray(plan?.transitBoard) ? plan.transitBoard : routeOptions.flatMap((route) => route.transitSteps || []);
  const isTransitFastest = plan?.recommendedMode === 'TRANSIT' || plan?.fastestMode === 'TRANSIT';
  const isRideFastest = plan?.recommendedMode === 'RIDE_APP' || plan?.fastestMode === 'RIDE_APP';
  const rideBoard = routeOptions.flatMap((route) => route.rideApps || []).filter(Boolean);

  const refreshPermissionStatus = useCallback((event?: Event) => {
    const detail = (event as CustomEvent<CrewCheckPermissionStatus> | undefined)?.detail || {};
    setNativeStatus({ ...readCrewCheckPermissionStatus(), ...detail });
  }, []);


  const selectedAddress = originMode === 'base2'
    ? { key: 'base2', label: base2Label || 'Outra base', cep: base2Cep, address: base2Address }
    : { key: 'home', label: 'Casa', cep: homeCep, address: homeAddress };

  const saveSelectedAddress = useCallback((result: { lat?: number; lng?: number; formattedAddress?: string; source?: string }, key = selectedAddress.key) => {
    if (typeof result.lat === 'number' && typeof result.lng === 'number') {
      localStorage.setItem(`crewcheck_${key}_lat`, String(result.lat));
      localStorage.setItem(`crewcheck_${key}_lng`, String(result.lng));
    }
    if (result.formattedAddress) localStorage.setItem(`crewcheck_${key}_formatted`, result.formattedAddress);
    if (result.source) localStorage.setItem(`crewcheck_${key}_source`, result.source);
  }, [selectedAddress.key]);

  const validateSelectedAddress = useCallback(async () => {
    if (originMode === 'gps') {
      toast.info('Selecione Casa ou Outra base para validar CEP/endereço.');
      return null;
    }
    const selected = originMode === 'base2'
      ? { key: 'base2', label: base2Label || 'Outra base', cep: base2Cep, address: base2Address }
      : { key: 'home', label: 'Casa', cep: homeCep, address: homeAddress };
    if (!selected.cep && !selected.address.trim()) {
      toast.info('Informe CEP ou endereço completo para validar.');
      return null;
    }
    setAddressLoading(true);
    try {
      const params = new URLSearchParams({ cep: selected.cep || '', address: selected.address || '' });
      const response = await fetch(`/api/smart-departure/address/validate?${params.toString()}`, { cache: 'no-store' });
      const payload = await response.json().catch(() => null) as { ok?: boolean; lat?: number; lng?: number; formattedAddress?: string; message?: string; source?: string } | null;
      if (!response.ok || !payload?.ok || typeof payload.lat !== 'number' || typeof payload.lng !== 'number') throw new Error(payload?.message || 'Não consegui validar o endereço.');
      saveSelectedAddress(payload, selected.key);
      localStorage.setItem('crewcheck_departure_origin_mode', originMode);
      localStorage.setItem('crewcheck_departure_address_status', payload.formattedAddress || 'Endereço validado');
      setAddressStatus(payload.formattedAddress || 'Endereço validado');
      toast.success(`${selected.label}: endereço validado pelo Google.`);
      return { ...payload, key: selected.key, label: selected.label, cep: selected.cep, address: selected.address };
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Falha ao validar endereço.';
      setAddressStatus(msg);
      toast.error(msg);
      return null;
    } finally {
      setAddressLoading(false);
    }
  }, [base2Address, base2Cep, base2Label, homeAddress, homeCep, originMode, saveSelectedAddress]);

  const runRoutesDiagnostics = useCallback(async () => {
    try {
      const response = await fetch('/api/smart-departure/diagnostics?airport=BSB', { cache: 'no-store' });
      const payload = await response.json().catch(() => null) as { mapsKeyConfigured?: boolean; routes?: unknown; directions?: unknown; errors?: string[] } | null;
      if (payload?.routes || payload?.directions) {
        toast.success('Google Routes/Directions respondeu no backend.');
      } else {
        toast.error(`Routes ainda indisponível: ${(payload?.errors || []).join(' · ') || 'sem detalhe'}`);
      }
    } catch {
      toast.error('Não consegui testar o backend de rotas agora.');
    }
  }, []);

  useEffect(() => {
    refreshPermissionStatus();
    const refresh = (event: Event) => refreshPermissionStatus(event);
    window.addEventListener('crewcheck:native-ready', refresh);
    window.addEventListener('crewcheck:permissions-updated', refresh);
    window.addEventListener('crewcheck:location-permission', refresh);
    window.addEventListener('crewcheck:notification-permission', refresh);
    window.addEventListener('focus', refresh);
    document.addEventListener('visibilitychange', refresh);
    const timer = window.setInterval(() => refreshPermissionStatus(), 2500);
    return () => {
      window.removeEventListener('crewcheck:native-ready', refresh);
      window.removeEventListener('crewcheck:permissions-updated', refresh);
      window.removeEventListener('crewcheck:location-permission', refresh);
      window.removeEventListener('crewcheck:notification-permission', refresh);
      window.removeEventListener('focus', refresh);
      document.removeEventListener('visibilitychange', refresh);
      window.clearInterval(timer);
    };
  }, [refreshPermissionStatus]);

  const requestAppNotifications = useCallback(() => {
    const immediate = requestCrewCheckNotificationPermission();
    window.setTimeout(() => refreshPermissionStatus(), 700);
    const latest = readCrewCheckPermissionStatus();
    if (immediate || latest.notifications === true) {
      setNativeStatus((current) => ({ ...current, notifications: true }));
      localStorage.setItem('crewcheck_notifications_enabled', 'true');
      toast.success('Notificações do CrewCheck já estão liberadas.');
      const title = 'CrewCheck ativado';
      const body = 'Você receberá alertas de escala, hora de sair e próximo voo quando o app tiver dados suficientes.';
      getCrewCheckNative()?.notify?.(title, body) || notifyCrewCheck(title, body, 'notifications_enabled');
    } else {
      toast.info('Autorize as notificações no aviso do Android. O CrewCheck confirma automaticamente após liberar.');
    }
  }, [refreshPermissionStatus]);

  const scheduleCurrentDepartureAlert = useCallback(() => {
    if (!nextEvent?.targetIso) {
      toast.info('Carregue uma escala com próxima programação para agendar o alerta.');
      return;
    }
    if (!readCrewCheckPermissionStatus().notifications) requestCrewCheckNotificationPermission();
    const leaveLabel = plan?.leaveAtLabel || 'Sair no horário calculado';
    const target = new Date(nextEvent.smartDepartureTargetIso || nextEvent.targetIso).getTime();
    const reminderAt = Math.max(Date.now() + 60_000, target - 90 * 60_000);
    const scheduled = scheduleCrewCheckNotification('CrewCheck · hora de sair', `${leaveLabel} para ${nextEvent.title || 'sua próxima programação'}.`, reminderAt);
    if (scheduled) toast.success('Alerta de saída agendado pelo CrewCheck.');
    else toast.info('Ative as notificações do app para agendar a saída inteligente.');
  }, [nextEvent?.targetIso, nextEvent?.smartDepartureTargetIso, nextEvent?.title, plan?.leaveAtLabel]);


  useEffect(() => {
    setAirport(inferSmartDepartureAirport(nextEvent, userBase));
  }, [nextEvent?.targetIso, nextEvent?.origin, nextEvent?.base, nextEvent?.route, userBase]);

  const runGeolocationCalculation = useCallback(async () => {
    if (!canCalculate) {
      setError('Importe uma escala ou abra uma escala salva para calcular a hora de sair.');
      return;
    }
    setPermission('requesting');
    setError(null);
    try {
      let coords: { ok?: boolean; lat?: number; lng?: number; accuracy?: number | string; error?: string; permission?: boolean; source?: string } | null = null;
      let originLabel = 'Localização atual';
      let originCep = '';
      let originAddress = '';
      if (originMode !== 'gps') {
        const selected = originMode === 'base2'
          ? { key: 'base2', label: base2Label || 'Outra base', cep: base2Cep, address: base2Address }
          : { key: 'home', label: 'Casa', cep: homeCep, address: homeAddress };
        originLabel = selected.label;
        originCep = selected.cep;
        originAddress = selected.address || localStorage.getItem(`crewcheck_${selected.key}_formatted`) || '';
        const savedLat = Number(localStorage.getItem(`crewcheck_${selected.key}_lat`) || '');
        const savedLng = Number(localStorage.getItem(`crewcheck_${selected.key}_lng`) || '');
        if (Number.isFinite(savedLat) && Number.isFinite(savedLng)) {
          coords = { ok: true, lat: savedLat, lng: savedLng, accuracy: 20, source: 'endereço salvo' };
        } else {
          const validated = await validateSelectedAddress();
          if (validated?.ok && typeof validated.lat === 'number' && typeof validated.lng === 'number') {
            coords = { ok: true, lat: validated.lat, lng: validated.lng, accuracy: 20, source: 'endereço validado' };
            originAddress = validated.formattedAddress || originAddress;
          }
        }
      }
      if (!coords?.ok) {
        coords = await requestCrewCheckCurrentLocation();
        if (!coords?.ok) coords = await requestCrewCheckBrowserLocation();
        originLabel = 'Localização atual';
      }
      if (!coords?.ok || typeof coords.lat !== 'number' || typeof coords.lng !== 'number') {
        setPermission(coords?.permission ? 'denied' : 'unsupported');
        setNativeStatus((current) => ({ ...current, location: false }));
        throw new Error(coords?.error || 'Não consegui puxar sua localização real. Use CEP/endereço salvo ou libere Localização para o CrewCheck e tente novamente.');
      }
      setPermission(originMode === 'gps' ? 'granted' : permission);
      if (originMode === 'gps') setNativeStatus((current) => ({ ...current, location: true }));
      localStorage.setItem('crewcheck_departure_margin_minutes', String(margin));
      localStorage.setItem('crewcheck_preferred_airport', airport);
      localStorage.setItem('crewcheck_departure_mode', mode);
      localStorage.setItem('crewcheck_departure_origin_mode', originMode);
      const params = new URLSearchParams({
        lat: String(coords.lat),
        lng: String(coords.lng),
        accuracy: String(coords.accuracy || ''),
        airport,
        targetIso: String(nextEvent?.smartDepartureTargetIso || nextEvent?.targetIso || ''),
        marginMinutes: String(margin),
        mode,
        originName: originLabel,
        originCep,
        originAddress,
        preferAddress: originMode === 'gps' ? 'false' : 'true',
      });
      const response = await fetch(`/api/smart-departure?${params.toString()}`, { cache: 'no-store' });
      const payload = await response.json().catch(() => null) as SmartDepartureScreenPlan | null;
      if (!response.ok || !payload?.ok) throw new Error(payload?.message || 'Não foi possível calcular a saída agora.');
      setPlan(payload);
      localStorage.setItem('crewcheck_departure_location_permission', 'granted');
      localStorage.setItem('crewcheck_departure_last_airport', airport);
      localStorage.setItem('crewcheck_departure_last_plan', JSON.stringify(payload));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Falha ao calcular rota com trânsito.');
    }
  }, [airport, base2Address, base2Cep, base2Label, canCalculate, homeAddress, homeCep, margin, mode, nextEvent?.targetIso, nextEvent?.smartDepartureTargetIso, originMode, permission, validateSelectedAddress]);

  const calculate = useCallback(() => {
    if (!canCalculate) {
      setError('Importe uma escala ou abra uma escala salva para calcular a hora de sair.');
      return;
    }
    const latestStatus = readCrewCheckPermissionStatus();
    setNativeStatus(latestStatus);
    const native = getCrewCheckNative();
    if (native?.requestLocation && latestStatus.location !== true) {
      setPermission('requesting');
      setError('Toque em Permitir no aviso do Android. Assim que liberar, o CrewCheck recalcula automaticamente.');
      requestCrewCheckLocationPermission();
      window.setTimeout(() => refreshPermissionStatus(), 700);
      window.setTimeout(() => void runGeolocationCalculation(), 1600);
      return;
    }
    void runGeolocationCalculation();
  }, [canCalculate, refreshPermissionStatus, runGeolocationCalculation]);

  useEffect(() => {
    if (permission === 'requesting' && nativeStatus.location === true) {
      setError(null);
      void runGeolocationCalculation();
    }
  }, [nativeStatus.location, permission, runGeolocationCalculation]);

  useEffect(() => {
    let timer: number | undefined;
    if (canCalculate && (localStorage.getItem('crewcheck_departure_location_permission') === 'granted' || nativeStatus.location === true)) {
      void runGeolocationCalculation();
      timer = window.setInterval(() => void runGeolocationCalculation(), 5 * 60_000);
    }
    return () => { if (timer) window.clearInterval(timer); };
  }, [runGeolocationCalculation, canCalculate, nativeStatus.location]);

  const googleMapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${airport} airport`)}&travelmode=driving`;
  const arrivalText = plan?.arrivalDeadlineLabel || (nextEvent?.time ? `${nextEvent.time} - ${margin} min` : '—');

  return (
    <div className="min-h-screen overflow-x-hidden overflow-y-auto bg-[#07111F] px-5 py-8 text-white crewcheck-smart-departure-screen">
      <div className="mx-auto max-w-6xl space-y-5">
        <HeaderBack title="Saída Inteligente" subtitle="ultra premium · carro · ônibus/metrô · Uber/99 · auditável" onBack={onBack} />
        <section className="overflow-hidden rounded-[2.2rem] border border-cyan-200/20 bg-[radial-gradient(circle_at_10%_0%,rgba(34,211,238,.24),transparent_34%),linear-gradient(135deg,rgba(255,255,255,.12),rgba(15,23,42,.72))] shadow-2xl shadow-cyan-950/30 backdrop-blur-2xl">
          <div className="grid gap-0 lg:grid-cols-[minmax(0,1fr)_22rem]">
            <div className="p-6 md:p-8">
              <div className="flex flex-col gap-5 md:flex-row md:items-start md:justify-between">
                <div>
                  <p className="text-xs font-black uppercase tracking-[0.28em] text-cyan-100/75">hora de sair</p>
                  <h1 className="mt-3 text-5xl font-black tracking-tight md:text-7xl">{plan?.leaveAtLabel || 'Calcular'}</h1>
                  <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-200/90">O CrewCheck compara carro, transporte público e corrida por app com a localização real autorizada, calcula a hora limite de saída e mostra a fonte do cálculo para você confiar antes de sair de casa.</p>
                </div>
                <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-[1.8rem] bg-cyan-300/15 text-cyan-100 shadow-xl"><Navigation className="h-10 w-10" /></div>
              </div>

              <div className="mt-7 grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
                <SmartDepartureMetric label="Aeroporto" value={plan?.airport || airport} hint={plan?.airportName || 'base detectada'} />
                <SmartDepartureMetric label="Chegar até" value={arrivalText} hint="antes da apresentação" />
                <SmartDepartureMetric label="Melhor rota" value={plan?.durationMinutes ? `${plan.durationMinutes} min` : '—'} hint={isRideFastest && plan?.pickupBufferMinutes ? `inclui chamada média ${plan.pickupBufferMinutes} min` : isTransitFastest ? 'transporte público' : (plan?.delayMinutes ? `+${plan.delayMinutes} min no trânsito` : 'rota calculada')} />
                <SmartDepartureMetric label="Distância" value={plan?.distanceKm ? `${plan.distanceKm} km` : '—'} hint={plan?.humanSourceLabel || 'rota protegida'} />
                <SmartDepartureMetric label="Fonte" value={plan?.humanSourceLabel || (String(plan?.source || '').match(/Google|Uber|Dados reais/i) ? 'Dados reais' : 'Estimativa')} hint={plan?.humanSourceLabel === 'Dados reais' ? 'informação em tempo real' : 'cálculo calibrado'} />
              </div>

              <div className="mt-5 flex flex-wrap gap-2">
                <span className={`inline-flex items-center gap-1 rounded-2xl border px-3 py-2 text-[11px] font-black uppercase tracking-[0.12em] ${locationAllowed ? 'border-emerald-300/25 bg-emerald-300/10 text-emerald-100' : 'border-amber-300/25 bg-amber-300/10 text-amber-50'}`}><MapPin className="h-3.5 w-3.5" /> {locationAllowed ? 'localização permitida' : 'localização pendente'}</span>
                <span className={`inline-flex items-center gap-1 rounded-2xl border px-3 py-2 text-[11px] font-black uppercase tracking-[0.12em] ${notificationsAllowed ? 'border-emerald-300/25 bg-emerald-300/10 text-emerald-100' : 'border-amber-300/25 bg-amber-300/10 text-amber-50'}`}><Bell className="h-3.5 w-3.5" /> {notificationsAllowed ? 'notificações permitidas' : 'notificações pendentes'}</span>
              </div>

              <div className="mt-5 rounded-[1.7rem] border border-white/10 bg-white/[0.055] p-4 shadow-xl shadow-black/10">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[0.22em] text-cyan-100/60">base de saída</p>
                    <p className="mt-1 text-sm font-bold text-slate-100">Use GPS, casa ou outra base para calcular distância real.</p>
                  </div>
                  <button type="button" onClick={runRoutesDiagnostics} className="rounded-2xl border border-cyan-200/20 bg-cyan-300/10 px-3 py-2 text-xs font-black text-cyan-50">Testar Google Routes</button>
                </div>
                <div className="mt-4 grid gap-3 lg:grid-cols-3">
                  {(['gps','home','base2'] as const).map((item) => (
                    <button key={item} type="button" onClick={() => { setOriginMode(item); localStorage.setItem('crewcheck_departure_origin_mode', item); }} className={`rounded-2xl border px-4 py-3 text-left transition ${originMode === item ? 'border-cyan-200/40 bg-cyan-300/15 text-cyan-50' : 'border-white/10 bg-white/[0.04] text-slate-200 hover:bg-white/[0.07]'}`}>
                      <p className="text-xs font-black uppercase tracking-[0.16em]">{item === 'gps' ? 'GPS atual' : item === 'home' ? 'Casa' : 'Outra base'}</p>
                      <p className="mt-1 text-[11px] font-semibold text-slate-300">{item === 'gps' ? 'usa localização real' : item === 'home' ? (homeAddress || homeCep || 'CEP/endereço opcional') : (base2Label || 'base fora de casa')}</p>
                    </button>
                  ))}
                </div>
                {originMode !== 'gps' ? (
                  <div className="mt-4 grid gap-3 lg:grid-cols-[8rem_minmax(0,1fr)_9rem]">
                    {originMode === 'base2' ? <input value={base2Label} onChange={(e) => { setBase2Label(e.target.value); localStorage.setItem('crewcheck_base2_label', e.target.value); }} placeholder="Nome da base" className="rounded-2xl border border-white/10 bg-white/90 px-3 py-3 text-sm font-bold text-slate-900 outline-none focus:border-cyan-300" /> : null}
                    <input value={originMode === 'base2' ? base2Cep : homeCep} onChange={(e) => { originMode === 'base2' ? (setBase2Cep(e.target.value), localStorage.setItem('crewcheck_base2_cep', e.target.value)) : (setHomeCep(e.target.value), localStorage.setItem('crewcheck_home_cep', e.target.value)); }} placeholder="CEP" className="rounded-2xl border border-white/10 bg-white/90 px-3 py-3 text-sm font-bold text-slate-900 outline-none focus:border-cyan-300" />
                    <input value={originMode === 'base2' ? base2Address : homeAddress} onChange={(e) => { originMode === 'base2' ? (setBase2Address(e.target.value), localStorage.setItem('crewcheck_base2_address', e.target.value)) : (setHomeAddress(e.target.value), localStorage.setItem('crewcheck_home_address', e.target.value)); }} placeholder="Endereço completo, se quiser mais precisão" className="rounded-2xl border border-white/10 bg-white/90 px-3 py-3 text-sm font-bold text-slate-900 outline-none focus:border-cyan-300" />
                    <button type="button" onClick={() => void validateSelectedAddress()} disabled={addressLoading} className="rounded-2xl bg-cyan-300 px-4 py-3 text-sm font-black text-slate-950 shadow-lg shadow-cyan-950/20 disabled:opacity-60">{addressLoading ? 'Validando...' : 'Validar'}</button>
                  </div>
                ) : null}
                {addressStatus ? <p className="mt-3 rounded-2xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs font-bold text-slate-200">{addressStatus}</p> : null}
              </div>

              {plan?.leaveAtFullLabel ? <div className="mt-5 rounded-3xl border border-cyan-300/20 bg-cyan-300/10 px-4 py-3 text-lg font-black leading-6 text-cyan-50">{plan.leaveAtFullLabel}</div> : null}
              {plan?.recommendedReason ? <div className="mt-5 rounded-3xl border border-emerald-300/20 bg-emerald-300/10 px-4 py-3 text-sm font-bold leading-6 text-emerald-50">CrewCheck recomenda: {plan.recommendedReason}</div> : null}

              {routeOptions.length ? (
                <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                  {routeOptions.slice(0, 6).map((route, index) => (
                    <div key={`${route.mode}-${route.leaveAtLabel}-${index}`} className={`rounded-3xl border p-4 ${index === 0 ? 'border-emerald-300/25 bg-emerald-300/10' : 'border-white/10 bg-white/[0.05]'}`}>
                      <p className="text-[10px] font-black uppercase tracking-[0.18em] text-cyan-100/60">{index === 0 ? 'opção mais rápida' : route.mode === 'TRANSIT' ? 'transporte público' : route.mode === 'RIDE_APP' ? 'corrida por app' : 'carro'}</p>
                      <p className="mt-2 text-2xl font-black text-white">{route.leaveAtLabel || '—'}</p>
                      <p className="mt-1 text-sm font-bold text-slate-300">{route.durationMinutes || '—'} min · {route.mode === 'RIDE_APP' ? 'chamada + trajeto' : (route.label || 'rota')}</p><p className="mt-2 text-[11px] font-black uppercase tracking-[0.12em] text-cyan-100/70">{route.humanSourceLabel || route.routeQuality || 'Estimativa CrewCheck'}{route.pickupBufferMinutes ? ` · chamada média ${route.pickupBufferMinutes} min` : ''}</p>
                      {route.mode === 'TRANSIT' && route.firstTransitDeparture ? <p className="mt-2 rounded-2xl bg-white/10 px-3 py-2 text-xs font-black text-emerald-100">Primeiro embarque: {route.firstTransitDeparture}</p> : null}
                      {route.mode === 'RIDE_APP' && route.fareLabel ? <p className="mt-2 rounded-2xl bg-white/10 px-3 py-2 text-xs font-black text-emerald-100">Estimativa: {route.fareLabel} · {route.fareConfidence || 'confirmar no app'}</p> : null}
                      {route.mode === 'RIDE_APP' && route.rideApps?.length ? <div className="mt-3 flex flex-wrap gap-2">{route.rideApps.slice(0, 2).map((app) => <a key={app.id || app.name} href={app.webUrl || app.deepLink || app.mapsUrl || '#'} target="_blank" rel="noreferrer" className="rounded-2xl border border-cyan-200/20 bg-cyan-300/10 px-3 py-2 text-xs font-black text-cyan-50">Abrir {app.name || 'app'}</a>)}</div> : null}
                    </div>
                  ))}
                </div>
              ) : null}


              {rideBoard.length ? (
                <div className="mt-5 rounded-[2rem] border border-fuchsia-300/20 bg-fuchsia-300/[0.08] p-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <p className="text-xs font-black uppercase tracking-[0.22em] text-fuchsia-100/75">corrida por app</p>
                    <span className="rounded-full border border-fuchsia-300/20 bg-white/10 px-3 py-1 text-[10px] font-black uppercase tracking-[0.12em] text-fuchsia-50">Uber / 99 · confirmar no app</span>
                  </div>
                  <div className="mt-3 grid gap-2 md:grid-cols-2">
                    {rideBoard.slice(0, 4).map((app, index) => (
                      <div key={`${app.id}-${index}`} className="rounded-2xl border border-white/10 bg-white/[0.05] p-3">
                        <div className="flex items-start justify-between gap-2">
                          <p className="text-sm font-black text-fuchsia-50">{app.name || 'Corrida'}</p>
                          <span className="rounded-xl bg-white/10 px-2 py-1 text-xs font-black text-emerald-100">{app.fareLabel || 'confirmar'}</span>
                        </div>
                        <p className="mt-1 text-xs font-semibold leading-5 text-fuchsia-50/75">{app.status || 'Confirmar no app'}{app.etaMinutes ? ` · ${app.etaMinutes} min` : ''}</p>
                        <p className="text-[11px] font-bold text-slate-300">{app.fareConfidence || app.source || 'Estimativa CrewCheck'}</p>
                        <div className="mt-3 flex flex-wrap gap-2">
                          <a href={app.webUrl || app.deepLink || '#'} target="_blank" rel="noreferrer" className="rounded-2xl border border-fuchsia-200/20 bg-fuchsia-300/10 px-3 py-2 text-xs font-black text-fuchsia-50">Abrir {app.name || 'app'}</a>
                          {app.mapsUrl ? <a href={app.mapsUrl} target="_blank" rel="noreferrer" className="rounded-2xl border border-white/10 bg-white/[0.06] px-3 py-2 text-xs font-black text-slate-100">Ver rota</a> : null}
                        </div>
                      </div>
                    ))}
                  </div>
                  <p className="mt-3 text-xs leading-5 text-fuchsia-50/60">O CrewCheck exibe estimativa auditável e abre o app oficial com origem/destino preenchidos. O valor final sempre deve ser confirmado no aplicativo da corrida.</p>
                </div>
              ) : null}

              {transitBoard.length ? (
                <div className="mt-5 rounded-[2rem] border border-cyan-300/20 bg-cyan-300/[0.08] p-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <p className="text-xs font-black uppercase tracking-[0.22em] text-cyan-100/75">horários ônibus/metrô</p>
                    <span className="rounded-full border border-emerald-300/20 bg-emerald-300/10 px-3 py-1 text-[10px] font-black uppercase tracking-[0.12em] text-emerald-100">tempo real quando disponível</span>
                  </div>
                  <div className="mt-3 grid gap-2 md:grid-cols-2">
                    {transitBoard.slice(0, 8).map((step, index) => (
                      <div key={`${step.line}-${step.departureLabel}-${index}`} className="rounded-2xl border border-white/10 bg-white/[0.05] p-3">
                        <div className="flex items-start justify-between gap-2">
                          <p className="text-sm font-black text-cyan-50">{step.mode || 'Transporte'} {step.line ? `· ${step.line}` : ''}</p>
                          <span className="rounded-xl bg-white/10 px-2 py-1 text-xs font-black text-emerald-100">{step.departureLabel || 'a confirmar'}</span>
                        </div>
                        <p className="mt-1 text-xs font-semibold leading-5 text-cyan-50/75">{step.from || 'origem'} → {step.to || 'destino'}{step.arrivalLabel ? ` · chega ${step.arrivalLabel}` : ''}</p>
                        {step.headsign ? <p className="text-[11px] font-bold text-slate-400">Sentido {step.headsign}</p> : null}
                      </div>
                    ))}
                  </div>
                  <p className="mt-3 text-xs leading-5 text-cyan-50/60">Os horários dependem da cobertura da operadora no Google Transit. Quando não houver tempo real, o CrewCheck usa a grade oficial prevista e mostra fallback conservador.</p>
                </div>
              ) : null}

              {error ? <div className="mt-5 rounded-3xl border border-amber-300/25 bg-amber-300/10 px-4 py-3 text-sm font-bold leading-6 text-amber-50">{error}</div> : null}
              {plan?.warning ? <div className="mt-5 rounded-3xl border border-sky-300/20 bg-sky-300/10 px-4 py-3 text-sm font-bold leading-6 text-sky-50">{plan.warning}</div> : null}
              {plan?.isLate ? <div className="mt-5 rounded-3xl border border-rose-300/30 bg-rose-400/15 px-4 py-3 text-sm font-black leading-6 text-rose-50">Atenção: pela estimativa atual, a saída recomendada é agora.</div> : null}

              <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
                <button onClick={calculate} disabled={permission === 'requesting' || !canCalculate} className="cc-button-primary rounded-2xl px-6 py-4 text-sm font-black shadow-xl transition active:scale-95 disabled:opacity-50">{permission === 'requesting' ? 'Aguardando permissão...' : (locationAllowed ? 'Calcular / recalcular agora' : 'Ativar localização e calcular')}</button>
                <a href={googleMapsUrl} target="_blank" rel="noreferrer" className="rounded-2xl border border-cyan-200/20 bg-white/[0.06] px-6 py-4 text-center text-sm font-black text-cyan-50 transition hover:bg-white/[0.10]"><ExternalLink className="mr-2 inline h-4 w-4" /> Abrir rota</a>
                {rideBoard[0]?.webUrl ? <a href={rideBoard[0].webUrl} target="_blank" rel="noreferrer" className="rounded-2xl border border-fuchsia-200/25 bg-fuchsia-300/10 px-6 py-4 text-center text-sm font-black text-fuchsia-50 transition hover:bg-fuchsia-300/15"><Car className="mr-2 inline h-4 w-4" /> Abrir corrida</a> : null}
                <button onClick={requestAppNotifications} className="rounded-2xl border border-emerald-200/25 bg-emerald-300/10 px-6 py-4 text-sm font-black text-emerald-50 transition hover:bg-emerald-300/15"><Bell className="mr-2 inline h-4 w-4" /> {notificationsAllowed ? 'Notificações permitidas' : 'Ativar notificações'}</button>
                <button onClick={scheduleCurrentDepartureAlert} className="rounded-2xl border border-cyan-200/20 bg-cyan-300/10 px-6 py-4 text-sm font-black text-cyan-50 transition hover:bg-cyan-300/15"><Clock className="mr-2 inline h-4 w-4" /> Agendar hora de sair</button>
                <button onClick={onOpenRoster} className="rounded-2xl border border-white/10 px-6 py-4 text-sm font-black text-slate-100 transition hover:bg-white/10"><CalendarDays className="mr-2 inline h-4 w-4" /> Ver escala</button>
              </div>
            </div>

            <aside className="border-t border-white/10 bg-white/[0.045] p-6 lg:border-l lg:border-t-0">
              <p className="text-xs font-black uppercase tracking-[0.24em] text-cyan-100/70">Configuração rápida</p>
              <div className="mt-5 space-y-4">
                <SmartDepartureField label="Aeroporto/base da apresentação">
                  <select value={airport} onChange={(event) => setAirport(event.target.value)} className="w-full rounded-2xl border border-white/10 bg-[#07111F]/70 px-4 py-3 text-sm font-black text-white outline-none focus:border-cyan-300">
                    {SMART_DEPARTURE_AIRPORTS.map(([code, name]) => <option key={code} value={code}>{code} · {name}</option>)}
                  </select>
                </SmartDepartureField>
                <SmartDepartureField label="Margem de chegada">
                  <select value={margin} onChange={(event) => setMargin(Number(event.target.value))} className="w-full rounded-2xl border border-white/10 bg-[#07111F]/70 px-4 py-3 text-sm font-black text-white outline-none focus:border-cyan-300">
                    {[15,20,25,30,40,60].map((item) => <option key={item} value={item}>{item} minutos antes</option>)}
                  </select>
                </SmartDepartureField>
                <SmartDepartureField label="Transporte">
                  <select value={mode} onChange={(event) => setMode(event.target.value as 'AUTO' | 'DRIVE' | 'TRANSIT' | 'RIDE_APP')} className="w-full rounded-2xl border border-white/10 bg-[#07111F]/70 px-4 py-3 text-sm font-black text-white outline-none focus:border-cyan-300">
                    <option value="AUTO">Auto: sempre a forma mais rápida</option>
                    <option value="DRIVE">Carro próprio / trânsito</option>
                    <option value="TRANSIT">Transporte público</option>
                    <option value="RIDE_APP">Corrida por app · Uber/99</option>
                  </select>
                </SmartDepartureField>
              </div>
              <div className="mt-6 rounded-3xl border border-emerald-300/20 bg-emerald-300/10 p-4 text-sm leading-6 text-emerald-50/90">
                <b>LGPD:</b> a localização é usada sob permissão e apenas para calcular essa rota. As chaves do Google e da Uber ficam no backend/Render e não aparecem no aplicativo.
              </div>
              <div className="mt-4 rounded-3xl border border-cyan-300/20 bg-cyan-300/10 p-4 text-xs leading-6 text-cyan-50/80">
                <b>Trust Center:</b> o CrewCheck mostra se a rota veio do Google Routes, Directions, Uber API, app oficial ou fallback conservador. Quando o dado não for confirmado, o card sinaliza para confirmar no app oficial.
              </div>
              <div className="mt-4 rounded-3xl border border-white/10 bg-white/[0.04] p-4 text-xs leading-6 text-slate-300">
                Dica premium: no modo Auto o CrewCheck compara trânsito, transporte público e corrida por app. O preço final de Uber/99 sempre deve ser confirmado no app oficial.
              </div>
            </aside>
          </div>
        </section>
      </div>
    </div>
  );
}

function SmartDepartureField({ label, children }: { label: string; children: ReactNode }) {
  return <label className="block space-y-2 text-xs font-black uppercase tracking-[0.16em] text-cyan-100/70"><span>{label}</span>{children}</label>;
}

function SmartDepartureMetric({ label, value, hint }: { label: string; value: string; hint: string }) {
  return <div className="rounded-3xl border border-white/10 bg-white/[0.06] p-4 shadow-xl shadow-black/10"><p className="text-[0.65rem] font-black uppercase tracking-[0.18em] text-cyan-100/60">{label}</p><p className="mt-2 text-2xl font-black tracking-tight text-white">{value}</p><p className="mt-1 text-xs font-semibold leading-5 text-slate-300">{hint}</p></div>;
}

function IFlightBetaUserPanel({ onBack, onOpenImport }: { onBack: () => void; onOpenImport: () => void }) {
  return (
    <div className="min-h-screen overflow-x-hidden overflow-y-auto bg-[#07111F] px-5 py-8 text-white">
      <div className="mx-auto max-w-4xl">
        <HeaderBack title="iFlight automático" subtitle="Recurso em desenvolvimento" onBack={onBack} />
        <div className="mt-6 overflow-hidden rounded-[2rem] border border-orange-300/20 bg-white/[0.06] shadow-2xl shadow-black/25 backdrop-blur-2xl">
          <div className="bg-gradient-to-r from-orange-300/20 via-cyan-300/10 to-fuchsia-300/20 p-6 md:p-8">
            <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.22em] text-orange-100/80">beta privado</p>
                <h1 className="mt-2 text-3xl font-black tracking-tight md:text-5xl">Upload automático via iFlight ainda está em validação.</h1>
                <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-200/85">Por segurança e LGPD, o CrewCheck ainda não libera a sincronização automática completa para usuários finais. Quando estiver estável, ela aparecerá aqui sem precisar atualizar sua conta.</p>
              </div>
              <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-[1.7rem] bg-orange-300/15 text-orange-100"><Plane className="h-10 w-10" /></div>
            </div>
          </div>
          <div className="grid gap-4 p-5 md:grid-cols-3 md:p-7">
            <div className="rounded-3xl border border-white/10 bg-white/[0.05] p-5"><Shield className="mb-3 h-7 w-7 text-emerald-200" /><b>Credenciais protegidas</b><p className="mt-2 text-sm leading-6 text-slate-300">Senha e MFA corporativos não são salvos pelo CrewCheck.</p></div>
            <div className="rounded-3xl border border-white/10 bg-white/[0.05] p-5"><FileText className="mb-3 h-7 w-7 text-cyan-200" /><b>PDF manual liberado</b><p className="mt-2 text-sm leading-6 text-slate-300">Use PDF exportado pelo iFlight, CrewTopia ou CrewRosterReport/AIMS.</p></div>
            <div className="rounded-3xl border border-white/10 bg-white/[0.05] p-5"><AlertTriangle className="mb-3 h-7 w-7 text-amber-200" /><b>Fase de testes</b><p className="mt-2 text-sm leading-6 text-slate-300">Encontrou divergência? Envie o PDF/print pela aba Suporte.</p></div>
          </div>
          <div className="flex flex-col gap-3 border-t border-white/10 p-5 md:flex-row md:p-7">
            <button onClick={onOpenImport} className="rounded-2xl bg-white px-6 py-3 text-sm font-black text-[#07111F] shadow-lg transition hover:bg-cyan-50"><CloudUpload className="mr-2 inline h-4 w-4" /> Importar PDF agora</button>
            <a href="mailto:bmedeiros1987@gmail.com?subject=Feedback%20CrewCheck%20Beta" className="rounded-2xl border border-white/10 px-6 py-3 text-center text-sm font-black text-cyan-50 transition hover:bg-white/10"><Mail className="mr-2 inline h-4 w-4" /> Enviar feedback</a>
          </div>
        </div>
      </div>
    </div>
  );
}

function ImportScreen({ userLabel, roleSelection, onRoleSelectionChange, isDragging, isProcessing, error, fileName, fileInputRef, isAdmin, onBack, onDrop, onDragOver, onDragLeave, onFileInput, onLogout }: {
  userLabel: string;
  roleSelection: CrewRoleSelection;
  onRoleSelectionChange: (value: CrewRoleSelection) => void;
  isDragging: boolean;
  isProcessing: boolean;
  error: string | null;
  fileName: string | null;
  fileInputRef: RefObject<HTMLInputElement>;
  isAdmin: boolean;
  onBack: () => void;
  onDrop: (event: DragEvent) => void;
  onDragOver: (event: DragEvent) => void;
  onDragLeave: () => void;
  onFileInput: (event: ChangeEvent<HTMLInputElement>) => void;
  onLogout: () => void;
}) {
  return (
    <div className="min-h-screen overflow-x-hidden overflow-y-auto bg-[#07111F] text-white crewcheck-import-screen">
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,rgba(59,130,246,0.35),transparent_28%),radial-gradient(circle_at_80%_0%,rgba(236,72,153,0.25),transparent_32%),linear-gradient(135deg,#07111F_0%,#0B1730_45%,#0A1020_100%)]" />
        <div className="absolute inset-0 opacity-[0.08]" style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,0.85) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.85) 1px, transparent 1px)', backgroundSize: '64px 64px' }} />
      </div>

      <div className="relative z-10">
        <header className="container py-6">
          <div className="flex items-center justify-between gap-4 crewcheck-light-card rounded-3xl border border-white/10 bg-white/[0.06] px-5 py-4 shadow-2xl shadow-black/20 backdrop-blur-xl">
            <button onClick={onBack} className="flex items-center gap-3 text-left">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10 text-cyan-100"><ArrowLeft className="h-5 w-5" /></div>
              <div>
                <h1 className="text-lg font-black tracking-tight">Nova escala</h1>
                <p className="text-xs uppercase tracking-[0.24em] text-cyan-100/70">PDF direto · CrewTopia/iFlight · LGPD</p>
              </div>
            </button>
            <div className="hidden items-center gap-2 md:flex">
              <Badge className="border-white/10 bg-white/10 text-cyan-100 hover:bg-white/10"><Lock className="mr-1.5 h-3.5 w-3.5" /> Conta protegida</Badge>
              <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/10 px-3 py-1 text-sm text-cyan-100"><UserRound className="h-4 w-4" /><span className="max-w-[11rem] truncate">{userLabel}</span></div>
              <button onClick={onLogout} className="rounded-full border border-white/10 bg-white/10 px-3 py-1 text-xs font-black text-cyan-100 hover:bg-white/15"><LogOut className="mr-1 inline h-3.5 w-3.5" /> Sair</button>
            </div>
          </div>
        </header>

        <main className="container pb-16 pt-6 md:pb-24 md:pt-10">
          <section className="grid items-center gap-10 lg:grid-cols-[minmax(0,0.9fr)_minmax(28rem,0.8fr)] xl:grid-cols-[minmax(0,1fr)_minmax(30rem,0.74fr)]">
            <div className="cc-import-hero-panel">
              <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-cyan-300/20 bg-cyan-300/10 px-4 py-2 text-sm text-cyan-100 shadow-lg shadow-cyan-950/30"><Sparkles className="h-4 w-4" /> Upload direto de PDF CrewTopia, iFlight ou AIMS com LGPD</div>
              <h2 className="max-w-4xl text-4xl font-black leading-[1.04] tracking-tight md:text-6xl">Envie sua escala em PDF e veja tudo organizado em segundos.</h2>
              <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-200/80">Aceita PDF exportado pelo CrewTopia, pelo iFlight ou CrewRosterReport/AIMS. O CrewCheck interpreta voos, folgas, sobreavisos, pernoites, treinamentos, rotina e alertas.</p>
              <div className="mt-8 grid max-w-3xl grid-cols-2 gap-3 md:grid-cols-4">
                <Kpi icon={Radar} value="PDF" label="CrewTopia/iFlight/AIMS" />
                <Kpi icon={Shield} value="ACT" label="piloto ou comissário" />
                <Kpi icon={CalendarDays} value="Google" label="calendário sem duplicar" />
                <Kpi icon={Dumbbell} value="Rotina" label="sugestão dentro da escala" />
              </div>
            </div>

            <Card className="crewcheck-light-card relative overflow-hidden rounded-[2rem] border-white/10 bg-white/[0.08] p-4 text-white shadow-2xl shadow-black/30 backdrop-blur-2xl">
              <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-cyan-300 via-fuchsia-400 to-amber-300" />
              <div className="crewcheck-light-card rounded-[1.5rem] border border-white/10 bg-[#0B1730]/70 p-5 md:p-7">
                <div className="mb-5 flex items-center justify-between gap-4">
                  <div><p className="text-sm font-semibold text-cyan-100">Upload seguro</p><h3 className="text-2xl font-black tracking-tight">Analisar escala</h3></div>
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-300/15 text-cyan-200"><FileText className="h-6 w-6" /></div>
                </div>

                <div className="mb-5 rounded-[1.2rem] border border-amber-300/20 bg-amber-300/10 p-4 text-sm leading-6 text-amber-50/90">
                  <div className="flex gap-3"><AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-200" /><p><strong>Fase de testes privados:</strong> o CrewCheck ainda não tem data oficial de lançamento. As informações podem conter divergências; confira sempre com sua escala oficial. Se encontrar erro, abra a aba <strong>Suporte</strong> e envie o PDF ou print para ajustarmos o sistema.</p></div>
                </div>

                <div className="mb-5 grid gap-3 md:grid-cols-2">
                  <div className="rounded-[1.2rem] border border-emerald-300/20 bg-emerald-300/10 p-4"><p className="text-sm font-black text-emerald-100">Upload manual liberado</p><p className="mt-1 text-xs leading-5 text-emerald-50/80">Selecione qualquer PDF exportado pelo CrewTopia, iFlight ou CrewRosterReport/AIMS.</p></div>
                  <div className="rounded-[1.2rem] border border-orange-300/20 bg-orange-300/10 p-4"><p className="text-sm font-black text-orange-100">iFlight automático {isAdmin ? 'liberado para administrador' : 'em desenvolvimento'}</p><p className="mt-1 text-xs leading-5 text-orange-50/80">{isAdmin ? 'Você vê o módulo completo para testes internos.' : 'Para usuários finais, a opção completa será liberada somente após validação final.'}</p></div>
                </div>

                <div className="crewcheck-light-card mb-5 rounded-[1.2rem] border border-white/10 bg-white/[0.06] p-4">
                  <div className="mb-3 flex items-center justify-between gap-3"><div><p className="text-sm font-bold text-cyan-100">ACT aplicável</p><p className="text-xs leading-5 text-slate-300">O sistema tenta identificar pelo PDF, mas você pode forçar a função correta.</p></div><Badge className="border-cyan-300/20 bg-cyan-300/10 text-cyan-100 hover:bg-cyan-300/10">2025/2027</Badge></div>
                  <select value={roleSelection} onChange={(event) => onRoleSelectionChange(event.target.value as CrewRoleSelection)} className="h-12 w-full rounded-2xl border border-white/15 bg-[#07111F] px-4 text-sm font-bold text-white outline-none focus:border-cyan-300">
                    <option value="auto">Detectar automaticamente pela escala</option>
                    <option value="cabin">Aplicar ACT Comissários</option>
                    <option value="pilot">Aplicar ACT Pilotos</option>
                  </select>
                </div>

                <div onDragOver={onDragOver} onDragLeave={onDragLeave} onDrop={onDrop} className={`crewcheck-light-card relative rounded-[1.35rem] border-2 border-dashed p-8 text-center transition-all duration-300 ${isDragging ? 'scale-[1.015] border-cyan-300 bg-cyan-300/10' : 'border-white/15 bg-white/[0.04] hover:border-fuchsia-300/60 hover:bg-white/[0.07]'} ${isProcessing ? 'pointer-events-none opacity-70' : ''}`}>
                  {isProcessing ? (
                    <div className="flex flex-col items-center gap-4 py-6"><div className="h-14 w-14 animate-spin rounded-full border-4 border-cyan-300 border-t-transparent" /><div><p className="text-lg font-bold">Interpretando {fileName || 'PDF'}...</p><p className="mt-1 text-sm text-slate-300">Lendo cabeçalho, trechos, jornadas, folgas e totais.</p></div></div>
                  ) : (
                    <div className="flex flex-col items-center gap-5 py-4">
                      <div className="flex h-20 w-20 items-center justify-center rounded-[1.7rem] bg-gradient-to-br from-cyan-300 to-fuchsia-400 text-[#07111F] shadow-xl shadow-cyan-500/25"><Upload className="h-9 w-9" /></div>
                      <div><p className="text-xl font-black">Arraste sua escala em PDF aqui</p><p className="mt-2 text-sm text-slate-300">CrewTopia, iFlight, CrewRosterReport ou AIMS — PDF original exportado do sistema</p></div>
                      <label className="cc-button-primary relative inline-flex cursor-pointer items-center justify-center rounded-2xl px-7 py-3 text-sm font-black shadow-lg transition active:scale-[0.99]"><input ref={fileInputRef} type="file" accept="application/pdf,.pdf,application/octet-stream" onChange={onFileInput} className="absolute inset-0 h-full w-full cursor-pointer opacity-0" />Escolher PDF da escala agora</label>
                      <p className="max-w-md text-xs leading-5 text-slate-400">No iPhone/iPad, prefira Arquivos → No iPhone/iCloud Drive. Se veio do WhatsApp, salve em Arquivos antes. A importação automática pelo iFlight ainda é experimental para usuários finais.</p>
                    </div>
                  )}
                </div>

                {error && <div className="mt-4 flex gap-3 rounded-2xl border border-red-300/20 bg-red-500/10 p-4 text-left text-red-100"><AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" /><p className="text-sm leading-6">{error}</p></div>}

                <div className="mt-5 grid gap-3 text-sm text-slate-200/85">
                  <TrustLine icon={CheckCircle2} text="Processamento com parser do servidor e fallback local no app." />
                  <TrustLine icon={CheckCircle2} text="Gera painel, alertas, rotina, PDF, ICS e Google Calendar." />
                  <TrustLine icon={CheckCircle2} text="Salvamento automático sem duplicar histórico." />
                </div>
              </div>
            </Card>
          </section>
        </main>
      </div>
    </div>
  );
}


type FlightBoardType = 'departure' | 'arrival';

type ExternalRadarLink = { label: string; url: string; kind?: string };

type AirportBoardRow = {
  flightNumber: string;
  airlineCode?: string | null;
  airlineName?: string | null;
  destination?: string | null;
  origin?: string | null;
  gate?: string | null;
  terminal?: string | null;
  scheduledTime?: string | null;
  confirmedTime?: string | null;
  status?: string | null;
  type?: FlightBoardType;
  externalLinks?: ExternalRadarLink[];
};

type RadarDiagnostic = { provider?: string; endpoint?: string; baseUrl?: string; ok?: boolean; status?: number; reason?: string; count?: number; throttled?: boolean; waitMs?: number; cached?: boolean };


const BOARD_AIRPORTS = [
  { code: 'BSB', city: 'Brasília' },
  { code: 'GRU', city: 'Guarulhos' },
  { code: 'CGH', city: 'Congonhas' },
  { code: 'SDU', city: 'Santos Dumont' },
  { code: 'GIG', city: 'Galeão' },
  { code: 'CNF', city: 'Confins' },
  { code: 'VCP', city: 'Viracopos' },
  { code: 'SSA', city: 'Salvador' },
  { code: 'REC', city: 'Recife' },
  { code: 'FOR', city: 'Fortaleza' },
  { code: 'NAT', city: 'Natal' },
  { code: 'POA', city: 'Porto Alegre' },
  { code: 'CWB', city: 'Curitiba' },
  { code: 'MAO', city: 'Manaus' },
];

const BOARD_AIRLINES = [
  { code: '', label: 'Todas' },
  { code: 'LA', label: 'LATAM' },
  { code: 'G3', label: 'GOL' },
  { code: 'AD', label: 'Azul' },
  { code: 'TP', label: 'TAP' },
  { code: 'CM', label: 'Copa' },
  { code: 'AA', label: 'American' },
];

function FlightBoardScreen({ onBack }: { onBack: () => void }) {
  const [airport, setAirport] = useState('BSB');
  const [type, setType] = useState<FlightBoardType>('departure');
  const [airline, setAirline] = useState('');
  const [query, setQuery] = useState('');
  const [rows, setRows] = useState<AirportBoardRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [updatedAt, setUpdatedAt] = useState<string | null>(null);
  const [boardSource, setBoardSource] = useState('');
  const [boardMessage, setBoardMessage] = useState('');
  const [boardDiagnostics, setBoardDiagnostics] = useState<RadarDiagnostic[]>([]);
  const [providerReady, setProviderReady] = useState(false);
  const [externalSources, setExternalSources] = useState<ExternalRadarLink[]>([]);
  const [providerStatus, setProviderStatus] = useState<{ aviationstack?: boolean; flightstats?: boolean; official?: boolean }>({});
  const airportLabel = BOARD_AIRPORTS.find((item) => item.code === airport)?.city || airport;

  const loadBoard = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const params = new URLSearchParams({ airport, type, limit: '60', diagnostics: '1' });
      if (airline) params.set('airline', airline);
      const response = await fetch(`/api/airport-board?${params.toString()}`, { cache: 'no-store' });
      const payload = await response.json().catch(() => null);
      if (!response.ok || !payload?.ok) throw new Error(payload?.message || 'Painel indisponível.');
      setRows(Array.isArray(payload.rows) ? payload.rows : []);
      setUpdatedAt(payload.updatedAt || new Date().toISOString());
      setBoardSource(String(payload.source || ''));
      setBoardMessage(String(payload.message || ''));
      setBoardDiagnostics(Array.isArray(payload.diagnostics) ? payload.diagnostics : []);
      setExternalSources([]);
      setProviderStatus(payload.providerStatus || {});
      setProviderReady(Boolean(payload.providerReady || payload.rows?.length));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Não foi possível carregar o painel.');
      setRows([]);
      setBoardSource('');
      setBoardMessage('');
      setBoardDiagnostics([]);
      setExternalSources([]);
      setProviderStatus({});
      setProviderReady(false);
    } finally {
      setLoading(false);
    }
  }, [airport, type, airline]);

  useEffect(() => {
    void loadBoard();
    const timer = window.setInterval(() => void loadBoard(), 5 * 60_000);
    return () => window.clearInterval(timer);
  }, [loadBoard]);

  const filteredRows = rows.filter((row) => {
    const haystack = `${row.flightNumber || ''} ${row.airlineCode || ''} ${row.airlineName || ''} ${row.destination || ''} ${row.origin || ''} ${row.status || ''}`.toLowerCase();
    return !query.trim() || haystack.includes(query.trim().toLowerCase());
  });

  return (
    <div className="min-h-screen overflow-x-hidden bg-[#061425] px-4 py-6 pb-32 text-white sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <HeaderBack
          title="Radar de Voos"
          subtitle="painel estilo aeroporto · partidas e chegadas"
          onBack={onBack}
          action={<button onClick={() => void loadBoard()} className="cc-button-primary rounded-2xl px-4 py-2 text-xs font-black"><RefreshCw className={`mr-2 inline h-4 w-4 ${loading ? 'animate-spin' : ''}`} />Atualizar</button>}
        />

        <section className="mt-6 overflow-hidden rounded-[2.2rem] border border-cyan-300/20 bg-[radial-gradient(circle_at_20%_0%,rgba(14,165,233,.35),transparent_35%),linear-gradient(135deg,rgba(8,47,73,.92),rgba(2,6,23,.98))] shadow-2xl shadow-black/35">
          <div className="border-b border-cyan-200/10 px-5 py-5 sm:px-7">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
              <div>
                <div className="inline-flex items-center gap-2 rounded-full border border-cyan-200/15 bg-cyan-300/10 px-4 py-2 text-xs font-black uppercase tracking-[0.2em] text-cyan-100"><Monitor className="h-4 w-4" /> Torre CrewCheck</div>
                <h2 className="mt-4 text-4xl font-black tracking-tight sm:text-6xl">{type === 'departure' ? 'Partidas' : 'Chegadas'} · {airport}</h2>
                <p className="mt-2 text-sm text-cyan-50/75">{airportLabel} · filtros por localidade, companhia aérea e busca livre.</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <span className="rounded-full border border-cyan-200/20 bg-cyan-300/10 px-3 py-1 text-[0.68rem] font-black uppercase tracking-[0.16em] text-cyan-50">Fonte: {boardSource || (airport === 'BSB' ? 'BSB Aero oficial' : airport === 'GRU' ? 'GRU Airport oficial' : 'Aviationstack')}</span>
                  <span className={`rounded-full border px-3 py-1 text-[0.68rem] font-black uppercase tracking-[0.16em] ${providerReady ? 'border-emerald-200/30 bg-emerald-300/15 text-emerald-50' : 'border-amber-200/30 bg-amber-300/15 text-amber-50'}`}>{providerReady ? 'API ativa' : 'API a configurar'}</span>
                  <span className="rounded-full border border-white/15 bg-white/10 px-3 py-1 text-[0.68rem] font-black uppercase tracking-[0.16em] text-white/80">Atualiza a cada 5 min</span>
                  {providerStatus.flightstats ? <span className="rounded-full border border-indigo-200/30 bg-indigo-300/15 px-3 py-1 text-[0.68rem] font-black uppercase tracking-[0.16em] text-indigo-50">Provedor premium ativo</span> : null}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 sm:flex sm:flex-wrap">
                <select value={airport} onChange={(event) => setAirport(event.target.value)} className="h-12 rounded-2xl border border-white/10 bg-white/10 px-4 text-sm font-black text-white outline-none backdrop-blur-xl">
                  {BOARD_AIRPORTS.map((item) => <option key={item.code} value={item.code} className="bg-slate-950">{item.code} · {item.city}</option>)}
                </select>
                <select value={airline} onChange={(event) => setAirline(event.target.value)} className="h-12 rounded-2xl border border-white/10 bg-white/10 px-4 text-sm font-black text-white outline-none backdrop-blur-xl">
                  {BOARD_AIRLINES.map((item) => <option key={item.code || 'all'} value={item.code} className="bg-slate-950">{item.label}</option>)}
                </select>
                <div className="col-span-2 grid grid-cols-2 rounded-2xl border border-white/10 bg-white/10 p-1 sm:col-span-1 sm:w-64">
                  <button onClick={() => setType('departure')} className={`rounded-xl px-4 py-2 text-xs font-black uppercase tracking-[0.12em] transition ${type === 'departure' ? 'bg-cyan-300 text-[#07111f]' : 'text-cyan-100 hover:bg-white/10'}`}>Partidas</button>
                  <button onClick={() => setType('arrival')} className={`rounded-xl px-4 py-2 text-xs font-black uppercase tracking-[0.12em] transition ${type === 'arrival' ? 'bg-cyan-300 text-[#07111f]' : 'text-cyan-100 hover:bg-white/10'}`}>Chegadas</button>
                </div>
              </div>
            </div>

            <div className="mt-5 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
              <label className="flex h-12 min-w-0 flex-1 items-center gap-3 rounded-2xl border border-white/10 bg-black/20 px-4 text-sm text-cyan-50 shadow-inner shadow-black/20">
                <Search className="h-4 w-4 shrink-0 text-cyan-200" />
                <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar voo, destino/origem, companhia ou status..." className="min-w-0 flex-1 bg-transparent font-semibold outline-none placeholder:text-cyan-100/40" />
              </label>
              <div className="flex items-center gap-2 rounded-2xl border border-white/10 bg-white/8 px-4 py-3 text-xs font-bold text-cyan-50/75"><SlidersHorizontal className="h-4 w-4 text-cyan-200" /> {filteredRows.length} voo(s) · atualizado {updatedAt ? new Date(updatedAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '—'}</div>
            </div>
          </div>

          <div className="hidden overflow-hidden lg:block">
            <div className="grid grid-cols-[7rem_12rem_minmax(12rem,1fr)_7rem_7rem_minmax(10rem,1fr)] border-b border-cyan-200/10 bg-black/25 px-5 py-3 text-sm font-black uppercase tracking-[0.12em] text-cyan-100">
              <span>Voo</span><span>Companhia</span><span>{type === 'departure' ? 'Destino' : 'Origem'}</span><span>Portão</span><span>Hora</span><span>Observação</span>
            </div>
            {loading && !filteredRows.length ? <BoardLoading /> : filteredRows.length ? filteredRows.map((row, index) => <AirportBoardDesktopRow key={`${row.flightNumber}-${index}`} row={row} type={type} />) : <BoardEmpty error={error} />}
          </div>

          <div className="grid gap-3 p-4 lg:hidden">
            {loading && !filteredRows.length ? <BoardLoading /> : filteredRows.length ? filteredRows.map((row, index) => <AirportBoardMobileCard key={`${row.flightNumber}-${index}`} row={row} type={type} />) : <BoardEmpty error={error} />}
          </div>
        </section>

        <div className="mt-4 rounded-3xl border border-white/10 bg-white/[0.05] p-4 text-xs leading-5 text-slate-300">
          <MapPin className="mr-2 inline h-4 w-4 text-cyan-200" /> O Radar de Voos usa fontes automáticas pelo backend do CrewCheck. Sites externos não ficam disponíveis ao usuário; portão, status e terminal aparecem somente quando houver dado confiável. {boardMessage ? `${boardMessage} ` : ''}As informações aeroportuárias podem variar; confirme sempre com os monitores oficiais do aeroporto.
          {!filteredRows.length && boardDiagnostics.length ? (
            <div className="mt-3 rounded-2xl border border-amber-200/20 bg-amber-300/10 p-3 text-amber-50">
              <strong>Diagnóstico premium:</strong> {boardDiagnostics.slice(0, 5).map((item, index) => (
                <span key={index} className="block">{item.provider || 'Provedor'} {item.endpoint || ''}: {item.ok ? `${item.count ?? 0} item(ns)` : (item.throttled ? 'aguardando limite da API' : (item.reason || `HTTP ${item.status || 'erro'}`))}</span>
              ))}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}

function airlineTheme(code?: string | null) {
  const normalized = String(code || '').toUpperCase();
  if (['LA', 'JJ', 'TAM'].includes(normalized)) return 'bg-violet-700 text-white';
  if (['G3', 'GLO'].includes(normalized)) return 'bg-orange-500 text-white';
  if (['AD', 'AZU'].includes(normalized)) return 'bg-blue-700 text-white';
  if (['TP', 'TAP'].includes(normalized)) return 'bg-emerald-400 text-[#07111f]';
  if (['CM', 'CMP'].includes(normalized)) return 'bg-sky-700 text-white';
  if (['AA', 'AAL'].includes(normalized)) return 'bg-white text-slate-900';
  return 'bg-cyan-300 text-[#07111f]';
}

function statusTheme(status?: string | null) {
  const text = String(status || '').toLowerCase();
  if (text.includes('cancel')) return 'text-rose-200';
  if (text.includes('atras') || text.includes('delay')) return 'text-amber-200';
  if (text.includes('chamada') || text.includes('embar')) return 'text-orange-200';
  if (text.includes('decol') || text.includes('pous') || text.includes('land')) return 'text-sky-200';
  return 'text-emerald-200';
}

function rowDestination(row: AirportBoardRow, type: FlightBoardType) {
  return type === 'departure' ? (row.destination || '—') : (row.origin || '—');
}

function AirportBoardDesktopRow({ row, type }: { row: AirportBoardRow; type: FlightBoardType }) {
  return (
    <div className="grid grid-cols-[7rem_12rem_minmax(12rem,1fr)_7rem_7rem_minmax(10rem,1fr)] items-center border-b border-cyan-200/5 bg-cyan-950/20 px-5 py-3 text-xl font-black text-white odd:bg-white/[0.035]">
      <span>{row.flightNumber || '—'}</span>
      <span><span className={`inline-flex min-w-24 justify-center rounded-full px-3 py-1 text-sm font-black ${airlineTheme(row.airlineCode)}`}>{row.airlineName || row.airlineCode || 'Cia'}</span></span>
      <span className="truncate text-yellow-200">{rowDestination(row, type)}</span>
      <span>{row.gate || '—'}</span>
      <span>{row.confirmedTime || row.scheduledTime || '—'}</span>
      <span className={statusTheme(row.status)}>{row.status || 'Confirmado'}</span>
    </div>
  );
}

function AirportBoardMobileCard({ row, type }: { row: AirportBoardRow; type: FlightBoardType }) {
  return (
    <div className="rounded-3xl border border-cyan-200/10 bg-white/[0.07] p-4 shadow-xl shadow-black/20">
      <div className="flex items-start justify-between gap-3">
        <div><p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-100/55">{type === 'departure' ? 'Destino' : 'Origem'}</p><h3 className="mt-1 text-2xl font-black text-yellow-200">{rowDestination(row, type)}</h3></div>
        <span className={`rounded-full px-3 py-1 text-xs font-black ${airlineTheme(row.airlineCode)}`}>{row.airlineName || row.airlineCode || 'Cia'}</span>
      </div>
      <div className="mt-4 grid grid-cols-3 gap-2 text-center">
        <BoardPill label="Voo" value={row.flightNumber || '—'} />
        <BoardPill label="Portão" value={row.gate || '—'} />
        <BoardPill label="Hora" value={row.confirmedTime || row.scheduledTime || '—'} />
      </div>
      <p className={`mt-4 text-lg font-black ${statusTheme(row.status)}`}>{row.status || 'Confirmado'}</p>
    </div>
  );
}

function BoardPill({ label, value }: { label: string; value: string }) {
  return <div className="rounded-2xl border border-cyan-200/10 bg-black/20 px-3 py-2"><p className="text-[10px] font-black uppercase tracking-[0.14em] text-cyan-100/50">{label}</p><p className="mt-1 text-base font-black text-white">{value}</p></div>;
}

function BoardLoading() {
  return <div className="flex min-h-[16rem] flex-col items-center justify-center gap-3 p-8 text-center text-cyan-100"><Loader2 className="h-10 w-10 animate-spin" /><p className="font-black">Atualizando painel de voos...</p></div>;
}

function BoardEmpty({ error }: { error?: string }) {
  return <div className="flex min-h-[16rem] flex-col items-center justify-center gap-3 p-8 text-center text-cyan-100"><Building2 className="h-10 w-10" /><p className="font-black">Nenhum voo encontrado com estes filtros.</p><p className="max-w-lg text-sm text-cyan-50/65">{error || 'Tente trocar aeroporto, companhia ou tipo de movimento. Alguns provedores podem limitar atualizações por aeroporto/plano.'}</p></div>;
}

function HistoryScreen({ rosters, loading, dbStatus, openingId, onBack, onOpen, onRefresh }: {
  rosters: SavedRosterSummary[];
  loading: boolean;
  dbStatus: DatabaseStatus | null;
  openingId: string | null;
  onBack: () => void;
  onOpen: (id: string) => void;
  onRefresh: () => void;
}) {
  const dbOnline = Boolean(dbStatus?.connected || dbStatus?.ok);
  return (
    <div className="min-h-screen bg-[#08111f] px-5 py-8 text-white">
      <div className="mx-auto max-w-4xl">
        <HeaderBack title="Histórico de escalas" subtitle={dbOnline ? 'Banco online' : 'Histórico local/offline'} onBack={onBack} action={<button onClick={onRefresh} className="rounded-2xl border border-white/10 bg-white/10 px-4 py-2 text-xs font-black text-cyan-100"><RefreshCw className="mr-2 inline h-4 w-4" />Atualizar</button>} />
        {loading ? <StateCard icon={Loader2} title="Buscando escalas" text="Carregando histórico salvo..." spin /> : rosters.length ? (
          <div className="mt-6 grid gap-3">
            {rosters.map((item) => (
              <button key={item.id} onClick={() => onOpen(item.id)} disabled={openingId === item.id} className="flex w-full items-center justify-between gap-4 rounded-3xl border border-white/10 bg-white/[0.05] p-5 text-left transition hover:bg-white/[0.09] disabled:opacity-60">
                <div><p className="text-xs font-black uppercase tracking-[0.2em] text-cyan-100/70">{monthLabel(item.month, item.year)} · {item.base || 'Base'}</p><h3 className="mt-1 text-lg font-black">{item.crewName || 'Tripulante'}</h3><p className="mt-1 text-sm text-slate-400">{item.sourceFileName || 'Escala salva'} · score {item.score ?? '-'}</p></div>
                <div className="rounded-2xl bg-white px-4 py-2 text-sm font-black text-[#07111f]">{openingId === item.id ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Abrir'}</div>
              </button>
            ))}
          </div>
        ) : <StateCard icon={FolderOpen} title="Nenhuma escala salva" text="Importe uma escala uma vez; ela ficará disponível aqui após o login." />}
      </div>
    </div>
  );
}

function NotesPanel({ onBack }: { onBack: () => void }) {
  const [note, setNote] = useState(() => localStorage.getItem('crewcheck_personal_notes') || '');
  return (
    <div className="min-h-screen bg-[#08111f] px-5 py-8 text-white">
      <div className="mx-auto max-w-3xl">
        <HeaderBack title="Notas" subtitle="Anotações locais do tripulante" onBack={onBack} />
        <div className="mt-6 rounded-3xl border border-white/10 bg-white/[0.05] p-5">
          <textarea value={note} onChange={(event) => setNote(event.target.value)} placeholder="Ex.: observar pernoite, descanso, voo extra, treinamento, pendência pessoal..." className="min-h-[18rem] w-full rounded-2xl border border-white/10 bg-[#07111f] p-4 text-sm leading-6 text-white outline-none focus:border-cyan-300" />
          <div className="mt-4 flex justify-end"><Button onClick={() => { localStorage.setItem('crewcheck_personal_notes', note); toast.success('Notas salvas neste dispositivo.'); }} className="rounded-2xl bg-cyan-300 text-[#07111f] hover:bg-cyan-200"><StickyNote className="h-4 w-4" /> Salvar notas</Button></div>
        </div>
      </div>
    </div>
  );
}

function SettingsHomePanel({ userLabel, userEmail, profileSettings, avatar, pendingOffline, hasRoster, themeMode, onThemeModeChange, onProfileSettingsChange, onAvatarChange, onBack, onOpenIFlight, onOpenImport, onOpenResultsSettings, onOpenPerDiem, onOpenSalary, onExportPdf, onExportIcs, onSyncPending, onLogout }: {
  userLabel: string;
  userEmail: string;
  profileSettings: LocalProfileSettings;
  avatar: string;
  pendingOffline: number;
  hasRoster: boolean;
  themeMode: CrewThemeMode;
  onThemeModeChange: (mode: CrewThemeMode) => void;
  onProfileSettingsChange: (settings: LocalProfileSettings) => void;
  onAvatarChange: (value: string) => void;
  onBack: () => void;
  onOpenIFlight: () => void;
  onOpenImport: () => void;
  onOpenResultsSettings: () => void;
  onOpenPerDiem: () => void;
  onOpenSalary: () => void;
  onExportPdf: () => void;
  onExportIcs: () => void;
  onSyncPending: () => void;
  onLogout: () => void;
}) {
  type SettingsCategoryKey = 'profile' | 'calendar' | 'preferences' | 'notifications' | 'finance' | 'exports' | 'privacy' | 'manual';
  const [activeCategory, setActiveCategory] = useState<SettingsCategoryKey>('profile');
  const [settingsPulse, setSettingsPulse] = useState<SettingsCategoryKey | null>(null);
  const settingsContentRef = useRef<HTMLElement | null>(null);

  function openSettingsCategory(key: SettingsCategoryKey) {
    setActiveCategory(key);
    setSettingsPulse(key);
    toast.success('Abrindo configuração.');
    window.setTimeout(() => {
      settingsContentRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setSettingsPulse(null);
    }, 90);
  }
  const [preview, setPreview] = useState(avatar);
  const [isSaving, setIsSaving] = useState(false);
  const [profileForm, setProfileForm] = useState<LocalProfileSettings>(profileSettings);
  const [language, setLanguage] = useState<CrewLanguage>(() => getSavedLanguage());
  const [googleSettings, setGoogleSettings] = useState<GoogleCalendarSettings>(() => loadGoogleCalendarSettings());
  const [calendars, setCalendars] = useState<GoogleCalendarOption[]>([]);
  const [googleConnected, setGoogleConnected] = useState(() => hasGoogleCalendarToken());
  const [googleBusy, setGoogleBusy] = useState(false);
  const [clientIdOverride, setClientIdOverride] = useState(() => getGoogleClientIdOverride());
  const googleConfigured = isGoogleCalendarConfigured();
  const hasEnvClientId = hasGoogleClientIdFromEnv();

  useEffect(() => {
    setPreview(avatar);
  }, [avatar]);

  function persistGoogle(next: GoogleCalendarSettings) {
    const saved = saveGoogleCalendarSettings(next);
    setGoogleSettings(saved);
    toast.success('Configuração do Google Calendar salva.');
  }

  async function handleConnectGoogle() {
    if (!isGoogleCalendarConfigured()) {
      toast.error('Configure o Google Client ID para ativar o Google Calendar direto.');
      return;
    }
    setGoogleBusy(true);
    try {
      await connectGoogleCalendar('consent select_account');
      setGoogleConnected(true);
      const items = await listGoogleCalendars();
      setCalendars(items);
      const current = loadGoogleCalendarSettings();
      if (!current.selectedCalendarId && items[0]) persistGoogle({ ...current, selectedCalendarId: items[0].id, selectedCalendarName: items[0].summary });
      toast.success('Google Calendar conectado.');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Não consegui conectar ao Google Calendar.');
    } finally {
      setGoogleBusy(false);
    }
  }

  async function handleRefreshCalendars() {
    setGoogleBusy(true);
    try {
      const items = await listGoogleCalendars();
      setCalendars(items);
      toast.success('Calendários atualizados.');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Não consegui atualizar os calendários.');
    } finally {
      setGoogleBusy(false);
    }
  }

  function handleSaveClientId() {
    saveGoogleClientIdOverride(clientIdOverride);
    toast.success('Client ID Google salvo/removido neste dispositivo.');
  }

  const calendarOptions = (() => {
    const map = new Map<string, GoogleCalendarOption>();
    map.set(googleSettings.selectedCalendarId || 'primary', { id: googleSettings.selectedCalendarId || 'primary', summary: googleSettings.selectedCalendarName || 'Calendário principal' });
    map.set('primary', { id: 'primary', summary: 'Calendário principal', primary: true, accessRole: 'owner' });
    calendars.forEach((calendar) => map.set(calendar.id, calendar));
    return Array.from(map.values());
  })();

  async function handleAvatarInput(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/') && !/\.(png|jpe?g|webp|heic|heif)$/i.test(file.name)) {
      toast.error('Escolha uma imagem válida.');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error('A imagem precisa ter até 5 MB.');
      return;
    }
    setIsSaving(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => typeof reader.result === 'string' ? resolve(reader.result) : reject(new Error('Imagem inválida.'));
        reader.onerror = () => reject(reader.error || new Error('Falha ao ler imagem.'));
        reader.readAsDataURL(file);
      });
      setPreview(dataUrl);
      onAvatarChange(dataUrl);
      toast.success('Foto de perfil atualizada.');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Não consegui salvar a imagem.');
    } finally {
      setIsSaving(false);
    }
  }

  function removeAvatar() {
    setPreview('');
    onAvatarChange('');
    toast.success('Foto removida.');
  }

  function saveProfile() {
    onProfileSettingsChange(profileForm);
  }

  function handleLanguageChange(next: CrewLanguage) {
    setLanguage(saveCrewLanguage(next));
    applyDocumentLanguage();
    toast.success('Idioma salvo neste dispositivo.');
    window.setTimeout(() => window.dispatchEvent(new Event('crewcheck:language-change')), 0);
  }

  const categories: Array<{ key: SettingsCategoryKey; title: string; text: string; icon: LucideIcon; badge?: string; tone: string }> = [
    { key: 'profile', title: 'Perfil', text: 'nome, foto e base', icon: UserRound, badge: profileForm.base || 'local', tone: 'from-cyan-300 to-blue-500' },
    { key: 'calendar', title: 'Agenda', text: 'Google e ICS', icon: CalendarDays, badge: googleConnected ? 'conectada' : 'opcional', tone: 'from-blue-300 to-indigo-500' },
    { key: 'preferences', title: 'Preferências', text: 'tema e idioma', icon: Languages, badge: themeMode === 'system' ? 'auto' : themeMode, tone: 'from-violet-300 to-fuchsia-500' },
    { key: 'notifications', title: 'Permissões', text: 'localização e alertas', icon: Bell, badge: 'status', tone: 'from-emerald-300 to-teal-500' },
    { key: 'finance', title: 'Valores', text: 'diárias e salário', icon: TrendingUp, badge: 'previsões', tone: 'from-lime-300 to-emerald-500' },
    { key: 'exports', title: 'Exportar', text: 'PDF, agenda e fila', icon: DownloadIcon, badge: hasRoster ? 'pronto' : 'sem escala', tone: 'from-sky-300 to-cyan-500' },
    { key: 'privacy', title: 'Privacidade', text: 'LGPD e segurança', icon: Shield, badge: 'local', tone: 'from-slate-200 to-slate-500' },
    { key: 'manual', title: 'Manual', text: 'guia e suporte', icon: FileText, badge: 'ajuda', tone: 'from-amber-300 to-orange-500' },
  ];

  const current = categories.find((item) => item.key === activeCategory) || categories[0];

  const copySupportSummary = () => {
    const text = `CrewCheck v${APP_VERSION}\nUsuário: ${userLabel}\nE-mail: ${userEmail || 'não informado'}\nBase: ${profileForm.base || 'não informada'}\nCategoria: ${current.title}`;
    navigator.clipboard?.writeText(text)?.then(() => toast.success('Resumo copiado.')).catch(() => toast.info('Não consegui copiar automaticamente.'));
  };

  function renderCategoryContent() {
    if (activeCategory === 'profile') {
      return (
        <SettingsCategoryCard eyebrow="Perfil local" title="Quem aparece no CrewCheck" description="Esses dados ficam salvos apenas neste dispositivo e ajudam a identificar chefia, base e exportações.">
          <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              <div className="relative flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-[1.7rem] border border-cyan-200/20 bg-gradient-to-br from-cyan-300/25 to-blue-500/10">
                {preview ? <img src={preview} alt="Foto do perfil" className="h-full w-full object-cover" /> : <UserRound className="h-10 w-10 text-cyan-100" />}
              </div>
              <div>
                <h3 className="text-2xl font-black">{profileForm.displayName || userLabel || 'Tripulante'}</h3>
                <p className="mt-1 text-sm leading-6 text-slate-400">Perfil minimalista para exibição, cálculos e relatórios.</p>
              </div>
            </div>
            <Badge className="w-fit rounded-full border-0 bg-cyan-300/15 text-cyan-100">{profileForm.base || 'Base opcional'}</Badge>
          </div>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            <label className="flex cursor-pointer items-center justify-center gap-3 rounded-2xl bg-cyan-300 px-5 py-4 text-sm font-black text-[#07111f] shadow-lg shadow-cyan-950/25 transition hover:bg-cyan-200 active:scale-[0.99]">
              <Camera className="h-5 w-5" /> {isSaving ? 'Salvando...' : 'Trocar foto'}
              <input type="file" accept="image/*,.heic,.heif" onChange={handleAvatarInput} disabled={isSaving} className="sr-only" />
            </label>
            <button onClick={removeAvatar} disabled={!preview} className="flex items-center justify-center gap-3 rounded-2xl border border-white/10 bg-white/10 px-5 py-4 text-sm font-black text-white transition hover:bg-white/15 disabled:cursor-not-allowed disabled:opacity-40">
              <Trash2 className="h-5 w-5" /> Remover foto
            </button>
          </div>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            <ProfileField label="Nome exibido" value={profileForm.displayName} placeholder="Nome que aparecerá no app" onChange={(value) => setProfileForm({ ...profileForm, displayName: value })} />
            <ProfileField label="Descrição" value={profileForm.company} placeholder="Descrição opcional" onChange={(value) => setProfileForm({ ...profileForm, company: value })} />
            <ProfileField label="Base" value={profileForm.base} placeholder="BSB" onChange={(value) => setProfileForm({ ...profileForm, base: value.toUpperCase() })} />
            <ProfileField label="Função" value={profileForm.rank} placeholder="CCM, chefe, piloto..." onChange={(value) => setProfileForm({ ...profileForm, rank: value })} />
          </div>
          <button onClick={saveProfile} className="mt-5 w-full rounded-2xl bg-white px-5 py-4 text-sm font-black text-[#07111f] shadow-lg transition hover:bg-cyan-50">Salvar perfil</button>
        </SettingsCategoryCard>
      );
    }

    if (activeCategory === 'calendar') {
      return (
        <SettingsCategoryCard eyebrow="Agenda automática" title="Google Calendar e exportação ICS" description="Escolha o calendário, evite duplicidade e mantenha voos, rotina e alertas sincronizados quando desejar.">
          <div className="grid gap-3 sm:grid-cols-2">
            <button onClick={handleConnectGoogle} disabled={!googleConfigured || googleBusy} className="rounded-2xl bg-cyan-300 px-5 py-4 text-sm font-black text-[#07111f] transition hover:bg-cyan-200 disabled:opacity-50">{googleConnected ? 'Reconectar Google' : 'Conectar Google'}</button>
            <button onClick={handleRefreshCalendars} disabled={!googleConfigured || googleBusy} className="rounded-2xl border border-cyan-300/30 bg-cyan-300/10 px-5 py-4 text-sm font-black text-cyan-50 transition hover:bg-cyan-300/15 disabled:opacity-50"><RefreshCw className={`mr-2 inline h-4 w-4 ${googleBusy ? 'animate-spin' : ''}`} /> Atualizar calendários</button>
          </div>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            <label className="block"><span className="text-xs font-black uppercase tracking-[0.14em] text-cyan-100/60">Calendário padrão</span><select value={googleSettings.selectedCalendarId || 'primary'} onChange={(event) => { const selected = calendarOptions.find((c) => c.id === event.target.value); persistGoogle({ ...googleSettings, selectedCalendarId: event.target.value, selectedCalendarName: selected?.summary || event.target.value }); }} className="mt-2 h-12 w-full rounded-2xl border border-white/10 bg-[#07111f] px-3 text-sm font-bold text-white outline-none focus:border-cyan-300">{calendarOptions.map((calendar) => <option key={calendar.id} value={calendar.id}>{calendar.summary}{calendar.primary ? ' · principal' : ''}</option>)}</select></label>
            <label className="block"><span className="text-xs font-black uppercase tracking-[0.14em] text-cyan-100/60">Modo de exportação</span><select value={googleSettings.exportMode || 'all'} onChange={(event) => persistGoogle({ ...googleSettings, exportMode: event.target.value as GoogleCalendarSyncMode })} className="mt-2 h-12 w-full rounded-2xl border border-white/10 bg-[#07111f] px-3 text-sm font-bold text-white outline-none focus:border-cyan-300"><option value="all">Tudo: voos, atividades, folgas e rotina</option><option value="flights">Somente voos</option><option value="gym">Somente academia</option><option value="routine">Somente rotina</option></select></label>
          </div>
          <label className="mt-4 flex cursor-pointer items-start gap-3 rounded-2xl border border-white/10 bg-white/[0.045] p-4 text-sm text-slate-200"><input type="checkbox" checked={googleSettings.autoSync} onChange={(event) => persistGoogle({ ...googleSettings, autoSync: event.target.checked })} className="mt-1" /><span><strong>Sincronizar após importar escala.</strong><br /><span className="text-slate-400">A autorização fica no navegador e pode expirar. Reconecte quando necessário.</span></span></label>
          {!hasEnvClientId && <div className="mt-4 rounded-2xl border border-amber-300/20 bg-amber-300/10 p-4"><p className="text-sm font-bold text-amber-50">Client ID opcional neste dispositivo</p><input value={clientIdOverride} onChange={(event) => setClientIdOverride(event.target.value)} placeholder="Cole o Client ID Google temporariamente" className="mt-3 h-12 w-full rounded-2xl border border-white/10 bg-[#07111f] px-4 text-sm font-semibold text-white outline-none placeholder:text-slate-600 focus:border-cyan-300" /><button onClick={handleSaveClientId} className="mt-3 rounded-2xl bg-amber-200 px-5 py-3 text-sm font-black text-[#07111f]">Salvar Client ID local</button></div>}
        </SettingsCategoryCard>
      );
    }

    if (activeCategory === 'preferences') {
      return (
        <div className="space-y-5">
          <ThemeSettingsCard themeMode={themeMode} onThemeModeChange={onThemeModeChange} />
          <CrewCheckColorSettingsCard />
          <SettingsCategoryCard eyebrow="Idioma" title="Linguagem do sistema" description="A preferência fica salva neste dispositivo e vale para as telas principais.">
            <select value={language} onChange={(event) => handleLanguageChange(event.target.value as CrewLanguage)} className="h-12 w-full rounded-2xl border border-white/10 bg-[#07111f] px-4 text-sm font-bold text-white outline-none focus:border-cyan-300"><option value="pt">Português</option><option value="en">English</option><option value="es">Español</option><option value="fr">Français</option><option value="it">Italiano</option><option value="de">Deutsch</option></select>
          </SettingsCategoryCard>
        </div>
      );
    }

    if (activeCategory === 'notifications') {
      return (
        <SettingsCategoryCard eyebrow="Permissões" title="Localização, notificações e Saída Inteligente" description="O CrewCheck usa sua localização apenas sob permissão para calcular hora de sair, transporte público, carro e corrida por app.">
          <div className="grid gap-3 sm:grid-cols-3"><StatusTile icon={MapPin} title="Localização" text="necessária para rota real" /><StatusTile icon={Bell} title="Notificações" text="hora de sair e alertas" /><StatusTile icon={Navigation} title="Saída" text="Maps, Uber/99 e trânsito" /></div>
          <div className="mt-5 grid gap-3 sm:grid-cols-2"><button onClick={() => window.dispatchEvent(new CustomEvent('crewcheck:request-native-location'))} className="rounded-2xl bg-cyan-300 px-5 py-4 text-sm font-black text-[#07111f]">Verificar localização</button><button onClick={() => window.dispatchEvent(new CustomEvent('crewcheck:request-notifications'))} className="rounded-2xl border border-cyan-300/30 bg-cyan-300/10 px-5 py-4 text-sm font-black text-cyan-50">Verificar notificações</button></div>
          <p className="mt-4 rounded-2xl border border-white/10 bg-white/[0.045] p-4 text-sm leading-6 text-slate-300">Quando uma permissão não estiver liberada, o app usa estimativa conservadora e sinaliza claramente a fonte do cálculo.</p>
        </SettingsCategoryCard>
      );
    }

    if (activeCategory === 'finance') {
      return (
        <SettingsCategoryCard eyebrow="Valores" title="Diárias, ceia e salário" description="Acesse previsões em telas próprias, com cálculo explicável e botões de exportação quando houver escala carregada.">
          <div className="grid gap-3 sm:grid-cols-3"><button onClick={onOpenPerDiem} className="rounded-2xl bg-emerald-200 px-5 py-4 text-sm font-black text-[#07111f]">Diárias</button><button onClick={onOpenPerDiem} className="rounded-2xl bg-cyan-200 px-5 py-4 text-sm font-black text-[#07111f]">Ceia</button><button onClick={onOpenSalary} className="rounded-2xl bg-violet-200 px-5 py-4 text-sm font-black text-[#07111f]">Salário</button></div>
          <div className="mt-4 rounded-2xl border border-white/10 bg-white/[0.045] p-4 text-sm leading-6 text-slate-300">As telas financeiras mostram resumo, memória de cálculo e exportação/compartilhamento quando fizer sentido.</div>
        </SettingsCategoryCard>
      );
    }

    if (activeCategory === 'exports') {
      return (
        <SettingsCategoryCard eyebrow="Exportações" title="Compartilhar e salvar" description="Use quando quiser enviar a escala, relatório financeiro ou agenda para você mesmo, WhatsApp, e-mail ou calendário.">
          <div className="grid gap-3 sm:grid-cols-3"><button onClick={onExportPdf} className="rounded-2xl bg-cyan-300 px-5 py-4 text-sm font-black text-[#07111f]">PDF premium</button><button onClick={onExportIcs} className="rounded-2xl bg-blue-200 px-5 py-4 text-sm font-black text-[#07111f]">Calendário ICS</button><button onClick={onSyncPending} className="rounded-2xl bg-violet-200 px-5 py-4 text-sm font-black text-[#07111f]">Sincronizar fila</button></div>
          <p className="mt-4 text-sm leading-6 text-slate-400">{hasRoster ? 'Escala carregada. Exportações disponíveis.' : 'Importe ou abra uma escala para liberar PDF e calendário completos.'} {pendingOffline > 0 ? `${pendingOffline} pendência(s) offline aguardando sincronização.` : 'Nenhuma pendência offline agora.'}</p>
        </SettingsCategoryCard>
      );
    }

    if (activeCategory === 'privacy') {
      return (
        <SettingsCategoryCard eyebrow="LGPD" title="Privacidade sem ruído técnico" description="Informações corporativas sensíveis não ficam salvas no CrewCheck. A senha e MFA sempre permanecem no portal oficial.">
          <div className="grid gap-3 sm:grid-cols-2"><StatusTile icon={Lock} title="Senha corporativa" text="não armazenada" /><StatusTile icon={Shield} title="Perfil" text="salvo localmente" /><StatusTile icon={Database} title="Histórico" text="pode funcionar offline" /><StatusTile icon={ExternalLink} title="iFlight" text="módulo automático em validação" /></div>
          <button onClick={() => window.open('/privacy.html', '_blank', 'noopener,noreferrer')} className="mt-5 rounded-2xl border border-white/10 bg-white/10 px-5 py-4 text-sm font-black text-white">Abrir política de privacidade</button>
        </SettingsCategoryCard>
      );
    }

    return (
      <SettingsCategoryCard eyebrow="Manual e suporte" title="Guia do usuário dentro das Configurações" description="O manual fica aqui para manter o menu principal limpo. Use também para falar com suporte quando encontrar divergência.">
        <div className="grid gap-3 sm:grid-cols-2"><button onClick={() => window.open('/manual.html', '_blank', 'noopener,noreferrer')} className="rounded-2xl bg-white px-5 py-4 text-sm font-black text-[#07111f]"><FileText className="mr-2 inline h-4 w-4" /> Abrir manual</button><a href="mailto:bmedeiros1987@gmail.com?subject=Suporte%20CrewCheck&body=Olá,%20preciso%20de%20ajuda%20com%20o%20CrewCheck.%0A%0AVersão:%2010.8.77%0A" className="rounded-2xl border border-cyan-300/30 bg-cyan-300/10 px-5 py-4 text-center text-sm font-black text-cyan-50"><Mail className="mr-2 inline h-4 w-4" /> Falar com suporte</a></div>
        <button onClick={copySupportSummary} className="mt-3 rounded-2xl border border-white/10 bg-white/10 px-5 py-4 text-sm font-black text-white">Copiar resumo para suporte</button>
      </SettingsCategoryCard>
    );
  }

  return (
    <div className="min-h-screen bg-[#08111f] pb-28 text-white crewcheck-settings-screen crewcheck-settings-categories-premium">
      <div className="pointer-events-none fixed inset-0 opacity-90"><div className="absolute inset-0 bg-[radial-gradient(circle_at_10%_0%,rgba(14,165,233,0.18),transparent_28rem),radial-gradient(circle_at_90%_5%,rgba(37,99,235,0.14),transparent_30rem),linear-gradient(180deg,#08111f_0%,#07111f_50%,#020817_100%)]" /></div>
      <div className="relative z-10 mx-auto max-w-7xl px-5 py-7">
        <HeaderBack title="Configurações" subtitle="Categorias separadas, mais claras e objetivas" onBack={onBack} />
        <div className="mt-5 rounded-[2rem] border border-cyan-200/18 bg-white/[0.07] p-5 shadow-2xl shadow-cyan-950/20 backdrop-blur-2xl">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div><p className="text-xs font-black uppercase tracking-[0.22em] text-cyan-100/65">CrewCheck v{APP_VERSION}</p><h2 className="mt-1 text-3xl font-black tracking-tight">Preferências em telas separadas</h2><p className="mt-2 max-w-3xl text-sm leading-6 text-slate-300">Escolha uma categoria. O menu principal fica limpo, e cada ajuste aparece no lugar certo.</p></div>
            <div className="flex flex-wrap gap-2"><button onClick={onOpenImport} className="rounded-2xl bg-cyan-300 px-4 py-3 text-xs font-black text-[#07111f]">Importar escala</button><button onClick={onLogout} className="rounded-2xl border border-white/10 px-4 py-3 text-xs font-black text-white">Sair</button></div>
          </div>
        </div>
        <div className="mt-6 grid gap-5 lg:grid-cols-[22rem_minmax(0,1fr)]">
          <aside className="space-y-3 lg:sticky lg:top-6 lg:self-start">
            {categories.map(({ key, title, text, icon: Icon, badge, tone }) => {
              const active = activeCategory === key;
              return <button key={key} onClick={() => openSettingsCategory(key)} className={`flex w-full items-center gap-3 rounded-[1.35rem] border p-3 text-left transition active:scale-[0.99] ${active ? 'border-cyan-300/50 bg-cyan-300/14 shadow-xl shadow-cyan-950/20' : 'border-white/10 bg-white/[0.045] hover:bg-white/[0.075]'} ${settingsPulse === key ? 'ring-2 ring-cyan-200/70 scale-[1.01]' : ''}`}><span className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br ${tone} text-[#06101d] shadow-lg`}><Icon className="h-5 w-5" /></span><span className="min-w-0 flex-1"><span className="block text-sm font-black text-white">{title}</span><span className="block truncate text-xs font-semibold text-slate-400">{text}</span></span>{badge && <span className="rounded-full bg-white/10 px-2 py-1 text-[10px] font-black uppercase tracking-[0.1em] text-cyan-100">{badge}</span>}</button>;
            })}
          </aside>
          <main ref={settingsContentRef} className="min-w-0 scroll-mt-6">{renderCategoryContent()}</main>
        </div>
      </div>
    </div>
  );
}

function SettingsCategoryCard({ eyebrow, title, description, children }: { eyebrow: string; title: string; description: string; children: ReactNode }) {
  return <section className="rounded-[2rem] border border-white/10 bg-white/[0.065] p-5 shadow-2xl shadow-black/20 backdrop-blur-2xl sm:p-6"><p className="text-xs font-black uppercase tracking-[0.2em] text-cyan-100/60">{eyebrow}</p><h3 className="mt-1 text-2xl font-black tracking-tight text-white sm:text-3xl">{title}</h3><p className="mt-2 max-w-3xl text-sm leading-6 text-slate-400">{description}</p><div className="mt-5">{children}</div></section>;
}

function StatusTile({ icon: Icon, title, text }: { icon: LucideIcon; title: string; text: string }) {
  return <div className="rounded-2xl border border-white/10 bg-white/[0.045] p-4"><Icon className="mb-3 h-6 w-6 text-cyan-200" /><p className="font-black text-white">{title}</p><p className="mt-1 text-xs leading-5 text-slate-400">{text}</p></div>;
}

function ThemeSettingsCard({ themeMode, onThemeModeChange }: { themeMode: CrewThemeMode; onThemeModeChange: (mode: CrewThemeMode) => void }) {
  const options: { value: CrewThemeMode; title: string; text: string; icon: LucideIcon }[] = [
    { value: 'light', title: 'Claro', text: 'Interface branca e limpa', icon: Sun },
    { value: 'dark', title: 'Escuro', text: 'Visual premium noturno', icon: Moon },
    { value: 'system', title: 'Sistema', text: 'Segue Android/navegador', icon: Monitor },
  ];
  return (
    <div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 shadow-2xl shadow-black/20 backdrop-blur-2xl sm:p-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-cyan-100/60">aparência</p>
          <h3 className="mt-1 text-2xl font-black">Tema claro e escuro</h3>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-400">Escolha o tema do CrewCheck. A preferência fica salva neste dispositivo e vale para o app, web, dashboard, resultados e configurações.</p>
        </div>
        <Badge className="rounded-full border-0 bg-cyan-300/15 text-cyan-100">{themeMode === 'system' ? 'Automático' : themeMode === 'light' ? 'Claro' : 'Escuro'}</Badge>
      </div>
      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        {options.map(({ value, title, text, icon: Icon }) => {
          const active = themeMode === value;
          return (
            <button key={value} type="button" onClick={() => onThemeModeChange(value)} className={`rounded-[1.35rem] border p-4 text-left transition active:scale-[0.99] ${active ? 'border-cyan-300/60 bg-cyan-300/15 text-cyan-50 shadow-lg shadow-cyan-950/25' : 'border-white/10 bg-white/[0.045] text-slate-200 hover:bg-white/[0.08]'}`}>
              <div className="flex items-center gap-3">
                <div className={`flex h-11 w-11 items-center justify-center rounded-2xl ${active ? 'bg-cyan-300 text-[#07111f]' : 'bg-white/10 text-cyan-200'}`}><Icon className="h-5 w-5" /></div>
                <div>
                  <p className="font-black">{title}</p>
                  <p className="mt-0.5 text-xs leading-4 text-slate-400">{text}</p>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}


function applyCrewCheckVisualColorsLocal() {
  try {
    const root = document.documentElement;
    const map: Array<[string, string, string]> = [
      ['crewcheck_color_flight_bg', '--cc-scale-flight-bg', '#e0f2fe'],
      ['crewcheck_color_flight_fg', '--cc-scale-flight-fg', '#082f49'],
      ['crewcheck_color_extra_bg', '--cc-scale-extra-bg', '#e2e8f0'],
      ['crewcheck_color_extra_fg', '--cc-scale-extra-fg', '#0f172a'],
      ['crewcheck_color_routine_bg', '--cc-routine-pill-bg', '#ffffff'],
      ['crewcheck_color_routine_fg', '--cc-routine-pill-fg', '#0f172a'],
      ['crewcheck_color_safe_bg', '--cc-routine-safe-bg', '#d1fae5'],
      ['crewcheck_color_safe_fg', '--cc-routine-safe-fg', '#064e3b'],
    ];
    for (const [key, cssVar, fallback] of map) root.style.setProperty(cssVar, localStorage.getItem(key) || fallback);
  } catch {}
}

function CrewCheckColorSettingsCard() {
  const defaults = {
    flightBg: localStorage.getItem('crewcheck_color_flight_bg') || '#e0f2fe',
    flightFg: localStorage.getItem('crewcheck_color_flight_fg') || '#082f49',
    extraBg: localStorage.getItem('crewcheck_color_extra_bg') || '#e2e8f0',
    extraFg: localStorage.getItem('crewcheck_color_extra_fg') || '#0f172a',
    routineBg: localStorage.getItem('crewcheck_color_routine_bg') || '#ffffff',
    routineFg: localStorage.getItem('crewcheck_color_routine_fg') || '#0f172a',
    safeBg: localStorage.getItem('crewcheck_color_safe_bg') || '#d1fae5',
    safeFg: localStorage.getItem('crewcheck_color_safe_fg') || '#064e3b',
  };
  const [colors, setColors] = useState(defaults);
  function save(next = colors) {
    const pairs: Array<[keyof typeof next, string]> = [
      ['flightBg','crewcheck_color_flight_bg'], ['flightFg','crewcheck_color_flight_fg'],
      ['extraBg','crewcheck_color_extra_bg'], ['extraFg','crewcheck_color_extra_fg'],
      ['routineBg','crewcheck_color_routine_bg'], ['routineFg','crewcheck_color_routine_fg'],
      ['safeBg','crewcheck_color_safe_bg'], ['safeFg','crewcheck_color_safe_fg'],
    ];
    pairs.forEach(([field, key]) => localStorage.setItem(key, String(next[field])));
    applyCrewCheckVisualColorsLocal();
    window.dispatchEvent(new Event('crewcheck:visual-colors-change'));
    toast.success('Cores da escala e rotina salvas.');
  }
  function update(field: keyof typeof colors, value: string) {
    const next = { ...colors, [field]: value };
    setColors(next);
    save(next);
  }
  const rows: Array<[keyof typeof colors, string]> = [
    ['flightBg','Fundo voo normal'], ['flightFg','Fonte voo normal'], ['extraBg','Fundo voo extra'], ['extraFg','Fonte voo extra'],
    ['routineBg','Fundo cards rotina'], ['routineFg','Fonte cards rotina'], ['safeBg','Fundo sem choque'], ['safeFg','Fonte sem choque'],
  ];
  return (
    <SettingsCategoryCard eyebrow="Personalização visual" title="Cores da escala e dos cards" description="Defina cor de fundo e fonte dos cards de escala e dos selos de rotina, confiança, choque de horário e tipo de atividade.">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {rows.map(([field, label]) => <label key={field} className="rounded-2xl border border-white/10 bg-white/[0.045] p-3"><span className="block text-[10px] font-black uppercase tracking-[0.14em] text-cyan-100/70">{label}</span><input type="color" value={colors[field]} onChange={(event) => update(field, event.target.value)} className="mt-2 h-11 w-full rounded-xl border border-white/10 bg-transparent" /></label>)}
      </div>
      <div className="mt-4 flex flex-wrap gap-2"><span className="rounded-full px-3 py-2 text-xs font-black" style={{ background: colors.routineBg, color: colors.routineFg }}>confiança alta</span><span className="rounded-full px-3 py-2 text-xs font-black" style={{ background: colors.safeBg, color: colors.safeFg }}>sem choque</span><span className="rounded-full px-3 py-2 text-xs font-black" style={{ background: colors.flightBg, color: colors.flightFg }}>voo normal</span></div>
    </SettingsCategoryCard>
  );
}

function ProfileField({ label, value, placeholder, onChange }: { label: string; value: string; placeholder: string; onChange: (value: string) => void }) {
  return (
    <label className="block">
      <span className="text-xs font-black uppercase tracking-[0.14em] text-cyan-100/60">{label}</span>
      <input value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} className="mt-2 h-12 w-full rounded-2xl border border-white/10 bg-[#07111f] px-4 text-sm font-semibold text-white outline-none placeholder:text-slate-600 focus:border-cyan-300" />
    </label>
  );
}

function QuickConfigButton({ icon: Icon, title, text, onClick, tone }: { icon: LucideIcon; title: string; text: string; onClick: () => void; tone: 'cyan' | 'blue' | 'slate' | 'orange' | 'emerald' | 'violet' }) {
  const tones: Record<typeof tone, string> = {
    cyan: 'from-cyan-300/20 to-blue-500/10 text-cyan-100',
    blue: 'from-blue-300/20 to-indigo-500/10 text-blue-100',
    slate: 'from-slate-200/15 to-slate-600/10 text-slate-100',
    orange: 'from-orange-300/20 to-amber-500/10 text-orange-100',
    emerald: 'from-emerald-300/20 to-teal-500/10 text-emerald-100',
    violet: 'from-violet-300/20 to-fuchsia-500/10 text-violet-100',
  };
  return (
    <button onClick={onClick} className={`w-full rounded-[1.7rem] border border-white/10 bg-gradient-to-br ${tones[tone]} p-5 text-left shadow-xl shadow-black/20 transition hover:border-cyan-200/30 hover:bg-white/[0.08]`}>
      <Icon className="mb-4 h-8 w-8" />
      <h3 className="text-lg font-black">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-slate-300">{text}</p>
    </button>
  );
}

function MorePanel({ onBack, onNavigate, onLogout, pendingOffline, hasRoster, canAccessC32FAcademy }: { onBack: () => void; onNavigate: (view: string) => void; onLogout: () => void; pendingOffline: number; hasRoster: boolean; canAccessC32FAcademy: boolean }) {
  return (
    <div className="min-h-screen bg-[#08111f] px-5 py-8 text-white">
      <div className="mx-auto max-w-4xl">
        <HeaderBack title="Mais funções" subtitle="Menu completo do CrewCheck" onBack={onBack} />
        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          <MenuAction icon={CloudUpload} title="Importar nova escala" text="PDF CrewRosterReport/AIMS" onClick={() => onNavigate('import')} />
          <MenuAction icon={History} title="Histórico" text="Abrir escalas salvas" onClick={() => onNavigate('history')} />
          <MenuAction icon={Bell} title="Alertas" text="Irregularidades e avisos" onClick={() => onNavigate('alerts')} />
          <MenuAction icon={Monitor} title="Radar de Voos" text="Painel estilo aeroporto, por localidade e companhia" onClick={() => onNavigate('flightboard')} />
          <MenuAction icon={Navigation} title="Saída Inteligente" text="Hora de sair com trânsito real e margem de 15 min" onClick={() => onNavigate('departure')} />
          <MenuAction icon={FileText} title="Previsão de Diárias" text="Café, almoço, jantar, ceia e total estimado pela escala" onClick={() => onNavigate('perdiem')} />
          <MenuAction icon={Clock} title="Conferência de Ceia" text="Só conta se voo ou reserva cruzar 00:00–01:00" onClick={() => onNavigate('perdiem')} />
          <MenuAction icon={TrendingUp} title="Previsão de Salário" text="Bruto, líquido, descontos e holerite opcional" onClick={() => onNavigate('salary')} />
          {canAccessC32FAcademy && <MenuAction icon={GraduationCap} title="C32F / Check A32F" text="Apostila, revisão rápida e mapas A32F" onClick={() => onNavigate('c32f')} />}
          <MenuAction icon={BarChart3} title="Relatórios" text="Métricas e PDF" onClick={() => onNavigate('reports')} />
          <MenuAction icon={FileText} title="Exportar tudo em PDF" text={hasRoster ? "Relatório completo da escala atual" : "Importe/abra uma escala primeiro"} onClick={() => onNavigate('pdf')} />
          <MenuAction icon={CalendarDays} title="Exportar tudo para calendário" text="ICS completo com lembretes" onClick={() => onNavigate('ics')} />
          <MenuAction icon={CalendarDays} title="Google Calendar" text="Sincronismo automático sem duplicidade" onClick={() => onNavigate('google')} />
          <MenuAction icon={CalendarDays} title="Calendário" text="Visual, ICS e Google" onClick={() => onNavigate('calendar')} />
          <MenuAction icon={Settings} title="Configurações" text="Conta, rotina e Google" onClick={() => onNavigate('settings')} />
          <MenuAction icon={Mail} title="Suporte" text="Enviar erro, PDF ou print" onClick={() => { window.location.href = 'mailto:bmedeiros1987@gmail.com?subject=Feedback%20CrewCheck%20Beta'; }} />
          <MenuAction icon={Database} title="Atualizar ICS offline" text={`${pendingOffline} pendência(s)`} onClick={() => onNavigate('sync')} />
          <MenuAction icon={LogOut} title="Sair" text="Encerrar sessão" onClick={onLogout} />
        </div>
        <div className="mt-6 rounded-2xl border border-emerald-300/15 bg-emerald-300/10 px-4 py-3 text-center text-[11px] font-black uppercase tracking-[0.18em] text-emerald-100">
          Premium · LGPD · Offline-first
        </div>
      </div>
    </div>
  );
}


function C32FStudyPanel({ onBack, onOpenRoster }: { onBack: () => void; onOpenRoster: () => void }) {
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [pdfStatus, setPdfStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [pdfPage, setPdfPage] = useState(1);
  const [pdfZoom, setPdfZoom] = useState<'page-width' | 'page-fit' | '100' | '125' | '150'>('page-width');
  const [c32fViewMode, setC32fViewMode] = useState<'reader' | 'pdf'>('reader');

  useEffect(() => {
    let active = true;
    let objectUrl = '';

    async function loadProtectedPdf() {
      try {
        setPdfStatus('loading');
        const token = getToken();
        const response = await fetch('/api/c32f/apostila-pdf', {
          headers: token ? { authorization: `Bearer ${token}` } : {},
          cache: 'no-store',
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const blob = await response.blob();
        objectUrl = URL.createObjectURL(new Blob([blob], { type: 'application/pdf' }));
        if (active) {
          setPdfUrl(objectUrl);
          setPdfStatus('ready');
        } else {
          URL.revokeObjectURL(objectUrl);
        }
      } catch {
        if (active) setPdfStatus('error');
      }
    }

    loadProtectedPdf();
    return () => {
      active = false;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, []);

  const modules = [
    { title: 'Revisão relâmpago', tag: 'decorar', text: '2.000 ft: Tripulação a seus postos. 500 ft: Posição de impacto. 11.500 ft: Airbus bright + cintos + luzes de emergência. 14.000 ft: queda automática das máscaras.' },
    { title: 'Primeiros socorros', tag: 'AMPLA/RPPP', text: 'AMPLA: Alergias, Medicações, Passado médico, Líquidos/alimentos, Associação ao evento. RPPP: Respiração, Pulso, Pele, Pupilas.' },
    { title: 'RCP e DEA', tag: 'crítico', text: 'Treine o fluxo de avaliação, acionamento do DEA, segurança da cena e situações em que o atendimento é assumido ou interrompido conforme manual vigente.' },
    { title: 'Combate ao fogo', tag: 'cabine', text: 'Funções: combatente, assistente, comunicador e suporte. Revise porta quente/fria, bin, áreas ocultas, rescaldo e vigilância contínua.' },
    { title: 'Evacuação A32F', tag: 'mapas', text: 'Revise A319, A320, A321 e A321neo. Atenção: A321 clássico usa referência central A4/A5; no A321neo mantém A3 na dianteira direita.' },
    { title: 'Kits e oxigênio', tag: 'equip.', text: 'Diferencie KIM, KPS, KPU e KME. Associe cada kit à finalidade prática e revise máscaras, cilindros e fluxo de despressurização.' },
  ];

  const quickQuestions = [
    'Consigo falar os callouts principais sem olhar?',
    'Sei explicar ATAC: Atendente, Transportador, Assistente e Comunicador?',
    'Sei diferenciar porta quente e porta fria em ocorrência de fogo?',
    'Sei quando bloquear uma saída insegura e redirecionar fluxo?',
    'Sei explicar a diferença operacional entre A321 clássico e A321neo?',
  ];


  const readerTables = [
    {
      title: 'Quadro premium de memorização rápida',
      subtitle: 'Transformado em tabela larga e legível para estudo direto no sistema, sem depender do zoom do PDF.',
      columns: ['Tema', 'O que decorar'],
      rows: [
        ['Callouts', '“Tripulação a seus postos” • “Posição de impacto” • “Tripulação, evacuar” • “Permaneçam sentados”. Treine falando em voz alta, sem ler.'],
        ['Despressurização', 'Airbus: 11.500 ft = cabine em bright, avisos de cintos e luzes de emergência. 14.000 ft = queda automática das máscaras.'],
        ['Combate ao fogo', 'Memorize os papéis: combatente, assistente, comunicador e suporte. Depois revise base do fogo, distância, rescaldo e vigilância.'],
        ['Primeiros socorros', 'AMPLA, RPPP, ATAC e DEA. Use como roteiro mental para avaliação, comunicação e continuidade do atendimento.'],
        ['Kits', 'KIM, KPS, KPU e KME. Diferencie finalidade, abertura e uso prático de cada kit.'],
        ['Evacuação A32F', 'A321 clássico: atenção ao centro A4/A5. A321neo: mantém A3 na dianteira direita. Revise mapas e lógica do OK de cabine.'],
      ],
      notes: [
        'Use este quadro como aquecimento de 5 minutos antes de estudar o PDF original.',
        'Quando errar um tema, volte ao PDF na página correspondente para conferir a fonte completa.',
      ],
    },
    {
      title: 'Despressurização e descida de emergência · marcos críticos',
      subtitle: 'Quadro refeito com linhas maiores para evitar cortes e perda de informação no iPad/desktop.',
      columns: ['Marco / frota', 'Sinal verificado ou ação esperada'],
      rows: [
        ['Airbus · ~11.500 ft', 'Cabine em BRIGHT, avisos de atar cintos ligados e luzes de emergência acesas.'],
        ['Airbus · ~14.000 ft', 'Queda automática das máscaras. Revise também a lógica de comunicação e altitude segura.'],
        ['B777/B787 · ~10.000 ft', 'Acende aviso de atar cintos com respectivo chime.'],
        ['B777/B787 · ~14.000 ft', 'Queda automática das máscaras, cabine em BRIGHT e chimes específicos da frota.'],
        ['Após “Tripulação, altitude segura”', 'Checar cabine, lavatórios e áreas críticas; comunicar situação geral conforme fluxo do manual vigente.'],
      ],
      notes: [
        'Memorização-chave: 11.500 ft, 14.000 ft, 2.000 ft e 500 ft.',
        'Em caso de divergência operacional, prevalecem o manual e comunicações oficiais vigentes.',
      ],
    },
    {
      title: 'Combate ao fogo · papéis da equipe',
      subtitle: 'Resumo organizado para prova oral/check: quem faz o quê e o que não esquecer.',
      columns: ['Função', 'Responsabilidade prática'],
      rows: [
        ['Combatente', 'Atua diretamente sobre o foco; usa extintor adequado; mira na base do fogo; mantém segurança e comunica necessidade de suporte.'],
        ['Assistente', 'Prepara equipamentos, substitui extintor, auxilia PBE, observa evolução e antecipa recursos.'],
        ['Comunicador', 'Mantém cockpit/chefe de equipe informado com localização, tipo de fogo, recursos usados e evolução.'],
        ['Suporte', 'Controla passageiros, isola área, preserva corredor, evita pânico e organiza contingência.'],
        ['Rescaldo e vigilância', 'Mesmo após aparente extinção, manter rescaldo e vigilância contínua para evitar reignição.'],
      ],
      notes: [
        'Regra prática: atacar a base do fogo e manter distância operacional segura conforme manual.',
        'Fogo oculto, bin e PED/bateria exigem atenção reforçada à vigilância pós-extinção.',
      ],
    },
    {
      title: 'Extintores · aplicação e checagem mental',
      subtitle: 'Versão legível dos pontos mais cobrados sobre tipos, uso e cuidados.',
      columns: ['Tipo', 'Uso / característica principal'],
      rows: [
        ['BCF 1301 · lixeira do lavatório', 'Disparo automático na lixeira do lavatório quando a temperatura atinge aproximadamente 77 °C.'],
        ['Halon / BCF 1211', 'Indicado para classes B e C; pode ser usado em classe A com rescaldo posterior.'],
        ['Kidde / Air Total', 'Verificar fixação, manômetro/área verde, lacre e etiqueta; duração média costuma ser curta, então planeje o uso.'],
        ['P3 HAFEX / Halotron BrX', 'Agente limpo substituto do Halon 1211, com mesma lógica prática de combate.'],
        ['Halon MAIP', 'Manter lógica operacional de checagem, identificação e aplicação conforme item específico do manual.'],
      ],
      notes: [
        'A pergunta de prova costuma misturar tipo de fogo, extintor, PBE e rescaldo.',
        'Nunca trate extinção aparente como final do procedimento: monitore e comunique.',
      ],
    },
    {
      title: 'PBE · função, ativação e sinais de atenção',
      subtitle: 'Quadro expandido para leitura mais limpa que o PDF em tela pequena.',
      columns: ['Modelo / ponto', 'Checagem ou ativação resumida'],
      rows: [
        ['Função geral', 'Proteção respiratória contra fumaça, gases e partículas durante combate ao fogo ou ambiente contaminado.'],
        ['Scott', 'Verificar fixação, data de fabricação e indicador de umidade pelo visor; confirmar condição aceitável conforme padrão do manual.'],
        ['Puritan', 'Verificar fixação e integridade do vácuo da embalagem; vestir e acionar/ajustar conforme tiras indicadas.'],
        ['Drager', 'Verificar fixação, embalagem lacrada e data; ativação conforme mecanismo do modelo.'],
        ['Air Liquide', 'Verificar fixação, data e indicador; ativação ocorre durante abertura/vestimenta, conforme modelo.'],
      ],
      notes: [
        'Associe PBE + extintor + comunicação + suporte de cabine.',
        'Se o modelo mudar na aeronave, prevalece a checagem do equipamento instalado.',
      ],
    },
    {
      title: 'Primeiros socorros · AMPLA e RPPP',
      subtitle: 'Roteiro de avaliação em formato de card/tabela para decorar antes do C32F.',
      columns: ['Item', 'Pergunta ou observação prática'],
      rows: [
        ['A · Alergias', 'Perguntar alergias conhecidas, reações prévias e relação com o evento atual.'],
        ['M · Medicações', 'Verificar medicamentos em uso, dose, horário e se houve uso recente.'],
        ['P · Passado médico', 'Investigar histórico relevante e condições conhecidas.'],
        ['L · Líquidos/alimentos', 'Checar última ingestão de líquidos/alimentos e possíveis gatilhos.'],
        ['A · Associação ao evento', 'Relacionar sinais, sintomas, início e fatores desencadeantes.'],
        ['RPPP', 'Respiração, Pulso, Pele e Pupilas: observar padrão, frequência, cor, temperatura, sudorese e alterações.'],
      ],
      notes: [
        'AMPLA é roteiro de entrevista; RPPP é roteiro de observação clínica.',
        'Documente e comunique conforme fluxo operacional vigente.',
      ],
    },
    {
      title: 'Kits médicos e biossegurança',
      subtitle: 'Quadro refeito para diferenciar finalidade prática de cada kit.',
      columns: ['Kit', 'Finalidade resumida'],
      rows: [
        ['KPS · Kit Primeiros Socorros', 'Itens de curativo e apoio inicial; associe a atendimentos simples e suporte básico.'],
        ['KPU · Kit de Precaução Universal', 'Biossegurança: barreira de proteção, limpeza/absorção e proteção da tripulação/passageiros.'],
        ['KIM · Kit Insumos Médicos', 'Pode ser aberto pela tripulação de cabine; contém insumos médicos de apoio conforme manual vigente.'],
        ['KME · Kit Médico de Emergência', 'Recurso de atendimento médico avançado conforme política operacional; revisar condição de abertura/uso e comunicação.'],
      ],
      notes: [
        'Pergunta típica: qual kit usar, quem pode abrir e qual comunicação fazer.',
        'Não confundir kit de biossegurança com kit de atendimento médico.',
      ],
    },
    {
      title: 'Ressuscitação cardiopulmonar · leitura ampliada',
      subtitle: 'Quadro reformatado para leitura mais nítida em tablet, iPad e desktop.',
      columns: ['Paciente', 'Compressões / ventilações'],
      rows: [
        ['Adulto / adolescente', '05 ciclos de 30 compressões x 02 ventilações; compressões com as duas mãos na metade inferior do esterno.'],
        ['Criança', '10 ciclos de 15 compressões x 02 ventilações; geralmente com uma mão (ou duas, conforme o porte físico).'],
        ['Bebê', '10 ciclos de 15 compressões x 01 ventilação; dois dedos no centro do tórax, logo abaixo da linha mamilar.'],
        ['Neonatal', '10 ciclos de 03 compressões x 01 ventilação; dois polegares sobre o esterno, envolvendo o tórax com as mãos.'],
      ],
      notes: [
        'Seguir sempre o procedimento vigente do manual e da RTM-C aplicável.',
        'Se houver diferença entre este quadro e uma publicação oficial posterior, prevalece a publicação oficial.',
      ],
    },
    {
      title: 'Sobrevivência no mar, deserto e gelo · revisão ampliada',
      subtitle: 'Tabela reformulada em linhas mais longas para leitura confortável dentro do CrewCheck.',
      columns: ['Ambiente', 'Ações e cuidados prioritários'],
      rows: [
        ['Mar', 'Manter organização do grupo; utilizar coletes, auxílio à flutuação e slide raft; priorizar sinalização visível; economizar água e energia.'],
        ['Deserto', 'Primeiros socorros, abrigo/sombra, proteção contra calor/sol, planejamento, racionamento de água e sinalização.'],
        ['Gelo / frio intenso', 'Abrigo e isolamento térmico; proteger extremidades; monitorar hipotermia/congelamento; reduzir vento e conservar calor corporal.'],
        ['Selva', 'Aplicar SAFA + D + A: Sinalização, Abrigo, Fogo, Água, Descanso e Alimentação.'],
      ],
      notes: [
        'Mar: sinalização visível + preservação do grupo + controle de água e energia.',
        'Deserto: abrigo/sombra e água são críticos.',
        'Gelo: abrigo, calor corporal e proteção ao vento/congelamento são críticos.',
      ],
    },
  ];

  const readerBlocks = [
    {
      title: 'Plano de revisão em 30 minutos',
      bullets: [
        '5 min · Callouts e vozes de comando.',
        '5 min · Despressurização e oxigênio.',
        '5 min · Combate ao fogo e funções da equipe.',
        '5 min · RCP/DEA, ATAC e situações de interrupção/assunção do atendimento.',
        '5 min · Mapas de evacuação A32F.',
        '5 min · KIM, KPS, KPU, KME, PBE, extintores e ELT.',
      ],
    },
    {
      title: 'Prioridade máxima de memorização',
      bullets: [
        'AMPLA e RPPP.',
        'ATAC e funções de atendimento.',
        '2.000 ft, 500 ft, 11.500 ft e 14.000 ft.',
        'Porta quente / porta fria no lavatório.',
        'Fogo em bin com PED/bateria de lítio.',
        'A321 clássico x A321neo na distribuição de funções.',
      ],
    },
    {
      title: 'Evacuação A32F · pontos de fala',
      bullets: [
        'Treinar lógica de fluxo, bloqueio de saída insegura e redirecionamento.',
        'Revisar “quem encontra quem” no OK de cabine por configuração.',
        'Não decorar apenas mapa: explique a lógica da função e da confirmação.',
        'A321 clássico e A321neo costumam gerar confusão: revise em separado.',
      ],
    },
    {
      title: 'Como usar esta tela premium',
      bullets: [
        'Use “Leitura guiada” como estudo principal no celular/iPad.',
        'Use “PDF original” para conferir paginação e fidelidade visual.',
        'Use “Abrir PDF em nova aba” quando quiser zoom livre do navegador.',
        'Na véspera do C32F, revise apenas os quadros de memorização e durma bem.',
      ],
    },
  ];

  const pdfChapters = [
    { label: 'Capa V6', page: 1 },
    { label: 'Índice visual', page: 2 },
    { label: 'Dashboard de estudo', page: 3 },
    { label: 'Checklist premium', page: 4 },
    { label: 'Parte I · Base', page: 9 },
    { label: 'Parte II · Crítico', page: 27 },
    { label: 'Apêndice V5 · Master', page: 35 },
  ];

  async function downloadProtectedPdf() {
    try {
      const token = getToken();
      const response = await fetch('/api/c32f/apostila-pdf?download=1', {
        headers: token ? { authorization: `Bearer ${token}` } : {},
        cache: 'no-store',
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'Apostila_C32F_Check_A32F_V6.pdf';
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1500);
    } catch {
      toast.error('Não foi possível baixar a apostila C32F. Faça login novamente e tente de novo.');
    }
  }


  function openPdfInNewTab() {
    if (!pdfUrl) return;
    window.open(`${pdfUrl}#page=${pdfPage}&zoom=${pdfZoom}`, '_blank', 'noopener,noreferrer');
  }

  return (
    <div className="min-h-screen bg-[#08111f] px-5 py-8 pb-32 text-white">
      <div className="mx-auto max-w-6xl">
        <HeaderBack title="C32F / Check A32F" subtitle="Sistema privado de estudo" onBack={onBack} action={<Button onClick={onOpenRoster} className="rounded-2xl bg-cyan-300 text-[#07111f] hover:bg-cyan-200">Ver escala</Button>} />

        <section className="mt-6 overflow-hidden rounded-[2.2rem] border border-cyan-300/20 bg-gradient-to-br from-cyan-300/18 via-white/[0.07] to-fuchsia-400/10 p-6 shadow-2xl shadow-black/30">
          <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.24em] text-cyan-100/70">Academia CrewCheck · privado</p>
              <h2 className="mt-2 text-3xl font-black tracking-tight md:text-5xl">C32F Premium · Leitura guiada da Apostila V6</h2>
              <p className="mt-3 max-w-3xl text-sm leading-6 text-slate-200/90">A apostila foi transformada em quadros legíveis dentro do CrewCheck. Use a leitura guiada para estudar sem cortes e o PDF original para conferência integral.</p>
            </div>
            <div className="rounded-[1.4rem] border border-emerald-300/20 bg-emerald-400/10 p-4 text-sm leading-6 text-emerald-50/90">
              Acesso liberado somente para bmedeiros1987@gmail.com. Em caso de divergência, prevalecem manuais e comunicações oficiais vigentes.
            </div>
          </div>
        </section>

        <section className="mt-6 grid gap-5 xl:grid-cols-[19rem_1fr]">
          <aside className="rounded-[2rem] border border-white/10 bg-white/[0.06] p-4 shadow-2xl shadow-black/20 xl:sticky xl:top-4 xl:h-fit">
            <div className="mb-4 flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-cyan-300 text-[#07111f]"><FileText className="h-5 w-5" /></div>
              <div>
                <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-100/70">C32F V6</p>
                <h3 className="font-black">Estudo guiado</h3>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setC32fViewMode('reader')}
                className={`rounded-2xl border px-4 py-3 text-center text-sm font-black transition ${c32fViewMode === 'reader' ? 'border-cyan-200 bg-cyan-300 text-[#07111f]' : 'border-white/10 bg-white/[0.05] text-slate-100 hover:bg-white/[0.09]'}`}
              >
                Leitura guiada
              </button>
              <button
                type="button"
                onClick={() => setC32fViewMode('pdf')}
                className={`rounded-2xl border px-4 py-3 text-center text-sm font-black transition ${c32fViewMode === 'pdf' ? 'border-cyan-200 bg-cyan-300 text-[#07111f]' : 'border-white/10 bg-white/[0.05] text-slate-100 hover:bg-white/[0.09]'}`}
              >
                PDF original
              </button>
            </div>

            <div className="mt-4 grid gap-2">
              {pdfChapters.map((chapter) => (
                <button
                  key={chapter.label}
                  type="button"
                  onClick={() => { setPdfPage(chapter.page); setC32fViewMode('pdf'); }}
                  className={`rounded-2xl border px-4 py-3 text-left text-sm font-black transition ${pdfPage === chapter.page ? 'border-cyan-200 bg-cyan-300 text-[#07111f]' : 'border-white/10 bg-white/[0.05] text-slate-100 hover:bg-white/[0.09]'}`}
                >
                  <span className="block text-[10px] uppercase tracking-[0.16em] opacity-70">Página {chapter.page}</span>
                  {chapter.label}
                </button>
              ))}
            </div>

            <div className="mt-4 rounded-[1.4rem] border border-white/10 bg-black/15 p-3">
              <label className="mb-2 block text-[11px] font-black uppercase tracking-[0.16em] text-cyan-100/70">Zoom do PDF</label>
              <select value={pdfZoom} onChange={(e) => setPdfZoom(e.target.value as any)} className="w-full rounded-xl border border-white/10 bg-slate-950/80 px-3 py-2 text-sm text-white outline-none">
                <option value="page-width">Ajustar à largura</option>
                <option value="page-fit">Ajustar à página</option>
                <option value="100">100%</option>
                <option value="125">125%</option>
                <option value="150">150%</option>
              </select>
            </div>

            <div className="mt-4 grid gap-2">
              <Button onClick={downloadProtectedPdf} disabled={pdfStatus !== 'ready'} className="w-full rounded-2xl bg-white text-[#07111f] hover:bg-cyan-50">
                <DownloadIcon className="h-4 w-4" /> Baixar apostila
              </Button>
              <Button onClick={openPdfInNewTab} disabled={pdfStatus !== 'ready'} variant="outline" className="w-full rounded-2xl border-white/15 bg-white/[0.04] text-white hover:bg-white/[0.10]">
                <ExternalLink className="h-4 w-4" /> Abrir PDF em nova aba
              </Button>
            </div>
          </aside>

          <div className="overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.06] shadow-2xl shadow-black/20">
            <div className="flex flex-col gap-3 border-b border-white/10 bg-black/15 px-5 py-4 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.2em] text-cyan-100/70">{c32fViewMode === 'reader' ? 'Leitura guiada premium' : 'Visualizador integrado'}</p>
                <h3 className="text-lg font-black">{c32fViewMode === 'reader' ? 'Conteúdo reformatado para leitura mais nítida' : `Apostila Premium V6 · Página ${pdfPage}`}</h3>
                <p className="mt-1 text-sm text-slate-300">{c32fViewMode === 'reader' ? 'Quadros críticos reescritos em linhas maiores, com melhor centralização e leitura dentro do CrewCheck.' : 'Se o PDF ficar pequeno no dispositivo, use o zoom ou troque para Leitura guiada.'}</p>
              </div>
              <div className="rounded-full border border-white/10 bg-white/[0.08] px-3 py-1 text-[11px] font-black uppercase tracking-[0.16em] text-slate-200">
                {c32fViewMode === 'reader' ? 'Modo leitura' : pdfStatus === 'ready' ? 'PDF carregado' : pdfStatus === 'loading' ? 'Carregando PDF' : 'Falha ao carregar'}
              </div>
            </div>

            {c32fViewMode === 'reader' ? (
              <div className="max-h-[78vh] overflow-y-auto px-4 py-4 md:px-6 md:py-6">
                <div className="grid gap-4 xl:grid-cols-[1.15fr_0.85fr]">
                  <div className="grid gap-4">
                    {readerTables.map((table) => (
                      <article key={table.title} className="rounded-[1.7rem] border border-white/10 bg-slate-950/45 p-4 md:p-5">
                        <h4 className="text-lg font-black text-white md:text-xl">{table.title}</h4>
                        <p className="mt-1 text-sm leading-6 text-slate-300">{table.subtitle}</p>
                        <div className="mt-4 overflow-x-auto rounded-2xl border border-cyan-300/15 bg-white/[0.03]">
                          <table className="min-w-full text-left text-sm">
                            <thead className="bg-cyan-300 text-[#07111f]">
                              <tr>
                                {table.columns.map((column) => <th key={column} className="px-4 py-3 font-black">{column}</th>)}
                              </tr>
                            </thead>
                            <tbody>
                              {table.rows.map((row) => (
                                <tr key={row[0]} className="border-t border-white/10 align-top">
                                  <td className="w-[26%] px-4 py-3 font-black text-white">{row[0]}</td>
                                  <td className="px-4 py-3 leading-7 text-slate-200">{row[1]}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                        <div className="mt-4 rounded-2xl border border-amber-300/15 bg-amber-300/10 p-4">
                          <p className="text-xs font-black uppercase tracking-[0.16em] text-amber-100/80">Memorização rápida</p>
                          <ul className="mt-3 grid gap-2 text-sm leading-6 text-amber-50/90">
                            {table.notes.map((note) => <li key={note}>• {note}</li>)}
                          </ul>
                        </div>
                      </article>
                    ))}
                  </div>

                  <div className="grid gap-4">
                    {readerBlocks.map((block) => (
                      <article key={block.title} className="rounded-[1.7rem] border border-white/10 bg-white/[0.05] p-5 shadow-xl shadow-black/10">
                        <h4 className="text-lg font-black text-white">{block.title}</h4>
                        <div className="mt-4 grid gap-2">
                          {block.bullets.map((bullet) => (
                            <div key={bullet} className="rounded-2xl border border-white/10 bg-slate-950/50 px-4 py-3 text-sm leading-6 text-slate-200">{bullet}</div>
                          ))}
                        </div>
                      </article>
                    ))}
                    <article className="rounded-[1.7rem] border border-emerald-300/15 bg-emerald-300/10 p-5">
                      <h4 className="text-lg font-black text-emerald-50">Sugestão de uso</h4>
                      <ul className="mt-4 grid gap-2 text-sm leading-6 text-emerald-50/90">
                        <li>• Use a <b>Leitura guiada</b> para revisar tabelas críticas de forma mais legível.</li>
                        <li>• Use o <b>PDF original</b> quando quiser conferir a paginação e o conteúdo integral.</li>
                        <li>• Em tablet/iPad, o modo leitura costuma ficar mais claro do que o visualizador nativo do PDF.</li>
                      </ul>
                    </article>
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-[78vh] min-h-[34rem] bg-slate-950/70 p-3 md:p-5">
                {pdfStatus === 'ready' && pdfUrl ? (
                  <div className="mx-auto h-full w-full max-w-[1100px] overflow-hidden rounded-[1.6rem] bg-white shadow-2xl shadow-black/30 ring-1 ring-white/10">
                    <iframe key={`${pdfUrl}-${pdfPage}-${pdfZoom}`} title="Apostila Premium C32F V6" src={`${pdfUrl}#page=${pdfPage}&zoom=${pdfZoom}`} className="h-full w-full border-0 bg-white" />
                  </div>
                ) : (
                  <div className="flex h-full items-center justify-center p-6 text-center">
                    <div className="max-w-md rounded-[2rem] border border-white/10 bg-white/[0.06] p-6">
                      <Loader2 className={`mx-auto h-8 w-8 ${pdfStatus === 'loading' ? 'animate-spin text-cyan-200' : 'text-amber-200'}`} />
                      <h3 className="mt-4 text-xl font-black">{pdfStatus === 'loading' ? 'Carregando apostila privada...' : 'Não foi possível abrir o PDF'}</h3>
                      <p className="mt-2 text-sm leading-6 text-slate-300">{pdfStatus === 'loading' ? 'O CrewCheck está validando seu login antes de exibir a apostila C32F.' : 'Confirme se você está logado como administrador autorizado e tente atualizar a página.'}</p>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </section>

        <section className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {modules.map((item) => (
            <article key={item.title} className="crewcheck-light-card rounded-[1.8rem] border border-white/10 bg-white/[0.06] p-5 shadow-xl shadow-black/20">
              <div className="mb-4 flex items-center justify-between gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-300/15 text-cyan-200"><GraduationCap className="h-6 w-6" /></div>
                <span className="rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-1 text-[10px] font-black uppercase tracking-[0.14em] text-cyan-100">{item.tag}</span>
              </div>
              <h3 className="text-lg font-black">{item.title}</h3>
              <p className="mt-3 text-sm leading-6 text-slate-300">{item.text}</p>
            </article>
          ))}
        </section>

        <section className="mt-6 grid gap-4 lg:grid-cols-[1fr_0.9fr]">
          <div className="crewcheck-light-card rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 shadow-2xl shadow-black/20">
            <h3 className="text-xl font-black">Checklist de prova/check</h3>
            <div className="mt-4 grid gap-3">
              {quickQuestions.map((question, index) => (
                <div key={question} className="flex gap-3 rounded-2xl border border-white/10 bg-white/[0.05] p-4">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-cyan-300 text-sm font-black text-[#07111f]">{index + 1}</span>
                  <p className="text-sm leading-6 text-slate-200">{question}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="crewcheck-light-card rounded-[2rem] border border-amber-300/20 bg-amber-400/10 p-5 shadow-2xl shadow-black/20">
            <h3 className="text-xl font-black text-amber-50">Quando aparecer C32F na escala</h3>
            <p className="mt-3 text-sm leading-6 text-amber-50/85">O CrewCheck trata C32F como Check de Competência A32F, separado de voo, folga e voo extra. Ele deve aparecer como treinamento/check, entrar no calendário como atividade de solo e servir como gatilho para revisão desta academia.</p>
            <div className="mt-4 rounded-2xl border border-amber-200/20 bg-black/15 p-4 text-sm leading-6 text-amber-50/90">
              Sugestão de rotina: nos 7 dias anteriores, revise um bloco por dia. Na véspera, use apenas revisão rápida e sono.
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}


type PerDiemType = 'CAFE' | 'ALMOCO' | 'JANTAR' | 'CEIA';
type PerDiemCurrency = 'BRL' | 'USD' | 'EUR' | 'GBP';

type PerDiemEntry = {
  date: string;
  dutyCode: string;
  type: PerDiemType;
  label: string;
  window: string;
  value: number;
  currency: PerDiemCurrency;
  currencyLabel: string;
  countryLabel?: string;
  international: boolean;
  confidence: 'alta' | 'estimada';
  reason: string;
};

type SalaryDeductionLine = { label: string; value: number; detail?: string };

type PayslipCalibration = {
  fileName: string;
  parsedAt: string;
  gross?: number;
  discounts?: number;
  net?: number;
  baseSalary?: number;
  recurringDeductions?: number;
  lines?: SalaryDeductionLine[];
};

type DirectDiscountOverride = {
  total: number;
  note?: string;
  updatedAt: string;
};

type AdminPreciseSalaryBreakdown = {
  fgtsBase: number;
  fgts: number;
  inssBase: number;
  irBase: number;
  inss: number;
  irrf: number;
  vgbl: number;
  fixedDiscounts: number;
  coparticipation: number;
  discountLines: SalaryDeductionLine[];
  estimatedDiscounts: number;
  netPrecise: number;
  disclaimer: string;
};

type SalaryForecast = {
  baseSalary: number;
  dayKm: number;
  nightKm: number;
  dfsDayKm: number;
  dfsNightKm: number;
  flightPay: number;
  reserveHours: number;
  standbyHours: number;
  reservePay: number;
  standbyPay: number;
  trainingPay: number;
  ccmChiefBonusCount: number;
  ccmChiefBonusPay: number;
  instructorBonusCount: number;
  instructorBonusPay: number;
  dsrPay: number;
  gross: number;
  estimatedDiscounts: number;
  estimatedNet: number;
  adminBreakdown?: AdminPreciseSalaryBreakdown;
  confidence: string;
};

const CREW_DIEM_MAIN_VALUE = 109.44;
const CREW_DIEM_BREAKFAST_VALUE = 27.36;
const CREW_DIEM_DOMESTIC_CURRENCY: PerDiemCurrency = 'BRL';

type InternationalPerDiemRule = {
  country: string;
  group: string;
  currency: PerDiemCurrency;
  mainValue: number;
  source: string;
};

const CREW_INTERNATIONAL_PER_DIEM_RULES: Record<string, InternationalPerDiemRule> = {
  NORTH_AMERICA: { country: 'América do Norte', group: 'América do Norte', currency: 'USD', mainValue: 25.70, source: 'ACT 2025/2027, cláusula 2.4.2' },
  MEXICO: { country: 'México', group: 'México', currency: 'USD', mainValue: 23.00, source: 'ACT 2025/2027, cláusula 2.4.2' },
  SOUTH_AMERICA_CARIBBEAN: { country: 'América do Sul/Caribe', group: 'América do Sul e Caribe', currency: 'USD', mainValue: 21.00, source: 'ACT 2025/2027, cláusula 2.4.2' },
  ARGENTINA: { country: 'Argentina', group: 'Argentina', currency: 'USD', mainValue: 22.05, source: 'ACT 2025/2027, cláusula 2.4.2' },
  CHILE: { country: 'Chile', group: 'Chile', currency: 'USD', mainValue: 25.15, source: 'ACT 2025/2027, cláusula 2.4.2' },
  UNITED_KINGDOM: { country: 'Inglaterra/Reino Unido', group: 'Inglaterra', currency: 'GBP', mainValue: 24.00, source: 'ACT 2025/2027, cláusula 2.4.2' },
  EUROPE: { country: 'Europa', group: 'Europa', currency: 'EUR', mainValue: 23.00, source: 'ACT 2025/2027, cláusula 2.4.2' },
  AFRICA: { country: 'África', group: 'África', currency: 'USD', mainValue: 24.70, source: 'ACT 2025/2027, cláusula 2.4.2' },
  OTHER: { country: 'Demais países', group: 'Demais países', currency: 'USD', mainValue: 21.05, source: 'ACT 2025/2027, cláusula 2.4.2' },
};

const CREW_AIRPORT_INTERNATIONAL_RULE: Record<string, keyof typeof CREW_INTERNATIONAL_PER_DIEM_RULES> = {
  EZE: 'ARGENTINA', AEP: 'ARGENTINA', COR: 'ARGENTINA', MDZ: 'ARGENTINA',
  SCL: 'CHILE',
  MEX: 'MEXICO', CUN: 'MEXICO', GDL: 'MEXICO', MTY: 'MEXICO',
  MIA: 'NORTH_AMERICA', JFK: 'NORTH_AMERICA', EWR: 'NORTH_AMERICA', BOS: 'NORTH_AMERICA', LAX: 'NORTH_AMERICA', MCO: 'NORTH_AMERICA', ATL: 'NORTH_AMERICA', DFW: 'NORTH_AMERICA', YYZ: 'NORTH_AMERICA', YUL: 'NORTH_AMERICA',
  LHR: 'UNITED_KINGDOM', LGW: 'UNITED_KINGDOM',
  MAD: 'EUROPE', BCN: 'EUROPE', LIS: 'EUROPE', OPO: 'EUROPE', CDG: 'EUROPE', ORY: 'EUROPE', FRA: 'EUROPE', MUC: 'EUROPE', AMS: 'EUROPE', FCO: 'EUROPE', MXP: 'EUROPE', ZRH: 'EUROPE',
  JNB: 'AFRICA', CPT: 'AFRICA',
  MVD: 'SOUTH_AMERICA_CARIBBEAN', ASU: 'SOUTH_AMERICA_CARIBBEAN', LIM: 'SOUTH_AMERICA_CARIBBEAN', BOG: 'SOUTH_AMERICA_CARIBBEAN', UIO: 'SOUTH_AMERICA_CARIBBEAN', GYE: 'SOUTH_AMERICA_CARIBBEAN', CCS: 'SOUTH_AMERICA_CARIBBEAN', PTY: 'SOUTH_AMERICA_CARIBBEAN', SJO: 'SOUTH_AMERICA_CARIBBEAN', PUJ: 'SOUTH_AMERICA_CARIBBEAN', SDQ: 'SOUTH_AMERICA_CARIBBEAN', HAV: 'SOUTH_AMERICA_CARIBBEAN',
};
const CREW_SALARY_BASE = 3076.64;
const CREW_KM_DAY_RATE = 0.058547;
const CREW_KM_NIGHT_RATE = 0.117094;
const CREW_KM_DFS_DAY_RATE = 0.117094;
const CREW_KM_DFS_NIGHT_RATE = 0.117094;
const CREW_RESERVE_HOUR_RATE = 49.765;
const CREW_STANDBY_HOUR_RATE = 16.588;
const CREW_TRAINING_INDEMNITY = 328.32;
const CREW_CCM_CHIEF_BONUS = 54.99;
const CREW_INSTRUCTOR_BONUS = 0; // Instrutor só entra quando houver valor/regra confirmados; treinamento comum usa indenização separada.
const CREW_DSR_FACTOR = 0.32;
const CREW_HISTORICAL_DISCOUNT_FACTOR = 0.61;
const CREW_HISTORICAL_MONTHLY_AVERAGE = { gross: 9779.73, net: 3818.78, discounts: 5960.95, sampleMonths: 4 };
const CREW_ADMIN_ORGANIC_COMPENSATION = 512.77;
const CREW_ADMIN_IRRF_TOP_RATE = 0.275;
const CREW_ADMIN_IRRF_DEDUCTION = 909.00;
const CREW_ADMIN_VGBL_RATE = 0.03;
const CREW_ADMIN_INSS_CAP = 988.07;
const CREW_ADMIN_INSS_EFFECTIVE_RATE = 0.116;
const CREW_ADMIN_COPARTICIPATION_AVG = 84.82;
const CREW_ADMIN_FIXED_DEDUCTIONS: SalaryDeductionLine[] = [
  { label: 'Parcela/crédito trabalhador MCT1', value: 1809.98, detail: 'histórico recorrente' },
  { label: 'Parcela/crédito trabalhador MCT2', value: 213.97, detail: 'histórico recorrente' },
  { label: 'Assistência Médica Amil', value: 565.86 },
  { label: 'Cota adicional Staff Travel', value: 183.00 },
  { label: 'Mensalidade Gympass', value: 199.99, detail: 'valor mais recente' },
  { label: 'Contribuição confed./assist. aeronautas', value: 109.44 },
  { label: 'Mensalidade sindicato aeronautas', value: 62.81 },
  { label: 'Odonto agregados', value: 49.74 },
  { label: 'Assistência odontológica família', value: 17.63 },
  { label: 'Cartão Saúde', value: 14.90 },
  { label: 'Mensalidade Grêmio', value: 9.23 },
];

const CREW_DIEM_WINDOWS: { type: PerDiemType; label: string; start: number; end: number; value: number }[] = [
  { type: 'CAFE', label: 'Café da manhã', start: 5 * 60, end: 8 * 60, value: CREW_DIEM_BREAKFAST_VALUE },
  { type: 'ALMOCO', label: 'Almoço', start: 11 * 60, end: 13 * 60, value: CREW_DIEM_MAIN_VALUE },
  { type: 'JANTAR', label: 'Jantar', start: 19 * 60, end: 20 * 60, value: CREW_DIEM_MAIN_VALUE },
  { type: 'CEIA', label: 'Ceia', start: 0, end: 60, value: CREW_DIEM_MAIN_VALUE },
];

const AIRPORT_COORDS: Record<string, [number, number]> = {
  BSB: [-15.8697, -47.9208], GRU: [-23.4356, -46.4731], CGH: [-23.6261, -46.6564], VCP: [-23.0074, -47.1345], GIG: [-22.8099, -43.2506], SDU: [-22.9105, -43.1631],
  CNF: [-19.6244, -43.9719], REC: [-8.1265, -34.9236], NAT: [-5.7681, -35.3761], SSA: [-12.9086, -38.3225], FOR: [-3.7763, -38.5326], POA: [-29.9944, -51.1714],
  CWB: [-25.5285, -49.1758], GYN: [-16.6320, -49.2207], MAO: [-3.0386, -60.0497], BEL: [-1.3793, -48.4763], FLN: [-27.6705, -48.5477], VIX: [-20.2581, -40.2864],
  MCZ: [-9.5108, -35.7917], JPA: [-7.1458, -34.9486], AJU: [-10.9840, -37.0703], THE: [-5.0606, -42.8235], SLZ: [-2.5854, -44.2341], CGB: [-15.6529, -56.1167], CGR: [-20.4694, -54.6703],
  BPS: [-16.4386, -39.0809], IOS: [-14.8159, -39.0332], IGU: [-25.5961, -54.4872], NVT: [-26.8794, -48.6514], JOI: [-26.2245, -48.7974], LDB: [-23.3336, -51.1301], UDI: [-18.8828, -48.2253], RAO: [-21.1342, -47.7742],
};

function formatMoney(value: number): string {
  return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function formatPerDiemCurrency(value: number, currency: PerDiemCurrency = 'BRL'): string {
  if (currency === 'BRL') return formatMoney(value);
  const locale = currency === 'GBP' ? 'en-GB' : currency === 'EUR' ? 'pt-PT' : 'en-US';
  return value.toLocaleString(locale, { style: 'currency', currency });
}

function emptyPerDiemCurrencyTotals(): Record<PerDiemCurrency, number> {
  return { BRL: 0, USD: 0, EUR: 0, GBP: 0 };
}

function addPerDiemCurrencyTotal(target: Record<PerDiemCurrency, number>, currency: PerDiemCurrency, value: number) {
  target[currency] = Number((target[currency] + value).toFixed(2));
}

function formatPerDiemTotals(totals: Record<PerDiemCurrency, number>): string {
  const order: PerDiemCurrency[] = ['BRL', 'USD', 'EUR', 'GBP'];
  const parts = order.filter((currency) => Math.abs(totals[currency] || 0) > 0.004).map((currency) => formatPerDiemCurrency(totals[currency], currency));
  return parts.length ? parts.join(' + ') : formatMoney(0);
}

function summarizePerDiemEntriesByCurrency(entries: PerDiemEntry[]): string {
  const totals = emptyPerDiemCurrencyTotals();
  for (const entry of entries) addPerDiemCurrencyTotal(totals, entry.currency, entry.value);
  return formatPerDiemTotals(totals);
}

function summarizePerDiemType(entries: PerDiemEntry[], type: PerDiemType): string {
  return summarizePerDiemEntriesByCurrency(entries.filter((entry) => entry.type === type));
}

function loadPayslipCalibration(): PayslipCalibration | null {
  try {
    const raw = localStorage.getItem('crewcheck_admin_payslip_calibration_v1');
    return raw ? JSON.parse(raw) as PayslipCalibration : null;
  } catch { return null; }
}

function savePayslipCalibration(value: PayslipCalibration | null): PayslipCalibration | null {
  try {
    if (value) localStorage.setItem('crewcheck_admin_payslip_calibration_v1', JSON.stringify(value));
    else localStorage.removeItem('crewcheck_admin_payslip_calibration_v1');
  } catch {}
  return value;
}

function loadDirectDiscountOverride(): DirectDiscountOverride | null {
  try {
    const raw = localStorage.getItem('crewcheck_direct_discount_override_v1');
    if (!raw) return null;
    const parsed = JSON.parse(raw) as DirectDiscountOverride;
    return Number.isFinite(parsed.total) && parsed.total >= 0 ? parsed : null;
  } catch { return null; }
}

function saveDirectDiscountOverride(value: DirectDiscountOverride | null): DirectDiscountOverride | null {
  try {
    if (value) localStorage.setItem('crewcheck_direct_discount_override_v1', JSON.stringify(value));
    else localStorage.removeItem('crewcheck_direct_discount_override_v1');
  } catch {}
  return value;
}

function applyDirectDiscountOverrideToForecast(forecast: SalaryForecast, override: DirectDiscountOverride | null): SalaryForecast {
  if (!override || !Number.isFinite(override.total)) return forecast;
  const total = Math.max(0, Number(override.total));
  const net = Math.max(0, forecast.gross - total);
  if (forecast.adminBreakdown) {
    return {
      ...forecast,
      estimatedDiscounts: total,
      estimatedNet: net,
      adminBreakdown: {
        ...forecast.adminBreakdown,
        fixedDiscounts: total,
        estimatedDiscounts: total,
        netPrecise: net,
        discountLines: [{ label: 'Descontos informados pelo usuário', value: total, detail: override.note || 'valor total informado, sem detalhar rubricas' }],
        disclaimer: `${forecast.adminBreakdown.disclaimer} Descontos substituídos pelo valor total informado pelo usuário, sem detalhamento de rubricas.`,
      },
    };
  }
  return {
    ...forecast,
    estimatedDiscounts: total,
    estimatedNet: net,
    confidence: `${forecast.confidence} Descontos substituídos pelo valor total informado pelo usuário, sem detalhamento.`,
  };
}

function parseBrazilMoneyInput(value: string): number | null {
  const normalized = String(value || '').replace(/\s/g, '').replace(/R\$/gi, '').replace(/\./g, '').replace(',', '.');
  const number = Number(normalized);
  return Number.isFinite(number) && number >= 0 ? number : null;
}

function downloadBlobFile(filename: string, blob: Blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function downloadTextFile(filename: string, content: string) {
  downloadBlobFile(filename, new Blob([content], { type: 'text/plain;charset=utf-8' }));
}

function buildFinancialPdfBlob(title: string, content: string): Blob {
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  let y = 18;
  doc.setFillColor(9, 40, 70);
  doc.rect(0, 0, pageWidth, 28, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text('CrewCheck Finance', 14, 13);
  doc.setFontSize(10);
  doc.text(title, 14, 21);
  y = 40;
  doc.setTextColor(20, 32, 48);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  const lines = doc.splitTextToSize(content, pageWidth - 28);
  for (const line of lines) {
    if (y > pageHeight - 18) {
      doc.addPage();
      y = 18;
    }
    doc.text(String(line), 14, y);
    y += 5;
  }
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('Previsão operacional. Confira sempre com os demonstrativos oficiais.', 14, pageHeight - 10);
  return doc.output('blob');
}

function openShareUrl(url: string) {
  try {
    const native = getCrewCheckNative();
    if (native?.openExternal) {
      native.openExternal(url);
      return;
    }
  } catch {}
  window.open(url, '_blank', 'noopener,noreferrer');
}

async function shareOrDownloadFinancialSummary(filename: string, content: string) {
  try {
    if (navigator.share) {
      await navigator.share({ title: 'CrewCheck Finance', text: content });
      return;
    }
  } catch {}
  downloadTextFile(filename, content);
}

function shareFinancialByWhatsApp(content: string) {
  openShareUrl(`https://wa.me/?text=${encodeURIComponent(content)}`);
}

function shareFinancialByEmail(title: string, content: string) {
  window.location.href = `mailto:?subject=${encodeURIComponent(title)}&body=${encodeURIComponent(content)}`;
}

function exportFinancialPdf(filename: string, title: string, content: string) {
  downloadBlobFile(filename.replace(/\.txt$/i, '.pdf'), buildFinancialPdfBlob(title, content));
  toast.success('PDF financeiro gerado.');
}

function FinanceShareActions({ filename, title, content }: { filename: string; title: string; content: string }) {
  return (
    <div className="flex flex-wrap justify-end gap-2">
      <Button onClick={() => void shareOrDownloadFinancialSummary(filename, content)} className="rounded-2xl bg-emerald-200 px-3 py-3 text-xs font-black text-[#07111f] hover:bg-emerald-100">Compartilhar</Button>
      <Button onClick={() => shareFinancialByWhatsApp(content)} className="rounded-2xl bg-green-300 px-3 py-3 text-xs font-black text-[#07111f] hover:bg-green-200">WhatsApp</Button>
      <Button onClick={() => shareFinancialByEmail(title, content)} className="rounded-2xl bg-sky-200 px-3 py-3 text-xs font-black text-[#07111f] hover:bg-sky-100">E-mail</Button>
      <Button onClick={() => exportFinancialPdf(filename, title, content)} className="rounded-2xl bg-violet-200 px-3 py-3 text-xs font-black text-[#07111f] hover:bg-violet-100">PDF</Button>
    </div>
  );
}

function financialPeriodLabel(bundle: SessionRosterBundle | null): string {
  const first = bundle?.roster.days?.[0]?.date;
  const last = bundle?.roster.days?.[bundle?.roster.days.length - 1]?.date;
  return first && last ? `${first} a ${last}` : 'período atual';
}

async function parsePayslipCalibrationPdf(file: File): Promise<PayslipCalibration> {
  const dataBase64 = await fileToBase64Payload(file);
  const response = await fetch('/api/parse-payslip', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ filename: file.name, dataBase64 }),
  });
  const payload = await response.json().catch(() => null);
  if (!response.ok || !payload?.ok) throw new Error(payload?.message || 'Não consegui ler o holerite.');
  return {
    fileName: file.name,
    parsedAt: new Date().toISOString(),
    gross: payload.gross,
    discounts: payload.discounts,
    net: payload.net,
    baseSalary: payload.baseSalary,
    recurringDeductions: payload.recurringDeductions,
    lines: payload.lines || [],
  };
}

function applyPayslipCalibrationToForecast(forecast: SalaryForecast, calibration: PayslipCalibration | null): SalaryForecast {
  if (!calibration || !forecast.adminBreakdown) return forecast;
  const admin = forecast.adminBreakdown;
  const calibratedRecurring = Number.isFinite(calibration.recurringDeductions || NaN) ? Number(calibration.recurringDeductions) : admin.fixedDiscounts + admin.coparticipation;
  const calculatedCore = admin.inss + admin.irrf + admin.vgbl;
  const estimatedDiscounts = Math.max(0, calculatedCore + calibratedRecurring);
  const netPrecise = Math.max(0, forecast.gross - estimatedDiscounts);
  const calibrationLine: SalaryDeductionLine = { label: 'Calibração por holerite PDF', value: calibratedRecurring, detail: calibration.fileName };
  return {
    ...forecast,
    adminBreakdown: {
      ...admin,
      fixedDiscounts: calibratedRecurring,
      estimatedDiscounts,
      netPrecise,
      discountLines: [...admin.discountLines.filter((line) => !/Parcela|Assistência|Cota|Gympass|Odonto|Cartão|Mensalidade|Contribuição|Coparticipação/i.test(line.label)), calibrationLine],
      disclaimer: `${admin.disclaimer} Calibrado com holerite local ${calibration.fileName}; o PDF não é enviado a terceiros e a calibração fica neste dispositivo.`,
    },
  };
}


function parseTimeToMinutes(value: string | null | undefined): number | null {
  const match = String(value || '').match(/(\d{1,2}):(\d{2})/);
  if (!match) return null;
  const hours = Number(match[1]);
  const minutes = Number(match[2]);
  if (!Number.isFinite(hours) || !Number.isFinite(minutes)) return null;
  return ((hours * 60 + minutes) % 1440 + 1440) % 1440;
}

function displayMinutes(value: number): string {
  const total = ((Math.round(value) % 1440) + 1440) % 1440;
  return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
}

function dayKey(date: Date): string {
  return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()}`;
}

function addDays(date: Date, days: number): Date {
  const copy = new Date(date);
  copy.setDate(copy.getDate() + days);
  return copy;
}

function easterDate(year: number): Date {
  const a = year % 19;
  const b = Math.floor(year / 100);
  const c = year % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31);
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  return new Date(year, month - 1, day);
}

function isKnownBrazilPaymentHoliday(date: Date): boolean {
  const d = date.getDate();
  const m = date.getMonth() + 1;
  const fixed = new Set(['1/1','21/4','1/5','7/9','12/10','2/11','15/11','20/11','25/12']);
  if (fixed.has(`${d}/${m}`)) return true;
  const easter = easterDate(date.getFullYear());
  const movable = [addDays(easter, -48), addDays(easter, -47), addDays(easter, -2), addDays(easter, 60)];
  return movable.some((holiday) => holiday.getFullYear() === date.getFullYear() && holiday.getMonth() === date.getMonth() && holiday.getDate() === date.getDate());
}

function estimatePaymentDateAfterWeeklyClose(endDate: Date): { date: Date; adjusted: boolean; reason: string } {
  const thursday = addDays(endDate, 2);
  if (thursday.getDay() === 4 && isKnownBrazilPaymentHoliday(thursday)) {
    return { date: addDays(thursday, -1), adjusted: true, reason: 'quinta com feriado/ponto facultativo conhecido; pagamento antecipado para quarta' };
  }
  let payment = thursday;
  let adjusted = false;
  while (payment.getDay() === 0 || payment.getDay() === 6 || isKnownBrazilPaymentHoliday(payment)) {
    payment = addDays(payment, -1);
    adjusted = true;
  }
  return { date: payment, adjusted, reason: adjusted ? 'ajustado para dia útil anterior' : 'pagamento estimado na quinta' };
}

function isFinancialStandbyOnly(day: CrewRoster['days'][number]): boolean {
  const code = String(day.pairingCode || day.type || '').toUpperCase();
  return /^(HSB|HSBE|SOBREAVISO)$/.test(code) && !day.legs?.length;
}

function isFinancialReserve(day: CrewRoster['days'][number]): boolean {
  const code = String(day.pairingCode || day.type || '').toUpperCase();
  return /^(ASB|RES|RESERVA)$/.test(code);
}

function isFinancialTraining(day: CrewRoster['days'][number]): boolean {
  const code = String(day.pairingCode || day.type || '').toUpperCase();
  return /^(CBF|EMER|C32F|CRM|MT|TRE|TRAIN|TREINAMENTO)$/.test(code) || String(day.type || '').toUpperCase() === 'TRAINING';
}

function isFinancialFlight(day: CrewRoster['days'][number]): boolean {
  return Boolean(day.legs?.length);
}

function isPerDiemEligibleForWindow(day: CrewRoster['days'][number], mealType: PerDiemType): boolean {
  if (isFinancialStandbyOnly(day)) return false;
  if (mealType === 'CEIA') return isFinancialFlight(day) || isFinancialReserve(day);
  return isFinancialFlight(day) || isFinancialReserve(day) || isFinancialTraining(day);
}

type PerDiemSegmentKind = 'flight' | 'reserve' | 'training' | 'layover';

type PerDiemOperationalSegment = {
  date: string;
  start: number;
  end: number;
  absStart: number;
  absEnd: number;
  code: string;
  kind: PerDiemSegmentKind;
  confidence: 'alta' | 'estimada';
  reason: string;
  currency: PerDiemCurrency;
  currencyLabel: string;
  countryLabel?: string;
  international: boolean;
  internationalRule?: InternationalPerDiemRule;
};

type PerDiemAnchor = {
  day: CrewRoster['days'][number];
  startAbs: number;
  endAbs: number;
  origin?: string;
  destination?: string;
  code: string;
};

const CREW_DIEM_TRUST_NOTE = 'Motor CrewCheck calibrado por demonstrativos LATAM reais e ACT 2025/2027 e reconciliado com demonstrativos oficiais reais: nacionais em R$ 109,44 / café R$ 27,36, fechamento semanal quarta–terça; internacionais separadas por moeda e pagas no dia do voo/serviço internacional. Quando houver demonstrativo oficial importado/calibrado, ele prevalece sobre a estimativa da escala.';


type OfficialPerDiemCalibrationRow = {
  date: string;
  type: PerDiemType;
  dutyCode: string;
  value: number;
  source: string;
};

// Demonstrativos oficiais LATAM enviados pelo usuário. Estes dados servem como
// base de reconciliação para evitar falsas estimativas quando a escala mensal
// não traz todo o contexto do fechamento semanal anterior/posterior.
const CREW_OFFICIAL_DOMESTIC_DIEM_CALIBRATION: OfficialPerDiemCalibrationRow[] = [
  // Demonstrativo 13/05/2026 – 19/05/2026 · pagamento 21/05 · total R$ 875,52
  { date: '14/05/2026', type: 'JANTAR', dutyCode: 'LA 3590', value: 109.44, source: 'Demonstrativo LATAM 13/05–19/05' },
  { date: '15/05/2026', type: 'ALMOCO', dutyCode: 'PERNOITE POA', value: 109.44, source: 'Demonstrativo LATAM 13/05–19/05' },
  { date: '15/05/2026', type: 'JANTAR', dutyCode: 'LA 3012', value: 109.44, source: 'Demonstrativo LATAM 13/05–19/05' },
  { date: '15/05/2026', type: 'CEIA', dutyCode: 'LA 3500', value: 109.44, source: 'Demonstrativo LATAM 13/05–19/05' },
  { date: '16/05/2026', type: 'JANTAR', dutyCode: 'PERNOITE MAB', value: 109.44, source: 'Demonstrativo LATAM 13/05–19/05' },
  { date: '16/05/2026', type: 'ALMOCO', dutyCode: 'PERNOITE MAB', value: 109.44, source: 'Demonstrativo LATAM 13/05–19/05' },
  { date: '17/05/2026', type: 'ALMOCO', dutyCode: 'LA 3721', value: 109.44, source: 'Demonstrativo LATAM 13/05–19/05' },
  { date: '18/05/2026', type: 'JANTAR', dutyCode: 'ASB', value: 109.44, source: 'Demonstrativo LATAM 13/05–19/05' },

  // Demonstrativo 20/05/2026 – 26/05/2026 · pagamento 28/05 · total R$ 656,64
  { date: '21/05/2026', type: 'ALMOCO', dutyCode: 'CRMBSB', value: 109.44, source: 'Demonstrativo LATAM 20/05–26/05' },
  { date: '22/05/2026', type: 'JANTAR', dutyCode: 'LA 3867', value: 109.44, source: 'Demonstrativo LATAM 20/05–26/05' },
  { date: '22/05/2026', type: 'CEIA', dutyCode: 'LA 3494', value: 109.44, source: 'Demonstrativo LATAM 20/05–26/05' },
  { date: '23/05/2026', type: 'JANTAR', dutyCode: 'PERNOITE JPA', value: 109.44, source: 'Demonstrativo LATAM 20/05–26/05' },
  { date: '23/05/2026', type: 'ALMOCO', dutyCode: 'PERNOITE JPA', value: 109.44, source: 'Demonstrativo LATAM 20/05–26/05' },
  { date: '24/05/2026', type: 'ALMOCO', dutyCode: 'LA 4700', value: 109.44, source: 'Demonstrativo LATAM 20/05–26/05' },

  // Demonstrativo 27/05/2026 – 02/06/2026 · pagamento 03/06 · total R$ 684,00
  { date: '29/05/2026', type: 'ALMOCO', dutyCode: 'LA 4648', value: 109.44, source: 'Demonstrativo LATAM 27/05–02/06' },
  { date: '29/05/2026', type: 'JANTAR', dutyCode: 'LA 3425', value: 109.44, source: 'Demonstrativo LATAM 27/05–02/06' },
  { date: '30/05/2026', type: 'JANTAR', dutyCode: 'LA 3992', value: 109.44, source: 'Demonstrativo LATAM 27/05–02/06' },
  { date: '31/05/2026', type: 'JANTAR', dutyCode: 'PERNOITE NAT', value: 109.44, source: 'Demonstrativo LATAM 27/05–02/06' },
  { date: '31/05/2026', type: 'ALMOCO', dutyCode: 'PERNOITE NAT', value: 109.44, source: 'Demonstrativo LATAM 27/05–02/06' },
  { date: '01/06/2026', type: 'CAFE', dutyCode: 'LA 4676', value: 27.36, source: 'Demonstrativo LATAM 27/05–02/06' },
  { date: '02/06/2026', type: 'ALMOCO', dutyCode: 'CBF/EMER', value: 109.44, source: 'Demonstrativo LATAM 27/05–02/06' },

  // Demonstrativo 03/06/2026 – 09/06/2026 · pagamento 11/06 · total R$ 547,20
  { date: '03/06/2026', type: 'JANTAR', dutyCode: 'ASB', value: 109.44, source: 'Demonstrativo LATAM 03/06–09/06' },
  { date: '07/06/2026', type: 'JANTAR', dutyCode: 'LA 4737', value: 109.44, source: 'Demonstrativo LATAM 03/06–09/06' },
  { date: '08/06/2026', type: 'ALMOCO', dutyCode: 'PERNOITE CGH', value: 109.44, source: 'Demonstrativo LATAM 03/06–09/06' },
  { date: '08/06/2026', type: 'JANTAR', dutyCode: 'C32F', value: 109.44, source: 'Demonstrativo LATAM 03/06–09/06' },
  { date: '09/06/2026', type: 'JANTAR', dutyCode: 'ASB', value: 109.44, source: 'Demonstrativo LATAM 03/06–09/06' },
];

function domesticWeekKeyForDate(dateString: string): string {
  const date = rosterDateFromString(dateString);
  const day = date.getDay();
  const daysSinceWednesday = (day - 3 + 7) % 7;
  const startDate = addDays(date, -daysSinceWednesday);
  const endDate = addDays(startDate, 6);
  return `${dayKey(startDate)}-${dayKey(endDate)}`;
}

function isOfficialBrunoPerDiemCalibrationEnabled(bundle: SessionRosterBundle | null): boolean {
  const roster = bundle?.roster;
  if (!roster?.days?.length) return false;
  const identity = `${roster.crewName || ''} ${roster.crewId || ''} ${roster.base || ''}`.toUpperCase();
  const looksLikeBruno = (identity.includes('BRUNO') && identity.includes('SARAIVA')) || identity.includes('4453812') || identity.includes('04453812');
  if (!looksLikeBruno) return false;
  const rosterWeekKeys = new Set((roster.days || []).map((day) => domesticWeekKeyForDate(day.date)));
  return CREW_OFFICIAL_DOMESTIC_DIEM_CALIBRATION.some((row) => rosterWeekKeys.has(domesticWeekKeyForDate(row.date)));
}

function officialRowToPerDiemEntry(row: OfficialPerDiemCalibrationRow): PerDiemEntry {
  const window = CREW_DIEM_WINDOWS.find((item) => item.type === row.type) || CREW_DIEM_WINDOWS[0];
  return {
    date: row.date,
    dutyCode: row.dutyCode,
    type: row.type,
    label: window.label,
    window: `${displayMinutes(window.start)} – ${displayMinutes(window.end)}`,
    value: row.value,
    currency: 'BRL',
    currencyLabel: 'Brasil · R$',
    international: false,
    confidence: 'alta',
    reason: `${row.source}: lançamento oficial de diária nacional usado como calibração prioritária. O demonstrativo oficial prevalece quando a escala mensal não contém todo o contexto do fechamento semanal ou quando a estimativa gerou divergência.`,
  };
}

function reconcileDomesticPerDiemWithOfficialDemonstratives(entries: PerDiemEntry[], bundle: SessionRosterBundle | null): PerDiemEntry[] {
  if (!isOfficialBrunoPerDiemCalibrationEnabled(bundle)) return entries;
  const rosterWeekKeys = new Set((bundle?.roster?.days || []).map((day) => domesticWeekKeyForDate(day.date)));
  const officialRows = CREW_OFFICIAL_DOMESTIC_DIEM_CALIBRATION.filter((row) => rosterWeekKeys.has(domesticWeekKeyForDate(row.date)));
  if (!officialRows.length) return entries;
  const overrideWeekKeys = new Set(officialRows.map((row) => domesticWeekKeyForDate(row.date)));
  const kept = entries.filter((entry) => entry.international || !overrideWeekKeys.has(domesticWeekKeyForDate(entry.date)));
  const officialEntries = officialRows.map(officialRowToPerDiemEntry);
  return [...kept, ...officialEntries];
}

function countMainAndCafe(entries: PerDiemEntry[]): string {
  const main = entries.filter((entry) => entry.currency === 'BRL' && entry.type !== 'CAFE').length;
  const cafe = entries.filter((entry) => entry.currency === 'BRL' && entry.type === 'CAFE').length;
  if (cafe && main) return `${main} principal(is) + ${cafe} café(s)`;
  if (cafe) return `${cafe} café(s)`;
  return `${main} principal(is)`;
}

function absoluteDayBase(date: string): number {
  const parsed = rosterDateFromString(date);
  parsed.setHours(0, 0, 0, 0);
  return Math.floor(parsed.getTime() / 60000);
}

function dateKeyFromAbsoluteMinutes(abs: number): string {
  const date = new Date(abs * 60000);
  return dayKey(date);
}

function codeForPerDiemDay(day: CrewRoster['days'][number]): string {
  return String(day.pairingCode || day.type || '').toUpperCase() || 'JORNADA';
}

function normalizedAirportCode(value: string | null | undefined): string {
  return String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4);
}

function internationalPerDiemRuleForAirport(airport: string | null | undefined): InternationalPerDiemRule | null {
  const code = normalizedAirportCode(airport);
  const key = CREW_AIRPORT_INTERNATIONAL_RULE[code];
  return key ? CREW_INTERNATIONAL_PER_DIEM_RULES[key] : null;
}

function perDiemMetaFromRule(rule: InternationalPerDiemRule | null): Pick<PerDiemOperationalSegment, 'currency' | 'currencyLabel' | 'countryLabel' | 'international' | 'internationalRule'> {
  if (!rule) return { currency: CREW_DIEM_DOMESTIC_CURRENCY, currencyLabel: 'Brasil · R$', international: false, internationalRule: undefined };
  return { currency: rule.currency, currencyLabel: `${rule.country} · ${rule.currency}`, countryLabel: rule.country, international: true, internationalRule: rule };
}

function applyInternationalPerDiemRule(segment: PerDiemOperationalSegment, rule: InternationalPerDiemRule, context: string): PerDiemOperationalSegment {
  const meta = perDiemMetaFromRule(rule);
  return {
    ...segment,
    ...meta,
    confidence: segment.confidence === 'estimada' ? 'estimada' : 'alta',
    reason: `${segment.reason} ${context} Diária internacional aplicada conforme país do pernoite/prestação no exterior: ${rule.country}, refeição principal ${formatPerDiemCurrency(rule.mainValue, rule.currency)} (${rule.source}).`,
  };
}

function dayDutyRangeMinutes(day: CrewRoster['days'][number]): { start: number; end: number; confidence: 'alta' | 'estimada' } | null {
  const firstLeg = day.legs?.[0];
  const lastLeg = day.legs?.[day.legs.length - 1];
  const range = dashboardDutyRange(day, firstLeg, lastLeg);
  const start = parseTimeToMinutes(range.start);
  const endRaw = parseTimeToMinutes(range.end);
  if (start === null || endRaw === null) return null;
  const end = endRaw <= start ? endRaw + 1440 : endRaw;
  if (end <= start) return null;
  const confidence: 'alta' | 'estimada' = /fim não|estimad|não lido/i.test(String(range.end || '')) ? 'estimada' : 'alta';
  return { start, end, confidence };
}

function splitAbsoluteSegment(startAbs: number, endAbs: number, code: string, kind: PerDiemSegmentKind, confidence: 'alta' | 'estimada', reason: string, meta: Partial<Pick<PerDiemOperationalSegment, 'currency' | 'currencyLabel' | 'countryLabel' | 'international' | 'internationalRule'>> = {}): PerDiemOperationalSegment[] {
  const out: PerDiemOperationalSegment[] = [];
  if (!Number.isFinite(startAbs) || !Number.isFinite(endAbs) || endAbs <= startAbs) return out;
  let cursor = startAbs;
  while (cursor < endAbs) {
    const date = dateKeyFromAbsoluteMinutes(cursor);
    const localStart = ((cursor % 1440) + 1440) % 1440;
    const nextMidnight = cursor - localStart + 1440;
    const sliceEndAbs = Math.min(endAbs, nextMidnight);
    const localEnd = ((sliceEndAbs % 1440) + 1440) % 1440 || 1440;
    out.push({
      date,
      start: localStart,
      end: localEnd,
      absStart: cursor,
      absEnd: sliceEndAbs,
      code,
      kind,
      confidence,
      reason,
      currency: meta.currency || CREW_DIEM_DOMESTIC_CURRENCY,
      currencyLabel: meta.currencyLabel || 'Brasil · R$',
      countryLabel: meta.countryLabel,
      international: Boolean(meta.international),
      internationalRule: meta.internationalRule,
    });
    cursor = sliceEndAbs;
  }
  return out;
}

function activitySegmentForDay(day: CrewRoster['days'][number]): PerDiemOperationalSegment[] {
  const dayType = String(day.type || '').toUpperCase();
  const code = codeForPerDiemDay(day);
  if (['DO', 'DOF', 'DR', 'DOP', 'DOPR', 'OFF', 'VC'].includes(dayType) || ['DO', 'DOF', 'DR', 'DOP', 'DOPR', 'OFF', 'VC'].includes(code)) return [];
  if (isFinancialStandbyOnly(day)) return [];
  const range = dayDutyRangeMinutes(day);
  if (!range) return [];
  const dayAbs = absoluteDayBase(day.date);
  const startAbs = dayAbs + range.start;
  const endAbs = dayAbs + range.end;
  if (isFinancialReserve(day)) {
    return splitAbsoluteSegment(startAbs, endAbs, 'ASB', 'reserve', range.confidence, 'Reserva ASB/RES real: não herda horário de HSB; sem fim legível, usa 6h e limita a 1 refeição principal, somando café apenas se cruzar 05:00–08:00.');
  }
  if (isFinancialFlight(day)) {
    const first = day.legs?.[0];
    const last = day.legs?.[day.legs.length - 1];
    const flightCode = first?.flightNumber ? `LA ${first.flightNumber}` : code;
    const route = first && last ? `${first.origin || ''}–${last.destination || ''}` : 'voo';
    return splitAbsoluteSegment(startAbs, endAbs, flightCode, 'flight', range.confidence, `Voo/etapa ativa ${route}: gera refeições somente nas janelas trabalhadas; café só quando a jornada começa antes de 05:00 e cruza 05:00–08:00.`);
  }
  if (isFinancialTraining(day)) {
    return splitAbsoluteSegment(startAbs, endAbs, code, 'training', range.confidence, 'Treinamento/CRM/EAD/MT: diária principal quando a atividade toca almoço ou jantar, conforme demonstrativos oficiais.');
  }
  return [];
}

function buildFlightAnchors(roster: CrewRoster): PerDiemAnchor[] {
  return (roster.days || [])
    .filter((day) => day.legs?.length)
    .map((day) => {
      const first = day.legs?.[0];
      const last = day.legs?.[day.legs.length - 1];
      const range = dayDutyRangeMinutes(day);
      if (!range || !first || !last) return null;
      const base = absoluteDayBase(day.date);
      return {
        day,
        startAbs: base + range.start,
        endAbs: base + range.end,
        origin: normalizedAirportCode(first.origin),
        destination: normalizedAirportCode(last.destination),
        code: first.flightNumber ? `LA ${first.flightNumber}` : codeForPerDiemDay(day),
      } as PerDiemAnchor;
    })
    .filter(Boolean)
    .sort((a, b) => (a as PerDiemAnchor).startAbs - (b as PerDiemAnchor).startAbs) as PerDiemAnchor[];
}

function buildLayoverPerDiemSegments(roster: CrewRoster): PerDiemOperationalSegment[] {
  const base = normalizedAirportCode(roster.base || 'BSB') || 'BSB';
  const anchors = buildFlightAnchors(roster);
  const out: PerDiemOperationalSegment[] = [];
  for (let i = 0; i < anchors.length; i += 1) {
    const current = anchors[i];
    const away = normalizedAirportCode(current.destination);
    if (!away || away === base) continue;
    const next = anchors.slice(i + 1).find((candidate) => candidate.startAbs > current.endAbs && normalizedAirportCode(candidate.origin) === away);
    if (!next) continue;
    const gap = next.startAbs - current.endAbs;
    if (gap < 60 || gap > 6 * 24 * 60) continue;
    const internationalRule = internationalPerDiemRuleForAirport(away);
    const meta = perDiemMetaFromRule(internationalRule);
    const layoverReason = internationalRule
      ? `Pernoite fora do Brasil em ${away}. O ACT prevê diárias internacionais em moeda estrangeira do país/local de prestação; café internacional é conservador e não é gerado por pernoite puro quando pode estar incluído no hotel.`
      : `Permanência fora da base em ${away} entre voos. Demonstrativos LATAM pagam almoço/jantar quando o pernoite cobre essas janelas; café e ceia não são gerados por pernoite puro.`;
    out.push(...splitAbsoluteSegment(
      current.endAbs,
      next.startAbs,
      `PERNOITE ${away}`,
      'layover',
      'alta',
      layoverReason,
      meta
    ));
  }
  return out;
}

function buildPerDiemOperationalSegments(bundle: SessionRosterBundle | null): PerDiemOperationalSegment[] {
  const roster = bundle?.roster;
  if (!roster?.days?.length) return [];
  const active = roster.days.flatMap(activitySegmentForDay);
  const layovers = buildLayoverPerDiemSegments(roster);
  const internationalLayovers = layovers.filter((segment) => segment.international && segment.internationalRule);
  const enrichedActive = active.map((segment) => {
    if (segment.kind !== 'flight') return segment;
    const adjacentInternational = internationalLayovers.find((layover) => {
      const beforeLayover = segment.absEnd <= layover.absStart && (layover.absStart - segment.absEnd) <= 12 * 60;
      const afterLayover = segment.absStart >= layover.absEnd && (segment.absStart - layover.absEnd) <= 12 * 60;
      return beforeLayover || afterLayover;
    });
    return adjacentInternational?.internationalRule
      ? applyInternationalPerDiemRule(segment, adjacentInternational.internationalRule, 'Voo conectado a pernoite internacional; bate-volta sem pernoite permanece em reais.')
      : segment;
  });
  return [...enrichedActive, ...layovers].sort((a, b) => rosterDateFromString(a.date).getTime() - rosterDateFromString(b.date).getTime() || a.start - b.start || a.kind.localeCompare(b.kind));
}


function rangesOverlap(startA: number, endA: number, startB: number, endB: number): boolean {
  // Diárias reais LATAM: atividade 09:00–11:00 toca almoço e o demonstrativo paga.
  // Não conta duração zero nem atividade que começa exatamente no fim da janela.
  if (!Number.isFinite(startA) || !Number.isFinite(endA) || endA <= startA) return false;
  return startA < endB && endA >= startB;
}

function segmentTouchesMealWindow(segment: PerDiemOperationalSegment, window: typeof CREW_DIEM_WINDOWS[number]): boolean {
  if (window.type === 'CEIA') {
    if (segment.kind !== 'flight' && segment.kind !== 'reserve') return false;
    return segment.start < 60 || segment.end >= 1440 || rangesOverlap(segment.start, segment.end, 0, 60);
  }
  if (window.type === 'CAFE') {
    if (segment.kind === 'layover' || segment.kind === 'training') return false;
    if (segment.international && segment.kind !== 'flight') return false;
    if (segment.kind === 'flight') return segment.start < 5 * 60 && rangesOverlap(segment.start, segment.end, window.start, window.end);
    return rangesOverlap(segment.start, segment.end, window.start, window.end);
  }
  if (segment.kind === 'layover' || segment.kind === 'flight' || segment.kind === 'reserve' || segment.kind === 'training') {
    return rangesOverlap(segment.start, segment.end, window.start, window.end);
  }
  return false;
}

function reserveMealWindowsForSegment(segment: PerDiemOperationalSegment): typeof CREW_DIEM_WINDOWS[number][] {
  const hits: typeof CREW_DIEM_WINDOWS[number][] = [];
  const cafe = CREW_DIEM_WINDOWS.find((item) => item.type === 'CAFE');
  if (cafe && segmentTouchesMealWindow(segment, cafe)) hits.push(cafe);
  const main = CREW_DIEM_WINDOWS
    .filter((item) => item.type === 'ALMOCO' || item.type === 'JANTAR' || item.type === 'CEIA')
    .find((item) => segmentTouchesMealWindow(segment, item));
  if (main) hits.push(main);
  return hits;
}

function mealWindowsForSegment(segment: PerDiemOperationalSegment): typeof CREW_DIEM_WINDOWS[number][] {
  if (segment.kind === 'reserve') return reserveMealWindowsForSegment(segment);
  return CREW_DIEM_WINDOWS.filter((window) => segmentTouchesMealWindow(segment, window));
}

function makePerDiemEntryFromSegment(segment: PerDiemOperationalSegment, window: typeof CREW_DIEM_WINDOWS[number]): PerDiemEntry {
  const mainValue = segment.internationalRule ? segment.internationalRule.mainValue : CREW_DIEM_MAIN_VALUE;
  const value = window.type === 'CAFE' ? Number((mainValue * 0.25).toFixed(2)) : mainValue;
  const reasonByKind: Record<PerDiemSegmentKind, string> = {
    flight: window.type === 'CAFE'
      ? `${segment.reason} Café calibrado: só entra quando voo/jornada começa antes de 05:00 e cruza 05:00–08:00; em pernoite internacional pode ser zerado se o café estiver incluído no hotel.`
      : segment.reason,
    reserve: segment.reason,
    training: segment.reason,
    layover: segment.reason,
  };
  const internationalSuffix = segment.international ? ` Moeda aplicada: ${segment.currencyLabel}. Bate-volta internacional sem pernoite permanece em reais; ajuste manual se o demonstrativo oficial vier diferente.` : '';
  return {
    date: segment.date,
    dutyCode: segment.code,
    type: window.type,
    label: window.label,
    window: `${displayMinutes(window.start)} – ${displayMinutes(window.end)}`,
    value,
    currency: segment.currency,
    currencyLabel: segment.currencyLabel,
    countryLabel: segment.countryLabel,
    international: segment.international,
    confidence: segment.confidence,
    reason: `${reasonByKind[segment.kind]}${internationalSuffix}`,
  };
}

function isBetterPerDiemEntry(candidate: PerDiemEntry, current: PerDiemEntry | undefined): boolean {
  if (!current) return true;
  const priority = (entry: PerDiemEntry) => {
    const code = entry.dutyCode.toUpperCase();
    const intl = entry.international ? 10 : 0;
    if (/^LA\s?\d+/.test(code)) return intl + 4;
    if (/^(ASB|RES)/.test(code)) return intl + 3;
    if (/PERNOITE/.test(code)) return intl + 2;
    return intl + 1;
  };
  return priority(candidate) > priority(current);
}

type PerDiemWeekTotal = { key: string; start: string; end: string; paymentHint: string; totals: Record<PerDiemCurrency, number>; total: number; count: number; countLabel: string };
type InternationalPerDiemPayment = { key: string; date: string; dutyCode: string; countryLabel: string; currency: PerDiemCurrency; totals: Record<PerDiemCurrency, number>; total: number; count: number; paymentHint: string };


function computePerDiemForecast(bundle: SessionRosterBundle | null): { entries: PerDiemEntry[]; total: number; totalsByCurrency: Record<PerDiemCurrency, number>; byType: Record<PerDiemType, number>; byWeek: PerDiemWeekTotal[]; byInternationalPayment: InternationalPerDiemPayment[] } {
  const byKey = new Map<string, PerDiemEntry>();
  const segments = buildPerDiemOperationalSegments(bundle);
  for (const segment of segments) {
    for (const window of mealWindowsForSegment(segment)) {
      const entry = makePerDiemEntryFromSegment(segment, window);
      const key = `${segment.date}-${window.type}`;
      if (isBetterPerDiemEntry(entry, byKey.get(key))) byKey.set(key, entry);
    }
  }
  const estimatedEntries = Array.from(byKey.values());
  const entries = reconcileDomesticPerDiemWithOfficialDemonstratives(estimatedEntries, bundle)
    .sort((a, b) => rosterDateFromString(a.date).getTime() - rosterDateFromString(b.date).getTime() || CREW_DIEM_WINDOWS.findIndex((w) => w.type === a.type) - CREW_DIEM_WINDOWS.findIndex((w) => w.type === b.type));
  const byType = { CAFE: 0, ALMOCO: 0, JANTAR: 0, CEIA: 0 } as Record<PerDiemType, number>;
  const totalsByCurrency = emptyPerDiemCurrencyTotals();
  for (const entry of entries) {
    if (entry.currency === 'BRL') byType[entry.type] += entry.value;
    addPerDiemCurrencyTotal(totalsByCurrency, entry.currency, entry.value);
  }
  const byWeek = groupPerDiemByCrewWeek(entries.filter((entry) => !entry.international));
  const byInternationalPayment = groupInternationalPerDiemByFlightDate(entries.filter((entry) => entry.international));
  return { entries, total: totalsByCurrency.BRL, totalsByCurrency, byType, byWeek, byInternationalPayment };
}

function groupPerDiemByCrewWeek(entries: PerDiemEntry[]): PerDiemWeekTotal[] {
  const map = new Map<string, PerDiemWeekTotal>();
  for (const entry of entries) {
    const date = rosterDateFromString(entry.date);
    const day = date.getDay();
    const daysSinceWednesday = (day - 3 + 7) % 7;
    const startDate = addDays(date, -daysSinceWednesday);
    const endDate = addDays(startDate, 6);
    const payment = estimatePaymentDateAfterWeeklyClose(endDate);
    const start = dayKey(startDate);
    const end = dayKey(endDate);
    const key = `${start}-${end}`;
    const current = map.get(key) || { key, start, end, paymentHint: `Fechamento terça ${end} · pagamento estimado ${dayKey(payment.date)} (${payment.reason})`, totals: emptyPerDiemCurrencyTotals(), total: 0, count: 0, countLabel: '' };
    addPerDiemCurrencyTotal(current.totals, entry.currency, entry.value);
    current.total = current.totals.BRL;
    current.count += 1;
    current.countLabel = countMainAndCafe(entries.filter((item) => !item.international && domesticWeekKeyForDate(item.date) === key));
    map.set(key, current);
  }
  return Array.from(map.values()).sort((a, b) => rosterDateFromString(a.start).getTime() - rosterDateFromString(b.start).getTime());
}

function groupInternationalPerDiemByFlightDate(entries: PerDiemEntry[]): InternationalPerDiemPayment[] {
  const map = new Map<string, InternationalPerDiemPayment>();
  for (const entry of entries) {
    const cleanDuty = String(entry.dutyCode || 'Voo internacional').replace(/\s+/g, ' ').trim();
    const country = entry.countryLabel || entry.currencyLabel || 'Exterior';
    const key = `${entry.date}-${cleanDuty}-${entry.currency}`;
    const current = map.get(key) || {
      key,
      date: entry.date,
      dutyCode: cleanDuty,
      countryLabel: country,
      currency: entry.currency,
      totals: emptyPerDiemCurrencyTotals(),
      total: 0,
      count: 0,
      paymentHint: `Pagamento separado no dia do voo/serviço internacional: ${entry.date}`,
    };
    addPerDiemCurrencyTotal(current.totals, entry.currency, entry.value);
    current.total = current.totals[entry.currency];
    current.count += 1;
    map.set(key, current);
  }
  return Array.from(map.values()).sort((a, b) => rosterDateFromString(a.date).getTime() - rosterDateFromString(b.date).getTime() || a.dutyCode.localeCompare(b.dutyCode));
}


function haversineKm(from: string, to: string): number {
  const a = AIRPORT_COORDS[String(from || '').toUpperCase()];
  const b = AIRPORT_COORDS[String(to || '').toUpperCase()];
  if (!a || !b) return 0;
  const rad = Math.PI / 180;
  const dLat = (b[0] - a[0]) * rad;
  const dLon = (b[1] - a[1]) * rad;
  const lat1 = a[0] * rad;
  const lat2 = b[0] * rad;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return Math.round(6371 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h)));
}

function isWeekendRosterDate(date: string): boolean {
  const value = rosterDateFromString(date);
  const day = value.getDay();
  return day === 0 || day === 6;
}

function isNightLeg(leg: CrewRoster['days'][number]['legs'][number]): boolean {
  const dep = parseTimeToMinutes(leg.departureTime);
  const arr = parseTimeToMinutes(leg.arrivalTime);
  if (dep === null || arr === null) return false;
  const end = arr <= dep ? arr + 1440 : arr;
  for (let t = dep; t <= end; t += 30) {
    const minute = t % 1440;
    if (minute >= 22 * 60 || minute < 5 * 60) return true;
  }
  return false;
}


function isInstructorBonusDay(day: CrewRoster['days'][number]): boolean {
  const text = `${day.pairingCode || ''} ${day.type || ''} ${day.rawText || ''}`.toUpperCase();
  // A gratificação/adicional de instrutor só entra como confirmado quando o PDF/iFlight trouxer
  // indicação explícita de INSTRUTOR/INSTRUCTOR/INSTR/INST. Treinamento comum continua separado.
  return /\b(INSTRUTOR|INSTRUCTOR|INSTR|INST)\b/.test(text);
}

function hoursBetweenDisplay(start: string, end: string): number {
  const a = parseTimeToMinutes(start);
  const b = parseTimeToMinutes(end);
  if (a === null || b === null) return 0;
  const diff = b <= a ? b + 1440 - a : b - a;
  return Math.max(0, diff / 60);
}

type CrewCheckFlightLeg = CrewRoster['days'][number]['legs'][number];

function normalizeCrewNameForFinance(value: string | null | undefined): string {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toUpperCase()
    .replace(/[^A-Z\s]/g, ' ')
    .replace(/\b(SR|SRA|MR|MRS|MS|COMISSARIO|COMISSARIA|TRIPULANTE)\b/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function isSameCrewForFinance(a: string | null | undefined, b: string | null | undefined): boolean {
  const left = normalizeCrewNameForFinance(a);
  const right = normalizeCrewNameForFinance(b);
  if (!left || !right) return false;
  if (left === right) return true;
  const aParts = left.split(' ').filter((part) => part.length > 1 && !['DE','DA','DO','DAS','DOS','E'].includes(part));
  const bParts = right.split(' ').filter((part) => part.length > 1 && !['DE','DA','DO','DAS','DOS','E'].includes(part));
  if (aParts.length >= 2 && bParts.length >= 2) {
    const firstLast = aParts[0] === bParts[0] && aParts[aParts.length - 1] === bParts[bParts.length - 1];
    if (firstLast) return true;
    const shortParts = aParts.length <= bParts.length ? aParts : bParts;
    const longParts = aParts.length <= bParts.length ? bParts : aParts;
    if (shortParts.length >= 2 && shortParts.every((part) => longParts.includes(part))) return true;
    const common = shortParts.filter((part) => longParts.includes(part));
    if (common.length >= 2 && common.includes(shortParts[0])) return true;
  }
  return false;
}

function loadFinanceCrewNameCandidates(bundle?: SessionRosterBundle | null): string[] {
  const candidates = [
    bundle?.roster.crewName,
  ];
  try {
    candidates.push(localStorage.getItem('crewcheck_profile_display_name') || undefined);
    candidates.push(localStorage.getItem('crewcheck_profile_full_name') || undefined);
    candidates.push(localStorage.getItem('crewcheck_last_roster_crew_name') || undefined);
  } catch {}
  const normalized = new Set<string>();
  return candidates
    .map((item) => String(item || '').trim())
    .filter((item) => item && !/^tripulante$/i.test(item) && !/@/.test(item))
    .filter((item) => {
      const key = normalizeCrewNameForFinance(item);
      if (!key || normalized.has(key)) return false;
      normalized.add(key);
      return true;
    });
}

function crewNameMatchesAnyForFinance(name: string | null | undefined, candidates: string[]): boolean {
  return candidates.some((candidate) => isSameCrewForFinance(name, candidate));
}

function shouldCountCcmChiefBonusForFinance(leg: CrewCheckFlightLeg, crewNameCandidates: string[]): boolean {
  if (leg.ccmBonusStatus === 'confirmed') return true;
  const crew = leg.crew || [];
  const firstCcm = crew.find((member) => String(member.role || '').toUpperCase() === 'CCM') || null;
  const lead = leg.ccmLead || firstCcm;
  if (!lead) return false;
  if (lead.isCurrentCrew) return true;
  if (crewNameMatchesAnyForFinance(lead.name, crewNameCandidates)) return true;
  const current = crew.find((member) => member.isCurrentCrew || crewNameMatchesAnyForFinance(member.name, crewNameCandidates));
  return Boolean(current && String(current.role || '').toUpperCase() === 'CCM' && Number(lead.order) === Number(current.order));
}

function computeSalaryForecast(bundle: SessionRosterBundle | null, adminPrecise = false): SalaryForecast {
  let dayKm = 0;
  let nightKm = 0;
  let dfsDayKm = 0;
  let dfsNightKm = 0;
  let reserveHours = 0;
  let standbyHours = 0;
  let trainingCount = 0;
  let ccmChiefBonusCount = 0;
  let instructorBonusCount = 0;
  const crewNameCandidates = loadFinanceCrewNameCandidates(bundle);
  for (const day of bundle?.roster.days || []) {
    const weekend = isWeekendRosterDate(day.date);
    for (const leg of day.legs || []) {
      if (shouldCountCcmChiefBonusForFinance(leg, crewNameCandidates)) ccmChiefBonusCount += 1;
      const km = haversineKm(leg.origin, leg.destination);
      if (!km) continue;
      const night = isNightLeg(leg);
      if (weekend && night) dfsNightKm += km;
      else if (weekend) dfsDayKm += km;
      else if (night) nightKm += km;
      else dayKm += km;
    }
    const code = String(day.pairingCode || day.type || '').toUpperCase();
    const range = dashboardDutyRange(day, day.legs?.[0], day.legs?.[day.legs.length - 1]);
    const hours = hoursBetweenDisplay(range.start, range.end);
    if (/^(ASB|RES)$/.test(code)) reserveHours += hours;
    if (/^(HSB|HSBE)$/.test(code)) standbyHours += hours;
    if (/^(CBF|EMER|CRM|C32F|TRE|TREINAMENTO)$/.test(code) || day.type === 'CRM') trainingCount += 1;
    if (isInstructorBonusDay(day)) instructorBonusCount += 1;
  }
  const flightPay = dayKm * CREW_KM_DAY_RATE + nightKm * CREW_KM_NIGHT_RATE + dfsDayKm * CREW_KM_DFS_DAY_RATE + dfsNightKm * CREW_KM_DFS_NIGHT_RATE;
  const reservePay = reserveHours * CREW_RESERVE_HOUR_RATE;
  const standbyPay = standbyHours * CREW_STANDBY_HOUR_RATE;
  const trainingPay = trainingCount > 0 ? CREW_TRAINING_INDEMNITY : 0;
  const ccmChiefBonusPay = ccmChiefBonusCount * CREW_CCM_CHIEF_BONUS;
  const instructorBonusPay = instructorBonusCount * CREW_INSTRUCTOR_BONUS;
  const variable = flightPay + reservePay + standbyPay + trainingPay + ccmChiefBonusPay + instructorBonusPay;
  const dsrPay = variable * CREW_DSR_FACTOR;
  const gross = CREW_SALARY_BASE + variable + dsrPay;
  const estimatedDiscounts = gross * CREW_HISTORICAL_DISCOUNT_FACTOR;
  const estimatedNet = Math.max(0, gross - estimatedDiscounts);
  const adminBreakdown = adminPrecise ? computeAdminPreciseSalaryBreakdown(gross, trainingPay) : undefined;
  return { baseSalary: CREW_SALARY_BASE, dayKm, nightKm, dfsDayKm, dfsNightKm, flightPay, reserveHours, standbyHours, reservePay, standbyPay, trainingPay, ccmChiefBonusCount, ccmChiefBonusPay, instructorBonusCount, instructorBonusPay, dsrPay, gross, estimatedDiscounts, estimatedNet, adminBreakdown, confidence: adminBreakdown ? 'Modo administrador: cálculo itemizado com base nos demonstrativos enviados, incluindo INSS, IRRF, VGBL e descontos recorrentes.' : 'Estimativa baseada na escala, distâncias aproximadas e média histórica dos demonstrativos.' };
}

function estimateAdminInss(base: number): number {
  if (base <= 0) return 0;
  return Math.min(CREW_ADMIN_INSS_CAP, Math.max(0, base * CREW_ADMIN_INSS_EFFECTIVE_RATE));
}

function computeAdminPreciseSalaryBreakdown(gross: number, nonTaxableTrainingPay: number): AdminPreciseSalaryBreakdown {
  const fgtsBase = Math.max(0, gross - nonTaxableTrainingPay);
  const fgts = fgtsBase * 0.08;
  const inssBase = Math.max(0, fgtsBase - CREW_ADMIN_ORGANIC_COMPENSATION);
  const inss = estimateAdminInss(inssBase);
  const irBase = Math.max(0, fgtsBase - inss);
  const irrf = Math.max(0, irBase * CREW_ADMIN_IRRF_TOP_RATE - CREW_ADMIN_IRRF_DEDUCTION);
  const vgbl = fgtsBase * CREW_ADMIN_VGBL_RATE;
  const fixedLines: SalaryDeductionLine[] = [...CREW_ADMIN_FIXED_DEDUCTIONS, { label: 'Coparticipação Amil estimada', value: CREW_ADMIN_COPARTICIPATION_AVG, detail: 'média histórica variável' }];
  const calculatedLines: SalaryDeductionLine[] = [
    { label: 'INSS remuneração estimado', value: inss, detail: `base estimada ${formatMoney(inssBase)}` },
    { label: 'IRRF salário estimado', value: irrf, detail: `base IR estimada ${formatMoney(irBase)}` },
    { label: 'Previdência privada VGBL', value: vgbl, detail: '3% da base estimada' },
  ];
  const discountLines = [...calculatedLines, ...fixedLines];
  const fixedDiscounts = fixedLines.reduce((sum, line) => sum + line.value, 0);
  const estimatedDiscounts = discountLines.reduce((sum, line) => sum + line.value, 0);
  const netPrecise = Math.max(0, gross - estimatedDiscounts);
  return {
    fgtsBase,
    fgts,
    inssBase,
    irBase,
    inss,
    irrf,
    vgbl,
    fixedDiscounts,
    coparticipation: CREW_ADMIN_COPARTICIPATION_AVG,
    discountLines,
    estimatedDiscounts,
    netPrecise,
    disclaimer: 'Previsão avançada visível apenas para o administrador. Descontos pessoais, coparticipação médica, ajustes retroativos, diferenças de folha e incidências oficiais podem alterar o líquido final.',
  };
}


function ForecastHero({ title, subtitle, total, tag, icon: Icon }: { title: string; subtitle: string; total: string; tag: string; icon: LucideIcon }) {
  return (
    <section className="relative overflow-hidden rounded-[2.2rem] border border-cyan-200/20 bg-gradient-to-br from-cyan-300/18 via-blue-500/10 to-violet-500/12 p-6 shadow-2xl shadow-black/25">
      <div className="absolute -right-10 -top-10 h-44 w-44 rounded-full bg-cyan-200/20 blur-2xl" />
      <div className="relative flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <span className="rounded-full border border-cyan-200/20 bg-cyan-100/10 px-3 py-1 text-[10px] font-black uppercase tracking-[0.22em] text-cyan-100">{tag}</span>
          <h2 className="mt-4 text-3xl font-black tracking-tight sm:text-5xl">{title}</h2>
          <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-300">{subtitle}</p>
        </div>
        <div className="rounded-[1.8rem] border border-white/10 bg-white/10 p-5 text-right backdrop-blur-xl">
          <Icon className="ml-auto mb-3 h-7 w-7 text-cyan-200" />
          <p className="text-[11px] font-black uppercase tracking-[0.18em] text-slate-300">Total previsto</p>
          <p className="mt-1 text-3xl font-black text-white">{total}</p>
        </div>
      </div>
    </section>
  );
}

function PerDiemForecastScreen({ bundle, onBack, onOpenImport }: { bundle: SessionRosterBundle | null; onBack: () => void; onOpenImport: () => void }) {
  const forecast = computePerDiemForecast(bundle);
  const hasRoster = Boolean(bundle?.roster.days?.length);
  const summaryText = [
    'CrewCheck · Previsão de Diárias',
    `Período: ${financialPeriodLabel(bundle)}`,
    `Total mensal: ${formatPerDiemTotals(forecast.totalsByCurrency)}`,
    `Café: ${summarizePerDiemType(forecast.entries, 'CAFE')}`,
    `Almoço: ${summarizePerDiemType(forecast.entries, 'ALMOCO')}`,
    `Jantar: ${summarizePerDiemType(forecast.entries, 'JANTAR')}`,
    `Ceia: ${summarizePerDiemType(forecast.entries, 'CEIA')}`,
    '',
    'Nacionais — fechamento semanal:',
    ...forecast.byWeek.map((week) => `${week.start} a ${week.end}: ${formatPerDiemTotals(week.totals)} · ${week.paymentHint}`),
    '',
    'Internacionais — pagamento separado no dia do voo:',
    ...(forecast.byInternationalPayment.length ? forecast.byInternationalPayment.map((item) => `${item.date} · ${item.dutyCode}: ${formatPerDiemTotals(item.totals)} · ${item.paymentHint}`) : ['Nenhuma diária internacional prevista.']),
    '',
    'Previsão operacional. Confira sempre com o demonstrativo oficial.',
  ].join('\n');
  return (
    <div className="min-h-screen bg-[#08111f] px-5 py-8 pb-32 text-white crewcheck-finance-screen">
      <div className="mx-auto max-w-6xl">
        <HeaderBack title="Previsão de Diárias" subtitle="alimentação · escala · depósitos" onBack={onBack} action={hasRoster ? <FinanceShareActions filename="crewcheck-diarias.txt" title="CrewCheck · Previsão de Diárias" content={summaryText} /> : undefined} />
        <div className="mt-6">
          <ForecastHero icon={FileText} tag="CrewCheck Finance" title="Diárias previstas" subtitle="Motor calibrado por demonstrativos oficiais e ACT: nacionais por fechamento semanal, internacionais em pagamento separado no dia do voo/serviço, por país do pernoite/prestação. Reserva ASB não herda HSB; bate-volta internacional permanece em reais." total={formatPerDiemTotals(forecast.totalsByCurrency)} />
        </div>
        <div className="mt-4 rounded-3xl border border-emerald-300/20 bg-emerald-300/10 p-4 text-sm font-semibold leading-6 text-emerald-50/90">{CREW_DIEM_TRUST_NOTE}</div>
        {!hasRoster && <StateCard icon={CloudUpload} title="Importe uma escala" text="A previsão de diárias precisa de uma escala aberta ou salva. Envie PDF CrewTopia, iFlight, CrewRosterReport ou AIMS." />}
        {!hasRoster && <div className="mt-5"><Button onClick={onOpenImport} className="rounded-2xl bg-cyan-300 px-6 py-6 font-black text-[#07111f] hover:bg-cyan-200">Importar escala agora</Button></div>}
        {hasRoster && (
          <>
            <section className="mt-6 grid gap-3 sm:grid-cols-4">
              <Kpi icon={Clock} value={summarizePerDiemType(forecast.entries, 'CAFE')} label="Café · 05:00–08:00 · 25% da principal" />
              <Kpi icon={Clock} value={summarizePerDiemType(forecast.entries, 'ALMOCO')} label="Almoço · 11:00–13:00" />
              <Kpi icon={Clock} value={summarizePerDiemType(forecast.entries, 'JANTAR')} label="Jantar · 19:00–20:00" />
              <Kpi icon={Clock} value={summarizePerDiemType(forecast.entries, 'CEIA')} label="Ceia · 00:00–01:00" />
            </section>
            <section className="mt-6 rounded-[2rem] border border-cyan-200/15 bg-cyan-300/10 p-5 shadow-2xl shadow-black/20">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <p className="text-[11px] font-black uppercase tracking-[0.22em] text-cyan-100/70">fechamento semanal</p>
                  <h3 className="mt-1 text-2xl font-black">Totais por semana</h3>
                  <p className="mt-2 text-sm leading-6 text-cyan-50/80">Somente diárias nacionais entram no fechamento semanal de quarta a terça. Diárias internacionais ficam em painel próprio, por moeda, com pagamento separado no dia do voo/serviço internacional.</p>
                </div>
                <Badge className="rounded-full border-0 bg-cyan-200 text-[#07111f]">nacionais</Badge>
              </div>
              <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                {forecast.byWeek.map((week) => <div key={week.key} className="rounded-2xl border border-white/10 bg-white/[0.07] p-4"><p className="text-xs font-black uppercase tracking-[0.16em] text-cyan-100/70">{week.start} → {week.end}</p><p className="mt-2 text-2xl font-black text-emerald-100">{formatPerDiemTotals(week.totals)}</p><p className="mt-1 text-xs leading-5 text-cyan-50/70">{week.countLabel || `${week.count} diária(s)`} · {week.paymentHint}</p></div>)}
              </div>
            </section>

            <section className="mt-6 rounded-[2rem] border border-violet-200/15 bg-violet-300/10 p-5 shadow-2xl shadow-black/20">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <p className="text-[11px] font-black uppercase tracking-[0.22em] text-violet-100/70">internacionais</p>
                  <h3 className="mt-1 text-2xl font-black">Pagamentos separados por voo</h3>
                  <p className="mt-2 text-sm leading-6 text-violet-50/80">Internacionais não entram no depósito semanal nacional. São exibidas por data do voo/serviço, país e moeda, mantendo BRL separado de USD/EUR/GBP.</p>
                </div>
                <Badge className="rounded-full border-0 bg-violet-200 text-[#07111f]">dia do voo</Badge>
              </div>
              <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                {forecast.byInternationalPayment.map((item) => <div key={item.key} className="rounded-2xl border border-white/10 bg-white/[0.07] p-4"><p className="text-xs font-black uppercase tracking-[0.16em] text-violet-100/70">{item.date} · {item.countryLabel}</p><p className="mt-2 text-xl font-black text-violet-50">{formatPerDiemTotals(item.totals)}</p><p className="mt-1 text-xs leading-5 text-violet-50/70">{item.count} diária(s) · {item.dutyCode}</p><p className="mt-2 text-[11px] font-bold leading-5 text-violet-50/60">{item.paymentHint}</p></div>)}
                {forecast.byInternationalPayment.length === 0 && <div className="rounded-2xl border border-white/10 bg-white/[0.07] p-4 text-sm text-violet-50/75">Nenhuma diária internacional prevista nesta escala.</div>}
              </div>
            </section>
            <section className="mt-6 overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.055] shadow-2xl shadow-black/20">
              <div className="grid grid-cols-[1fr_1fr_1fr_1fr] gap-2 border-b border-white/10 bg-white/[0.06] px-4 py-3 text-[10px] font-black uppercase tracking-[0.18em] text-cyan-100/70 sm:grid-cols-[1fr_1fr_1fr_1fr_1fr]">
                <span>Data</span><span>Tipo</span><span>Janela</span><span>Valor</span><span className="hidden sm:block">Base</span>
              </div>
              <div className="divide-y divide-white/10">
                {forecast.entries.map((entry, index) => (
                  <div key={`${entry.date}-${entry.type}-${index}`} className="grid grid-cols-[1fr_1fr_1fr_1fr] gap-2 px-4 py-4 text-sm sm:grid-cols-[1fr_1fr_1fr_1fr_1fr]">
                    <span className="font-black text-white">{entry.date}</span>
                    <span className="font-black text-cyan-100">{entry.label}</span>
                    <span className="text-slate-300">{entry.window}</span>
                    <span className="font-black text-emerald-200">{formatPerDiemCurrency(entry.value, entry.currency)}</span>
                    <span className="hidden text-slate-400 sm:block">{entry.dutyCode} · {entry.currencyLabel} · {entry.confidence}</span>
                  </div>
                ))}
                {forecast.entries.length === 0 && <div className="px-4 py-8 text-center text-sm text-slate-300">Nenhuma janela de diária encontrada para a escala atual.</div>}
              </div>
            </section>
            <div className="mt-5 rounded-3xl border border-amber-300/20 bg-amber-300/10 p-5 text-sm leading-6 text-amber-50/90">
              Previsão operacional calibrada com demonstrativos reais e ACT. Confira sempre com o demonstrativo oficial: a regra pode variar por ajustes, hotel, café incluído, moeda local e lançamentos manuais. Sobreaviso puro não gera diária; ASB não herda HSB; bate-volta internacional permanece em reais; pernoite fora do Brasil gera moeda estrangeira pelo país do pernoite/prestação; internacionais são pagas separadamente no dia do voo/serviço; ceia só entra com voo/reserva ativa entre 00:00 e 01:00.
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function SalaryForecastScreen({ bundle, isAdmin, onBack, onOpenImport }: { bundle: SessionRosterBundle | null; isAdmin: boolean; onBack: () => void; onOpenImport: () => void }) {
  const [payslipCalibration, setPayslipCalibration] = useState<PayslipCalibration | null>(() => loadPayslipCalibration());
  const [directDiscount, setDirectDiscount] = useState<DirectDiscountOverride | null>(() => loadDirectDiscountOverride());
  const [directDiscountInput, setDirectDiscountInput] = useState(() => directDiscount ? String(directDiscount.total).replace('.', ',') : '');
  const [directDiscountNote, setDirectDiscountNote] = useState(() => directDiscount?.note || '');
  const [isReadingPayslip, setIsReadingPayslip] = useState(false);
  const baseForecast = computeSalaryForecast(bundle, isAdmin);
  const calibratedForecast = applyPayslipCalibrationToForecast(baseForecast, payslipCalibration);
  const forecast = applyDirectDiscountOverrideToForecast(calibratedForecast, directDiscount);
  const admin = forecast.adminBreakdown;
  const salarySummaryText = [
    'CrewCheck · Previsão de Salário',
    `Período: ${financialPeriodLabel(bundle)}`,
    `Bruto previsto: ${formatMoney(forecast.gross)}`,
    `Descontos previstos: ${formatMoney(admin?.estimatedDiscounts ?? forecast.estimatedDiscounts)}`,
    `Líquido previsto: ${formatMoney(admin?.netPrecise ?? forecast.estimatedNet)}`,
    `Média histórica líquida: ${formatMoney(CREW_HISTORICAL_MONTHLY_AVERAGE.net)}`,
    '',
    'Esta é uma previsão. O holerite oficial pode variar por impostos, convênios, coparticipação, ajustes retroativos e regras de folha.',
  ].join('\n');
  async function handlePayslipUpload(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    setIsReadingPayslip(true);
    try {
      const parsed = await parsePayslipCalibrationPdf(file);
      setPayslipCalibration(savePayslipCalibration(parsed));
      toast.success('Holerite lido localmente para calibrar a previsão.');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Não consegui ler o holerite.');
    } finally {
      setIsReadingPayslip(false);
    }
  }
  function clearPayslipCalibration() {
    setPayslipCalibration(savePayslipCalibration(null));
    toast.success('Calibração removida deste dispositivo.');
  }
  function saveDirectDiscount() {
    const total = parseBrazilMoneyInput(directDiscountInput);
    if (total === null) {
      toast.error('Informe o total de descontos em reais. Exemplo: 5960,95');
      return;
    }
    setDirectDiscount(saveDirectDiscountOverride({ total, note: directDiscountNote.trim() || 'Informado pelo usuário', updatedAt: new Date().toISOString() }));
    toast.success('Descontos diretos salvos neste dispositivo.');
  }
  function clearDirectDiscount() {
    setDirectDiscount(saveDirectDiscountOverride(null));
    setDirectDiscountInput('');
    setDirectDiscountNote('');
    toast.success('Descontos diretos removidos.');
  }
  const hasRoster = Boolean(bundle?.roster.days?.length);
  return (
    <div className="min-h-screen bg-[#08111f] px-5 py-8 pb-32 text-white crewcheck-finance-screen">
      <div className="mx-auto max-w-6xl">
        <HeaderBack title="Previsão de Salário" subtitle="proventos · escala · variável" onBack={onBack} action={hasRoster ? <FinanceShareActions filename="crewcheck-salario.txt" title="CrewCheck · Previsão de Salário" content={salarySummaryText} /> : undefined} />
        <div className="mt-6">
          <ForecastHero icon={TrendingUp} tag={admin ? 'CrewCheck Admin Finance' : 'CrewCheck Finance'} title={admin ? 'Salário previsto — administrador' : 'Salário estimado'} subtitle={admin ? 'Cálculo itemizado calibrado pelos seus demonstrativos: bruto, INSS, IRRF, VGBL, convênios, parcelas recorrentes e líquido previsto.' : 'Estimativa baseada em salário base, KM de voo, reserva, sobreaviso, treinamento, repouso remunerado e histórico dos demonstrativos enviados.'} total={formatMoney(admin?.netPrecise ?? forecast.estimatedNet)} />
        </div>
        <div className="mt-4 rounded-3xl border border-emerald-300/20 bg-emerald-300/10 p-4 text-sm font-semibold leading-6 text-emerald-50/90">{CREW_DIEM_TRUST_NOTE}</div>
        {!hasRoster && <StateCard icon={CloudUpload} title="Importe uma escala" text="Para estimar salário, abra uma escala do mês. O CrewCheck calcula voos, reserva, sobreaviso e variáveis previstas." />}
        {!hasRoster && <div className="mt-5"><Button onClick={onOpenImport} className="rounded-2xl bg-cyan-300 px-6 py-6 font-black text-[#07111f] hover:bg-cyan-200">Importar escala agora</Button></div>}
        {hasRoster && (
          <>
            <section className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
              <Kpi icon={FileText} value={formatMoney(forecast.baseSalary)} label="Salário base mensal" />
              <Kpi icon={Plane} value={formatMoney(forecast.flightPay)} label={`KM voo · ${Math.round(forecast.dayKm + forecast.nightKm + forecast.dfsDayKm + forecast.dfsNightKm).toLocaleString('pt-BR')} km`} />
              <Kpi icon={Clock} value={formatMoney(forecast.reservePay + forecast.standbyPay)} label={`${forecast.reserveHours.toFixed(1)}h reserva · ${forecast.standbyHours.toFixed(1)}h sobreaviso`} />
              <Kpi icon={UserRound} value={formatMoney(forecast.ccmChiefBonusPay)} label={`${forecast.ccmChiefBonusCount} chefia(s) CCM confirmada(s)`} />
              <Kpi icon={GraduationCap} value={formatMoney(forecast.trainingPay)} label="Indenização treinamento estimada" />
              <Kpi icon={TrendingUp} value={formatMoney(forecast.gross)} label="Bruto estimado antes dos descontos" />
            </section>
            <section className="mt-6 grid gap-4 lg:grid-cols-[1fr_0.8fr]">
              <div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 shadow-2xl shadow-black/20">
                <h3 className="text-xl font-black">Composição prevista</h3>
                <div className="mt-5 grid gap-3">
                  <FinanceLine label="Salário" value={forecast.baseSalary} />
                  <FinanceLine label="KM voo diurno" value={forecast.dayKm * CREW_KM_DAY_RATE} detail={`${Math.round(forecast.dayKm).toLocaleString('pt-BR')} km × ${CREW_KM_DAY_RATE.toFixed(6)}`} />
                  <FinanceLine label="KM voo noturno" value={forecast.nightKm * CREW_KM_NIGHT_RATE} detail={`${Math.round(forecast.nightKm).toLocaleString('pt-BR')} km × ${CREW_KM_NIGHT_RATE.toFixed(6)}`} />
                  <FinanceLine label="KM DFS" value={forecast.dfsDayKm * CREW_KM_DFS_DAY_RATE + forecast.dfsNightKm * CREW_KM_DFS_NIGHT_RATE} detail={`${Math.round(forecast.dfsDayKm + forecast.dfsNightKm).toLocaleString('pt-BR')} km`} />
                  <FinanceLine label="Horas reserva" value={forecast.reservePay} detail={`${forecast.reserveHours.toFixed(1)}h × ${formatMoney(CREW_RESERVE_HOUR_RATE)}`} />
                  <FinanceLine label="Horas sobreaviso" value={forecast.standbyPay} detail={`${forecast.standbyHours.toFixed(1)}h × ${formatMoney(CREW_STANDBY_HOUR_RATE)}`} />
                  <FinanceLine label="Treinamento/indenização estimada" value={forecast.trainingPay} />
                  <FinanceLine label="Gratificação chefe de cabine" value={forecast.ccmChiefBonusPay} detail={`${forecast.ccmChiefBonusCount} ocorrência(s) confirmada(s) × ${formatMoney(CREW_CCM_CHIEF_BONUS)}`} />
                  <FinanceLine label="Adicional de instrutor" value={forecast.instructorBonusPay} detail={forecast.instructorBonusCount ? `${forecast.instructorBonusCount} ocorrência(s) com indicação explícita de instrutor · valor pendente de confirmação` : 'Não soma automaticamente. Treinamento comum entra como indenização de treinamento.'} />
                  <FinanceLine label="Repouso remunerado estimado" value={forecast.dsrPay} detail="32% sobre variáveis calibrado pelo histórico" />
                </div>
              </div>
              <div className="rounded-[2rem] border border-cyan-200/15 bg-cyan-300/10 p-5 shadow-2xl shadow-black/20">
                <h3 className="text-xl font-black text-cyan-50">Resumo líquido</h3>
                <div className="mt-5 space-y-4">
                  <FinanceLine label="Bruto estimado" value={forecast.gross} />
                  <FinanceLine label={admin ? 'Descontos itemizados previstos' : 'Descontos estimados'} value={admin?.estimatedDiscounts ?? forecast.estimatedDiscounts} negative detail={admin ? 'INSS, IRRF, VGBL e recorrentes' : 'média histórica aproximada'} />
                  <div className="rounded-3xl border border-emerald-300/20 bg-emerald-300/12 p-5">
                    <p className="text-xs font-black uppercase tracking-[0.18em] text-emerald-100/75">Líquido previsto</p>
                    <p className="mt-2 text-4xl font-black text-emerald-100">{formatMoney(admin?.netPrecise ?? forecast.estimatedNet)}</p>
                  </div>
                  <p className="text-xs leading-5 text-cyan-50/80">{forecast.confidence} Use como projeção. O contracheque oficial pode variar por impostos, convênios, descontos pessoais, ajustes e regras de folha.</p>
                </div>
              </div>
            </section>
            <section className="mt-6 rounded-[2rem] border border-sky-200/15 bg-sky-300/10 p-5 shadow-2xl shadow-black/20">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <p className="text-[11px] font-black uppercase tracking-[0.22em] text-sky-100/80">média histórica</p>
                  <h3 className="mt-1 text-2xl font-black text-sky-50">Média mensal calibrada</h3>
                  <p className="mt-2 max-w-3xl text-sm leading-6 text-sky-50/80">Referência inicial calculada pelos demonstrativos enviados. Use como comparação rápida para saber se a previsão do mês está acima ou abaixo da média.</p>
                </div>
                <Badge className="rounded-full border-0 bg-sky-200 text-[#07111f]">{CREW_HISTORICAL_MONTHLY_AVERAGE.sampleMonths} meses</Badge>
              </div>
              <div className="mt-4 grid gap-3 sm:grid-cols-3">
                <Kpi icon={TrendingUp} value={formatMoney(CREW_HISTORICAL_MONTHLY_AVERAGE.gross)} label="Bruto médio histórico" />
                <Kpi icon={Shield} value={formatMoney(CREW_HISTORICAL_MONTHLY_AVERAGE.discounts)} label="Descontos médios históricos" />
                <Kpi icon={FileText} value={formatMoney(CREW_HISTORICAL_MONTHLY_AVERAGE.net)} label="Líquido médio histórico" />
              </div>
            </section>
            <section className="mt-6 rounded-[2rem] border border-violet-200/15 bg-violet-300/10 p-5 shadow-2xl shadow-black/20">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
                <div>
                  <p className="text-[11px] font-black uppercase tracking-[0.22em] text-violet-100/80">descontos sem detalhar</p>
                  <h3 className="mt-1 text-2xl font-black text-violet-50">Informar total de descontos</h3>
                  <p className="mt-2 max-w-3xl text-sm leading-6 text-violet-50/80">Se preferir não enviar holerite ou não detalhar rubricas, informe apenas o total mensal de descontos. O CrewCheck usa esse valor para estimar o líquido com mais privacidade.</p>
                </div>
                <div className="grid gap-2 sm:min-w-[360px] sm:grid-cols-[1fr_auto]">
                  <input value={directDiscountInput} onChange={(event) => setDirectDiscountInput(event.target.value)} placeholder="Ex.: 5960,95" inputMode="decimal" className="rounded-2xl border border-white/15 bg-black/20 px-4 py-3 text-sm font-black text-white outline-none placeholder:text-white/40" />
                  <Button onClick={saveDirectDiscount} className="rounded-2xl bg-violet-200 px-5 py-3 font-black text-[#07111f] hover:bg-violet-100">Salvar</Button>
                  <input value={directDiscountNote} onChange={(event) => setDirectDiscountNote(event.target.value)} placeholder="Observação opcional" className="rounded-2xl border border-white/15 bg-black/20 px-4 py-3 text-sm text-white outline-none placeholder:text-white/40 sm:col-span-2" />
                  {directDiscount && <button onClick={clearDirectDiscount} className="rounded-2xl border border-white/15 px-5 py-3 text-sm font-black text-violet-50 sm:col-span-2">Remover desconto direto · {formatMoney(directDiscount.total)}</button>}
                </div>
              </div>
            </section>
            <section className="mt-6 rounded-[2rem] border border-emerald-200/15 bg-emerald-300/10 p-5 shadow-2xl shadow-black/20">
                <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p className="text-[11px] font-black uppercase tracking-[0.22em] text-emerald-100/80">calibração LGPD</p>
                    <h3 className="mt-1 text-2xl font-black text-emerald-50">Importar holerite PDF</h3>
                    <p className="mt-2 max-w-3xl text-sm leading-6 text-emerald-50/80">Use um holerite/demonstrativo para calibrar descontos recorrentes e deixar a previsão líquida mais próxima. O arquivo é processado para extrair valores, e a calibração fica salva apenas neste dispositivo.</p>
                  </div>
                  <div className="flex flex-col gap-2 sm:min-w-64">
                    <label className="cursor-pointer rounded-2xl bg-emerald-200 px-5 py-3 text-center text-sm font-black text-[#07111f] shadow-lg shadow-black/20">
                      {isReadingPayslip ? 'Lendo PDF...' : 'Subir holerite PDF'}
                      <input type="file" accept="application/pdf,.pdf" className="hidden" onChange={(event) => void handlePayslipUpload(event)} />
                    </label>
                    {payslipCalibration && <button onClick={clearPayslipCalibration} className="rounded-2xl border border-white/15 px-5 py-3 text-sm font-black text-emerald-50">Remover calibração</button>}
                  </div>
                </div>
                {payslipCalibration && <div className="mt-4 grid gap-3 sm:grid-cols-3">
                  <Kpi icon={FileText} value={payslipCalibration.gross ? formatMoney(payslipCalibration.gross) : '—'} label={`Bruto do holerite · ${payslipCalibration.fileName}`} />
                  <Kpi icon={TrendingUp} value={payslipCalibration.net ? formatMoney(payslipCalibration.net) : '—'} label="Líquido lido do PDF" />
                  <Kpi icon={Shield} value={payslipCalibration.discounts ? formatMoney(payslipCalibration.discounts) : '—'} label="Descontos usados como referência" />
                </div>}
              </section>
            {admin && (
              <section className="mt-6 rounded-[2rem] border border-amber-200/15 bg-amber-300/10 p-5 shadow-2xl shadow-black/20">
                <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                  <div>
                    <p className="text-[11px] font-black uppercase tracking-[0.22em] text-amber-100/80">visível só para administrador</p>
                    <h3 className="mt-1 text-2xl font-black text-amber-50">Previsão líquida mais precisa</h3>
                    <p className="mt-2 max-w-3xl text-sm leading-6 text-amber-50/80">{admin.disclaimer}</p>
                  </div>
                  <div className="rounded-3xl border border-amber-100/20 bg-black/20 px-5 py-4 text-right">
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-amber-100/75">líquido admin</p>
                    <p className="text-3xl font-black text-amber-50">{formatMoney(admin.netPrecise)}</p>
                  </div>
                </div>
                <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  <Kpi icon={TrendingUp} value={formatMoney(forecast.gross)} label="Bruto previsto pela escala" />
                  <Kpi icon={FileText} value={formatMoney(admin.fgtsBase)} label={`Base FGTS · FGTS ${formatMoney(admin.fgts)}`} />
                  <Kpi icon={Shield} value={formatMoney(admin.inssBase)} label={`Base INSS · desconto ${formatMoney(admin.inss)}`} />
                  <Kpi icon={FileText} value={formatMoney(admin.irBase)} label={`Base IR · IRRF ${formatMoney(admin.irrf)}`} />
                </div>
                <div className="mt-5 grid gap-3 lg:grid-cols-2">
                  {admin.discountLines.map((line) => (
                    <FinanceLine key={line.label} label={line.label} value={line.value} negative detail={line.detail} />
                  ))}
                </div>
              </section>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function FinanceLine({ label, value, detail, negative }: { label: string; value: number; detail?: string; negative?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-2xl border border-white/10 bg-white/[0.055] px-4 py-3">
      <div><p className="font-black text-white">{label}</p>{detail && <p className="mt-1 text-xs text-slate-400">{detail}</p>}</div>
      <span className={`shrink-0 text-right text-lg font-black ${negative ? 'text-rose-200' : 'text-cyan-100'}`}>{negative ? '- ' : ''}{formatMoney(value)}</span>
    </div>
  );
}


function SupportPanel({ onBack, onOpenSettings, onOpenImport }: { onBack: () => void; onOpenSettings: () => void; onOpenImport: () => void }) {
  const subject = encodeURIComponent('Suporte CrewCheck');
  const body = encodeURIComponent(`Olá, preciso de ajuda com o CrewCheck.\n\nVersão: ${APP_VERSION}\nTela/erro:\nPrint/PDF anexado:\n`);
  const supportEmail = `mailto:bmedeiros1987@gmail.com?subject=${subject}&body=${body}`;
  const copySupportInfo = () => {
    const text = `CrewCheck v${APP_VERSION}\nURL: ${window.location.href}\nNavegador: ${navigator.userAgent}`;
    navigator.clipboard?.writeText(text)?.then(() => toast.success('Resumo técnico copiado.')).catch(() => toast.info('Não consegui copiar automaticamente.'));
  };
  return (
    <div className="min-h-screen overflow-x-hidden overflow-y-auto bg-[#07111F] px-5 py-8 text-white">
      <div className="mx-auto max-w-5xl">
        <HeaderBack title="Ajuda e suporte" subtitle="Fale com suporte ou envie divergência" onBack={onBack} />
        <section className="mt-6 overflow-hidden rounded-[2rem] border border-cyan-300/20 bg-white/[0.065] shadow-2xl shadow-cyan-950/20 backdrop-blur-2xl">
          <div className="bg-gradient-to-r from-cyan-300/18 via-white/[0.08] to-emerald-300/14 p-6 sm:p-8">
            <p className="text-xs font-black uppercase tracking-[0.22em] text-cyan-100/70">suporte premium</p>
            <h1 className="mt-2 text-3xl font-black tracking-tight sm:text-5xl">Precisa falar comigo?</h1>
            <p className="mt-4 max-w-3xl text-sm leading-7 text-slate-200/85">Envie print, PDF da escala e descreva o que não bateu. O CrewCheck evita expor informações administrativas para usuários finais e mantém o suporte focado no que ajuda a resolver rápido.</p>
          </div>
          <div className="grid gap-4 p-5 sm:grid-cols-3 sm:p-7">
            <a href={supportEmail} className="rounded-3xl border border-cyan-200/20 bg-cyan-300/10 p-5 text-left transition hover:bg-cyan-300/15"><Mail className="mb-4 h-8 w-8 text-cyan-200" /><h3 className="font-black">Enviar e-mail</h3><p className="mt-2 text-sm leading-6 text-slate-300">Abre mensagem com assunto e versão preenchidos.</p></a>
            <button onClick={copySupportInfo} className="rounded-3xl border border-white/10 bg-white/[0.055] p-5 text-left transition hover:bg-white/[0.09]"><FileText className="mb-4 h-8 w-8 text-emerald-200" /><h3 className="font-black">Copiar resumo</h3><p className="mt-2 text-sm leading-6 text-slate-300">Inclui versão, URL e navegador para diagnóstico.</p></button>
            <button onClick={onOpenImport} className="rounded-3xl border border-white/10 bg-white/[0.055] p-5 text-left transition hover:bg-white/[0.09]"><CloudUpload className="mb-4 h-8 w-8 text-amber-200" /><h3 className="font-black">Reimportar escala</h3><p className="mt-2 text-sm leading-6 text-slate-300">Use o PDF oficial antes de reportar divergência.</p></button>
          </div>
          <div className="border-t border-white/10 p-5 sm:p-7"><button onClick={onOpenSettings} className="rounded-2xl border border-cyan-300/25 bg-cyan-300/10 px-5 py-4 text-sm font-black text-cyan-50 transition hover:bg-cyan-300/15"><Settings className="mr-2 inline h-4 w-4" /> Abrir Configurações e Manual</button></div>
        </section>
      </div>
    </div>
  );
}

function SimplePanel({ title, description, icon: Icon, actions, onBack }: { title: string; description: string; icon: LucideIcon; actions: { label: string; onClick: () => void }[]; onBack: () => void }) {
  return (
    <div className="min-h-screen bg-[#08111f] px-5 py-8 text-white">
      <div className="mx-auto max-w-3xl">
        <HeaderBack title={title} subtitle="CrewCheck Premium" onBack={onBack} />
        <div className="mt-8 rounded-[2rem] border border-white/10 bg-white/[0.05] p-6 text-center">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-[1.6rem] bg-cyan-300/15 text-cyan-200"><Icon className="h-10 w-10" /></div>
          <h2 className="mt-5 text-2xl font-black">{title}</h2>
          <p className="mx-auto mt-3 max-w-xl text-sm leading-6 text-slate-300">{description}</p>
          <div className="mt-6 grid gap-3 sm:grid-cols-2">{actions.map((action) => <Button key={action.label} onClick={action.onClick} className="rounded-2xl bg-cyan-300 text-[#07111f] hover:bg-cyan-200">{action.label}</Button>)}</div>
        </div>
      </div>
    </div>
  );
}

function HeaderBack({ title, subtitle, onBack, action }: { title: string; subtitle: string; onBack: () => void; action?: ReactNode }) {
  return (
    <div className="crewcheck-header-shell flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <button onClick={onBack} className="crewcheck-header-back flex items-center gap-3 text-left"><div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10 text-cyan-100"><ArrowLeft className="h-5 w-5" /></div><div><h1 className="text-xl font-black">{title}</h1><p className="text-xs uppercase tracking-[0.22em] text-cyan-100/60">{subtitle}</p></div></button>
      {action && <div className="sm:ml-auto">{action}</div>}
    </div>
  );
}

function StateCard({ icon: Icon, title, text, spin }: { icon: LucideIcon; title: string; text: string; spin?: boolean }) {
  return <div className="crewcheck-light-card mt-6 rounded-3xl border border-white/10 bg-white/[0.05] p-6 text-center text-slate-300"><Icon className={`mx-auto mb-4 h-8 w-8 text-cyan-200 ${spin ? 'animate-spin' : ''}`} /><h3 className="text-lg font-black text-white">{title}</h3><p className="mt-2 text-sm">{text}</p></div>;
}

function MenuAction({ icon: Icon, title, text, onClick }: { icon: LucideIcon; title: string; text: string; onClick: () => void }) {
  return <button onClick={onClick} className="crewcheck-light-card flex items-center gap-4 rounded-3xl border border-white/10 bg-white/[0.05] p-5 text-left transition hover:bg-white/[0.09]"><div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-300/15 text-cyan-200"><Icon className="h-6 w-6" /></div><div><h3 className="font-black">{title}</h3><p className="text-sm text-slate-400">{text}</p></div><ChevronRight className="ml-auto h-5 w-5 text-slate-500" /></button>;
}

function monthLabel(month: number | null, year: number | null): string {
  const names = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
  if (!month || !year) return 'Período salvo';
  return `${names[month - 1] || String(month).padStart(2, '0')}/${year}`;
}

function Kpi({ icon: Icon, value, label }: { icon: LucideIcon; value: string; label: string }) {
  return <div className="crewcheck-light-card rounded-2xl border border-white/10 bg-white/[0.06] p-4 backdrop-blur-xl"><Icon className="mb-3 h-5 w-5 text-cyan-200" /><p className="text-xl font-black">{value}</p><p className="mt-1 text-xs leading-4 text-slate-300">{label}</p></div>;
}

function TrustLine({ icon: Icon, text }: { icon: LucideIcon; text: string }) {
  return <div className="flex items-start gap-3"><Icon className="mt-0.5 h-4 w-4 shrink-0 text-cyan-300" /><span>{text}</span></div>;
}
