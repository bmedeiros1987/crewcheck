# CrewCheck v10.8.50 — Saída Inteligente Premium Transit Live

## Objetivo
Deixar a Saída Inteligente mais premium e confiável, com comparação real entre carro e transporte público, horários de ônibus/metrô quando disponíveis e escolha automática da opção mais rápida.

## Melhorias
- Modo Auto passa a escolher a rota mais rápida por duração total, sem preferência fixa por carro.
- Transporte público consulta múltiplas estratégias no Google Routes: menos baldeações e menos caminhada.
- Adiciona fallback Google Directions Transit para ampliar cobertura quando Routes não retornar detalhes.
- Exibe quadro de horários de ônibus/metrô com linha, estação/ponto, horário de embarque e chegada quando a API retornar esses dados.
- Mostra aviso transparente: tempo real quando disponível pela operadora; caso contrário, usa grade prevista.
- UI premium no Cockpit e na tela Saída Inteligente.
- Cache reduzido para 60s por padrão para dados de transporte/rota.
- Android atualizado para versionCode 10850 e versionName 10.8.50.

## Observação técnica
A precisão de ônibus/metrô em tempo real depende da disponibilidade de dados Google Transit/GTFS Realtime da região. Quando a operadora não oferece dados ao Google, o CrewCheck mantém estimativa/grade prevista e fallback conservador.
