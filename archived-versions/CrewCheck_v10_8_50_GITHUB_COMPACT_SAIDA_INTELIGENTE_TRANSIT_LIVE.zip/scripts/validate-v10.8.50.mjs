import fs from 'node:fs';

const mustContain = [
  ['package.json', '"version": "10.8.50"'],
  ['server.mjs', 'computePremiumTransitCandidates'],
  ['server.mjs', 'transitBoard'],
  ['server.mjs', 'recommendedReason'],
  ['server.mjs', 'LESS_WALKING'],
  ['server.mjs', 'FEWER_TRANSFERS'],
  ['client/src/components/premium/Dashboard.tsx', 'ônibus/metrô sincronizado'],
  ['client/src/components/premium/Dashboard.tsx', 'Mais rápida'],
  ['client/src/pages/Home.tsx', 'horários ônibus/metrô'],
  ['client/src/pages/Home.tsx', 'Auto: sempre a forma mais rápida'],
  ['android-wrapper/app/build.gradle', 'versionCode 10850'],
  ['android-wrapper/app/build.gradle', "versionName '10.8.50'"],
];

let ok = true;
for (const [file, token] of mustContain) {
  if (!fs.existsSync(file)) {
    console.error(`Arquivo ausente: ${file}`);
    ok = false;
    continue;
  }
  const text = fs.readFileSync(file, 'utf8');
  if (!text.includes(token)) {
    console.error(`Token ausente em ${file}: ${token}`);
    ok = false;
  }
}

if (!ok) process.exit(1);
console.log('CrewCheck v10.8.50 validado: Saída Inteligente Premium com Google Routes/Transit, horários ônibus/metrô, escolha automática da rota mais rápida e UI reliable OK.');
