# CrewCheck v11.0.95 — Meteorologia Premium + Premium Unlimited

## Destaques
- Nova aba Meteorologia para pilotos com METAR e TAF via Aviation Weather Center.
- Pesquisa por ICAO/IATA, favoritos locais e glossário METAR/TAF para download.
- Card de meteorologia na próxima programação, consultando origem e destino quando houver voo.
- Integração com Telegram Concierge para perguntas de METAR/TAF por texto ou áudio, com resposta traduzida e estilo ATIS no áudio.
- Usuários Premium Unlimited/lifetime pré-configurados por e-mail e nota de agradecimento no Perfil.
- Mantém produção Android premium com R8/ProGuard, shrinkResources e mapping.

## Versão Android
- versionName: 11.0.95
- versionCode: 11095

## Fontes externas
- Aviation Weather Center Data API: /api/data/metar e /api/data/taf.
- O backend faz proxy para evitar CORS e controlar cache/frequência.

## Variáveis opcionais
```env
AVIATIONWEATHER_USER_AGENT=CrewCheck/11.0.95 contato@crewcheck.app
AVIATIONWEATHER_TIMEOUT_MS=9500
AVIATIONWEATHER_CACHE_TTL_MS=300000
CREWCHECK_LIFETIME_EMAILS=bmedeiros1987@gmail.com,...
```
